with open('balloon_trivia.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if 'id="reto-area"' in line:
        print('reto-area HTML at line:', i+1)
    if 'function retoResult' in line:
        print('retoResult at line:', i+1)

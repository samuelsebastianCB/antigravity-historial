with open('balloon_trivia.html', 'r', encoding='utf-8') as f:
    text = f.read()

lines = text.splitlines()
for i, line in enumerate(lines):
    if 'id="teams-styles"' in line:
        print('teams-styles at line:', i+1)
    if 'LEADERBOARD PANEL' in line:
        print('lb-panel at line:', i+1)
    if 'Repeat picker modal' in line:
        print('repeat-modal at line:', i+1)
    if 'function openRepeatPicker' in line:
        print('openRepeatPicker at line:', i+1)

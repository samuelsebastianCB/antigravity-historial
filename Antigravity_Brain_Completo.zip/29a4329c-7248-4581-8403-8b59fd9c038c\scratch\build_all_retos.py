import json, re

with open('balloon_trivia.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Update questions 31-40 in balloon_trivia.html
old_retos_block = '''  // ── Retos ─────────────────────────────────────────────────────
  { q:"¡Reto Miller! Escucha la indicación del organizador.",
    type:"reto", points:300, instruction:"Di una sola vez en voz alta:\\n📢 Perro – Casa – Sol – Mesa – Flor\\nEl participante debe repetirlas en el mismo orden.", answer:"Perro – Casa – Sol – Mesa – Flor (en orden)" },
  { q:"¡Reto Miller! Escucha la indicación del organizador.",
    type:"reto", points:400, instruction:"Di una sola vez en voz alta:\\n📢 4 – 8 – 2 – 9 – 1 – 6 – 3\\nEl participante debe repetirlos en el mismo orden.", answer:"4 – 8 – 2 – 9 – 1 – 6 – 3 (en orden)" },
  { q:"¡Reto Miller Avanzado! Escucha la indicación del organizador.",
    type:"reto", points:500, instruction:"Di una sola vez en voz alta:\\n📢 A – F – M – P – R – T – B – L – S\\nEl participante debe repetirlas en el mismo orden (9 letras).", answer:"A – F – M – P – R – T – B – L – S (en orden)" },
  { q:"¡Reto de Agrupación! Sigue la indicación del organizador.",
    type:"reto", points:400, instruction:"Muestra o di la siguiente serie:\\n📢 5 5 2 0 2 6 1 9 5 6\\nPide al participante que proponga cómo agruparla para recordarla mejor.\\nEjemplo válido: 55 – 2026 – 1956", answer:"Cualquier agrupación lógica. Ej.: 55 – 2026 – 1956" },
  { q:"¡Reto Miller! Observa o escucha las opciones del organizador.",
    type:"reto", points:300, instruction:"Pregunta al participante cuál es más fácil de recordar:\\n\\nOpción A: 5 5 1 2 3 4 5 6 7 8\\nOpción B: 55 – 1234 – 5678\\n\\nRespuesta: la Opción B, porque está agrupada (chunking).", answer:"Opción B: 55 – 1234 – 5678 (agrupada)" },
  { q:"¡Detecta el Cambio! Escucha la indicación del organizador.",
    type:"reto", points:400, instruction:"Di lentamente la primera lista:\\n📢 perro, manzana, balón, carro, estrella\\n\\nLuego di la segunda lista:\\n📢 perro, manzana, casa, carro, estrella\\n\\nPregunta: ¿Qué palabra cambió?\\nRespuesta: balón por casa.", answer:"Cambió 'balón' por 'casa'" },
  { q:"¡Reto de Orden! Escucha la indicación del organizador.",
    type:"reto", points:400, instruction:"Di una sola vez en voz alta:\\n📢 Rojo – Verde – Azul – Amarillo – Rosa – Negro – Blanco\\nEl participante debe repetir los 7 colores en el mismo orden.", answer:"Rojo – Verde – Azul – Amarillo – Rosa – Negro – Blanco (en orden)" },
  { q:"¡Reto de Agrupación! Sigue la indicación del organizador.",
    type:"reto", points:400, instruction:"Da esta serie larga de letras:\\n📢 B – M – Z – A – F – Q – L – R – W – D – N – K\\n\\nPregunta: ¿Qué estrategia usarías para recordarlas?\\nRespuesta correcta: Agruparlas en bloques (chunks).\\nEj.: BMZ – AFQ – LRW – DNK", answer:"Agruparlas en bloques/chunks. Ej.: BMZ – AFQ – LRW – DNK" },
  { q:"¡Reto de Aplicación! Escucha la situación del organizador.",
    type:"reto", points:500, instruction:"Plantea esta situación:\\n«Un menú tiene 20 opciones mezcladas sin orden. ¿Cómo aplicarías la Ley de Miller para mejorarlo?»\\n\\nRespuesta válida: Agrupar las opciones en categorías o crear submenús.", answer:"Agrupar en categorías o submenús (aplicar chunking)" },
  { q:"🌟 ¡Globo Dorado! Escucha tu reto especial.",
    type:"reto", points:500, instruction:"Pide al participante que explique con sus propias palabras la Ley de Miller.\\n\\n✅ Debe mencionar al menos DOS de estos puntos:\\n• La memoria de trabajo es limitada.\\n• El número mágico es 7 (± 2).\\n• El chunking / agrupación ayuda a recordar más.", answer:"Memoria limitada + número mágico 7 ± 2 + chunking/agrupación" },'''

new_retos_block = '''  // ── Retos Adaptados (Simón Dice y Respuesta Abierta) ─────────
  { q:"¡Reto Simón Dice! Toca los botones en el mismo orden que escuchas.",
    type:"reto", points:300, isSimon:true,
    instruction:"Di en voz alta: Perro – Casa – Sol – Mesa – Flor. El participante debe tocar los botones en ese orden exacto.",
    sequence:[
      {id:"perro", label:"Perro", icon:"🐶"},
      {id:"casa", label:"Casa", icon:"🏠"},
      {id:"sol", label:"Sol", icon:"☀️"},
      {id:"mesa", label:"Mesa", icon:"🪑"},
      {id:"flor", label:"Flor", icon:"🌸"}
    ],
    answer:"🐶 Perro ➔ 🏠 Casa ➔ ☀️ Sol ➔ 🪑 Mesa ➔ 🌸 Flor" },

  { q:"¡Reto Simón Dice de 7 Números! Memoriza y reproduce la secuencia.",
    type:"reto", points:400, isSimon:true,
    instruction:"Di en voz alta: 4 – 8 – 2 – 9 – 1 – 6 – 3. El participante debe presionar los números en ese orden.",
    sequence:[
      {id:"4", label:"4", icon:"4️⃣"},
      {id:"8", label:"8", icon:"8️⃣"},
      {id:"2", label:"2", icon:"2️⃣"},
      {id:"9", label:"9", icon:"9️⃣"},
      {id:"1", label:"1", icon:"1️⃣"},
      {id:"6", label:"6", icon:"6️⃣"},
      {id:"3", label:"3", icon:"3️⃣"}
    ],
    answer:"4️⃣ ➔ 8️⃣ ➔ 2️⃣ ➔ 9️⃣ ➔ 1️⃣ ➔ 6️⃣ ➔ 3️⃣" },

  { q:"¡Reto Simón Dice Extremo! Límite superior de Miller (9 letras).",
    type:"reto", points:500, isSimon:true,
    instruction:"Di en voz alta: A – F – M – P – R – T – B – L – S. Selecciona las 9 letras en el orden correcto.",
    sequence:[
      {id:"A", label:"A", icon:"🅰️"},
      {id:"F", label:"F", icon:"🇫"},
      {id:"M", label:"M", icon:"Ⓜ️"},
      {id:"P", label:"P", icon:"🅿️"},
      {id:"R", label:"R", icon:"🇷"},
      {id:"T", label:"T", icon:"🇹"},
      {id:"B", label:"B", icon:"🅱️"},
      {id:"L", label:"L", icon:"🇱"},
      {id:"S", label:"S", icon:"🇸"}
    ],
    answer:"A ➔ F ➔ M ➔ P ➔ R ➔ T ➔ B ➔ L ➔ S (9 letras)" },

  { q:"¡Reto de Chunking! Ordena los bloques lógicos de la serie 5520261956.",
    type:"reto", points:400, isSimon:true,
    instruction:"Agrupa la serie en bloques con sentido temporal/telefónico para memorizarla mejor.",
    sequence:[
      {id:"55", label:"55", icon:"📞"},
      {id:"2026", label:"2026 (Año actual)", icon:"📅"},
      {id:"1956", label:"1956 (Año de Miller)", icon:"🏛️"}
    ],
    answer:"📞 55 ➔ 📅 2026 ➔ 🏛️ 1956" },

  { q:"¡Reto de Percepción! Selecciona la serie mejor optimizada por Chunking.",
    type:"reto", points:300, isSimon:true,
    instruction:"Elige cuál presentación facilita el procesamiento inmediato según la Ley de Miller.",
    sequence:[
      {id:"B", label:"Opción B: 55 – 1234 – 5678 (Bloques estructurados)", icon:"🧩"}
    ],
    options:[
      {id:"A", label:"Opción A: 5 5 1 2 3 4 5 6 7 8 (Sin agrupar)", icon:"🎲"},
      {id:"B", label:"Opción B: 55 – 1234 – 5678 (Bloques estructurados)", icon:"🧩"}
    ],
    answer:"🧩 Opción B: 55 – 1234 – 5678 (Agrupada en chunks)" },

  { q:"¡Detecta el Cambio! Compara ambas listas y selecciona la palabra modificada.",
    type:"reto", points:400, isSimon:true,
    instruction:"Lista 1: perro, manzana, balón, carro, estrella.\\nLista 2: perro, manzana, casa, carro, estrella.\\n¿Qué elemento cambió?",
    sequence:[
      {id:"balon_casa", label:"Balón cambió por Casa", icon:"⚽➔🏠"}
    ],
    options:[
      {id:"perro_gato", label:"Perro cambió por Gato", icon:"🐶➔🐱"},
      {id:"balon_casa", label:"Balón cambió por Casa", icon:"⚽➔🏠"},
      {id:"manzana_platano", label:"Manzana cambió por Plátano", icon:"🍎➔🍌"},
      {id:"carro_bici", label:"Carro cambió por Bici", icon:"🚗➔🚲"}
    ],
    answer:"⚽➔🏠 Balón fue reemplazado por Casa" },

  { q:"¡Reto Simón Dice de 7 Colores! Reproduce la secuencia en orden.",
    type:"reto", points:400, isSimon:true,
    instruction:"Di en voz alta: Rojo – Verde – Azul – Amarillo – Rosa – Negro – Blanco. Toca los 7 colores en orden.",
    sequence:[
      {id:"rojo", label:"Rojo", icon:"🔴"},
      {id:"verde", label:"Verde", icon:"🟢"},
      {id:"azul", label:"Azul", icon:"🔵"},
      {id:"amarillo", label:"Amarillo", icon:"🟡"},
      {id:"rosa", label:"Rosa", icon:"🌸"},
      {id:"negro", label:"Negro", icon:"⚫"},
      {id:"blanco", label:"Blanco", icon:"⚪"}
    ],
    answer:"🔴 Rojo ➔ 🟢 Verde ➔ 🔵 Azul ➔ 🟡 Amarillo ➔ 🌸 Rosa ➔ ⚫ Negro ➔ ⚪ Blanco" },

  { q:"¡Reto Chunks de Letras! Agrupa las 12 letras en bloques de 3.",
    type:"reto", points:400, isSimon:true,
    instruction:"Serie original: B M Z A F Q L R W D N K. Toca los 4 bloques ordenados.",
    sequence:[
      {id:"BMZ", label:"BMZ", icon:"🔤"},
      {id:"AFQ", label:"AFQ", icon:"🔤"},
      {id:"LRW", label:"LRW", icon:"🔤"},
      {id:"DNK", label:"DNK", icon:"🔤"}
    ],
    answer:"🔤 BMZ ➔ 🔤 AFQ ➔ 🔤 LRW ➔ 🔤 DNK" },

  { q:"¡Reto de Aplicación UX! Ordena la mejor estrategia para un menú de 20 opciones.",
    type:"reto", points:500, isSimon:true,
    instruction:"Aplica la Ley de Miller en diseño web ordenando los 3 principios clave.",
    sequence:[
      {id:"categorizar", label:"1. Agrupar en 3 a 5 categorías", icon:"📂"},
      {id:"submenus", label:"2. Desplegar en submenús contextuales", icon:"📑"},
      {id:"limitar", label:"3. Mantener 7 ± 2 opciones visibles", icon:"✨"}
    ],
    answer:"📂 Categorías ➔ 📑 Submenús ➔ ✨ 7 ± 2 elementos por nivel" },

  { q:"🌟 ¡Globo Dorado Final! Explica con tus palabras la Ley de Miller.",
    type:"reto", points:500, isOpenText:true,
    instruction:"Pregunta abierta: Escribe tu explicación sobre la Ley de Miller (memoria de trabajo, 7 ± 2, chunking). ¡No tiene calificación automática, solo responde y envía!",
    answer:"🌟 Reto final completado: Explicación abierta registrada con éxito." },'''

if old_retos_block in html:
    html = html.replace(old_retos_block, new_retos_block)
    print("Replaced questions array with Simon Says sequence data and Question 40 open text.")
else:
    print("WARNING: Could not find exact old_retos_block in html. Searching for substring...")
    # Try finding by questions[30]
    pos = html.find('// ── Retos ──')
    if pos != -1:
        end_pos = html.find('];', pos)
        html = html[:pos] + new_retos_block + '\n' + html[end_pos:]
        print("Replaced retos section via index finding.")

# 2. Update reto-area HTML to include Simon Says interactive sequence area and Q40 open text area
old_reto_area = '''  <div id="reto-area">
    <!-- Header row: label + manual toggle button -->
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;flex-wrap:wrap;gap:8px;">
      <div style="font-size:0.75rem;font-weight:800;letter-spacing:1.5px;color:#fbbf24;text-transform:uppercase;">📋 Instrucción para el Organizador</div>
      <button id="btn-toggle-instruccion" onclick="toggleRetoInstruction()"
        style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.25);border-radius:50px;padding:6px 16px;font-size:0.78rem;font-weight:800;color:#fff;cursor:pointer;font-family:inherit;transition:all 0.2s;">
        👁 Ver / Ocultar
      </button>
    </div>

    <!-- Instruction wrapper — gets blurred after 5s -->
    <div id="reto-instruction-wrap" style="position:relative;">
      <div class="reto-instruction" id="reto-instruction-text"></div>
      <!-- Reveal overlay (shown when instruction is hidden) -->
      <div id="reto-reveal-overlay" style="display:none;position:absolute;inset:0;border-radius:12px;background:rgba(0,0,0,0.5);backdrop-filter:blur(2px);align-items:center;justify-content:center;flex-direction:column;gap:8px;">
        <span style="font-size:0.85rem;color:rgba(255,255,255,0.7);">Instrucción oculta</span>
        <button onclick="showRetoInstruction()" style="background:linear-gradient(135deg,#7c3aed,#4f46e5);border:none;border-radius:50px;padding:10px 24px;font-size:0.9rem;font-weight:800;color:#fff;cursor:pointer;font-family:inherit;">
          👁 Ver instrucción
        </button>
      </div>
    </div>

    <div style="text-align:center;margin-top:14px;">
      <p style="color:rgba(255,255,255,0.55);font-size:0.88rem;margin-bottom:12px;">¿El participante respondió correctamente?</p>
      <button class="btn-reto-correct" onclick="retoResult(true)">✅ Sí, correcto</button>
      <button class="btn-reto-wrong"   onclick="retoResult(false)">❌ No, incorrecto</button>
    </div>
  </div>'''

new_reto_area = '''  <div id="reto-area">
    <!-- Header row: label + manual toggle button -->
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;flex-wrap:wrap;gap:8px;">
      <div style="font-size:0.75rem;font-weight:800;letter-spacing:1.5px;color:#fbbf24;text-transform:uppercase;">📋 Guía del Organizador</div>
      <button id="btn-toggle-instruccion" onclick="toggleRetoInstruction()"
        style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.25);border-radius:50px;padding:6px 16px;font-size:0.78rem;font-weight:800;color:#fff;cursor:pointer;font-family:inherit;transition:all 0.2s;">
        👁 Ver / Ocultar
      </button>
    </div>

    <!-- Instruction wrapper -->
    <div id="reto-instruction-wrap" style="position:relative;margin-bottom:16px;">
      <div class="reto-instruction" id="reto-instruction-text"></div>
      <div id="reto-reveal-overlay" style="display:none;position:absolute;inset:0;border-radius:12px;background:rgba(0,0,0,0.5);backdrop-filter:blur(2px);align-items:center;justify-content:center;flex-direction:column;gap:8px;">
        <span style="font-size:0.85rem;color:rgba(255,255,255,0.7);">Instrucción oculta</span>
        <button onclick="showRetoInstruction()" style="background:linear-gradient(135deg,#7c3aed,#4f46e5);border:none;border-radius:50px;padding:10px 24px;font-size:0.9rem;font-weight:800;color:#fff;cursor:pointer;font-family:inherit;">
          👁 Ver instrucción
        </button>
      </div>
    </div>

    <!-- ══ SIMON SAYS SEQUENCE INTERACTIVE AREA (Q31-Q39) ══ -->
    <div id="reto-simon-container" style="display:none;background:rgba(15,23,42,0.9);border:1.5px solid rgba(168,85,247,0.4);border-radius:24px;padding:20px;margin-bottom:16px;box-shadow:0 12px 30px rgba(0,0,0,0.5);">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
        <div style="font-size:0.85rem;font-weight:900;color:#c084fc;letter-spacing:1px;text-transform:uppercase;display:flex;align-items:center;gap:6px;">
          <span>🎮</span> RETO SIMÓN DICE: ELIGE EL ORDEN
        </div>
        <button onclick="resetSimonSequence()" style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.2);border-radius:50px;padding:4px 12px;font-size:0.75rem;color:#f8fafc;cursor:pointer;">
          ↺ Reiniciar
        </button>
      </div>

      <div style="font-size:0.8rem;color:#94a3b8;margin-bottom:10px;">
        Toca los botones en el orden exacto para completar la secuencia:
      </div>

      <!-- Current selected slots -->
      <div id="simon-selected-slots" style="display:flex;gap:8px;flex-wrap:wrap;min-height:48px;padding:10px;background:rgba(0,0,0,0.4);border-radius:16px;border:1px dashed rgba(255,255,255,0.2);margin-bottom:16px;align-items:center;">
        <span style="color:#64748b;font-size:0.8rem;font-style:italic;" id="simon-empty-hint">Secuencia vacía... Toca los botones abajo en orden.</span>
      </div>

      <!-- Buttons pool with icons -->
      <div id="simon-buttons-pool" style="display:grid;grid-template-columns:repeat(auto-fill, minmax(130px, 1fr));gap:10px;margin-bottom:16px;"></div>

      <div style="display:flex;gap:10px;justify-content:flex-end;">
        <button onclick="checkSimonSequence()" id="btn-check-simon"
          style="background:linear-gradient(135deg,#22c55e,#16a34a);border:none;border-radius:50px;padding:10px 24px;font-size:0.9rem;font-weight:900;color:#fff;cursor:pointer;box-shadow:0 4px 14px rgba(34,197,94,0.35);">
          ✨ Comprobar Orden
        </button>
      </div>
    </div>

    <!-- ══ QUESTION 40: OPEN TEXT RESPONSE AREA ══ -->
    <div id="reto-open-container" style="display:none;background:linear-gradient(135deg,rgba(30,27,75,0.95),rgba(15,23,42,0.98));border:2px solid #f59e0b;border-radius:24px;padding:24px;margin-bottom:16px;box-shadow:0 12px 35px rgba(245,158,11,0.25);">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
        <span style="font-size:1.8rem;">🌟</span>
        <div>
          <div style="font-size:1rem;font-weight:900;color:#fcd34d;letter-spacing:1px;text-transform:uppercase;">
            GLOBO DORADO FINAL — RESPUESTA ABIERTA
          </div>
          <div style="font-size:0.75rem;color:#cbd5e1;">
            Esta respuesta no tiene calificación automática. ¡Escribe la explicación y pulsa enviar!
          </div>
        </div>
      </div>

      <div style="margin-bottom:12px;">
        <label style="display:block;font-size:0.8rem;font-weight:bold;color:#fde68a;margin-bottom:6px;">
          Escribe tu respuesta o explicación sobre la Ley de Miller:
        </label>
        <textarea id="q40-host-textarea" rows="4" placeholder="Ej. La Ley de Miller explica que la memoria de trabajo humana solo puede retener entre 5 y 9 elementos (7 ± 2) de manera inmediata. Para recordar más, utilizamos el chunking o agrupación en bloques..."
          style="width:100%;box-sizing:border-box;background:rgba(0,0,0,0.5);border:1.5px solid rgba(245,158,11,0.4);border-radius:16px;padding:12px 14px;color:#fff;font-family:inherit;font-size:0.95rem;line-height:1.5;outline:none;resize:vertical;"></textarea>
      </div>

      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
        <span style="font-size:0.75rem;color:#94a3b8;">
          🏆 Otorga los 500 puntos finales de participación.
        </span>
        <button onclick="submitQ40Host()" id="btn-submit-q40-host"
          style="background:linear-gradient(135deg,#f59e0b,#d97706);border:none;border-radius:50px;padding:12px 28px;font-size:0.95rem;font-weight:900;color:#000;cursor:pointer;box-shadow:0 6px 20px rgba(245,158,11,0.4);">
          📨 Enviar y Concluir Reto Final
        </button>
      </div>

      <div id="q40-submitted-card" style="display:none;margin-top:16px;padding:14px;background:rgba(245,158,11,0.15);border:1px solid #f59e0b;border-radius:16px;">
        <div style="font-size:0.8rem;font-weight:bold;color:#fde68a;margin-bottom:4px;">✅ RESPUESTA REGISTRADA CON ÉXITO:</div>
        <p id="q40-submitted-text" style="font-size:0.95rem;color:#fff;margin:0;font-style:italic;line-height:1.5;"></p>
      </div>
    </div>

    <!-- Presenter manual override buttons -->
    <div style="text-align:center;margin-top:14px;">
      <p style="color:rgba(255,255,255,0.45);font-size:0.75rem;margin-bottom:8px;">Control manual del presentador:</p>
      <button class="btn-reto-correct" onclick="retoResult(true)">✅ Validar como Correcto</button>
      <button class="btn-reto-wrong"   onclick="retoResult(false)">❌ Marcar Incorrecto</button>
    </div>
  </div>'''

if old_reto_area in html:
    html = html.replace(old_reto_area, new_reto_area)
    print("Replaced reto-area HTML with Simon Says interactive sequence and Q40 open text.")
else:
    print("WARNING: Could not find exact old_reto_area. Replacing via regex/tags.")
    html = re.sub(r'<div id="reto-area">.*?</div>\s*</div>\s*<div id="answer-reveal">', new_reto_area + '\n\n  <div id="answer-reveal">', html, flags=re.DOTALL)

with open('balloon_trivia.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("Updated balloon_trivia.html successfully.")

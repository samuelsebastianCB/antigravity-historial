with open('join.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Replace reto section in join.html with Simon and Open text UI
old_reto_section = '''        <!-- Reto State -->
        <div id="q-reto-view" class="hidden text-center py-6 px-4 bg-amber-950/30 border border-amber-800/40 rounded-3xl my-auto">
          <span class="text-4xl mb-2 inline-block">⭐</span>
          <h4 class="text-base font-black text-amber-300 mb-1">¡Reto en Curso!</h4>
          <p id="q-reto-inst" class="text-xs text-amber-200/80 leading-relaxed mb-4">
            Escucha la indicación del organizador en el salón.
          </p>
          <div class="text-[11px] text-slate-400">El profesor registrará si cumples el reto en la pantalla principal.</div>
        </div>'''

new_reto_section = '''        <!-- ══ SIMON SAYS SEQUENCE RETO (Q31-Q39) ══ -->
        <div id="q-simon-view" class="hidden flex flex-col gap-3 my-auto">
          <div class="bg-purple-950/40 border border-purple-800/50 rounded-2xl p-4">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-black uppercase tracking-wider text-purple-300 flex items-center gap-1">
                <span>🎮</span> Simón Dice: Toca en Orden
              </span>
              <button onclick="resetMobileSimon()" class="text-xs text-purple-400 hover:text-purple-200 font-bold">
                ↺ Reiniciar
              </button>
            </div>
            <div id="mobile-simon-slots" class="min-h-[42px] p-2 bg-slate-950/60 rounded-xl border border-slate-800 flex flex-wrap gap-1.5 items-center">
              <span id="mobile-simon-empty" class="text-xs text-slate-500 italic">Toca los botones abajo en orden...</span>
            </div>
          </div>

          <div id="mobile-simon-buttons" class="grid grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1"></div>

          <button onclick="checkMobileSimon()"
            class="w-full bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-black py-3 rounded-2xl text-sm shadow-lg shadow-emerald-900/30 transition">
            ✨ Comprobar Secuencia
          </button>
        </div>

        <!-- ══ QUESTION 40: OPEN TEXT RESPONSE ══ -->
        <div id="q-open-view" class="hidden flex flex-col gap-3 my-auto">
          <div class="bg-gradient-to-b from-amber-950/50 to-slate-900 border border-amber-600/50 rounded-3xl p-5 shadow-xl">
            <div class="flex items-center gap-2 mb-2">
              <span class="text-2xl">🌟</span>
              <div>
                <h4 class="text-base font-black text-amber-300">Globo Dorado Final</h4>
                <p class="text-[11px] text-amber-200/70">Pregunta Abierta · Sin calificación automática</p>
              </div>
            </div>
            <p class="text-xs text-slate-300 mb-3 leading-relaxed">
              Explica con tus palabras qué es la Ley de Miller (memoria de trabajo, 7 ± 2 y chunking). ¡Escribe y envía tu respuesta al salón!
            </p>
            <textarea id="mobile-q40-input" rows="4" placeholder="Escribe aquí tu explicación sobre la Ley de Miller..."
              class="w-full bg-slate-950/80 border border-amber-500/40 rounded-2xl p-3 text-white text-sm focus:outline-none focus:border-amber-400 transition mb-3"></textarea>

            <button onclick="submitMobileQ40()"
              class="w-full bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-black py-3.5 rounded-2xl text-base shadow-lg shadow-amber-500/30 transition">
              📨 Enviar Respuesta al Proyector
            </button>
          </div>
        </div>

        <!-- Generic Reto Fallback -->
        <div id="q-reto-view" class="hidden text-center py-6 px-4 bg-amber-950/30 border border-amber-800/40 rounded-3xl my-auto">
          <span class="text-4xl mb-2 inline-block">⭐</span>
          <h4 class="text-base font-black text-amber-300 mb-1">¡Reto en Curso!</h4>
          <p id="q-reto-inst" class="text-xs text-amber-200/80 leading-relaxed mb-4">
            Escucha la indicación del organizador en el salón.
          </p>
          <div class="text-[11px] text-slate-400">El profesor registrará si cumples el reto en la pantalla principal.</div>
        </div>'''

html = html.replace(old_reto_section, new_reto_section)

# Update displayQuestion in join.html
old_display_q = '''      if (q.type === 'mc') {
        mcBox.classList.remove('hidden');
        const letters = ['A', 'B', 'C', 'D'];
        q.options.forEach((opt, idx) => {
          const btn = document.createElement('button');
          btn.className = 'opt-btn';
          btn.innerHTML = `<span class="opt-badge">${letters[idx]}</span><span class="flex-1">${opt}</span>`;
          btn.onclick = () => submitAnswer(idx, false, btn, q.correct);
          mcBox.appendChild(btn);
        });
      } else if (q.type === 'vf') {
        vfBox.classList.remove('hidden');
      } else if (q.type === 'reto') {
        retoBox.classList.remove('hidden');
        document.getElementById('q-reto-inst').textContent = q.instruction || 'Escucha al profesor.';
      }'''

new_display_q = '''      const simonBox = document.getElementById('q-simon-view');
      const openBox = document.getElementById('q-open-view');
      simonBox.classList.add('hidden');
      openBox.classList.add('hidden');

      if (q.type === 'mc') {
        mcBox.classList.remove('hidden');
        const letters = ['A', 'B', 'C', 'D'];
        q.options.forEach((opt, idx) => {
          const btn = document.createElement('button');
          btn.className = 'opt-btn';
          btn.innerHTML = `<span class="opt-badge">${letters[idx]}</span><span class="flex-1">${opt}</span>`;
          btn.onclick = () => submitAnswer(idx, false, btn, q.correct);
          mcBox.appendChild(btn);
        });
      } else if (q.type === 'vf') {
        vfBox.classList.remove('hidden');
      } else if (q.isOpenText || num === 40) {
        openBox.classList.remove('hidden');
        const inp = document.getElementById('mobile-q40-input');
        if (inp) inp.value = '';
      } else if (q.isSimon || q.sequence) {
        simonBox.classList.remove('hidden');
        initMobileSimon(q);
      } else if (q.type === 'reto') {
        retoBox.classList.remove('hidden');
        document.getElementById('q-reto-inst').textContent = q.instruction || 'Escucha al profesor.';
      }'''

html = html.replace(old_display_q, new_display_q)

# Add Mobile Simon and Q40 handler functions before </script>
mobile_simon_js = '''
    // ── MOBILE SIMON SAYS & Q40 LOGIC ──
    let mobileSimonTarget = [];
    let mobileSimonSequence = [];
    let mobileSimonPool = [];

    function initMobileSimon(q) {
      mobileSimonSequence = [];
      mobileSimonTarget = (q.sequence || []).map(i => i.id);

      let items = q.options ? [...q.options] : [...(q.sequence || [])];
      mobileSimonPool = items.sort(() => Math.random() - 0.5);

      renderMobileSimonPool();
      renderMobileSimonSlots();
    }

    function renderMobileSimonPool() {
      const box = document.getElementById('mobile-simon-buttons');
      if (!box) return;
      box.innerHTML = '';

      mobileSimonPool.forEach(item => {
        const isSel = mobileSimonSequence.some(s => s.id === item.id);
        const btn = document.createElement('button');
        btn.disabled = isSel;
        btn.className = `p-3 rounded-xl border text-left flex items-center gap-2 text-xs font-bold transition ${
          isSel ? 'bg-slate-900/40 border-slate-800 text-slate-600' : 'bg-slate-800 border-purple-500/40 text-white active:scale-95'
        }`;
        btn.innerHTML = `<span class="text-lg">${item.icon}</span><span class="truncate">${item.label}</span>`;
        btn.onclick = () => {
          if (isSel) return;
          mobileSimonSequence.push(item);
          if (navigator.vibrate) navigator.vibrate(25);
          renderMobileSimonPool();
          renderMobileSimonSlots();
          if (mobileSimonSequence.length === mobileSimonTarget.length) {
            setTimeout(checkMobileSimon, 300);
          }
        };
        box.appendChild(btn);
      });
    }

    function renderMobileSimonSlots() {
      const box = document.getElementById('mobile-simon-slots');
      if (!box) return;
      box.innerHTML = '';

      if (mobileSimonSequence.length === 0) {
        box.innerHTML = '<span class="text-xs text-slate-500 italic">Toca los botones en orden...</span>';
        return;
      }

      mobileSimonSequence.forEach((item, idx) => {
        const badge = document.createElement('div');
        badge.className = 'px-2 py-1 rounded-full bg-purple-500/20 border border-purple-400 text-purple-200 text-xs font-bold flex items-center gap-1';
        badge.innerHTML = `<span class="opacity-60 text-[10px]">${idx+1}.</span><span>${item.icon}</span>`;
        box.appendChild(badge);
      });
    }

    function resetMobileSimon() {
      mobileSimonSequence = [];
      renderMobileSimonPool();
      renderMobileSimonSlots();
    }

    function checkMobileSimon() {
      if (mobileSimonSequence.length === 0) return;

      const userIds = mobileSimonSequence.map(i => i.id);
      const isMatch = (userIds.length === mobileSimonTarget.length) &&
                      userIds.every((v, idx) => v === mobileSimonTarget[idx]);

      const feed = document.getElementById('q-feedback');
      feed.classList.remove('hidden');

      if (isMatch) {
        if (window.confetti) window.confetti({ particleCount: 70, spread: 60 });
        if (navigator.vibrate) navigator.vibrate([80, 40, 120]);
        feed.className = 'py-3 rounded-2xl mt-3 font-black text-sm bg-emerald-950/70 border border-emerald-600 text-emerald-300 text-center';
        feed.textContent = `🎉 ¡SECUENCIA CORRECTA! +${currentActiveQ.points || 400} PTS`;
        player.score = (player.score || 0) + (currentActiveQ.points || 400);
        document.getElementById('player-score-display').textContent = player.score + ' pts';
        try { localStorage.setItem('trivia_player', JSON.stringify(player)); } catch(e){}

        // Notify server
        fetch('/api/answer', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            playerId: player.id,
            playerName: player.name,
            playerColor: player.color,
            isCorrect: true,
            points: currentActiveQ.points || 400,
            questionNum: currentActiveQ.num
          })
        }).catch(()=>{});
      } else {
        if (navigator.vibrate) navigator.vibrate(150);
        feed.className = 'py-3 rounded-2xl mt-3 font-black text-sm bg-red-950/70 border border-red-600 text-red-300 text-center';
        feed.textContent = `💥 ¡Orden incorrecto! Inténtalo de nuevo.`;
        setTimeout(() => {
          feed.classList.add('hidden');
          resetMobileSimon();
        }, 1200);
      }
    }

    // ── MOBILE QUESTION 40 OPEN TEXT SUBMIT ──
    async function submitMobileQ40() {
      const input = document.getElementById('mobile-q40-input');
      const text = input ? input.value.trim() : '';
      if (!text || text.length < 3) {
        input.focus();
        input.classList.add('border-red-500');
        setTimeout(() => input.classList.remove('border-red-500'), 1000);
        return;
      }

      if (window.confetti) window.confetti({ particleCount: 100, spread: 80 });
      if (navigator.vibrate) navigator.vibrate([100, 50, 150]);

      const feed = document.getElementById('q-feedback');
      feed.classList.remove('hidden');
      feed.className = 'py-4 rounded-2xl mt-3 font-black text-sm bg-amber-950/70 border border-amber-500 text-amber-300 text-center leading-relaxed';
      feed.innerHTML = `🌟 ¡RESPUESTA ENVIADA AL PROYECTOR!<br/><span class="text-xs text-slate-300 font-normal">«${text}»</span><br/><span class="text-emerald-400 font-bold">+500 PTS Otorgados</span>`;

      player.score = (player.score || 0) + 500;
      document.getElementById('player-score-display').textContent = player.score + ' pts';
      try { localStorage.setItem('trivia_player', JSON.stringify(player)); } catch(e){}

      document.querySelectorAll('#q-open-view button, #q-open-view textarea').forEach(el => el.disabled = true);

      // Notify server
      try {
        await fetch('/api/answer', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            playerId: player.id,
            playerName: player.name,
            playerColor: player.color,
            isCorrect: true,
            isOpenText: true,
            openText: text,
            points: 500,
            questionNum: 40
          })
        });
      } catch(e){}
    }
'''

html = html.replace('</script>', mobile_simon_js + '\n</script>')

with open('join.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("Updated join.html with mobile Simon sequence buttons and Q40 open text submission!")

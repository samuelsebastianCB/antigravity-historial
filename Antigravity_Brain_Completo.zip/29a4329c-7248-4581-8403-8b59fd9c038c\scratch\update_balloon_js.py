import re

with open('balloon_trivia.html', 'r', encoding='utf-8') as f:
    html = f.read()

# JavaScript to append before </script>
splitflap_js = '''
// ══════════════════════════════════════════════════════════════
//  SPLIT-FLAP ANALOG TRAIN STATION ENGINE (SOLARI DI UDINE STYLE)
//  Exact parameters from user specification:
//    tileColor: "#111827", textColor: "#f8fafc", tileRadius: 8, gap: 6,
//    cycleDelay: 2400, flipsPerChar: 8, flipDuration: 0.12, stagger: 0.06
// ══════════════════════════════════════════════════════════════

const CHARSET = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.:-!/*#";
let soundEnabled = true;
let audioCtx = null;

function getAudioContext() {
  if (!audioCtx) {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (AudioContext) audioCtx = new AudioContext();
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(()=>{});
  }
  return audioCtx;
}

function playMechanicalFlapSound() {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(260 + Math.random() * 120, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(70, ctx.currentTime + 0.028);
    gain.gain.setValueAtTime(0.045, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.028);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.028);
  } catch(e){}
}

function toggleFlapSound() {
  soundEnabled = !soundEnabled;
  const btn = document.getElementById('btn-sound-toggle');
  if (btn) btn.textContent = soundEnabled ? '🔊 Sonido On' : '🔇 Sonido Off';
}

class SplitFlapText {
  constructor(container, options = {}) {
    this.container = container;
    this.words = options.words || ["LAUNCH READY", "SYNC ONLINE", "SIGNAL LIVE"];
    this.flipDuration = options.flipDuration || 0.12;
    this.stagger = options.stagger || 0.06;
    this.cycleDelay = options.cycleDelay || 2400;
    this.charset = options.charset || "alphanumeric";
    this.flipsPerChar = options.flipsPerChar || 8;
    this.tileColor = options.tileColor || "#111827";
    this.textColor = options.textColor || "#f8fafc";
    this.tileRadius = options.tileRadius || 8;
    this.gap = options.gap || 6;
    this.padTo = options.padTo || 14;
    this.loop = options.loop !== false;
    this.isSmall = options.isSmall || false;

    this.currentWordIdx = 0;
    this.tiles = [];
    this.timer = null;
    this.init();
  }

  init() {
    this.container.innerHTML = '';
    this.container.style.gap = `${this.gap}px`;
    for (let i = 0; i < this.padTo; i++) {
      const tile = document.createElement('div');
      tile.className = 'splitflap-tile' + (this.isSmall ? ' sf-sm' : '');
      tile.style.background = this.tileColor;
      tile.style.borderRadius = `${this.tileRadius}px`;
      tile.innerHTML = `
        <div class="sf-half sf-top-back" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
        <div class="sf-half sf-bottom-back" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
        <div class="sf-half sf-top-flip" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
        <div class="sf-half sf-bottom-flip" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
      `;
      this.container.appendChild(tile);
      this.tiles.push({
        el: tile,
        currentChar: ' ',
        targetChar: ' ',
        isFlipping: false
      });
    }

    if (this.words && this.words.length > 0) {
      this.setText(this.words[0], false);
      if (this.loop && this.words.length > 1) {
        this.scheduleNext();
      }
    }
  }

  scheduleNext() {
    this.timer = setTimeout(() => {
      this.currentWordIdx = (this.currentWordIdx + 1) % this.words.length;
      this.setText(this.words[this.currentWordIdx], true);
      this.scheduleNext();
    }, this.cycleDelay);
  }

  setText(text, animate = true) {
    const formatted = (text || '').toUpperCase().padEnd(this.padTo, ' ').slice(0, this.padTo);
    for (let i = 0; i < this.padTo; i++) {
      const targetChar = formatted[i] || ' ';
      const tile = this.tiles[i];
      if (tile) {
        if (!animate) {
          this.setTileChar(tile, targetChar);
        } else {
          setTimeout(() => {
            this.flipTileTo(tile, targetChar, this.flipsPerChar);
          }, i * (this.stagger * 1000));
        }
      }
    }
  }

  setTileChar(tile, char) {
    tile.currentChar = char;
    tile.targetChar = char;
    const spans = tile.el.querySelectorAll('.sf-half span');
    spans.forEach(s => s.textContent = char);
    const topFlip = tile.el.querySelector('.sf-top-flip');
    const bottomFlip = tile.el.querySelector('.sf-bottom-flip');
    topFlip.style.transform = 'rotateX(0deg)';
    bottomFlip.style.transform = 'rotateX(90deg)';
  }

  flipTileTo(tile, targetChar, remainingFlips) {
    if (remainingFlips <= 0 && tile.currentChar === targetChar) return;

    let nextChar;
    if (remainingFlips > 1) {
      // Pick random alphanumeric character for intermediate flips
      const pool = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
      nextChar = pool[Math.floor(Math.random() * pool.length)];
    } else {
      nextChar = targetChar;
    }

    const curChar = tile.currentChar;
    tile.currentChar = nextChar;

    const topBackSpan = tile.el.querySelector('.sf-top-back span');
    const bottomBackSpan = tile.el.querySelector('.sf-bottom-back span');
    const topFlip = tile.el.querySelector('.sf-top-flip');
    const bottomFlip = tile.el.querySelector('.sf-bottom-flip');
    const topFlipSpan = topFlip.querySelector('span');
    const bottomFlipSpan = bottomFlip.querySelector('span');

    topBackSpan.textContent = nextChar;
    bottomBackSpan.textContent = curChar;
    topFlipSpan.textContent = curChar;
    bottomFlipSpan.textContent = nextChar;

    topFlip.style.transition = `transform ${this.flipDuration * 0.5}s ease-in`;
    bottomFlip.style.transition = `transform ${this.flipDuration * 0.5}s ease-out`;

    topFlip.style.transform = 'rotateX(0deg)';
    bottomFlip.style.transform = 'rotateX(90deg)';

    // Trigger step 1: top flap folds down
    requestAnimationFrame(() => {
      topFlip.style.transform = 'rotateX(-90deg)';
      playMechanicalFlapSound();

      setTimeout(() => {
        // Trigger step 2: bottom flap drops down
        bottomFlip.style.transform = 'rotateX(0deg)';

        setTimeout(() => {
          bottomBackSpan.textContent = nextChar;
          topFlip.style.transition = 'none';
          bottomFlip.style.transition = 'none';
          topFlip.style.transform = 'rotateX(0deg)';
          bottomFlip.style.transform = 'rotateX(90deg)';
          topFlipSpan.textContent = nextChar;

          if (remainingFlips > 1 || tile.currentChar !== targetChar) {
            this.flipTileTo(tile, targetChar, remainingFlips - 1);
          }
        }, this.flipDuration * 500);
      }, this.flipDuration * 500);
    });
  }
}

// ── INITIALIZE SPLITFLAP TICKER ──
let mainTicker = null;
function initSplitFlapTicker() {
  const tickerEl = document.getElementById('splitflap-ticker');
  if (tickerEl) {
    mainTicker = new SplitFlapText(tickerEl, {
      words: [
        "LAUNCH READY",
        "SYNC ONLINE",
        "SIGNAL LIVE",
        "TRIVIA MILLER",
        "EN ESTACION",
        "SALA CONECTA"
      ],
      flipDuration: 0.12,
      stagger: 0.06,
      cycleDelay: 2400,
      flipsPerChar: 8,
      tileColor: "#111827",
      textColor: "#f8fafc",
      tileRadius: 8,
      gap: 6,
      padTo: 13,
      loop: true
    });
  }
}

// ── MULTIPLAYER PLAYERS STATE & DEPARTURE BOARD ──
let connectedPlayers = [];
let stationClockInterval = null;

function openStationBoard() {
  document.getElementById('station-board-modal').style.display = 'flex';
  updateStationClock();
  if (!stationClockInterval) {
    stationClockInterval = setInterval(updateStationClock, 1000);
  }
  renderStationTable();
}

function closeStationBoard() {
  document.getElementById('station-board-modal').style.display = 'none';
}

function updateStationClock() {
  const clk = document.getElementById('station-clock');
  if (clk) {
    const now = new Date();
    clk.textContent = now.toTimeString().split(' ')[0];
  }
}

function renderStationTable() {
  const tbody = document.getElementById('station-table-body');
  const emptyMsg = document.getElementById('station-empty-msg');
  const counter = document.getElementById('station-passenger-count');
  if (!tbody) return;

  if (counter) counter.textContent = connectedPlayers.length;

  if (connectedPlayers.length === 0) {
    tbody.innerHTML = '';
    if (emptyMsg) emptyMsg.style.display = 'block';
    return;
  }
  if (emptyMsg) emptyMsg.style.display = 'none';

  // Sort by score descending
  const sorted = [...connectedPlayers].sort((a,b) => (b.score||0) - (a.score||0));
  tbody.innerHTML = '';

  sorted.forEach((p, idx) => {
    const tr = document.createElement('tr');
    tr.className = 'station-row';
    const via = String(idx + 1).padStart(2, '0');
    const scoreStr = String(p.score || 0).padStart(4, '0') + ' P';
    const status = p.status || 'ABORDA';

    tr.innerHTML = `
      <td><span style="font-weight:900;color:#f59e0b;font-family:'Roboto Mono',monospace;">${via}</span></td>
      <td>
        <div class="row-name-flap inline-flex" data-name="${p.name}"></div>
      </td>
      <td>
        <span style="display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:50px;background:${p.color}22;border:1px solid ${p.color}88;color:#fff;font-size:0.75rem;font-weight:bold;">
          <span style="width:8px;height:8px;border-radius:50%;background:${p.color};box-shadow:0 0 8px ${p.color};"></span>
          ${p.colorName || 'Color'}
        </span>
      </td>
      <td>
        <div class="row-score-flap inline-flex" data-score="${scoreStr}"></div>
      </td>
      <td>
        <div class="row-status-flap inline-flex" data-status="${status}"></div>
      </td>
    `;
    tbody.appendChild(tr);

    // Initialize SplitFlap tiles for each column
    const nameEl = tr.querySelector('.row-name-flap');
    const scoreEl = tr.querySelector('.row-score-flap');
    const statusEl = tr.querySelector('.row-status-flap');

    new SplitFlapText(nameEl, {
      words: [p.name], padTo: 10, isSmall: true, gap: 3, tileRadius: 5,
      tileColor: "#111827", textColor: "#f8fafc", flipsPerChar: 4, loop: false
    });
    new SplitFlapText(scoreEl, {
      words: [scoreStr], padTo: 6, isSmall: true, gap: 3, tileRadius: 5,
      tileColor: "#111827", textColor: "#4ade80", flipsPerChar: 4, loop: false
    });
    new SplitFlapText(statusEl, {
      words: [status], padTo: 6, isSmall: true, gap: 3, tileRadius: 5,
      tileColor: "#111827", textColor: "#f59e0b", flipsPerChar: 4, loop: false
    });
  });
}

// ── QR CODE MODAL ──
function getJoinUrl() {
  const origin = window.location.origin;
  if (!origin || origin.startsWith('file:')) {
    return 'http://localhost:5000/join';
  }
  return origin + '/join';
}

function openQrModal() {
  const modal = document.getElementById('qr-modal');
  const img = document.getElementById('qr-code-img');
  const txt = document.getElementById('qr-url-text');
  const counter = document.getElementById('qr-passenger-counter');

  const joinUrl = getJoinUrl();
  txt.textContent = joinUrl;
  img.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(joinUrl)}&margin=4`;
  if (counter) counter.textContent = connectedPlayers.length;

  modal.style.display = 'flex';
}

function closeQrModal() {
  document.getElementById('qr-modal').style.display = 'none';
}

function copyJoinUrl() {
  const url = getJoinUrl();
  navigator.clipboard.writeText(url).then(() => {
    const btn = document.getElementById('btn-copy-url');
    btn.textContent = '✅ ¡Copiado!';
    setTimeout(() => btn.textContent = '📋 Copiar Enlace', 2000);
  }).catch(() => {
    alert("Enlace: " + url);
  });
}

// ── SSE REALTIME CONNECTION WITH BACKEND SERVER ──
function initMultiplayerSync() {
  try {
    const evtSource = new EventSource('/api/events');
    evtSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        handleHostEvent(data);
      } catch(e){}
    };
    evtSource.onopen = () => {
      console.log("Multiplayer SSE connected to server.");
    };
  } catch(e){
    console.log("Running in offline/standalone mode.");
  }
}

function handleHostEvent(ev) {
  if (ev.type === 'initial_sync') {
    connectedPlayers = ev.players || [];
    renderStationTable();
    updateScoreboard();
  } else if (ev.type === 'player_joined') {
    connectedPlayers = ev.players || [];
    renderStationTable();
    const qrCount = document.getElementById('qr-passenger-counter');
    if (qrCount) qrCount.textContent = connectedPlayers.length;
    // Notify with soft clack
    playMechanicalFlapSound();
  } else if (ev.type === 'score_updated') {
    connectedPlayers = ev.players || [];
    renderStationTable();
    playMechanicalFlapSound();
  }
}

// Hook into openTrivia to broadcast question to student phones
const originalOpenTrivia = window.openTrivia;
window.openTrivia = function(num) {
  if (typeof originalOpenTrivia === 'function') {
    originalOpenTrivia(num);
  }
  // Notify server so student phones get the question
  try {
    fetch('/api/pop', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        num: num,
        points: questions[num-1].points || 100,
        q: questions[num-1]
      })
    }).catch(()=>{});
  } catch(e){}
};

// Hook into returnToGrid to tell phones to return to waiting lounge
const originalReturnToGrid = window.returnToGrid;
window.returnToGrid = function() {
  if (typeof originalReturnToGrid === 'function') {
    originalReturnToGrid();
  }
  try {
    fetch('/api/close_question', { method: 'POST' }).catch(()=>{});
  } catch(e){}
};

// Initialize SplitFlap ticker and SSE when DOM is ready
window.addEventListener('DOMContentLoaded', () => {
  initSplitFlapTicker();
  initMultiplayerSync();
});
setTimeout(() => {
  if (!mainTicker) initSplitFlapTicker();
  initMultiplayerSync();
}, 600);
'''

html = html.replace('</script>', splitflap_js + '\n</script>')

with open('balloon_trivia.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("Updated balloon_trivia.html with SplitFlap engine, Station board and real-time syncing!")

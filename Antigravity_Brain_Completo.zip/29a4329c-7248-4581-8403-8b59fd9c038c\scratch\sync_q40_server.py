import re

# 1. Update server.py
with open('server.py', 'r', encoding='utf-8') as f:
    srv = f.read()

old_open_q = '''    def open_question(self, q_data, num, points):
        with self.lock:
            self.active_question = {
                "num": num,
                "points": points,
                "q": q_data.get("q", ""),
                "type": q_data.get("type", "mc"),
                "options": q_data.get("options", []),
                "correct": q_data.get("correct"),
                "answer": q_data.get("answer", ""),
                "instruction": q_data.get("instruction", "")
            }'''

new_open_q = '''    def open_question(self, q_data, num, points):
        with self.lock:
            self.active_question = {
                "num": num,
                "points": points,
                "q": q_data.get("q", ""),
                "type": q_data.get("type", "mc"),
                "options": q_data.get("options", []),
                "correct": q_data.get("correct"),
                "answer": q_data.get("answer", ""),
                "instruction": q_data.get("instruction", ""),
                "isSimon": q_data.get("isSimon", False),
                "sequence": q_data.get("sequence", []),
                "isOpenText": q_data.get("isOpenText", False)
            }'''

srv = srv.replace(old_open_q, new_open_q)

old_rec_ans = '''    def record_answer(self, player_id, is_correct, points, q_num=None):'''
new_rec_ans = '''    def record_answer(self, player_id, is_correct, points, q_num=None, is_open_text=False, open_text=""):'''

srv = srv.replace(old_rec_ans, new_rec_ans)

old_broadcast_ans = '''        self.broadcast("score_updated", {
            "playerId": player_id,
            "playerName": player["name"],
            "isCorrect": is_correct,
            "points": points,
            "newScore": new_score,
            "players": list(self.players.values())
        })
        return player'''

new_broadcast_ans = '''        self.broadcast("score_updated", {
            "playerId": player_id,
            "playerName": player["name"],
            "isCorrect": is_correct,
            "points": points,
            "newScore": new_score,
            "players": list(self.players.values())
        })
        if is_open_text and open_text:
            self.broadcast("open_text_submitted", {
                "playerId": player_id,
                "playerName": player["name"],
                "playerColor": player.get("color", "#f59e0b"),
                "text": open_text
            })
        return player'''

srv = srv.replace(old_broadcast_ans, new_broadcast_ans)

old_post_answer = '''        elif path == "/api/answer":
            player_id = body.get("playerId")
            is_correct = bool(body.get("isCorrect"))
            points = int(body.get("points", 0))
            q_num = body.get("questionNum")
            player = GAME.record_answer(player_id, is_correct, points, q_num)'''

new_post_answer = '''        elif path == "/api/answer":
            player_id = body.get("playerId")
            is_correct = bool(body.get("isCorrect"))
            points = int(body.get("points", 0))
            q_num = body.get("questionNum")
            is_open_text = bool(body.get("isOpenText"))
            open_text = body.get("openText", "")
            player = GAME.record_answer(player_id, is_correct, points, q_num, is_open_text, open_text)'''

srv = srv.replace(old_post_answer, new_post_answer)

with open('server.py', 'w', encoding='utf-8') as f:
    f.write(srv)

print("Updated server.py successfully.")

# 2. Update balloon_trivia.html to listen to open_text_submitted
with open('balloon_trivia.html', 'r', encoding='utf-8') as f:
    html = f.read()

old_event_handler = '''  } else if (ev.type === 'score_updated') {
    connectedPlayers = ev.players || [];
    renderStationTable();
    playMechanicalFlapSound();
  }'''

new_event_handler = '''  } else if (ev.type === 'score_updated') {
    connectedPlayers = ev.players || [];
    renderStationTable();
    playMechanicalFlapSound();
  } else if (ev.type === 'open_text_submitted') {
    const card = document.getElementById('q40-submitted-card');
    const txtDisplay = document.getElementById('q40-submitted-text');
    if (card && txtDisplay) {
      card.style.display = 'block';
      txtDisplay.innerHTML = `<span style="color:${ev.playerColor};font-weight:900;">${ev.playerName}:</span> «${ev.text}»`;
    }
    if (window.confetti) window.confetti({ particleCount: 120, spread: 80 });
    playMechanicalFlapSound();
  }'''

html = html.replace(old_event_handler, new_event_handler)

with open('balloon_trivia.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("Updated balloon_trivia.html with open_text_submitted handler.")

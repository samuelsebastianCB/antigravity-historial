# Walkthrough: Módulo de Análisis de Ventas mediante Serie de Fourier

El módulo obligatorio de **Serie de Fourier** para el análisis de ventas periódicas y estacionales ha sido completamente implementado y verificado en **Vinatería La Moderna**.

---

## 1. Arquitectura y Componentes Implementados

### 1.1 Núcleo Matemático Puro (TypeScript)
* **[fourier.math.ts](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/src/app/fourier/fourier.math.ts)**:
  * Modelo matemático exacto:
    $$f(t) = a_0 + \sum_{k=1}^{K} \left[ a_k \cos\left(\frac{2\pi k t}{T}\right) + b_k \sin\left(\frac{2\pi k t}{T}\right) \right] = a_0 + \sum_{k=1}^{K} A_k \cos\left(\frac{2\pi k t}{T} + \phi_k\right)$$
  * Ajuste mediante **mínimos cuadrados** sobre la base ortogonal trigonométrica (evita fuga espectral cuando el periodo no divide exactamente a $N$).
  * Relleno uniforme de la serie temporal (`rellenarSerie`) asignando 0 a cubetas sin actividad económica.
  * Periodograma espectral de Lomb-Scargle / Fourier para detección de picos dominantes de demanda.
  * Detección de patrones en lenguaje llano (semanales, mensuales, días pico, días valle y cambios de fase entre mitades).
  * Generación de alertas administrativas de inventario y pronóstico del siguiente pico periódico.
* **[fourier.math.spec.ts](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/src/app/fourier/fourier.math.spec.ts)**:
  * 15 pruebas unitarias automatizadas cubriendo exactitud matemática, ortogonalidad, monotonía del $R^2$, resiliencia a ruido y detección de ciclos.

### 1.2 Backend y Persistencia (PHP / MySQL)
* **[fourier_migration.sql](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/sql/fourier_migration.sql)** y **[esquema.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/config/esquema.php)**:
  * Creación idempotente de la tabla `FOURIER_ANALYSIS` para trazabilidad completa.
  * Soporte de campos `SALE_TYPE` (`NORMAL` vs `INTERNA`), `INTERNAL_BUYER`, `INTERNAL_REASON` en `SALE`.
  * Incorporación del campo `CATEGORY` en `PRODUCT`.
* **[obtener_serie_ventas.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/obtener_serie_ventas.php)**:
  * Agrupación por intervalos (`hora`, `dia`, `semana`, `mes`, `anio`).
  * Cálculo del hash SHA-256 del dataset para trazabilidad criptográfica.
* **[guardar_analisis_fourier.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/guardar_analisis_fourier.php)** & **[obtener_analisis_fourier.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/obtener_analisis_fourier.php)**:
  * Registro de auditoría con usuario, timestamp, coeficientes, métricas ($R^2$, $RMSE$) y parámetros para reproducción inmediata.
* **[obtener_compras_internas.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/obtener_compras_internas.php)**:
  * Consulta aislada de consumos internos para no distorsionar ventas a clientes ni el arqueo de caja.

### 1.3 Módulo Frontend y Experiencia de Usuario (Angular)
* **[fourier.ts](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/src/app/fourier/fourier.ts)**: Componente standalone que orquesta filtros, geometría SVG, tooltips interactivos, exportación CSV y reproducción del historial.
* **[fourier.html](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/src/app/fourier/fourier.html)**:
  * Barra de filtros completa (Presets rápidos 30/90/180 días, Año, intervalos, métrica, producto, categoría, slider de armónicos 1-12, selector de periodo base fundamental).
  * Banner de Alerta Administrativa de Inventario cuando se detecta un patrón periódico de incremento de demanda.
  * Gráfica SVG interactiva con polilíneas de ventas reales vs curva suave de Fourier y tooltip dinámico al posar el cursor.
  * Pestañas de inspección:
    1. **Gráfica Interactiva**: Resumen de ajuste ($R^2$, $RMSE$, $a_0$) y gráfico SVG.
    2. **Patrones y Periodicidad**: Explicación automática en lenguaje llano, picos recurrentes y estabilidad estacional.
    3. **Coeficientes y Armónicos**: Tabla detallada con $k$, $f_k$, $T_k$, $a_k$, $b_k$, $A_k$, $\phi_k$.
    4. **Observado vs Aproximado**: Tabla temporal con errores residuales $e_i$ y $e_i^2$.
    5. **Registros Utilizados**: Líneas de venta auditadas con botón de exportación a CSV.
  * Modal de Historial con opción de "Reabrir / Reproducir".
* **[fourier.css](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/src/app/fourier/fourier.css)**: Paleta institucional vino y dorado (`#640D14`, `#D4AF88`), tipografía clara y diseño totalmente adaptable.
* **Rutas e Integración**:
  * [app.routes.ts](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/src/app/app.routes.ts): Ruta `/fourier` protegida por `authGuard`.
  * [admin.html](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/src/app/admin/admin.html) y [admin.ts](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/src/app/admin/admin.ts): Tarjeta del módulo "Análisis de Fourier" agregada en el panel de control.

---

## 2. Verificación de Compilación y Pruebas

### Pruebas Unitarias Automatizadas
```bash
ng test --watch=false
```
* **Resultado**: `17 passed (17)` (15 pruebas matemáticas de Fourier + 2 de infraestructura).

### Compilación de Producción
```bash
ng build
```
* **Resultado**: Compilación limpia y exitosa (`Application bundle generation complete`).

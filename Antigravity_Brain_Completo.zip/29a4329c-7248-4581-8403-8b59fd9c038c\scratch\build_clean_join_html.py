import json

html_join = '''<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>📱 Pasajero — Trivia Ley de Miller</title>
  <!-- Tailwind CSS -->
  <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
  <!-- Canvas Confetti -->
  <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js"></script>

  <style>
    * { box-sizing: border-box; }
    body {
      font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
      background: #090714;
      min-height: 100vh;
      color: #fff;
      overflow-x: hidden;
    }
    .glass-card {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(14px);
      border: 1px solid rgba(139, 92, 246, 0.3);
      box-shadow: 0 15px 35px rgba(0,0,0,0.6);
    }
  </style>
</head>
<body class="p-4 flex flex-col justify-between min-h-screen max-w-md mx-auto">
  <!-- ════════════════════════════════════════════════════════════════════════
       1. PANTALLA DE REGISTRO (NOMBRE + COLOR ALEATORIO)
       ════════════════════════════════════════════════════════════════════════ -->
  <div id="join-screen" class="my-auto flex flex-col items-center text-center">
    <div class="w-16 h-16 rounded-3xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-3xl shadow-xl shadow-purple-900/50 mb-4 animate-bounce">
      🎈
    </div>
    <h1 class="text-2xl font-black tracking-tight text-white mb-1">UNIRSE AL JUEGO</h1>
    <p class="text-xs text-purple-200/80 mb-6">Trivia en Vivo • La Ley de Miller (7 ± 2)</p>

    <div class="glass-card w-full rounded-3xl p-6 text-left">
      <label class="block text-xs font-bold text-slate-300 mb-1.5">Tu Nombre o Apodo:</label>
      <input type="text" id="join-name-input" placeholder="Ej: Valentina, Lucas, Carlos..." maxlength="18"
             class="w-full px-4 py-3 bg-slate-900 border border-purple-500/40 rounded-2xl text-sm text-white focus:outline-none focus:border-purple-400 mb-4"
             onkeydown="if(event.key==='Enter') submitJoin()" />

      <label class="block text-xs font-bold text-slate-300 mb-1.5">Color de Pasajero Asignado:</label>
      <div class="flex items-center justify-between bg-slate-900/90 p-3 rounded-2xl border border-slate-700 mb-6">
        <div class="flex items-center gap-3">
          <div id="join-color-circle" class="w-7 h-7 rounded-full border border-white/40 shadow-md" style="background:#f43f5e"></div>
          <div>
            <span id="join-color-name" class="text-xs font-bold text-white block">Rojo Carmesí</span>
            <span class="text-[10px] text-slate-400">Color aleatorio de competencia</span>
          </div>
        </div>
        <button onclick="rerollJoinColor()" class="text-xs text-purple-300 hover:text-white font-bold bg-purple-900/40 px-3 py-1.5 rounded-xl border border-purple-500/30 active:scale-95 transition">
          🎲 Cambiar
        </button>
      </div>

      <button onclick="submitJoin()" class="w-full py-3.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 text-white rounded-2xl font-black text-sm tracking-wide shadow-lg shadow-purple-900/40 active:scale-95 transition flex items-center justify-center gap-2">
        <span>🚂</span> ¡Subir a Bordo!
      </button>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════════════
       2. PANTALLA PRINCIPAL DEL JUGADOR (CONECTADO)
       ════════════════════════════════════════════════════════════════════════ -->
  <div id="game-screen" class="hidden flex-1 flex flex-col">
    <!-- Header del Jugador -->
    <header class="flex items-center justify-between glass-card p-3 rounded-2xl mb-4">
      <div class="flex items-center gap-2.5">
        <div id="header-player-color" class="w-8 h-8 rounded-full border border-white/30 flex items-center justify-center text-xs font-black shadow-md text-white" style="background:#f43f5e">
          👤
        </div>
        <div>
          <h2 id="header-player-name" class="text-sm font-black text-white leading-tight">Alumno</h2>
          <span class="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> Conectado
          </span>
        </div>
      </div>
      <div class="text-right">
        <span class="text-[10px] text-slate-400 block font-bold uppercase">Puntaje</span>
        <span id="header-player-score" class="text-base font-black text-amber-400 font-mono">0 pts</span>
      </div>
    </header>

    <!-- ── ESTADO A: SALA DE ESPERA (SIN PREGUNTA ACTIVA) ── -->
    <div id="waiting-box" class="my-auto text-center py-10 px-4 glass-card rounded-3xl">
      <div class="text-4xl mb-3 animate-pulse">🚂</div>
      <h3 class="text-base font-black text-white mb-1">¡ESTÁS A BORDO DEL TREN!</h3>
      <p class="text-xs text-slate-400 leading-relaxed max-w-xs mx-auto mb-6">
        Mira hacia el proyector del salón. En cuanto el profesor elija un globo, la pregunta aparecerá automáticamente aquí en tu pantalla.
      </p>
      <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-purple-900/30 border border-purple-500/30 text-purple-300 text-xs font-bold">
        <span>⏱️</span> Esperando reactivo...
      </div>
    </div>

    <!-- ── ESTADO B: PREGUNTA ACTIVA ── -->
    <div id="question-box" class="hidden flex-1 flex flex-col justify-between">
      <div class="glass-card rounded-3xl p-5 mb-3 flex-1 flex flex-col">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
          <span id="m-q-num" class="text-xs font-black text-purple-300 px-2.5 py-0.5 rounded-lg bg-purple-500/20 border border-purple-500/30">
            Globo #1
          </span>
          <span id="m-q-points" class="text-xs font-black text-amber-400 font-mono">
            +100 PTS
          </span>
        </div>

        <h3 id="m-q-text" class="text-sm font-bold text-white mb-2 leading-snug">
          ¿Texto de la pregunta?
        </h3>
        <p id="m-q-instruction" class="text-[11px] text-purple-200/70 mb-4">
          Selecciona tu respuesta:
        </p>

        <!-- Vista Opción Múltiple -->
        <div id="m-opt-view" class="flex flex-col gap-2.5 flex-1 justify-center"></div>

        <!-- Vista Verdadero / Falso -->
        <div id="m-vf-view" class="grid grid-cols-2 gap-3 my-auto hidden">
          <button onclick="submitMobileVf(true)" class="p-5 rounded-2xl bg-emerald-950/70 border-2 border-emerald-500 text-emerald-300 font-black text-sm active:scale-95 flex flex-col items-center gap-2">
            <span class="text-2xl">🟢</span>
            <span>VERDADERO</span>
          </button>
          <button onclick="submitMobileVf(false)" class="p-5 rounded-2xl bg-rose-950/70 border-2 border-rose-500 text-rose-300 font-black text-sm active:scale-95 flex flex-col items-center gap-2">
            <span class="text-2xl">🔴</span>
            <span>FALSO</span>
          </button>
        </div>

        <!-- Vista Simón Dice con Secuencia Aleatoria Personalizada -->
        <div id="m-simon-view" class="hidden flex flex-col gap-3 my-auto">
          <!-- Fase 1: Memorización -->
          <div id="m-simon-memo" class="p-4 rounded-2xl bg-purple-950/50 border border-purple-500/40 text-center">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[11px] font-bold text-purple-300">👀 ¡MEMORIZA EL ORDEN!</span>
              <span id="m-simon-time" class="text-xs font-mono font-black text-amber-300">5.0s</span>
            </div>
            <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mb-3">
              <div id="m-simon-bar" class="bg-amber-400 h-full w-full"></div>
            </div>
            <div id="m-simon-display" class="flex flex-wrap items-center justify-center gap-2"></div>
          </div>

          <!-- Fase 2: Entrada Táctil -->
          <div id="m-simon-input" class="hidden flex flex-col gap-2.5">
            <div class="flex items-center justify-between">
              <span class="text-[11px] font-bold text-slate-300">🎮 Toca en el orden correcto:</span>
              <button onclick="resetMobileSimonInput()" class="text-[10px] text-rose-300 font-bold bg-slate-800 px-2 py-1 rounded-lg border border-slate-700">
                🔄 Limpiar
              </button>
            </div>
            <div id="m-simon-tray" class="min-h-[44px] p-2 rounded-xl bg-slate-900 border border-purple-500/30 flex flex-wrap items-center gap-1.5">
              <span class="text-[11px] text-slate-500 italic">Toca los botones...</span>
            </div>
            <div id="m-simon-buttons" class="grid grid-cols-2 gap-2 mt-1"></div>
            <button onclick="checkMobileSimonSubmit()" class="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-black text-xs rounded-xl shadow-md active:scale-95 transition mt-1">
              ✅ Confirmar Secuencia
            </button>
          </div>
        </div>

        <!-- Vista Pregunta 40 (Respuesta Abierta) -->
        <div id="m-open-view" class="hidden flex flex-col gap-3 my-auto">
          <p class="text-xs text-amber-200 bg-amber-950/40 p-3 rounded-xl border border-amber-500/30 leading-relaxed">
            🌟 <strong>Reflexión Final Abierta:</strong> Explica con tus propias palabras la Ley de Miller (menciona el número 7 ± 2 y el chunking). No tiene calificación numérica automática, pero es requisito enviarla.
          </p>
          <textarea id="m-q40-text" rows="4" placeholder="Escribe aquí tu explicación..."
                    class="w-full p-3 bg-slate-900 border border-amber-500/40 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"></textarea>
          <button onclick="submitMobileQ40()" class="w-full py-3 bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs rounded-xl shadow-md active:scale-95 transition flex items-center justify-center gap-2">
            <span>📨</span> Enviar Respuesta Final al Salón (+500 pts)
          </button>
        </div>

        <!-- Mensaje de Retroalimentación en Celular -->
        <div id="m-feedback" class="hidden p-3 rounded-xl text-xs font-bold mt-3 text-center"></div>
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════════════
       3. SCRIPT DEL PASAJERO (MULTIPLAYER)
       ════════════════════════════════════════════════════════════════════════ -->
  <script>
    const COLORS = [
      { name: "Rojo Carmesí", hex: "#f43f5e" },
      { name: "Naranja Fuego", hex: "#f97316" },
      { name: "Ámbar Dorado", hex: "#eab308" },
      { name: "Esmeralda Neón", hex: "#10b981" },
      { name: "Cian Eléctrico", hex: "#06b6d4" },
      { name: "Violeta Cyber", hex: "#8b5cf6" },
      { name: "Rosa Magenta", hex: "#ec4899" },
      { name: "Azul Glaciar", hex: "#0ea5e9" },
      { name: "Turquesa Vivo", hex: "#14b8a6" },
      { name: "Oro Radiante", hex: "#f59e0b" }
    ];

    let player = { id: null, name: "", color: "#f43f5e", colorName: "Rojo Carmesí", score: 0 };
    let colorIdx = Math.floor(Math.random() * COLORS.length);
    let activeQuestion = null;
    let simonTargetSeq = [];
    let simonUserSeq = [];
    let simonTimer = null;
    let hasAnsweredCurrent = false;

    // Inicializar color aleatorio de entrada
    function updateJoinColorDisplay() {
      const c = COLORS[colorIdx];
      document.getElementById('join-color-circle').style.background = c.hex;
      document.getElementById('join-color-name').textContent = c.name;
    }
    updateJoinColorDisplay();

    function rerollJoinColor() {
      colorIdx = (colorIdx + 1) % COLORS.length;
      updateJoinColorDisplay();
    }

    function submitJoin() {
      const nameInput = document.getElementById('join-name-input');
      const name = nameInput ? nameInput.value.trim() : '';
      if (!name) {
        if (nameInput) {
          nameInput.focus();
          nameInput.classList.add('border-red-500');
        }
        return;
      }

      const c = COLORS[colorIdx];
      player = {
        id: 'p_' + Date.now().toString().slice(-6),
        name: name,
        color: c.hex,
        colorName: c.name,
        score: 0
      };

      // Registrar con el servidor
      fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: player.name,
          color: player.color,
          colorName: player.colorName
        })
      }).then(r => r.json()).then(data => {
        if (data && data.player) {
          player.id = data.player.id;
        }
      }).catch(()=>{});

      // Pasar a la pantalla de juego
      document.getElementById('join-screen').classList.add('hidden');
      document.getElementById('game-screen').classList.remove('hidden');

      document.getElementById('header-player-name').textContent = player.name;
      document.getElementById('header-player-color').style.background = player.color;
      document.getElementById('header-player-score').textContent = '0 pts';

      // Conectar a eventos SSE del servidor
      initSse();
    }

    function initSse() {
      const ev = new EventSource('/api/events');
      ev.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          if (data.type === 'question_opened') {
            displayMobileQuestion(data.question, data.num, data.points);
          } else if (data.type === 'question_closed') {
            showWaitingScreen();
          } else if (data.type === 'score_updated' && data.playerId === player.id) {
            player.score = data.newScore;
            document.getElementById('header-player-score').textContent = `${player.score} pts`;
          }
        } catch(err){}
      };
      ev.onerror = () => setTimeout(initSse, 4000);
    }

    function showWaitingScreen() {
      document.getElementById('waiting-box').classList.remove('hidden');
      document.getElementById('question-box').classList.add('hidden');
      activeQuestion = null;
      hasAnsweredCurrent = false;
      if (simonTimer) clearInterval(simonTimer);
    }

    function displayMobileQuestion(q, num, points) {
      if (!q) return;
      activeQuestion = q;
      hasAnsweredCurrent = false;

      document.getElementById('waiting-box').classList.add('hidden');
      document.getElementById('question-box').classList.remove('hidden');

      document.getElementById('m-q-num').textContent = `Globo #${num}`;
      document.getElementById('m-q-points').textContent = `+${points} PTS`;
      document.getElementById('m-q-text').textContent = q.q;
      document.getElementById('m-q-instruction').textContent = q.instruction || 'Selecciona la opción correcta:';

      const optView = document.getElementById('m-opt-view');
      const vfView = document.getElementById('m-vf-view');
      const simonView = document.getElementById('m-simon-view');
      const openView = document.getElementById('m-open-view');
      const feedback = document.getElementById('m-feedback');

      optView.classList.add('hidden');
      vfView.classList.add('hidden');
      simonView.classList.add('hidden');
      openView.classList.add('hidden');
      feedback.classList.add('hidden');

      if (q.isOpenText) {
        openView.classList.remove('hidden');
        document.getElementById('m-q40-text').value = '';
      } else if (q.isSimon) {
        simonView.classList.remove('hidden');
        initMobileSimon(q);
      } else if (q.type === 'vf') {
        vfView.classList.remove('hidden');
      } else {
        optView.classList.remove('hidden');
        renderMobileOptions(q);
      }
    }

    function renderMobileOptions(q) {
      const box = document.getElementById('m-opt-view');
      box.innerHTML = '';
      const letters = ['A', 'B', 'C', 'D'];

      (q.options || []).forEach((opt, idx) => {
        const btn = document.createElement('button');
        btn.className = 'w-full p-3 rounded-2xl bg-slate-900 border border-purple-500/40 text-left text-xs font-semibold text-slate-200 active:scale-98 transition flex items-center gap-3';
        btn.innerHTML = `
          <span class="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center justify-center font-bold text-xs shrink-0">${letters[idx]}</span>
          <span>${opt}</span>
        `;
        btn.onclick = () => submitMobileAnswer(idx === q.correct, q.points);
        box.appendChild(btn);
      });
    }

    function submitMobileVf(val) {
      if (hasAnsweredCurrent || !activeQuestion) return;
      const isCorrect = (val === activeQuestion.correct);
      submitMobileAnswer(isCorrect, activeQuestion.points);
    }

    function submitMobileAnswer(isCorrect, points) {
      if (hasAnsweredCurrent) return;
      hasAnsweredCurrent = true;

      const feed = document.getElementById('m-feedback');
      feed.classList.remove('hidden');

      if (isCorrect) {
        if (window.confetti) window.confetti({ particleCount: 70, spread: 60 });
        if (navigator.vibrate) navigator.vibrate([80, 40, 100]);
        feed.className = 'p-3 rounded-xl text-xs font-black bg-emerald-950/80 border border-emerald-500 text-emerald-300';
        feed.textContent = `🎉 ¡CORRECTO! +${points} PTS`;
        player.score += points;
        document.getElementById('header-player-score').textContent = `${player.score} pts`;
      } else {
        if (navigator.vibrate) navigator.vibrate(150);
        feed.className = 'p-3 rounded-xl text-xs font-black bg-rose-950/80 border border-rose-500 text-rose-300';
        feed.textContent = '❌ INCORRECTO';
      }

      // Notificar al servidor
      fetch('/api/answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          playerId: player.id,
          playerName: player.name,
          playerColor: player.color,
          isCorrect: isCorrect,
          points: isCorrect ? points : 0
        })
      }).catch(()=>{});
    }

    // ── SIMÓN DICE MÓVIL CON ORDEN GENERADO AL AZAR PARA CADA PERSONA ──
    function initMobileSimon(q) {
      if (simonTimer) clearInterval(simonTimer);

      // Barajar el pool de forma aleatoria para ESTE alumno específico
      const pool = [...q.pool];
      for (let i = pool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [pool[i], pool[j]] = [pool[j], pool[i]];
      }
      simonTargetSeq = pool.slice(0, q.count);
      simonUserSeq = [];

      const memoBox = document.getElementById('m-simon-memo');
      const inputBox = document.getElementById('m-simon-input');
      const display = document.getElementById('m-simon-display');
      const timeText = document.getElementById('m-simon-time');
      const bar = document.getElementById('m-simon-bar');

      memoBox.classList.remove('hidden');
      inputBox.classList.add('hidden');
      bar.style.width = '100%';

      display.innerHTML = '';
      simonTargetSeq.forEach((item, idx) => {
        const badge = document.createElement('div');
        badge.className = 'flex flex-col items-center p-2 rounded-xl bg-purple-900/50 border border-purple-400 text-center min-w-[56px]';
        badge.innerHTML = `
          <span class="text-[9px] text-purple-300 font-bold">#${idx + 1}</span>
          <span class="text-2xl">${item.icon}</span>
          <span class="text-[9px] font-bold text-white leading-tight truncate max-w-[50px]">${item.label}</span>
        `;
        display.appendChild(badge);
      });

      let rem = 5.0;
      timeText.textContent = '5.0s';
      simonTimer = setInterval(() => {
        rem -= 0.1;
        if (rem <= 0) {
          clearInterval(simonTimer);
          startMobileSimonInput(q);
        } else {
          timeText.textContent = rem.toFixed(1) + 's';
          bar.style.width = (rem / 5.0 * 100) + '%';
        }
      }, 100);
    }

    function startMobileSimonInput(q) {
      document.getElementById('m-simon-memo').classList.add('hidden');
      document.getElementById('m-simon-input').classList.remove('hidden');

      renderMobileSimonTray();
      renderMobileSimonButtons(q);
    }

    function renderMobileSimonTray() {
      const tray = document.getElementById('m-simon-tray');
      tray.innerHTML = '';
      if (simonUserSeq.length === 0) {
        tray.innerHTML = '<span class="text-[11px] text-slate-500 italic">Toca los botones en orden...</span>';
        return;
      }
      simonUserSeq.forEach((item, idx) => {
        const chip = document.createElement('div');
        chip.className = 'px-2 py-1 rounded-full bg-purple-600/30 border border-purple-400 text-purple-200 text-[10px] font-bold flex items-center gap-1';
        chip.innerHTML = `<span>${idx + 1}.</span><span>${item.icon}</span><span class="truncate max-w-[60px]">${item.label}</span>`;
        tray.appendChild(chip);
      });
    }

    function renderMobileSimonButtons(q) {
      const box = document.getElementById('m-simon-buttons');
      box.innerHTML = '';
      q.pool.forEach(item => {
        const isSel = simonUserSeq.some(x => x.id === item.id);
        const btn = document.createElement('button');
        btn.disabled = isSel;
        btn.className = `p-2.5 rounded-xl border text-left flex items-center gap-2 text-xs font-bold transition ${
          isSel ? 'bg-slate-900 border-slate-800 text-slate-600' : 'bg-slate-800 border-purple-500/40 text-white active:scale-95'
        }`;
        btn.innerHTML = `<span class="text-xl">${item.icon}</span><span class="truncate">${item.label}</span>`;
        btn.onclick = () => {
          if (isSel) return;
          simonUserSeq.push(item);
          renderMobileSimonTray();
          renderMobileSimonButtons(q);
          if (simonUserSeq.length === simonTargetSeq.length) {
            setTimeout(checkMobileSimonSubmit, 250);
          }
        };
        box.appendChild(btn);
      });
    }

    function resetMobileSimonInput() {
      simonUserSeq = [];
      const q = activeQuestion;
      renderMobileSimonTray();
      renderMobileSimonButtons(q);
    }

    function checkMobileSimonSubmit() {
      if (hasAnsweredCurrent || simonUserSeq.length === 0) return;
      const userIds = simonUserSeq.map(i => i.id);
      const targetIds = simonTargetSeq.map(i => i.id);
      const isMatch = (userIds.length === targetIds.length) &&
                      userIds.every((v, idx) => v === targetIds[idx]);
      submitMobileAnswer(isMatch, activeQuestion.points);
    }

    // ── PREGUNTA 40 MÓVIL ──
    function submitMobileQ40() {
      if (hasAnsweredCurrent) return;
      const text = (document.getElementById('m-q40-text').value || '').trim();
      if (text.length < 5) {
        alert('Por favor escribe tu respuesta antes de enviarla.');
        return;
      }
      hasAnsweredCurrent = true;

      if (window.confetti) window.confetti({ particleCount: 90, spread: 80 });
      if (navigator.vibrate) navigator.vibrate([100, 50, 150]);

      const feed = document.getElementById('m-feedback');
      feed.classList.remove('hidden');
      feed.className = 'p-3 rounded-xl text-xs font-black bg-amber-950/80 border border-amber-500 text-amber-200';
      feed.innerHTML = `🌟 ¡RESPUESTA ENVIADA AL PROYECTOR!<br><span class="text-[10px] text-emerald-300 font-normal">+500 PTS Otorgados</span>`;

      player.score += 500;
      document.getElementById('header-player-score').textContent = `${player.score} pts`;

      fetch('/api/answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          playerId: player.id,
          playerName: player.name,
          playerColor: player.color,
          isOpenText: true,
          openText: text,
          points: 500,
          isCorrect: true
        })
      }).catch(()=>{});
    }
  </script>
</body>
</html>
'''

with open('join.html', 'w', encoding='utf-8') as f:
    f.write(html_join.strip())

print("join.html generado limpiamente sin errores.")

# Test scratch to verify Python capabilities
print("Python environment ready")

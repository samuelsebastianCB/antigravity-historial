import http.server
import socketserver

class TestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        self.end_headers()
        self.wfile.write(b"ThreadingHTTPServer is available and working!")

if hasattr(http.server, 'ThreadingHTTPServer'):
    print("ThreadingHTTPServer available!")
else:
    print("Fallback to socketserver ThreadingMixIn")

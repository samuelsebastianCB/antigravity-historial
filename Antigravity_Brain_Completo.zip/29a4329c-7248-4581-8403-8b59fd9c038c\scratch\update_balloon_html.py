import re

with open('balloon_trivia.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. SPLITFLAP & DEPARTURE BOARD & QR CSS
splitflap_css = '''
    /* ══════════════════════════════════════════════════════════════
       SPLIT-FLAP ANALOG TRAIN STATION DISPLAY (EUROPEAN SOLARI STYLE)
       tileColor: #111827, textColor: #f8fafc, tileRadius: 8px, gap: 6px
    ══════════════════════════════════════════════════════════════ */
    .splitflap-board-wrap {
      display: flex; flex-direction: column; align-items: center;
      margin: 14px auto 20px; max-width: 100%; overflow-x: auto;
    }
    .splitflap-row {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 6px 10px; background: #080c14; border-radius: 12px;
      border: 1px solid rgba(255,255,255,0.08);
      box-shadow: 0 8px 24px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.1);
    }
    .splitflap-tile {
      position: relative; width: 34px; height: 50px;
      background: #111827; border-radius: 8px; perspective: 350px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.12), inset 0 -1px 0 rgba(0,0,0,0.8);
      user-select: none; flex-shrink: 0;
    }
    /* Horizontal split crease slit */
    .splitflap-tile::after {
      content: ''; position: absolute; top: 50%; left: 0; right: 0;
      height: 1.5px; background: #030712;
      box-shadow: 0 1px 0 rgba(255,255,255,0.08);
      z-index: 10; pointer-events: none;
    }
    /* Side pivot notches */
    .splitflap-tile::before {
      content: ''; position: absolute; top: calc(50% - 3px); left: 1px; right: 1px;
      height: 6px; background: transparent;
      border-left: 2px solid #475569; border-right: 2px solid #475569;
      z-index: 11; pointer-events: none;
    }
    .sf-half {
      position: absolute; left: 0; right: 0; height: 50%; overflow: hidden;
      background: #111827; color: #f8fafc;
      font-family: 'Roboto Mono', 'SF Mono', 'Courier New', monospace;
      font-weight: 900; font-size: 30px; line-height: 50px; text-align: center;
      backface-visibility: hidden; transform-style: preserve-3d;
    }
    .sf-top-back { top: 0; border-radius: 8px 8px 0 0; }
    .sf-top-back span {
      position: absolute; top: 0; left: 0; width: 100%; height: 200%;
      display: flex; align-items: center; justify-content: center;
    }
    .sf-bottom-back { bottom: 0; border-radius: 0 0 8px 8px; }
    .sf-bottom-back span {
      position: absolute; bottom: 0; left: 0; width: 100%; height: 200%;
      display: flex; align-items: center; justify-content: center;
    }
    .sf-top-flip {
      top: 0; border-radius: 8px 8px 0 0; transform-origin: bottom center;
      z-index: 5; transition: transform 0.06s ease-in;
    }
    .sf-top-flip span {
      position: absolute; top: 0; left: 0; width: 100%; height: 200%;
      display: flex; align-items: center; justify-content: center;
    }
    .sf-bottom-flip {
      bottom: 0; border-radius: 0 0 8px 8px; transform-origin: top center;
      transform: rotateX(90deg); z-index: 5; transition: transform 0.06s ease-out;
    }
    .sf-bottom-flip span {
      position: absolute; bottom: 0; left: 0; width: 100%; height: 200%;
      display: flex; align-items: center; justify-content: center;
    }

    /* Small SplitFlap tile for table rows */
    .sf-sm { width: 22px; height: 32px; border-radius: 5px; }
    .sf-sm::after { height: 1px; }
    .sf-sm .sf-half { font-size: 18px; line-height: 32px; border-radius: 5px; }

    /* European Train Station Board Modal */
    #station-board-modal {
      display: none; position: fixed; inset: 0; z-index: 250;
      background: rgba(4, 7, 14, 0.94); backdrop-filter: blur(14px);
      align-items: center; justify-content: center; padding: 16px;
    }
    .station-casing {
      background: #090e17;
      border: 3px solid #1e293b;
      box-shadow: 0 25px 60px rgba(0,0,0,0.85), inset 0 2px 0 rgba(255,255,255,0.1), 0 0 0 1px #0f172a;
      border-radius: 24px; max-width: 900px; width: 100%; max-height: 90vh;
      display: flex; flex-direction: column; overflow: hidden;
    }
    .station-header-bar {
      background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
      padding: 16px 22px; border-bottom: 2px solid #334155;
      display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;
    }
    .station-badge {
      background: #f59e0b; color: #000; font-weight: 900; font-size: 0.72rem;
      letter-spacing: 1.5px; padding: 3px 8px; border-radius: 4px; text-transform: uppercase;
    }
    .station-grid-table {
      width: 100%; border-collapse: separate; border-spacing: 0 6px;
      font-family: 'Roboto Mono', 'SF Mono', monospace; font-size: 0.85rem;
    }
    .station-grid-table th {
      color: #94a3b8; font-size: 0.7rem; font-weight: 900; letter-spacing: 2px;
      text-transform: uppercase; padding: 8px 12px; text-align: left;
      border-bottom: 1px solid rgba(255,255,255,0.08);
    }
    .station-row {
      background: #0d131f; transition: background 0.2s;
    }
    .station-row td {
      padding: 8px 12px; vertical-align: middle;
    }
    .station-row:hover { background: #131b2c; }

    /* QR Code Modal */
    #qr-modal {
      display: none; position: fixed; inset: 0; z-index: 300;
      background: rgba(0,0,0,0.85); backdrop-filter: blur(10px);
      align-items: center; justify-content: center; padding: 20px;
    }
    .qr-modal-inner {
      background: #0f172a; border: 1.5px solid #334155;
      border-radius: 28px; padding: 28px 24px; max-width: 440px; width: 100%;
      text-align: center; box-shadow: 0 20px 50px rgba(0,0,0,0.7);
    }
    .qr-box {
      background: #fff; padding: 16px; border-radius: 20px; display: inline-block;
      margin: 14px auto; box-shadow: 0 10px 30px rgba(0,0,0,0.5);
    }

    /* Floating quick buttons */
    #btn-quick-qr {
      position: fixed; bottom: 68px; right: 16px; z-index: 200;
      background: linear-gradient(135deg, #6366f1, #8b5cf6);
      border: 1px solid rgba(255,255,255,0.3);
      border-radius: 50%; width: 44px; height: 44px; font-size: 1.25rem;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      backdrop-filter: blur(8px); transition: all 0.2s; color: #fff;
      box-shadow: 0 6px 18px rgba(99,102,241,0.45);
    }
    #btn-quick-qr:hover { transform: scale(1.1); box-shadow: 0 8px 24px rgba(99,102,241,0.6); }

    #btn-quick-station {
      position: fixed; bottom: 120px; right: 16px; z-index: 200;
      background: linear-gradient(135deg, #1e293b, #0f172a);
      border: 1px solid rgba(255,255,255,0.25);
      border-radius: 50%; width: 44px; height: 44px; font-size: 1.25rem;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      backdrop-filter: blur(8px); transition: all 0.2s; color: #fff;
      box-shadow: 0 6px 18px rgba(0,0,0,0.5);
    }
    #btn-quick-station:hover { transform: scale(1.1); border-color: #f59e0b; }
'''

# Insert CSS into <style id="teams-styles">
html = html.replace('<style id="teams-styles">', '<style id="teams-styles">\n' + splitflap_css)

# 2. Insert Floating Buttons before </body>
floating_buttons = '''
<!-- Quick Floating Buttons: QR and Station Board -->
<button id="btn-quick-qr" onclick="openQrModal()" title="Código QR para conectar celulares">📲</button>
<button id="btn-quick-station" onclick="openStationBoard()" title="Tablero Analógico Split-Flap">🚂</button>
'''
html = html.replace('</body>', floating_buttons + '\n</body>')

# 3. Add SplitFlap announcement ticker and Action Buttons in #main-screen
target_header_btn = '<button onclick="openScoreTable()"'
splitflap_top_bar = '''
    <!-- ══ SPLIT-FLAP ANALOG TRAIN STATION TICKER ══ -->
    <div class="splitflap-board-wrap">
      <div style="font-size:0.65rem;font-weight:900;letter-spacing:2px;color:#f59e0b;text-transform:uppercase;margin-bottom:6px;display:flex;align-items:center;gap:6px;">
        <span class="station-badge">HORARIO / DEPARTURES</span>
        <span style="color:#94a3b8;">ESTACIÓN CENTRAL LA SALLE</span>
        <span class="pulse-dot"></span>
      </div>
      <div id="splitflap-ticker" class="splitflap-row"></div>
    </div>
'''

html = html.replace('<div id="total-score-badge">', splitflap_top_bar + '    <div id="total-score-badge">')

new_buttons = '''      <button onclick="openStationBoard()"
        style="background:linear-gradient(135deg,rgba(30,41,59,0.9),rgba(15,23,42,0.95));border:1px solid rgba(245,158,11,0.5);border-radius:50px;padding:8px 22px;font-size:0.82rem;font-weight:800;color:#f59e0b;cursor:pointer;font-family:inherit;transition:all 0.2s;backdrop-filter:blur(6px);box-shadow:0 4px 14px rgba(245,158,11,0.15);"
        onmouseover="this.style.transform='scale(1.04)'" onmouseout="this.style.transform='scale(1)'">
        🚂 Tablero de Estación (Split-Flap)
      </button>
      <button onclick="openQrModal()"
        style="background:linear-gradient(135deg,rgba(99,102,241,0.25),rgba(139,92,246,0.25));border:1px solid rgba(168,85,247,0.5);border-radius:50px;padding:8px 22px;font-size:0.82rem;font-weight:800;color:#c084fc;cursor:pointer;font-family:inherit;transition:all 0.2s;backdrop-filter:blur(6px);box-shadow:0 4px 14px rgba(139,92,246,0.2);"
        onmouseover="this.style.transform='scale(1.04)'" onmouseout="this.style.transform='scale(1)'">
        📲 Unirse con QR
      </button>
'''
html = html.replace(target_header_btn, new_buttons + '      ' + target_header_btn)

# 4. Add Station Board Modal and QR Modal HTML
modals_html = '''
  <!-- ══════════════════════════════════════════
       EUROPEAN ANALOG TRAIN STATION DEPARTURE BOARD (SOLARI DI UDINE STYLE)
  ══════════════════════════════════════════ -->
  <div id="station-board-modal">
    <div class="station-casing">
      <div class="station-header-bar">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-size:1.8rem;">🚂</span>
          <div>
            <div style="font-size:1.15rem;font-weight:900;letter-spacing:1px;color:#f8fafc;font-family:'Roboto Mono',monospace;">
              TABLERO DE SALIDAS & PUNTUACIÓN
            </div>
            <div style="font-size:0.75rem;color:#94a3b8;font-family:'Roboto Mono',monospace;">
              ESTACIÓN TRIVIA // LEY DE MILLER // SISTEMA SOLARI
            </div>
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:14px;">
          <div style="text-align:right;font-family:'Roboto Mono',monospace;">
            <div id="station-clock" style="font-size:1.1rem;font-weight:900;color:#f59e0b;">12:00:00</div>
            <div style="font-size:0.7rem;color:#4ade80;">● SISTEMA SINCRONIZADO</div>
          </div>
          <button onclick="toggleFlapSound()" id="btn-sound-toggle"
            style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.2);border-radius:12px;padding:8px 12px;font-size:0.8rem;color:#fff;cursor:pointer;">
            🔊 Sonido On
          </button>
          <button onclick="closeStationBoard()"
            style="background:rgba(255,255,255,0.1);border:none;border-radius:50%;width:36px;height:36px;color:#fff;font-size:1.2rem;cursor:pointer;">
            ✕
          </button>
        </div>
      </div>

      <!-- Station Table Rows -->
      <div style="padding:16px 20px;overflow-y:auto;flex:1;">
        <table class="station-grid-table">
          <thead>
            <tr>
              <th style="width:70px;">VÍA</th>
              <th>PASAJERO (ALUMNO)</th>
              <th style="width:110px;">COLOR</th>
              <th style="width:130px;">PUNTOS</th>
              <th style="width:120px;">ESTADO</th>
            </tr>
          </thead>
          <tbody id="station-table-body">
            <!-- Dynamic SplitFlap Rows -->
          </tbody>
        </table>
        <div id="station-empty-msg" style="text-align:center;padding:32px 10px;color:#64748b;font-size:0.85rem;font-family:'Roboto Mono',monospace;">
          ESPERANDO PASAJEROS... ESCANEA EL CÓDIGO QR PARA SUBIR A BORDO.
        </div>
      </div>

      <!-- Station Footer -->
      <div style="padding:12px 20px;background:#060a12;border-top:1px solid #1e293b;display:flex;justify-content:space-between;align-items:center;font-size:0.75rem;color:#64748b;font-family:'Roboto Mono',monospace;">
        <div><span>TOTAL PASAJEROS:</span> <span id="station-passenger-count" style="color:#f8fafc;font-weight:900;">0</span></div>
        <button onclick="openQrModal()" style="color:#c084fc;font-weight:bold;background:none;border:none;cursor:pointer;">
          📲 Mostrar código QR de abordaje →
        </button>
      </div>
    </div>
  </div>

  <!-- ══════════════════════════════════════════
       QR CODE CONNECTION MODAL FOR MOBILE DEVICES
  ══════════════════════════════════════════ -->
  <div id="qr-modal">
    <div class="qr-modal-inner">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <span style="font-weight:900;font-size:1.15rem;color:#f8fafc;">📲 Conectar con tu Teléfono</span>
        <button onclick="closeQrModal()" style="background:none;border:none;color:rgba(255,255,255,0.5);font-size:1.4rem;cursor:pointer;">✕</button>
      </div>
      <p style="color:#94a3b8;font-size:0.85rem;margin:0 0 14px;">
        Apunta la cámara de tu celular al código QR para unirte a la partida en vivo.
      </p>

      <div class="qr-box">
        <img id="qr-code-img" src="" alt="Código QR para unirse" width="220" height="220" style="display:block;margin:0 auto;" />
      </div>

      <div style="margin:12px 0;">
        <div style="font-size:0.75rem;color:#64748b;text-transform:uppercase;font-weight:bold;margin-bottom:4px;">Enlace Directo</div>
        <div id="qr-url-text" style="font-family:'Roboto Mono',monospace;font-size:0.82rem;color:#38bdf8;background:rgba(15,23,42,0.8);padding:8px 12px;border-radius:10px;word-break:break-all;border:1px solid #1e293b;">
          Cargando enlace...
        </div>
      </div>

      <div style="display:flex;gap:10px;justify-content:center;margin-top:16px;">
        <button onclick="copyJoinUrl()" id="btn-copy-url"
          style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:50px;padding:8px 18px;font-size:0.82rem;font-weight:bold;color:#fff;cursor:pointer;">
          📋 Copiar Enlace
        </button>
        <button onclick="closeQrModal(); openStationBoard();"
          style="background:linear-gradient(135deg,#7c3aed,#4f46e5);border:none;border-radius:50px;padding:8px 18px;font-size:0.82rem;font-weight:bold;color:#fff;cursor:pointer;">
          🚂 Ver Tablero
        </button>
      </div>

      <div style="margin-top:14px;padding-top:12px;border-top:1px solid rgba(255,255,255,0.08);font-size:0.78rem;color:#94a3b8;">
        👥 Pasajeros registrados: <span id="qr-passenger-counter" style="color:#4ade80;font-weight:900;">0</span>
      </div>
    </div>
  </div>
'''

html = html.replace('<!-- ── Score table modal ── -->', modals_html + '\n  <!-- ── Score table modal ── -->')

with open('balloon_trivia.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("Updated HTML structure with SplitFlap and QR modals successfully.")

import os
import shutil
import sys

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

dest_dir = r"C:\Users\HP ZBOOK\Desktop\Trivia_Ley_de_Miller"
os.makedirs(dest_dir, exist_ok=True)

src_dir = r"C:\Users\HP ZBOOK\.gemini\antigravity\brain\29a4329c-7248-4581-8403-8b59fd9c038c"
files = ['balloon_trivia.html', 'join.html', 'server.py', 'questions_data.json', 'trivia_miller_colab.ipynb']

for f in files:
    src = os.path.join(src_dir, f)
    dst = os.path.join(dest_dir, f)
    shutil.copy2(src, dst)
    print(f"Copiado {f} a {dest_dir}")

# Copiar el .ipynb a Descargas también
downloads_dst = r"C:\Users\HP ZBOOK\Downloads\trivia_miller_colab.ipynb"
shutil.copy2(os.path.join(src_dir, 'trivia_miller_colab.ipynb'), downloads_dst)
print(f"Copiado trivia_miller_colab.ipynb a {downloads_dst}")

# Crear Iniciar_Juego.bat dentro de la carpeta
bat_inside = f'''@echo off
title Servidor Trivia Ley de Miller
chcp 65001 > nul
cls
echo ============================================================
echo   🎈🚂 INICIANDO SERVIDOR TRIVIA LEY DE MILLER
echo ============================================================
echo.
timeout /t 1 > nul
start "" http://localhost:5000/
python server.py 5000
pause
'''
with open(os.path.join(dest_dir, 'Iniciar_Juego.bat'), 'w', encoding='utf-8') as f:
    f.write(bat_inside)

# Crear Iniciar_Trivia_Miller.bat directamente en el Escritorio
desktop_bat = f'''@echo off
title Trivia Ley de Miller
chcp 65001 > nul
cd /d "{dest_dir}"
cls
echo ============================================================
echo   🎈🚂 INICIANDO SERVIDOR TRIVIA LEY DE MILLER
echo ============================================================
echo.
timeout /t 1 > nul
start "" http://localhost:5000/
python server.py 5000
pause
'''
with open(r"C:\Users\HP ZBOOK\Desktop\Iniciar_Trivia_Miller.bat", 'w', encoding='utf-8') as f:
    f.write(desktop_bat)

print("✅ Todos los archivos exportados exitosamente al Escritorio y Descargas.")

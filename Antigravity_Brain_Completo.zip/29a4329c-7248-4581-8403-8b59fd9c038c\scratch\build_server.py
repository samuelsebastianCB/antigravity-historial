# Server creator script
import os

print("Writing server.py...")

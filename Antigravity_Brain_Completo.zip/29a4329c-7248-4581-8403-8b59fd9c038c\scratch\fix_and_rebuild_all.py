import os
import shutil
import json
import sys

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

ROOT_DIR = r"C:\Users\HP ZBOOK\.gemini\antigravity\brain\29a4329c-7248-4581-8403-8b59fd9c038c"
DESKTOP_DIR = r"C:\Users\HP ZBOOK\Desktop\Trivia_Ley_de_Miller"
DOWNLOADS_DIR = r"C:\Users\HP ZBOOK\Downloads"

os.makedirs(DESKTOP_DIR, exist_ok=True)
os.makedirs(DOWNLOADS_DIR, exist_ok=True)

# 1. Cargar preguntas
q_path = os.path.join(ROOT_DIR, 'questions_data.json')
with open(q_path, 'r', encoding='utf-8') as f:
    questions = json.load(f)

print(f"Cargadas {len(questions)} preguntas.")

# 2. Cargar código fuente de balloon_html y join_html desde build_player_independent_sessions.py
# O leer el script build_player_independent_sessions.py
build_script_path = os.path.join(ROOT_DIR, 'scratch', 'build_player_independent_sessions.py')
with open(build_script_path, 'r', encoding='utf-8') as f:
    code = f.read()

# Ejecutar el script pero asegurando que la ruta destino sea absoluta
local_scope = {'__file__': build_script_path}
exec(code, local_scope)

balloon_html = local_scope.get('balloon_html')
join_html = local_scope.get('join_html')

assert balloon_html and len(balloon_html) > 5000, "balloon_html está vacío"
assert join_html and len(join_html) > 5000, "join_html está vacío"

# Escribir en ROOT_DIR
balloon_target = os.path.join(ROOT_DIR, 'balloon_trivia.html')
join_target = os.path.join(ROOT_DIR, 'join.html')

with open(balloon_target, 'w', encoding='utf-8') as f:
    f.write(balloon_html.strip())

with open(join_target, 'w', encoding='utf-8') as f:
    f.write(join_html.strip())

print(f"✅ balloon_trivia.html escrito ({len(balloon_html)} bytes)")
print(f"✅ join.html escrito ({len(join_html)} bytes)")

# 3. Regenerar trivia_miller_colab.ipynb
with open(os.path.join(ROOT_DIR, 'server.py'), 'r', encoding='utf-8') as f:
    server_py = f.read()

with open(os.path.join(ROOT_DIR, 'questions_data.json'), 'r', encoding='utf-8') as f:
    questions_json = f.read()

colab_setup_code = f'''# @title 🚀 INICIAR SERVIDOR TRIVIA ONLINE + TÚNEL CLOUDFLARE + CÓDIGO QR
# @markdown Haz clic en el botón de reproducción ▶ a la izquierda para iniciar todo automáticamente.

import os, sys, time, subprocess, re, urllib.request

print("⚙️ Preparando entorno en Google Colab...")

# 1. Instalar librerías de QR
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "pyqrcode", "pypng"], check=True)
import pyqrcode

# 2. Escribir archivos de la aplicación
with open("balloon_trivia.html", "w", encoding="utf-8") as f:
    f.write({json.dumps(balloon_html)})

with open("join.html", "w", encoding="utf-8") as f:
    f.write({json.dumps(join_html)})

with open("server.py", "w", encoding="utf-8") as f:
    f.write({json.dumps(server_py)})

with open("questions_data.json", "w", encoding="utf-8") as f:
    f.write({json.dumps(questions_json)})

print("✅ Archivos de juego generados con éxito.")

# 3. Descargar Cloudflare Tunnel (cloudflared) para URL pública HTTPS gratuita y sin cuentas
if not os.path.exists("cloudflared"):
    print("⬇️ Descargando Cloudflare Tunnel...")
    urllib.request.urlretrieve(
        "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
        "cloudflared"
    )
    os.chmod("cloudflared", 0o777)
    print("✅ Cloudflared listo.")

# 4. Iniciar servidor Python en segundo plano
print("🚀 Iniciando servidor Trivia en puerto 5000...")
server_proc = subprocess.Popen([sys.executable, "server.py", "5000"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.5)

# 5. Iniciar Cloudflare Tunnel
print("🌐 Creando túnel público HTTPS seguro...")
if os.path.exists("tunnel.log"):
    os.remove("tunnel.log")

tunnel_proc = subprocess.Popen(
    ["./cloudflared", "tunnel", "--url", "http://127.0.0.1:5000", "--logfile", "tunnel.log"],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)

public_url = None
for _ in range(30):
    time.sleep(1)
    if os.path.exists("tunnel.log"):
        with open("tunnel.log", "r", encoding="utf-8", errors="ignore") as f:
            log_data = f.read()
            match = re.search(r"https://[a-zA-Z0-9-]+\\.trycloudflare\\.com", log_data)
            if match:
                public_url = match.group(0)
                break

if not public_url:
    print("⚠️ No se pudo obtener la URL de Cloudflare en 30s. Mostrando log:")
    if os.path.exists("tunnel.log"):
        with open("tunnel.log", "r") as f: print(f.read())
    sys.exit(1)

host_url = public_url + "/"
join_url = public_url + "/join"

# Generar QR para el link de alumnos
qr = pyqrcode.create(join_url)
qr.png("qr_join.png", scale=8)

# 6. Mostrar panel con enlaces y QR en Google Colab
from IPython.display import display, HTML

display_html = f"""
<div style="background:#0b0f17;border:2px solid #334155;border-radius:24px;padding:24px;max-width:680px;font-family:system-ui,sans-serif;color:#f8fafc;box-shadow:0 20px 40px rgba(0,0,0,0.6);margin:16px 0;">
  <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">
    <span style="font-size:2rem;">🎈🚂</span>
    <div>
      <h2 style="margin:0;font-size:1.4rem;font-weight:900;color:#c084fc;">TRIVIA MILLER — SALA ONLINE EN VIVO</h2>
      <p style="margin:2px 0 0;font-size:0.8rem;color:#94a3b8;">Servidor conectado y listo para proyectar</p>
    </div>
  </div>

  <div style="background:#1e293b;border-radius:16px;padding:16px;margin-bottom:16px;">
    <div style="font-size:0.75rem;font-weight:bold;color:#f59e0b;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">
      🖥️ PANTALLA DEL MAESTRO / PROYECTOR:
    </div>
    <a href="{{host_url}}" target="_blank" style="font-size:1.05rem;font-weight:900;color:#38bdf8;text-decoration:none;display:inline-block;word-break:break-all;">
      👉 Abrir Juego en Proyector: {{host_url}}
    </a>
  </div>

  <div style="background:#1e293b;border-radius:16px;padding:16px;margin-bottom:16px;display:flex;align-items:center;gap:20px;flex-wrap:wrap;">
    <div style="background:#fff;padding:10px;border-radius:14px;display:inline-block;box-shadow:0 8px 20px rgba(0,0,0,0.5);">
      <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data={{join_url}}&margin=2" width="180" height="180" style="display:block;" alt="QR Alumnos" />
    </div>
    <div style="flex:1;min-width:200px;">
      <div style="font-size:0.75rem;font-weight:bold;color:#4ade80;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">
        📱 ESCANEAR QR PARA PARTICIPANTES:
      </div>
      <p style="font-size:0.85rem;color:#cbd5e1;margin:0 0 10px;line-height:1.4;">
        Pide a los alumnos que apunten su cámara a este código o entren directamente a:
      </p>
      <a href="{{join_url}}" target="_blank" style="font-size:0.95rem;font-weight:bold;color:#a855f7;word-break:break-all;text-decoration:none;">
        {{join_url}}
      </a>
      <div style="margin-top:10px;font-size:0.75rem;color:#94a3b8;">
        ✅ Registro con nombre<br/>
        ✅ Color aleatorio asignado<br/>
        ✅ Tablero Split-Flap en vivo
      </div>
    </div>
  </div>

  <div style="font-size:0.75rem;color:#64748b;text-align:center;">
    🟢 Servidor en ejecución. Mantén esta celda corriendo durante la clase.
  </div>
</div>
"""

display(HTML(display_html))

try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("Deteniendo servidor...")
    server_proc.terminate()
    tunnel_proc.terminate()
'''

notebook = {
    "cells": [
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "# 🎈🚂 Trivia Ley de Miller — Servidor Online con QR y Tablero Split-Flap\n",
                "### Juego interactivo multijugador con conexión por código QR, registro de participantes con colores aleatorios y Tablero Analógico de Estación de Trenes (Solari di Udine).\n",
                "\n",
                "---\n",
                "\n",
                "### 📖 Instrucciones de uso:\n",
                "1. Haz clic en el botón de **Ejecutar ▶** de la celda siguiente.\n",
                "2. Google Colab descargará el túnel seguro y pondrá el servidor en línea en segundos.\n",
                "3. Aparecerá el **Código QR** y los enlaces:\n",
                "   - **🖥️ Pantalla del Maestro (Proyector):** Haz clic para abrir la vista principal del juego en pantalla completa.\n",
                "   - **📱 Para Alumnos:** Pide a los alumnos que escaneen el código QR con la cámara de su celular o abran el enlace para registrar su nombre.\n",
                "4. Cada alumno recibe un **color aleatorio vibrante** y aparece de inmediato en el **Tablero Analógico Split-Flap** con sonido mecánico.\n",
                "5. ¡Al abrir un globo en la pantalla principal, la pregunta aparece automáticamente en los teléfonos de todos los alumnos!"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {
                "cellView": "form"
            },
            "outputs": [],
            "source": [colab_setup_code]
        }
    ],
    "metadata": {
        "colab": {
            "provenance": []
        },
        "kernelspec": {
            "name": "python3",
            "display_name": "Python 3"
        },
        "language_info": {
            "name": "python"
        }
    },
    "nbformat": 4,
    "nbformat_minor": 0
}

ipynb_target = os.path.join(ROOT_DIR, 'trivia_miller_colab.ipynb')
with open(ipynb_target, 'w', encoding='utf-8') as f:
    json.dump(notebook, f, indent=2, ensure_ascii=False)
print("✅ trivia_miller_colab.ipynb generado.")

# 4. Guardar también el código puro de Colab en un archivo .py fácil de copiar
colab_py_target = os.path.join(ROOT_DIR, 'colab_script_copiar_pegar.py')
with open(colab_py_target, 'w', encoding='utf-8') as f:
    f.write(colab_setup_code)
print("✅ colab_script_copiar_pegar.py generado.")

# 5. Copiar TODO al Escritorio y Descargas
files_to_export = [
    'balloon_trivia.html',
    'join.html',
    'server.py',
    'questions_data.json',
    'trivia_miller_colab.ipynb',
    'colab_script_copiar_pegar.py'
]

for f in files_to_export:
    s = os.path.join(ROOT_DIR, f)
    d = os.path.join(DESKTOP_DIR, f)
    shutil.copy2(s, d)
    print(f"Copiado a Escritorio: {f} ({os.path.getsize(d)} bytes)")

# Copiar el .ipynb y el script a Descargas
shutil.copy2(os.path.join(ROOT_DIR, 'trivia_miller_colab.ipynb'), os.path.join(DOWNLOADS_DIR, 'trivia_miller_colab.ipynb'))
shutil.copy2(os.path.join(ROOT_DIR, 'colab_script_copiar_pegar.py'), os.path.join(DOWNLOADS_DIR, 'colab_script_copiar_pegar.py'))
print("Copiado a Descargas: trivia_miller_colab.ipynb y colab_script_copiar_pegar.py")

# 6. Crear los lanzadores .bat
bat_inside = '''@echo off
title Servidor Trivia Ley de Miller
chcp 65001 > nul
cls
echo ============================================================
echo   🎈🚂 INICIANDO SERVIDOR TRIVIA LEY DE MILLER
echo ============================================================
echo.
echo Abriendo navegador en http://localhost:5000/ ...
timeout /t 1 > nul
start "" http://localhost:5000/
python server.py 5000
pause
'''
with open(os.path.join(DESKTOP_DIR, 'Iniciar_Juego.bat'), 'w', encoding='utf-8') as f:
    f.write(bat_inside)

desktop_bat = f'''@echo off
title Trivia Ley de Miller
chcp 65001 > nul
cd /d "{DESKTOP_DIR}"
cls
echo ============================================================
echo   🎈🚂 INICIANDO SERVIDOR TRIVIA LEY DE MILLER
echo ============================================================
echo.
echo Abriendo navegador en http://localhost:5000/ ...
timeout /t 1 > nul
start "" http://localhost:5000/
python server.py 5000
pause
'''
with open(r"C:\Users\HP ZBOOK\Desktop\Iniciar_Trivia_Miller.bat", 'w', encoding='utf-8') as f:
    f.write(desktop_bat)

print("\n🎉 RECONSTRUCCIÓN Y EXPORTACIÓN EXITOSA.")

import subprocess
import sys
import time
import urllib.request
import json

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

print("Iniciando server.py de prueba...")
proc = subprocess.Popen([sys.executable, "server.py", "5055"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
time.sleep(2)

try:
    # 1. Probar GET /
    req = urllib.request.urlopen("http://127.0.0.1:5055/")
    assert req.status == 200
    html = req.read().decode('utf-8')
    assert "TRIVIA: LA LEY DE MILLER" in html
    assert "team-setup-modal" not in html  # Verificar que el modal de equipos NO está
    assert "SoyGenesis" in html            # Verificar código del profesor
    print("✅ GET /: OK (Servidor proyecta pantalla anfitrión sin modal de equipos)")

    # 2. Probar GET /join.html
    req2 = urllib.request.urlopen("http://127.0.0.1:5055/join.html")
    assert req2.status == 200
    join_html = req2.read().decode('utf-8')
    assert "TRIVIA: LEY DE MILLER" in join_html
    print("✅ GET /join.html: OK (Pantalla móvil de alumnos con cuadrícula independiente)")

    # 3. Probar GET /api/host-info
    req_info = urllib.request.urlopen("http://127.0.0.1:5055/api/host-info")
    info = json.loads(req_info.read().decode('utf-8'))
    assert "ip" in info and "joinUrl" in info
    print(f"✅ GET /api/host-info: OK ({info['joinUrl']})")

    # 4. Probar POST /api/register
    reg_data = json.dumps({"name": "AlumnoTest", "color": "#f43f5e"}).encode('utf-8')
    req3 = urllib.request.Request("http://127.0.0.1:5055/api/register", data=reg_data, headers={"Content-Type": "application/json"})
    res3 = json.loads(urllib.request.urlopen(req3).read().decode('utf-8'))
    assert res3["success"] is True
    pid = res3["player"]["id"]
    print(f"✅ POST /api/register: OK (Jugador registrado: {pid})")

    # 5. Probar POST /api/pop (Globo 31 Simón Dice)
    with open('questions_data.json', 'r', encoding='utf-8') as f:
        q_list = json.load(f)
    q31 = q_list[30]
    pop_data = json.dumps({"num": 31, "points": 300, "question": q31}).encode('utf-8')
    req4 = urllib.request.Request("http://127.0.0.1:5055/api/pop", data=pop_data, headers={"Content-Type": "application/json"})
    res4 = json.loads(urllib.request.urlopen(req4).read().decode('utf-8'))
    assert res4["success"] is True
    print("✅ POST /api/pop: OK (Globo Simón Dice abierto)")

    # 6. Probar POST /api/answer (Simón Dice correcto)
    ans_data = json.dumps({
        "playerId": pid,
        "playerName": "AlumnoTest",
        "isCorrect": True,
        "points": 300,
        "questionNum": 31
    }).encode('utf-8')
    req5 = urllib.request.Request("http://127.0.0.1:5055/api/answer", data=ans_data, headers={"Content-Type": "application/json"})
    res5 = json.loads(urllib.request.urlopen(req5).read().decode('utf-8'))
    assert res5["success"] is True
    assert res5["player"]["score"] == 300
    print("✅ POST /api/answer (Simón Dice): OK (Puntuación actualizada: 300 pts)")

    # 7. Probar POST /api/answer (Pregunta 40 Respuesta Abierta)
    q40_data = json.dumps({
        "playerId": pid,
        "playerName": "AlumnoTest",
        "isCorrect": True,
        "isOpenText": True,
        "openText": "La Ley de Miller demuestra que la memoria de trabajo retiene 7 ± 2 elementos y que el chunking nos ayuda a recordar más.",
        "points": 500,
        "questionNum": 40
    }).encode('utf-8')
    req6 = urllib.request.Request("http://127.0.0.1:5055/api/answer", data=q40_data, headers={"Content-Type": "application/json"})
    res6 = json.loads(urllib.request.urlopen(req6).read().decode('utf-8'))
    assert res6["success"] is True
    assert res6["player"]["score"] == 800
    print("✅ POST /api/answer (Pregunta 40 Abierta): OK (Puntuación final: 800 pts)")

    print("\n🎉 ¡TODAS LAS PRUEBAS DE INTEGRACIÓN DEL SERVIDOR Y FRONTENDS PASARON EXITOSAMENTE!")

finally:
    proc.terminate()
    proc.wait()

# Módulo de Análisis de Ventas con Serie de Fourier (panel admin)

Implementar, en el panel administrativo (`src/app`), un módulo **"Análisis de Fourier"** que lea las ventas reales de la BD, las agrupe por intervalo, ajuste una **Serie de Fourier** (única técnica usada), la compare contra los datos reales, detecte periodicidades, genere alertas de inventario y guarde cada análisis con trazabilidad completa. Además separa **ventas normales** de **compras internas**.

## Hallazgos de la investigación (estado actual)

| Tema | Estado actual | Impacto |
|---|---|---|
| Ventas | Tablas `SALE` (`SALE_ID, SALE_DATE, TOTAL_AMOUNT, CUSTOMER_ID, EMPLOYEE_ID`) y `SALE_DETAIL` (`SALE_ID, PRODUCT_ID, QUANTITY_SOLD, SUBTOTAL`). No hay precio unitario guardado: se deriva `SUBTOTAL / QUANTITY_SOLD`. | Alcanza para fecha, hora, producto, cantidad, precio y total. |
| Categoría | **No existe** en `PRODUCT` (`obtener_productos.php` no la devuelve; en el admin no hay ni una mención). El cliente la infiere por palabras del nombre. | Hay que crear `PRODUCT.CATEGORY` para poder filtrar por categoría. |
| Compras internas | **No existen.** `PURCHASE_ORDER` / `ORDER_DETAIL` son pedidos a *proveedores* (reabastecimiento), no consumo interno. `registrar_venta.php` registra todo como venta de cliente. | Hay que crear el concepto (ver Preguntas, #1). |
| Auditoría | No existe tabla de análisis. El login admin es un bypass `test/test` guardado en `localStorage` (`admin_sesion`), y los PHP no validan sesión. | Trazabilidad por usuario es declarativa (ver Preguntas, #4). |
| Datos históricos | No hay script de esquema ni de datos en el repo. | Requisito 9.1 ("datos suficientes") depende de tus datos reales (Pregunta #3). |
| Entorno | No hay PHP, MySQL ni MAMP en esta máquina (nada escuchando en 8889/3306). | No puedo ejecutar el backend aquí; ver Plan de Verificación. |
| Bug relacionado | `backend-cliente/.../finalizar_orden_cliente.php:33` hace `if ($order_id >= 0) throw …`, lo que **rechaza cualquier orden válida**: las órdenes de la tienda del cliente nunca se convierten en `SALE`. | Esas ventas nunca llegarán al análisis. Lo corregiría (1 línea) si lo apruebas. |

## Open Questions

> [!IMPORTANT]
> **#1 — "Compras internas": ¿cuál es la definición correcta?** Entiendo: *consumo propio* (empleado/admin/dueño se lleva producto), que **descuenta inventario**, queda registrado y **no cuenta como venta a cliente**. Lo modelaría como una fila de `SALE` con `SALE_TYPE='INTERNA'` (+ comprador y motivo), registrada desde el Punto de Venta con un interruptor "Compra interna". **No** las confundo con los pedidos a proveedores. ¿Es correcto?

> [!IMPORTANT]
> **#2 — Categoría.** Propongo columna `PRODUCT.CATEGORY` (texto), campo en "Nuevo/Editar producto" y backfill inicial por palabras clave del nombre (misma lógica que usa el cliente) para que no queden vacías. ¿Tienes una lista fija de categorías (Vinos, Tequila, Whisky, Cerveza…)?

> [!IMPORTANT]
> **#3 — Datos históricos.** Si tu BD no tiene meses de ventas, el análisis dirá "datos insuficientes". Puedo agregar un script **opcional** que genere ventas de **demostración** con patrón semanal/mensual, marcadas `IS_DEMO=1`, excluidas por defecto del análisis y con insignia visible en la UI. Como exigiste *datos reales*, **no lo ejecutaré ni lo mezclaré sin tu OK**. ¿Lo quieres?

> [!WARNING]
> **#4 — Autenticación.** Los endpoints PHP no validan quién llama (CORS `*`, sin token) y el login admite `test/test`. "Usuario autorizado" y "usuario que ejecutó el análisis" quedarán basados en `admin_sesion` del navegador (spoofeable). Endurecer auth (sesión/JWT en PHP) es una tarea aparte; **no la incluyo** salvo que la pidas. El módulo solo se muestra a rol Administrador.

> [!NOTE]
> **#5 — Variable analizada.** Por defecto **unidades vendidas**; seleccionable **ingresos ($)**. **#6 — Gráfica:** SVG propio sin dependencias nuevas (el proyecto solo usa `gsap`). ¿Prefieres Chart.js?

## Diseño del análisis (Fourier, sin otros métodos)

1. **Serie temporal**: ventas normales (y opcionalmente internas/demo vía filtros explícitos) agrupadas por **hora / día / semana / mes / año**, **rellenando con 0** los intervalos vacíos entre fecha inicial y final (sin esto la periodicidad se falsea).
2. **Serie de Fourier por mínimos cuadrados**: 
   `ŷ(t) = a₀ + Σₖ₌₁ᴷ [aₖ·cos(2πkt/P) + bₖ·sin(2πkt/P)]`
   - `K` = número de armónicos (configurable, 1–12, tope < N/2).
   - `P` = periodo base: **Auto (toda la ventana → DFT ortogonal exacto)**, o **Semanal / Mensual / Anual / Personalizado** (en intervalos). Con periodo base fijo evita el *leakage* (un ciclo de 7 días no cae en armónico entero de una ventana de 90 días).
3. **Valores calculados y mostrados**: frecuencia `fₖ = k/P`, periodo `P/k`, amplitud `Aₖ=√(aₖ²+bₖ²)`, fase, coeficientes `a₀, aₖ, bₖ`, nº de armónicos, observado vs. aproximado por intervalo, error (RMSE) y % de varianza explicada.
4. **Detección de patrones** (periodograma = espectro de Fourier): se escanean periodos candidatos y se reportan los dominantes traducidos a lenguaje llano: *"Patrón semanal: pico recurrente los viernes–sábados; baja demanda lunes–martes"*, *"Estacionalidad mensual/anual"*, *"Cambio de periodicidad entre primera y segunda mitad del periodo"* (se compara el espectro de ambas mitades).
5. **Alerta de inventario**: si un periodo dominante tiene amplitud relativa y varianza explicada sobre umbral **y** el siguiente pico (extrapolación de la misma serie de Fourier hacia adelante) cae dentro de un ciclo, se genera:  
   *"⚠️ Se detectó un patrón periódico de aumento de demanda para este producto. Revisar inventario y próximos pedidos."* Se muestra en el módulo y como insignia en **Inventario**.
6. **Trazabilidad**: cada ejecución se guarda en `FOURIER_ANALYSIS` con usuario, fecha/hora, producto/categoría, periodo, intervalo, métrica, armónicos, periodo base, filtros (internas/demo), **hash SHA-256 del conjunto de datos + nº de registros**, coeficientes, serie observada/aproximada y patrones. Se puede reabrir y **reproducir** (los coeficientes y la serie están guardados; el hash prueba si los datos cambiaron desde entonces).
7. **Dónde se calcula**: la matemática vive en un módulo TypeScript **puro** (`fourier.math.ts`), probado con vitest (verificable aquí aunque no haya PHP/MySQL). PHP agrega datos y persiste/consulta resultados.

## Proposed Changes

### Base de datos (migración idempotente)

#### [NEW] [fourier_migration.sql](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/sql/fourier_migration.sql)
- `ALTER TABLE SALE ADD COLUMN SALE_TYPE VARCHAR(10) NOT NULL DEFAULT 'NORMAL'`, `INTERNAL_BUYER VARCHAR(120) NULL`, `INTERNAL_REASON VARCHAR(255) NULL`, `IS_DEMO TINYINT(1) NOT NULL DEFAULT 0` (el histórico existente queda como `NORMAL`).
- `ALTER TABLE PRODUCT ADD COLUMN CATEGORY VARCHAR(60) NULL` + backfill por palabras clave.
- `CREATE TABLE FOURIER_ANALYSIS (…)` (campos de trazabilidad arriba).
- Índice en `SALE(SALE_DATE, SALE_TYPE)`.

#### [NEW] [esquema.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/config/esquema.php)
Helper `asegurarEsquema($conexion)` que aplica lo anterior solo si falta (consulta `information_schema`), para que funcione sin correr SQL a mano. Lo incluyen los endpoints nuevos y `registrar_venta.php`.

### Backend PHP (`vinateria-backend/`) — todo con *prepared statements*

#### [MODIFY] [registrar_venta.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/registrar_venta.php)
Acepta `tipo` (`NORMAL`|`INTERNA`), `comprador_interno`, `motivo`. Mantiene transacción, `FOR UPDATE` y descuento de stock (las internas **sí** afectan inventario). Rechaza `INTERNA` sin comprador. Respuesta añade `tipo`.

#### [MODIFY] [obtener_ventas.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/obtener_ventas.php)
Parámetro `tipo=normal|interna|todas` (**default `normal`**, para que las internas no se mezclen). Devuelve `tipo`, `comprador`, `motivo`.

#### [MODIFY] [obtener_productos.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/obtener_productos.php), [guardar_producto.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/guardar_producto.php), [actualizar_producto.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/vinateria-backend/actualizar_producto.php)
Leen/escriben `CATEGORY`.

#### [NEW] `obtener_registros_ventas.php`
Registros a nivel línea: `fecha, hora, sale_id, producto_id, producto, categoria, cantidad, precio_unitario, subtotal, total_venta, tipo`. Filtros: `producto_id`, `categoria`, `desde`, `hasta`, `tipo`, `incluir_demo`. Devuelve también `dataset_hash` y `total_registros`.

#### [NEW] `obtener_serie_ventas.php`
Agrupa en SQL por `intervalo` (`hora|dia|semana|mes|anio`), métrica (`unidades|ingresos`), mismos filtros; devuelve buckets ordenados + hash del conjunto.

#### [NEW] `obtener_compras_internas.php`
Historial **separado** de compras internas (con comprador, motivo, líneas, total, inventario descontado).

#### [NEW] `guardar_analisis_fourier.php` / `obtener_analisis_fourier.php`
Persistir un análisis (valida rangos, tamaño JSON) / listar (filtro por producto, usuario, fecha, con alerta) y obtener uno por id para reabrirlo.

### Frontend admin (`src/app`)

#### [NEW] `shared/fourier.math.ts` + `fourier.math.spec.ts`
Funciones puras: `buildSeries`, `fitFourier(y, K, P)` (mínimos cuadrados con solución de ecuaciones normales), `evaluate`, `harmonicTable`, `periodogram`, `detectPatterns`, `describePatterns`, `forecastNextPeak`, `buildAlert`. Pruebas: senoide conocida → recupera `A`, `f`, `φ`; con K=N/2 reproduce la serie exactamente; ventana con ceros; datos insuficientes.

#### [NEW] `services/fourier.service.ts`
Cliente de los endpoints nuevos con tipos fuertes (sin `any`).

#### [NEW] `fourier/fourier.ts|html|css`  (ruta `/fourier`)
- **Panel de parámetros**: producto, categoría, periodo (rápidos: 30/90/180 días, año, personalizado), fecha inicial/final, intervalo, métrica, armónicos (slider), periodo base, filtros explícitos "Incluir compras internas" / "Incluir datos demo". Resumen visible: *"Producto: X · Periodo: ene–jun 2026 · Intervalo: Diario · Armónicos: 5"*.
- **Gráfica SVG**: puntos reales + curva de Fourier, tooltip observado/aproximado/diferencia, se redibuja al cambiar cualquier filtro.
- **Tablas**: armónicos (frecuencia, periodo, amplitud, fase, a/b), valor observado vs aproximado por intervalo, registros de datos usados (exportables a CSV).
- **Tarjetas de patrones** en lenguaje llano + alerta ⚠️.
- **Guardar análisis** y **Historial** (usuario, fecha, parámetros, hash, resultado; botón "Reabrir/Reproducir").
- Mensajes claros: datos insuficientes (<2 ciclos o <14 intervalos), sin ventas en rango.

#### [MODIFY] [app.routes.ts](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/src/app/app.routes.ts), [admin.ts](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/src/app/admin/admin.ts), [admin.html](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/src/app/admin/admin.html)
Ruta `/fourier` con guard de rol y nueva tarjeta "Análisis de Fourier" en el panel.

#### [MODIFY] `punto-venta/*`, `services/ventas.service.ts`
Interruptor **"Compra interna"** (comprador obligatorio + motivo); el ticket se rotula "OPERACIÓN INTERNA".

#### [MODIFY] `reportes/*`
Pestañas **Ventas** (solo normales; KPIs y corte de caja **no** incluyen internas) y **Compras internas** (historial propio, etiqueta de operación interna).

#### [MODIFY] `inventario/*`, `nuevo-producto/*`, `editar-producto/*`, `services/inventario.service.ts`
Campo **Categoría**; insignia ⚠️ en productos con alerta de periodicidad vigente.

#### [MODIFY] [finalizar_orden_cliente.php](file:///c:/Users/HP%20ZBOOK/Desktop/VinateriaLaModerna-admin-angular/VinateriaLaModerna-admin-angular/backend-cliente/public/php/finalizar_orden_cliente.php) *(opcional, 1 línea)*
Corregir `if ($order_id >= 0)` → `<= 0` para que las ventas de la tienda lleguen a `SALE`.

## Verification Plan

### Automated Tests
- `npx ng test --watch=false` — pruebas unitarias de `fourier.math.spec.ts` (recuperación de amplitud/frecuencia/fase, reconstrucción exacta con todos los armónicos, relleno de ceros, umbrales de alerta, ejemplo semanal sintético).
- `npx ng build` — compilación sin errores de tipos/plantillas.

### Manual Verification (requiere tu MAMP/MySQL; aquí no hay PHP ni MySQL)
1. Ejecutar `sql/fourier_migration.sql` (o abrir cualquier endpoint nuevo: `esquema.php` lo aplica solo).
2. Registrar una venta normal y una **compra interna** en Punto de Venta → confirmar que ambas descuentan stock, que Reportes → *Ventas* solo muestra la normal y *Compras internas* solo la interna.
3. En `/fourier`: elegir producto, rango e intervalo → ver curva real vs Fourier; cambiar armónicos/intervalo y confirmar que la gráfica y la tabla se actualizan.
4. Guardar un análisis, recargar y reabrirlo desde el historial; comprobar usuario, fecha, parámetros, hash.
5. Marcar/ocultar "Incluir compras internas" y confirmar que cambia el nº de registros y el hash.
6. Con datos con picos semanales (reales o los demo, si los apruebas) verificar el mensaje de patrón y la alerta ⚠️ en Inventario.

## Alcance explícitamente fuera
Autenticación real (tokens/sesión servidor), otros algoritmos predictivos (prohibidos como sustituto; Fourier es el único método), y cambios en la tienda del cliente salvo el bugfix opcional.

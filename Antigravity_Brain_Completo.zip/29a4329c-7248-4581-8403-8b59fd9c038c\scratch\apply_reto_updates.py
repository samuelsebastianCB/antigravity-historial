import json, re

# Define sequence data for retos 31-39 and open text for 40
reto_data = {
    31: {
        "sequence": [
            {"id": "perro", "label": "Perro", "icon": "🐶"},
            {"id": "casa", "label": "Casa", "icon": "🏠"},
            {"id": "sol", "label": "Sol", "icon": "☀️"},
            {"id": "mesa", "label": "Mesa", "icon": "🪑"},
            {"id": "flor", "label": "Flor", "icon": "🌸"}
        ],
        "display": "Perro – Casa – Sol – Mesa – Flor"
    },
    32: {
        "sequence": [
            {"id": "4", "label": "4", "icon": "4️⃣"},
            {"id": "8", "label": "8", "icon": "8️⃣"},
            {"id": "2", "label": "2", "icon": "2️⃣"},
            {"id": "9", "label": "9", "icon": "9️⃣"},
            {"id": "1", "label": "1", "icon": "1️⃣"},
            {"id": "6", "label": "6", "icon": "6️⃣"},
            {"id": "3", "label": "3", "icon": "3️⃣"}
        ],
        "display": "4 – 8 – 2 – 9 – 1 – 6 – 3"
    },
    33: {
        "sequence": [
            {"id": "A", "label": "A", "icon": "🅰️"},
            {"id": "F", "label": "F", "icon": "🇫"},
            {"id": "M", "label": "M", "icon": "Ⓜ️"},
            {"id": "P", "label": "P", "icon": "🅿️"},
            {"id": "R", "label": "R", "icon": "🇷"},
            {"id": "T", "label": "T", "icon": "🇹"},
            {"id": "B", "label": "B", "icon": "🅱️"},
            {"id": "L", "label": "L", "icon": "🇱"},
            {"id": "S", "label": "S", "icon": "🇸"}
        ],
        "display": "A – F – M – P – R – T – B – L – S"
    },
    34: {
        "sequence": [
            {"id": "55", "label": "55", "icon": "📞"},
            {"id": "2026", "label": "2026", "icon": "📅"},
            {"id": "1956", "label": "1956", "icon": "🏛️"}
        ],
        "display": "55 – 2026 – 1956 (Agrupación lógica)"
    },
    35: {
        "sequence": [
            {"id": "B", "label": "Opción B: 55 – 1234 – 5678 (Agrupada)", "icon": "🧩"}
        ],
        "options": [
            {"id": "A", "label": "Opción A: 5 5 1 2 3 4 5 6 7 8 (Desorganizada)", "icon": "🎲"},
            {"id": "B", "label": "Opción B: 55 – 1234 – 5678 (Agrupada por Chunking)", "icon": "🧩"}
        ],
        "display": "Opción B (Chunking)"
    },
    36: {
        "sequence": [
            {"id": "balon_casa", "label": "Balón cambió por Casa", "icon": "⚽➔🏠"}
        ],
        "options": [
            {"id": "perro_gato", "label": "Perro cambió por Gato", "icon": "🐶➔🐱"},
            {"id": "balon_casa", "label": "Balón cambió por Casa", "icon": "⚽➔🏠"},
            {"id": "manzana_platano", "label": "Manzana cambió por Plátano", "icon": "🍎➔🍌"},
            {"id": "carro_bici", "label": "Carro cambió por Bici", "icon": "🚗➔🚲"}
        ],
        "display": "Cambió Balón por Casa"
    },
    37: {
        "sequence": [
            {"id": "rojo", "label": "Rojo", "icon": "🔴"},
            {"id": "verde", "label": "Verde", "icon": "🟢"},
            {"id": "azul", "label": "Azul", "icon": "🔵"},
            {"id": "amarillo", "label": "Amarillo", "icon": "🟡"},
            {"id": "rosa", "label": "Rosa", "icon": "🌸"},
            {"id": "negro", "label": "Negro", "icon": "⚫"},
            {"id": "blanco", "label": "Blanco", "icon": "⚪"}
        ],
        "display": "Rojo – Verde – Azul – Amarillo – Rosa – Negro – Blanco"
    },
    38: {
        "sequence": [
            {"id": "BMZ", "label": "BMZ", "icon": "🔤"},
            {"id": "AFQ", "label": "AFQ", "icon": "🔤"},
            {"id": "LRW", "label": "LRW", "icon": "🔤"},
            {"id": "DNK", "label": "DNK", "icon": "🔤"}
        ],
        "display": "BMZ – AFQ – LRW – DNK"
    },
    39: {
        "sequence": [
            {"id": "agrupar", "label": "Agrupar opciones en 3 a 5 categorías", "icon": "📂"},
            {"id": "submenus", "label": "Crear submenús desplegables", "icon": "📑"},
            {"id": "limitar", "label": "Limitar a 7 ± 2 elementos por nivel", "icon": "✨"}
        ],
        "display": "Categorías lógicas + Submenús + 7 ± 2 por nivel"
    }
}

print("Reto data prepared.")

import json

# Definir las 40 preguntas con coherencia pedagógica absoluta sobre la Ley de Miller
QUESTIONS = [
    # ── BLOQUE 1: Opción Múltiple (1-20) ──────────────────────────────────────
    {
        "num": 1,
        "q": "¿Qué fenómeno de la mente humana describe principalmente la Ley de Miller?",
        "type": "mc", "points": 100,
        "options": [
            "La velocidad del olvido en la vejez",
            "La capacidad limitada de la memoria de trabajo inmediata",
            "El tiempo que tarda el cerebro en procesar un estímulo visual",
            "La cantidad de palabras que un niño aprende al día"
        ],
        "correct": 1,
        "answer": "La capacidad limitada de la memoria de trabajo inmediata"
    },
    {
        "num": 2,
        "q": "¿Quién fue el psicólogo cognitivo estadounidense que propuso esta ley en 1956?",
        "type": "mc", "points": 100,
        "options": [
            "Burrhus Frederic Skinner",
            "Jean Piaget",
            "George Armitage Miller",
            "Sigmund Freud"
        ],
        "correct": 2,
        "answer": "George Armitage Miller"
    },
    {
        "num": 3,
        "q": "¿Cuál es la expresión numérica clásica que define a la Ley de Miller?",
        "type": "mc", "points": 100,
        "options": [
            "5 ± 1 elementos",
            "7 ± 2 elementos",
            "10 ± 3 elementos",
            "3 ± 1 elementos"
        ],
        "correct": 1,
        "answer": "7 ± 2 elementos (El número mágico 7 más o menos 2)"
    },
    {
        "num": 4,
        "q": "Según el rango de 7 ± 2, ¿cuántos elementos independientes retiene en promedio la memoria inmediata?",
        "type": "mc", "points": 100,
        "options": [
            "Entre 1 y 4 elementos",
            "Entre 5 y 9 elementos",
            "Entre 10 y 14 elementos",
            "Exactamente 7 en todas las personas"
        ],
        "correct": 1,
        "answer": "Entre 5 y 9 elementos"
    },
    {
        "num": 5,
        "q": "¿Qué tipo de memoria es evaluada directamente en los experimentos de Miller?",
        "type": "mc", "points": 200,
        "options": [
            "Memoria a largo plazo o remota",
            "Memoria procedimental (habilidades motoras)",
            "Memoria de trabajo o memoria a corto plazo",
            "Memoria episódica autobiográfica"
        ],
        "correct": 2,
        "answer": "Memoria de trabajo o memoria a corto plazo"
    },
    {
        "num": 6,
        "q": "¿Cómo se llama la estrategia cognitiva que consiste en agrupar piezas sueltas en unidades con significado?",
        "type": "mc", "points": 200,
        "options": [
            "Condicionamiento operante",
            "Chunking (o agrupamiento)",
            "Efecto Stroop",
            "Priming semántico"
        ],
        "correct": 1,
        "answer": "Chunking (o agrupamiento)"
    },
    {
        "num": 7,
        "q": "¿En qué año se publicó el artículo seminal «The Magical Number Seven, Plus or Minus Two»?",
        "type": "mc", "points": 200,
        "options": [
            "1938",
            "1956",
            "1972",
            "1985"
        ],
        "correct": 1,
        "answer": "1956 (Publicado en Psychological Review)"
    },
    {
        "num": 8,
        "q": "¿Por qué recordamos más fácilmente un número telefónico como 55-1234-5678 que como 5512345678?",
        "type": "mc", "points": 200,
        "options": [
            "Porque los guiones eliminan los dígitos repetidos",
            "Porque el chunking reduce 10 dígitos individuales a solo 3 bloques significativos",
            "Porque activa la visión periférica",
            "Porque la mente solo lee números pares"
        ],
        "correct": 1,
        "answer": "Porque el chunking reduce 10 dígitos individuales a solo 3 bloques significativos"
    },
    {
        "num": 9,
        "q": "¿La capacidad de la memoria de trabajo inmediata es ilimitada si nos esforzamos al máximo?",
        "type": "mc", "points": 100,
        "options": [
            "Sí, con suficiente concentración mental",
            "No, tiene una restricción biológica y cognitiva estricta",
            "Solo es ilimitada en personas con título universitario",
            "Sí, si se escucha música clásica de fondo"
        ],
        "correct": 1,
        "answer": "No, tiene una restricción biológica y cognitiva estricta"
    },
    {
        "num": 10,
        "q": "En psicología cognitiva, ¿qué representa exactamente un «chunk» o trozo de información?",
        "type": "mc", "points": 200,
        "options": [
            "Una pérdida momentánea de recuerdos",
            "Una unidad cognitiva que enlaza varios elementos relacionados",
            "Un segundo exacto de retención en el reloj cerebral",
            "Un impulso eléctrico de una sola neurona"
        ],
        "correct": 1,
        "answer": "Una unidad cognitiva que enlaza varios elementos relacionados"
    },
    {
        "num": 11,
        "q": "¿Qué consecuencia directa ocurre cuando se satura la memoria de trabajo con demasiados estímulos a la vez?",
        "type": "mc", "points": 200,
        "options": [
            "Sobrecarga cognitiva, confusión y pérdida de la información reciente",
            "La información se graba de inmediato en la memoria permanente",
            "Aumenta la agudeza auditiva automáticamente",
            "El cerebro multiplica sus neuronas de inmediato"
        ],
        "correct": 0,
        "answer": "Sobrecarga cognitiva, confusión y pérdida de la información reciente"
    },
    {
        "num": 12,
        "q": "¿Cómo se aplica correctamente la Ley de Miller en el diseño de interfaces web y móviles (UX/UI)?",
        "type": "mc", "points": 200,
        "options": [
            "Obligando a que cada pantalla tenga exactamente 7 botones sin excepción",
            "Organizando menús y opciones en categorías breves para no saturar al usuario",
            "Eliminando el texto y usando únicamente iconos",
            "Haciendo que cada página desaparezca tras 7 segundos"
        ],
        "correct": 1,
        "answer": "Organizando menús y opciones en categorías breves para no saturar al usuario"
    },
    {
        "num": 13,
        "q": "Si debes memorizar una lista de compras de 15 productos distintos, ¿cuál es la mejor estrategia?",
        "type": "mc", "points": 200,
        "options": [
            "Repetirlos en voz alta a toda velocidad sin pausas",
            "Agruparlos en 3 o 4 categorías lógicas (frutas, lácteos, limpieza)",
            "Leer solo los primeros 3 y descartar los demás",
            "Cambiarles el orden cada minuto"
        ],
        "correct": 1,
        "answer": "Agruparlos en 3 o 4 categorías lógicas (frutas, lácteos, limpieza)"
    },
    {
        "num": 14,
        "q": "¿Cuál de los siguientes casos NO constituye un ejemplo de chunking?",
        "type": "mc", "points": 300,
        "options": [
            "Dividir una tarjeta de crédito en 4 bloques de 4 dígitos",
            "Aprender la sigla «UNAM» en vez de 4 palabras desvinculadas",
            "Intentar memorizar 12 letras al azar sin ningún patrón ni significado",
            "Agrupar los ingredientes de una receta por tiempos de cocción"
        ],
        "correct": 2,
        "answer": "Intentar memorizar 12 letras al azar sin ningún patrón ni significado"
    },
    {
        "num": 15,
        "q": "Revisiones contemporáneas (como Nelson Cowan en 2001) señalan que sin ensayo activo el límite puro ronda:",
        "type": "mc", "points": 300,
        "options": [
            "Aproximadamente 4 unidades (chunks)",
            "Más de 15 elementos independientes",
            "1 solo elemento a la vez",
            "Exactamente 20 elementos"
        ],
        "correct": 0,
        "answer": "Aproximadamente 4 unidades (chunks)"
    },
    {
        "num": 16,
        "q": "En diseño de software, ¿qué problema surge al mostrar 25 opciones en un solo menú desplegable?",
        "type": "mc", "points": 200,
        "options": [
            "Fatiga en la toma de decisiones por sobrecarga cognitiva",
            "Mayor consumo de batería en el monitor",
            "Aceleración no deseada del internet",
            "La pantalla se bloquea por falta de memoria RAM"
        ],
        "correct": 0,
        "answer": "Fatiga en la toma de decisiones por sobrecarga cognitiva"
    },
    {
        "num": 17,
        "q": "¿Por qué las placas de autos, RFCs y números de serie se segmentan con espacios o guiones?",
        "type": "mc", "points": 200,
        "options": [
            "Porque la ley prohíbe escribir textos continuos",
            "Para facilitar su lectura y retención dividiéndolos en chunks manejables",
            "Para que ocupen mayor superficie en el papel",
            "Porque los lectores ópticos no pueden leer más de 3 letras"
        ],
        "correct": 1,
        "answer": "Para facilitar su lectura y retención dividiéndolos en chunks manejables"
    },
    {
        "num": 18,
        "q": "¿Qué permite recordar una secuencia de 10 palabras con mayor facilidad en la memoria de trabajo?",
        "type": "mc", "points": 300,
        "options": [
            "Que formen una oración coherente con significado previo",
            "Que todas las palabras empiecen con la letra X",
            "Que pertenezcan a un idioma desconocido",
            "Que se pronuncien con voz extremadamente baja"
        ],
        "correct": 0,
        "answer": "Que formen una oración coherente con significado previo"
    },
    {
        "num": 19,
        "q": "¿En qué coinciden la Ley de Miller y la Ley de Hick en el diseño de experiencias de usuario?",
        "type": "mc", "points": 300,
        "options": [
            "Ambas afirman que a mayor número de opciones, mayor es el tiempo y esfuerzo mental necesario",
            "Ambas exigen que todas las pantallas sean de color azul",
            "Ambas sostienen que el usuario nunca lee los textos",
            "Son leyes contradictorias formuladas en física cuántica"
        ],
        "correct": 0,
        "answer": "Ambas afirman que a mayor número de opciones, mayor es el tiempo y esfuerzo mental necesario"
    },
    {
        "num": 20,
        "q": "¿Cuál es la enseñanza principal de la Ley de Miller para educadores y expositores?",
        "type": "mc", "points": 300,
        "options": [
            "Que se debe enseñar todo el contenido de golpe en los primeros 5 minutos",
            "Que la mente retiene mejor la información dosificada, jerarquizada y organizada en bloques pequeños",
            "Que las personas solo pueden aprender 7 conceptos en toda su vida",
            "Que el uso de diapositivas no tiene impacto en la atención"
        ],
        "correct": 1,
        "answer": "Que la mente retiene mejor la información dosificada, jerarquizada y organizada en bloques pequeños"
    },

    # ── BLOQUE 2: Verdadero o Falso (21-30) ───────────────────────────────────
    {
        "num": 21,
        "q": "V/F: La Ley de Miller establece que todas las personas recuerdan exactamente 7 elementos sin variación.",
        "type": "vf", "points": 100, "correct": False,
        "answer": "Falso — 7 es solo una media aproximada; el rango real varía típicamente entre 5 y 9 (7 ± 2)."
    },
    {
        "num": 22,
        "q": "V/F: El chunking permite retener más datos en total sin rebasar el límite de slots de la memoria de trabajo.",
        "type": "vf", "points": 100, "correct": True,
        "answer": "Verdadero — Al comprimir datos en bloques con sentido, cada bloque ocupa un solo slot."
    },
    {
        "num": 23,
        "q": "V/F: El rango clásico de elementos inmediatos planteado por George A. Miller va de 5 a 9.",
        "type": "vf", "points": 100, "correct": True,
        "answer": "Verdadero — 7 menos 2 equivale a 5, y 7 más 2 equivale a 9."
    },
    {
        "num": 24,
        "q": "V/F: La Ley de Miller exige que los sitios web tengan obligatoriamente 7 botones de menú siempre.",
        "type": "vf", "points": 200, "correct": False,
        "answer": "Falso — Es una guía cognitiva de dosificación y simplicidad, no una regla rígida de diseño."
    },
    {
        "num": 25,
        "q": "V/F: Separar los 16 dígitos de una tarjeta bancaria en grupos de 4 es un ejemplo funcional de chunking.",
        "type": "vf", "points": 100, "correct": True,
        "answer": "Verdadero — Transforma 16 dígitos independientes en 4 unidades manejables."
    },
    {
        "num": 26,
        "q": "V/F: El artículo seminal de George Miller fue publicado en el año 1956.",
        "type": "vf", "points": 200, "correct": True,
        "answer": "Verdadero — Publicado en 1956, marcando el inicio de la psicología cognitiva moderna."
    },
    {
        "num": 27,
        "q": "V/F: La sobrecarga cognitiva se produce cuando los datos exceden la capacidad de la memoria de trabajo.",
        "type": "vf", "points": 100, "correct": True,
        "answer": "Verdadero — Genera fatiga mental, confusión y pérdida de retención."
    },
    {
        "num": 28,
        "q": "V/F: Presentar 20 opciones dispersas sin categorías facilita que el usuario las memorice más rápido.",
        "type": "vf", "points": 200, "correct": False,
        "answer": "Falso — La dispersión sin estructura satura la mente y multiplica los tiempos de búsqueda."
    },
    {
        "num": 29,
        "q": "V/F: El acrónimo conocido «ONU» se almacena en la memoria como 1 solo chunk y no como 3 letras aisladas.",
        "type": "vf", "points": 100, "correct": True,
        "answer": "Verdadero — Posee un significado integrado y ocupa un único espacio mental."
    },
    {
        "num": 30,
        "q": "V/F: La memoria de trabajo y la memoria a largo plazo comparten exactamente los mismos límites de capacidad.",
        "type": "vf", "points": 200, "correct": False,
        "answer": "Falso — La memoria de trabajo es sumamente limitada (7 ± 2), mientras que la de largo plazo es prácticamente ilimitada."
    },

    # ── BLOQUE 3: Retos Simón Dice Interactivos con Secuencia Aleatoria (31-39)
    {
        "num": 31,
        "q": "¡Reto Simón Dice: Nivel Básico (5 Elementos)! Memoriza y repite la secuencia exacta.",
        "type": "reto", "points": 300, "isSimon": True, "count": 5,
        "theme": "Objetos Cotidianos",
        "instruction": "Se mostrarán 5 elementos al azar durante unos segundos. Memoriza el orden y tócalos en la misma secuencia.",
        "pool": [
            {"id": "perro", "label": "Perro", "icon": "🐶"},
            {"id": "casa", "label": "Casa", "icon": "🏠"},
            {"id": "sol", "label": "Sol", "icon": "☀️"},
            {"id": "mesa", "label": "Mesa", "icon": "🪑"},
            {"id": "flor", "label": "Flor", "icon": "🌸"},
            {"id": "manzana", "label": "Manzana", "icon": "🍎"},
            {"id": "carro", "label": "Carro", "icon": "🚗"},
            {"id": "balon", "label": "Balón", "icon": "⚽"}
        ],
        "answer": "Secuencia de 5 elementos generada al azar para demostrar el límite inferior de Miller (7 - 2 = 5)."
    },
    {
        "num": 32,
        "q": "¡Reto Simón Dice: El Número Mágico (7 Dígitos)! Memoriza y reproduce los dígitos en orden.",
        "type": "reto", "points": 400, "isSimon": True, "count": 7,
        "theme": "Dígitos Numéricos",
        "instruction": "Se presentará una serie de 7 números al azar. ¡Pon a prueba el número mágico de Miller repitiéndolos!",
        "pool": [
            {"id": "0", "label": "Cero", "icon": "0️⃣"},
            {"id": "1", "label": "Uno", "icon": "1️⃣"},
            {"id": "2", "label": "Dos", "icon": "2️⃣"},
            {"id": "3", "label": "Tres", "icon": "3️⃣"},
            {"id": "4", "label": "Cuatro", "icon": "4️⃣"},
            {"id": "5", "label": "Cinco", "icon": "5️⃣"},
            {"id": "6", "label": "Seis", "icon": "6️⃣"},
            {"id": "7", "label": "Siete", "icon": "7️⃣"},
            {"id": "8", "label": "Ocho", "icon": "8️⃣"},
            {"id": "9", "label": "Nueve", "icon": "9️⃣"}
        ],
        "answer": "Serie de 7 dígitos aleatorios representativa del promedio de retención de Miller (7)."
    },
    {
        "num": 33,
        "q": "¡Reto Simón Dice Extremo: Límite Superior (9 Letras)! Supera el desafío de 9 elementos.",
        "type": "reto", "points": 500, "isSimon": True, "count": 9,
        "theme": "Letras del Alfabeto",
        "instruction": "9 letras aleatorias (límite superior 7 + 2 = 9). Memoriza con máxima concentración antes de que se oculten.",
        "pool": [
            {"id": "A", "label": "A", "icon": "🅰️"},
            {"id": "B", "label": "B", "icon": "🅱️"},
            {"id": "C", "label": "C", "icon": "🇨"},
            {"id": "D", "label": "D", "icon": "🇩"},
            {"id": "E", "label": "E", "icon": "🇪"},
            {"id": "F", "label": "F", "icon": "🇫"},
            {"id": "G", "label": "G", "icon": "🇬"},
            {"id": "H", "label": "H", "icon": "🇭"},
            {"id": "L", "label": "L", "icon": "🇱"},
            {"id": "M", "label": "M", "icon": "Ⓜ️"},
            {"id": "P", "label": "P", "icon": "🅿️"},
            {"id": "R", "label": "R", "icon": "🇷"},
            {"id": "S", "label": "S", "icon": "🇸"},
            {"id": "T", "label": "T", "icon": "🇹"}
        ],
        "answer": "Secuencia de 9 letras que demuestra el límite máximo teórico de retención inmediata sin chunking."
    },
    {
        "num": 34,
        "q": "¡Reto Simón Dice: Chunking Numérico en 3 Bloques! Memoriza los 3 bloques con sentido.",
        "type": "reto", "points": 400, "isSimon": True, "count": 3,
        "theme": "Bloques Chunking",
        "instruction": "Memoriza los 3 bloques en que se dividió una secuencia de 10 dígitos y reprodúcelos en orden.",
        "pool": [
            {"id": "55", "label": "Lada (55)", "icon": "📞"},
            {"id": "2026", "label": "Año Actual (2026)", "icon": "📅"},
            {"id": "1956", "label": "Año Miller (1956)", "icon": "🏛️"},
            {"id": "777", "label": "Triple Siete (777)", "icon": "🎰"},
            {"id": "1200", "label": "Mediodía (1200)", "icon": "⏰"}
        ],
        "answer": "Demostración de cómo el chunking comprime 10 cifras en solo 3 bloques fáciles de recordar."
    },
    {
        "num": 35,
        "q": "¡Reto Simón Dice: 6 Iconos Cotidianos! Reproduce la secuencia de 6 elementos visuales.",
        "type": "reto", "points": 300, "isSimon": True, "count": 6,
        "theme": "Iconos Visuales",
        "instruction": "Se presentará una serie aleatoria de 6 iconos. Memorízalos y tócalos en el orden correspondiente.",
        "pool": [
            {"id": "pizza", "label": "Pizza", "icon": "🍕"},
            {"id": "avion", "label": "Avión", "icon": "✈️"},
            {"id": "guitarra", "label": "Guitarra", "icon": "🎸"},
            {"id": "libro", "label": "Libro", "icon": "📚"},
            {"id": "cafe", "label": "Café", "icon": "☕"},
            {"id": "celular", "label": "Celular", "icon": "📱"},
            {"id": "cohete", "label": "Cohete", "icon": "🚀"},
            {"id": "diamante", "label": "Diamante", "icon": "💎"}
        ],
        "answer": "Secuencia de 6 elementos que se ubica dentro de la franja óptima de Miller (5 a 9)."
    },
    {
        "num": 36,
        "q": "¡Reto Simón Dice: 5 Conceptos Clave de la Psicología Cognitiva! Memoriza la secuencia de conceptos.",
        "type": "reto", "points": 400, "isSimon": True, "count": 5,
        "theme": "Conceptos Cognitivos",
        "instruction": "Aparecerán 5 conceptos esenciales de la memoria en orden aleatorio. ¡Retén la secuencia y márcala tocando los botones!",
        "pool": [
            {"id": "memoria", "label": "Memoria", "icon": "🧠"},
            {"id": "chunking", "label": "Chunking", "icon": "🧩"},
            {"id": "atencion", "label": "Atención", "icon": "🎯"},
            {"id": "estimulo", "label": "Estímulo", "icon": "⚡"},
            {"id": "capacidad", "label": "Capacidad", "icon": "📦"},
            {"id": "percepcion", "label": "Percepción", "icon": "🔍"},
            {"id": "retencion", "label": "Retención", "icon": "⏳"}
        ],
        "answer": "Demuestra la retención de términos semánticos clave en la memoria de trabajo según el modelo cognitivo."
    },
    {
        "num": 37,
        "q": "¡Reto Simón Dice: Los 7 Colores del Espectro! Ordena los 7 colores seleccionados al azar.",
        "type": "reto", "points": 400, "isSimon": True, "count": 7,
        "theme": "Paleta de Colores",
        "instruction": "Aparecerán 7 colores en un orden aleatorio. ¡Retén la secuencia cromática y márcala en orden!",
        "pool": [
            {"id": "rojo", "label": "Rojo", "icon": "🔴"},
            {"id": "verde", "label": "Verde", "icon": "🟢"},
            {"id": "azul", "label": "Azul", "icon": "🔵"},
            {"id": "amarillo", "label": "Amarillo", "icon": "🟡"},
            {"id": "rosa", "label": "Rosa", "icon": "🌸"},
            {"id": "negro", "label": "Negro", "icon": "⚫"},
            {"id": "blanco", "label": "Blanco", "icon": "⚪"},
            {"id": "morado", "label": "Morado", "icon": "🟣"},
            {"id": "naranja", "label": "Naranja", "icon": "🟠"}
        ],
        "answer": "Serie de 7 colores aleatorios que evalúa la memoria de trabajo visual y semántica simultáneamente."
    },
    {
        "num": 38,
        "q": "¡Reto Simón Dice: 4 Chunks de Letras Triples! Memoriza los 4 bloques de 3 letras.",
        "type": "reto", "points": 400, "isSimon": True, "count": 4,
        "theme": "Acrónimos Triples",
        "instruction": "En lugar de memorizar 12 letras sueltas, memoriza estos 4 bloques compactos de 3 letras en orden.",
        "pool": [
            {"id": "BMZ", "label": "BMZ", "icon": "🔤"},
            {"id": "AFQ", "label": "AFQ", "icon": "🔤"},
            {"id": "LRW", "label": "LRW", "icon": "🔤"},
            {"id": "DNK", "label": "DNK", "icon": "🔤"},
            {"id": "XPT", "label": "XPT", "icon": "🔤"},
            {"id": "JKH", "label": "JKH", "icon": "🔤"}
        ],
        "answer": "Demuestra el poder del chunking: transformar una tarea imposible de 12 letras en una fácil de 4 bloques."
    },
    {
        "num": 39,
        "q": "¡Reto Simón Dice: Jerarquía de Diseño UX! Ordena los 4 pasos para simplificar un menú complejo.",
        "type": "reto", "points": 500, "isSimon": True, "count": 4,
        "theme": "Estrategia UX",
        "instruction": "Acomoda en orden los 4 principios de diseño para adaptar un menú de 20 opciones a la Ley de Miller.",
        "pool": [
            {"id": "1_cat", "label": "1. Agrupar en 3 a 5 categorías lógicas", "icon": "📂"},
            {"id": "2_sub", "label": "2. Crear submenús contextuales", "icon": "📑"},
            {"id": "3_lim", "label": "3. Limitar a 7 ± 2 elementos visibles", "icon": "✨"},
            {"id": "4_act", "label": "4. Priorizar la acción más frecuente", "icon": "🎯"}
        ],
        "answer": "📂 Categorías ➔ 📑 Submenús ➔ ✨ Límite 7 ± 2 ➔ 🎯 Acción prioritaria."
    },

    # ── BLOQUE 4: Pregunta 40 (Globo Dorado Final - Respuesta Abierta Escrita) ─
    {
        "num": 40,
        "q": "🌟 ¡Globo Dorado Final! Explica con tus propias palabras la Ley de Miller.",
        "type": "reto", "points": 500, "isOpenText": True,
        "instruction": "Pregunta de reflexión abierta final. Escribe tu explicación sobre la Ley de Miller (menciona la memoria de trabajo, el número 7 ± 2 y el chunking o agrupación). ¡No tiene calificación automática, pero debes responderla y enviarla para concluir la trivia!",
        "answer": "🌟 Reto final completado con éxito: Reflexión abierta registrada y proyectada en el salón."
    }
]

with open('questions_data.json', 'w', encoding='utf-8') as f:
    json.dump(QUESTIONS, f, indent=2, ensure_ascii=False)

print("questions_data.json generado con 40 preguntas rigurosas y coherentes.")

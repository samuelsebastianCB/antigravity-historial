import json
import os

with open('questions_data.json', 'r', encoding='utf-8') as f:
    questions = json.load(f)

print(f"Cargadas {len(questions)} preguntas.")

# Definir la plantilla limpia y completa de balloon_trivia.html
html_content = '''<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>🎈 Trivia: La Ley de Miller (7 ± 2)</title>
  <!-- Tailwind CSS -->
  <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
  <!-- Canvas Confetti -->
  <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js"></script>
  <!-- QRCode.js -->
  <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>

  <style>
    * { box-sizing: border-box; }
    body {
      font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
      background: #090714;
      min-height: 100vh;
      margin: 0;
      padding: 0;
      color: #fff;
      overflow-x: hidden;
    }

    /* ── DotGrid Canvas ── */
    #dot-grid-canvas {
      position: fixed;
      inset: 0;
      z-index: 0;
      pointer-events: none;
      display: block;
      width: 100%;
      height: 100%;
    }

    /* ── Balloon 3D Card ── */
    .balloon-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      perspective: 600px;
    }

    .balloon-card {
      position: relative;
      cursor: pointer;
      background: linear-gradient(145deg, var(--c1), var(--c2));
      border-radius: 50% 50% 50% 50% / 60% 60% 40% 40%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 900;
      font-size: 1.25rem;
      color: #fff;
      text-shadow: 0 2px 6px rgba(0,0,0,0.6);
      box-shadow: 0 8px 24px rgba(0,0,0,0.4), inset 0 -6px 14px rgba(0,0,0,0.3), inset 4px 4px 10px rgba(255,255,255,0.3);
      transition: transform 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275), box-shadow 0.25s, opacity 0.35s;
      transform-style: preserve-3d;
      user-select: none;
      width: 82px;
      height: 98px;
      animation: balloonSway 3.2s ease-in-out infinite alternate;
      overflow: hidden;
    }

    .balloon-card:hover {
      transform: translateY(-8px) scale(1.08);
      box-shadow: 0 16px 32px var(--shadow-glow, rgba(99,102,241,0.5)), inset 0 -4px 10px rgba(0,0,0,0.2), inset 4px 4px 12px rgba(255,255,255,0.5);
    }

    .balloon-card .shine {
      position: absolute;
      top: 15%;
      left: 18%;
      width: 30%;
      height: 20%;
      background: radial-gradient(circle, rgba(255,255,255,0.6) 0%, rgba(255,255,255,0) 80%);
      border-radius: 50%;
      pointer-events: none;
    }

    .balloon-knot {
      width: 12px;
      height: 8px;
      background: inherit;
      border-radius: 3px 3px 6px 6px;
      margin-top: -2px;
      filter: brightness(0.85);
      z-index: 1;
    }

    .balloon-string {
      width: 2px;
      height: 38px;
      background: rgba(255,255,255,0.25);
      border-radius: 1px;
    }

    @keyframes balloonSway {
      0% { transform: rotate(-2.5deg) translateY(0); }
      100% { transform: rotate(2.5deg) translateY(-6px); }
    }

    .balloon-popped {
      opacity: 0.18 !important;
      filter: grayscale(1) !important;
      transform: scale(0.85) !important;
      pointer-events: none !important;
      cursor: default !important;
    }

    /* Globo Dorado 40 Especial */
    .golden-balloon {
      box-shadow: 0 0 25px rgba(251, 191, 36, 0.8), inset 0 0 15px rgba(255, 255, 255, 0.6) !important;
      animation: goldenPulse 2s infinite alternate !important;
    }
    @keyframes goldenPulse {
      0% { transform: scale(1) translateY(0); box-shadow: 0 0 20px rgba(251, 191, 36, 0.7); }
      100% { transform: scale(1.1) translateY(-8px); box-shadow: 0 0 35px rgba(251, 191, 36, 1); }
    }

    /* ── Split-Flap Train Station Style (Solari di Udine) ── */
    .splitflap-wrapper {
      display: flex;
      align-items: center;
      justify-content: center;
      user-select: none;
    }
    .splitflap-tile {
      position: relative;
      width: 36px;
      height: 52px;
      background: #111827;
      border-radius: 8px;
      perspective: 400px;
      box-shadow: 0 6px 14px rgba(0,0,0,0.6), inset 0 1px 2px rgba(255,255,255,0.15);
      overflow: hidden;
      font-family: 'Courier New', Courier, monospace, system-ui;
      font-weight: 900;
      font-size: 28px;
      color: #f8fafc;
      text-align: center;
      line-height: 52px;
    }
    .splitflap-tile.sf-sm {
      width: 24px;
      height: 36px;
      border-radius: 5px;
      font-size: 18px;
      line-height: 36px;
    }
    .splitflap-tile.sf-lg {
      width: 52px;
      height: 72px;
      border-radius: 10px;
      font-size: 42px;
      line-height: 72px;
    }
    .sf-half {
      position: absolute;
      left: 0;
      right: 0;
      overflow: hidden;
      background: #111827;
      color: #f8fafc;
      backface-visibility: hidden;
    }
    .sf-top-back, .sf-top-flip {
      top: 0;
      height: 50%;
      border-bottom: 1px solid rgba(0,0,0,0.85);
      border-radius: 8px 8px 0 0;
      transform-origin: 50% 100%;
    }
    .sf-bottom-back, .sf-bottom-flip {
      bottom: 0;
      height: 50%;
      border-top: 1px solid rgba(255,255,255,0.1);
      border-radius: 0 0 8px 8px;
      transform-origin: 50% 0%;
    }
    .sf-top-back span, .sf-top-flip span {
      position: absolute;
      left: 0; right: 0; top: 0;
    }
    .sf-bottom-back span, .sf-bottom-flip span {
      position: absolute;
      left: 0; right: 0; bottom: 0;
    }
    .sf-top-flip { z-index: 2; }
    .sf-bottom-flip { z-index: 3; }

    /* Modales */
    .glass-modal {
      background: rgba(13, 10, 31, 0.94);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(139, 92, 246, 0.35);
      box-shadow: 0 25px 60px rgba(0,0,0,0.8), 0 0 40px rgba(139, 92, 246, 0.2);
    }
  </style>
</head>
<body class="text-slate-100 min-h-screen relative flex flex-col justify-between select-none">
  <!-- Fondo DotGrid Canvas -->
  <canvas id="dot-grid-canvas"></canvas>

  <!-- ════════════════════════════════════════════════════════════════════════
       1. MODAL DE ACCESO / ROLE GATEWAY (PROFESOR VS JUGADOR)
       ════════════════════════════════════════════════════════════════════════ -->
  <div id="role-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
    <div class="glass-modal max-w-2xl w-full rounded-3xl p-6 sm:p-8 text-center relative overflow-hidden animate-in fade-in zoom-in-95 duration-200">
      <div class="absolute -top-24 -left-24 w-48 h-48 bg-purple-600/30 rounded-full blur-3xl pointer-events-none"></div>
      <div class="absolute -bottom-24 -right-24 w-48 h-48 bg-amber-600/20 rounded-full blur-3xl pointer-events-none"></div>

      <div class="flex items-center justify-center gap-3 mb-2">
        <span class="text-4xl">🎈</span>
        <h1 class="text-2xl sm:text-3xl font-black tracking-tight text-white">TRIVIA: LA LEY DE MILLER</h1>
      </div>
      <p class="text-sm text-purple-200/80 mb-6 font-medium">El número mágico 7 ± 2 • Memoria de Trabajo • Chunking</p>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
        <!-- Tarjeta Modo Profesor -->
        <div class="p-5 rounded-2xl bg-slate-900/80 border-2 border-purple-500/40 hover:border-purple-400 transition-all flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-2">
              <span class="text-2xl">👨‍🏫</span>
              <span class="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40">Control Total</span>
            </div>
            <h3 class="text-lg font-bold text-white mb-1">Modo Profesor / Salón</h3>
            <p class="text-xs text-slate-400 mb-4 leading-relaxed">
              Proyecta los 40 globos, abre preguntas, ajusta puntajes, repite reactivos y proyecta el código QR.
            </p>
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-300 mb-1">Código de Acceso:</label>
            <input type="password" id="teacher-password-input" placeholder="Ingresa el código..." 
                   class="w-full px-3 py-2 bg-slate-800/90 border border-purple-500/40 rounded-xl text-sm text-white focus:outline-none focus:border-purple-400 mb-2"
                   onkeydown="if(event.key==='Enter') verifyTeacherLogin()" />
            <button onclick="verifyTeacherLogin()" class="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl font-bold text-xs tracking-wide shadow-lg shadow-purple-900/40 active:scale-95 transition">
              Ingresar como Profesor ➔
            </button>
            <p id="teacher-login-error" class="text-red-400 text-[11px] mt-1.5 hidden font-bold text-center">❌ Código incorrecto.</p>
          </div>
        </div>

        <!-- Tarjeta Modo Jugador -->
        <div class="p-5 rounded-2xl bg-slate-900/80 border-2 border-emerald-500/40 hover:border-emerald-400 transition-all flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-2">
              <span class="text-2xl">🎓</span>
              <span class="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">Pasajero / Alumno</span>
            </div>
            <h3 class="text-lg font-bold text-white mb-1">Modo Jugador</h3>
            <p class="text-xs text-slate-400 mb-4 leading-relaxed">
              Regístrate con tu nombre, obtén tu color aleatorio y responde a las preguntas proyectadas en clase.
            </p>
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-300 mb-1">Tu Nombre o Apodo:</label>
            <input type="text" id="player-name-input" placeholder="Ej: Santiago, Laura, Alex..." maxlength="18"
                   class="w-full px-3 py-2 bg-slate-800/90 border border-emerald-500/40 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-400 mb-2"
                   onkeydown="if(event.key==='Enter') enterAsPlayer()" />
            
            <div class="flex items-center justify-between bg-slate-800/60 p-2 rounded-xl border border-slate-700 mb-2.5">
              <div class="flex items-center gap-2">
                <div id="player-color-preview" class="w-5 h-5 rounded-full border border-white/40 shadow-sm" style="background:#f43f5e"></div>
                <span id="player-color-name" class="text-xs font-bold text-slate-200">Rojo Carmesí</span>
              </div>
              <button onclick="rerollPlayerColor()" class="text-[11px] text-purple-300 hover:text-white font-bold flex items-center gap-1 bg-purple-900/40 px-2 py-1 rounded-lg border border-purple-500/30">
                🎲 Cambiar
              </button>
            </div>

            <button onclick="enterAsPlayer()" class="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl font-bold text-xs tracking-wide shadow-lg shadow-emerald-900/40 active:scale-95 transition">
              Entrar como Jugador ➔
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════════════
       2. BARRA DE CONTROL SUPERIOR
       ════════════════════════════════════════════════════════════════════════ -->
  <header class="relative z-10 p-3 sm:p-4 bg-slate-900/80 backdrop-blur-md border-b border-purple-500/20 flex flex-wrap items-center justify-between gap-3 shadow-lg">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-xl shadow-md shadow-purple-900/50">
        🎈
      </div>
      <div>
        <h1 class="text-base sm:text-lg font-black tracking-tight flex items-center gap-2">
          <span>LEY DE MILLER</span>
          <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">7 ± 2</span>
        </h1>
        <p class="text-[11px] text-slate-400">40 Globos Interactivos • Retos Simón Dice • Estación Solari</p>
      </div>
    </div>

    <!-- Indicador de Rol Actual -->
    <div id="role-badge-container" class="flex items-center gap-2">
      <div id="role-indicator" class="px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 bg-slate-800 border border-slate-700">
        <span class="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
        <span id="role-text">Sin identificar</span>
      </div>
      <button onclick="openRoleModal()" title="Cambiar modo" class="p-1.5 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-700 text-xs">
        🔄
      </button>
    </div>

    <!-- Botones de Acción Maestro / Proyector -->
    <div class="flex items-center gap-2 flex-wrap">
      <!-- Botones para Profesor -->
      <div id="teacher-actions" class="flex items-center gap-2">
        <button onclick="openRepeatModal()" class="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-purple-200 border border-purple-500/30 text-xs font-bold flex items-center gap-1.5 transition">
          🔁 <span class="hidden sm:inline">Repetir</span>
        </button>
        <button onclick="openScoreTableModal()" class="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-200 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 transition">
          📊 <span class="hidden sm:inline">Puntuaciones</span>
        </button>
        <button onclick="openQrModal()" class="px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition">
          📲 <span class="hidden sm:inline">Proyectar QR</span>
        </button>
      </div>

      <!-- Tablero Split-Flap y Pantalla Completa (Visible para todos) -->
      <button onclick="openStationBoard()" class="px-3 py-1.5 rounded-xl bg-amber-950/60 hover:bg-amber-900/80 text-amber-200 border border-amber-500/40 text-xs font-black flex items-center gap-1.5 transition">
        🚂 <span class="hidden sm:inline">Tablero de Tren</span>
      </button>
      <button onclick="toggleFullscreen()" title="Pantalla Completa" class="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs transition">
        ⛶
      </button>
    </div>
  </header>

  <!-- ════════════════════════════════════════════════════════════════════════
       3. CINTA DE ESTUDIANTES CONECTADOS (LOBBY EN VIVO)
       ════════════════════════════════════════════════════════════════════════ -->
  <div id="players-ribbon" class="relative z-10 px-4 py-2 bg-slate-950/60 border-b border-purple-500/10 flex items-center gap-2 overflow-x-auto text-xs">
    <span class="font-bold text-slate-400 whitespace-nowrap flex items-center gap-1">
      👥 Pasajeros (<span id="players-count">0</span>):
    </span>
    <div id="players-chips" class="flex items-center gap-2">
      <span class="text-slate-500 italic text-[11px]">Esperando a que los alumnos escaneen el QR...</span>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════════════
       4. PANTALLA PRINCIPAL: MATRIZ DE 40 GLOBOS 3D
       ════════════════════════════════════════════════════════════════════════ -->
  <main class="relative z-10 flex-1 p-4 sm:p-6 max-w-7xl mx-auto w-full flex flex-col justify-center items-center">
    <!-- Ticker Split-Flap Rápido en la parte superior -->
    <div class="mb-5 flex flex-col items-center">
      <div id="splitflap-ticker" class="splitflap-wrapper mb-2"></div>
      <p id="board-instruction" class="text-xs text-purple-300 font-semibold tracking-wide uppercase">
        Selecciona un globo para comenzar
      </p>
    </div>

    <!-- Rejilla de los 40 Globos (8 columnas x 5 filas) -->
    <div id="balloon-grid" class="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-8 gap-4 sm:gap-6 justify-center items-center w-full">
      <!-- Los 40 globos se generan dinámicamente -->
    </div>
  </main>

  <!-- ════════════════════════════════════════════════════════════════════════
       5. MODAL DE PREGUNTA / RETO / GLOBO DORADO
       ════════════════════════════════════════════════════════════════════════ -->
  <div id="trivia-screen" class="fixed inset-0 z-40 hidden flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md">
    <div class="glass-modal max-w-3xl w-full rounded-3xl p-6 sm:p-8 flex flex-col relative max-h-[92vh] overflow-y-auto">
      <!-- Encabezado de la Pregunta -->
      <div class="flex items-center justify-between border-b border-purple-500/20 pb-3 mb-4">
        <div class="flex items-center gap-2">
          <span id="q-number-badge" class="px-3 py-1 rounded-xl bg-purple-500/20 text-purple-300 font-black text-sm border border-purple-500/30">
            Globo #1
          </span>
          <span id="q-category-badge" class="px-2.5 py-1 rounded-xl bg-indigo-500/20 text-indigo-300 font-bold text-xs">
            Opción Múltiple
          </span>
        </div>
        <div class="flex items-center gap-2">
          <span id="q-points-badge" class="px-3 py-1 rounded-xl bg-amber-500/20 text-amber-300 font-black text-sm border border-amber-500/30">
            +100 PTS
          </span>
          <button onclick="closeTriviaScreen()" class="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center font-bold text-sm">
            ✕
          </button>
        </div>
      </div>

      <!-- Texto Principal del Reactivo -->
      <h2 id="q-text" class="text-lg sm:text-xl font-black text-white leading-snug mb-3">
        ¿Pregunta de la trivia?
      </h2>
      <p id="q-instruction" class="text-xs text-purple-200/70 mb-5 font-medium">
        Instrucción complementaria...
      </p>

      <!-- ── VISTA A: OPCIÓN MÚLTIPLE (4 OPCIONES) ── -->
      <div id="q-options-view" class="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
        <!-- Generado en JS -->
      </div>

      <!-- ── VISTA B: VERDADERO / FALSO (2 OPCIONES GRANDES) ── -->
      <div id="q-vf-view" class="grid grid-cols-2 gap-4 mb-4 hidden">
        <button onclick="handleVfAnswer(true)" class="p-6 rounded-2xl bg-emerald-950/60 border-2 border-emerald-500/50 hover:border-emerald-400 hover:bg-emerald-900/60 text-emerald-200 text-lg font-black transition flex flex-col items-center gap-2 active:scale-95">
          <span class="text-3xl">🟢</span>
          <span>VERDADERO</span>
        </button>
        <button onclick="handleVfAnswer(false)" class="p-6 rounded-2xl bg-rose-950/60 border-2 border-rose-500/50 hover:border-rose-400 hover:bg-rose-900/60 text-rose-200 text-lg font-black transition flex flex-col items-center gap-2 active:scale-95">
          <span class="text-3xl">🔴</span>
          <span>FALSO</span>
        </button>
      </div>

      <!-- ── VISTA C: RETO SIMÓN DICE INTERACTIVO (Q31-Q39) ── -->
      <div id="q-simon-view" class="hidden flex flex-col gap-4 mb-4">
        <!-- Fase 1: Memorización -->
        <div id="simon-memo-box" class="p-5 rounded-2xl bg-purple-950/40 border border-purple-500/40 text-center">
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-bold text-purple-300 uppercase tracking-wider">👀 Fase 1: ¡Memoriza la secuencia!</span>
            <span id="simon-countdown-text" class="text-xs font-mono font-black text-amber-300">5s</span>
          </div>
          <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden mb-4">
            <div id="simon-timer-bar" class="bg-gradient-to-r from-amber-400 to-purple-500 h-full w-full transition-all duration-100 ease-linear"></div>
          </div>
          <div id="simon-display-items" class="flex flex-wrap items-center justify-center gap-3">
            <!-- Items de la secuencia generada al azar -->
          </div>
        </div>

        <!-- Fase 2: Reproducción Interactiva con Botones e Iconos -->
        <div id="simon-input-box" class="hidden flex flex-col gap-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-300 uppercase tracking-wider">🎮 ¡Tu turno! Toca los botones en orden:</span>
            <div class="flex items-center gap-2">
              <button onclick="undoSimonLast()" class="text-xs px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-bold border border-slate-700">
                ⏪ Borrar
              </button>
              <button onclick="resetSimonPlayerInput()" class="text-xs px-2.5 py-1 rounded-lg bg-slate-800 text-rose-300 hover:text-white font-bold border border-slate-700">
                🔄 Reiniciar
              </button>
            </div>
          </div>

          <!-- Bandeja de orden actual seleccionado -->
          <div id="simon-user-tray" class="min-h-[52px] p-2.5 rounded-xl bg-slate-900/90 border border-purple-500/30 flex flex-wrap items-center gap-2">
            <span class="text-xs text-slate-500 italic">Toca los botones de abajo para formar tu secuencia...</span>
          </div>

          <!-- Botones disponibles con sus respectivos iconos -->
          <div id="simon-interactive-buttons" class="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-1">
            <!-- Botones generados con icono + label -->
          </div>

          <button id="btn-confirm-simon" onclick="checkSimonFinal()" class="w-full mt-2 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 text-white font-black text-sm rounded-xl tracking-wide shadow-lg shadow-purple-900/40 active:scale-95 transition">
            ✅ Confirmar y Enviar Secuencia
          </button>
        </div>
      </div>

      <!-- ── VISTA D: PREGUNTA 40 (GLOBO DORADO FINAL - RESPUESTA ABIERTA) ── -->
      <div id="q-opentext-view" class="hidden flex flex-col gap-3 mb-4">
        <div class="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/40 text-amber-200 text-xs leading-relaxed">
          ✨ <strong>Reflexión Final Abierta:</strong> Redacta en tus propias palabras qué es la Ley de Miller, mencionando el número mágico 7 ± 2 y la técnica del chunking. Esta respuesta no tiene calificación numérica automática, pero es requisito enviarla para culminar el reto.
        </div>
        <textarea id="q40-input-text" rows="4" placeholder="Escribe aquí tu conclusión sobre la Ley de Miller..." 
                  class="w-full p-3.5 bg-slate-900/90 border border-amber-500/40 rounded-2xl text-sm text-white focus:outline-none focus:border-amber-400 placeholder:text-slate-500"></textarea>
        <button onclick="submitQ40OpenText()" class="w-full py-3 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 text-slate-950 font-black text-sm rounded-xl tracking-wide shadow-lg shadow-amber-950/50 active:scale-95 transition flex items-center justify-center gap-2">
          <span>📨</span> Enviar Respuesta Final al Salón (+500 pts)
        </button>
      </div>

      <!-- Tarjeta de Retroalimentación y Explicación -->
      <div id="q-feedback-card" class="hidden p-4 rounded-2xl border text-sm font-semibold mb-3 transition-all">
        <!-- Feedback de acierto o fallo -->
      </div>

      <!-- Pie del Modal: Botón Siguiente / Cerrar -->
      <div class="flex items-center justify-end gap-3 pt-3 border-t border-purple-500/20">
        <button id="btn-next-question" onclick="closeTriviaScreen()" class="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition shadow-md">
          Continuar ➔
        </button>
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════════════
       6. TABLERO DE TREN ANALÓGICO SOLARI DI UDINE (SPLIT-FLAP)
       ════════════════════════════════════════════════════════════════════════ -->
  <div id="station-board-modal" class="fixed inset-0 z-50 hidden flex-col items-center justify-between p-4 sm:p-8 bg-[#07050d]/95 backdrop-blur-xl">
    <div class="w-full max-w-5xl flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
      <div class="flex items-center gap-3">
        <span class="text-3xl">🚂</span>
        <div>
          <h2 class="text-xl sm:text-2xl font-black tracking-widest uppercase text-slate-100 font-mono">
            ESTACIÓN CENTRAL • CLASIFICACIÓN
          </h2>
          <p class="text-xs text-slate-400 font-mono">Horarios y Puntuaciones Analógicas • Actualización Continua</p>
        </div>
      </div>
      <div class="flex items-center gap-3">
        <span id="station-clock" class="text-lg font-mono font-black text-amber-400 bg-slate-900 px-3 py-1 rounded-xl border border-slate-800">
          12:00:00
        </span>
        <button id="btn-sound-toggle" onclick="toggleFlapSound()" class="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-bold text-slate-300 hover:text-white">
          🔊 Sonido On
        </button>
        <button onclick="closeStationBoard()" class="w-9 h-9 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center font-black">
          ✕
        </button>
      </div>
    </div>

    <!-- Ticker Grande Central -->
    <div class="my-auto w-full flex flex-col items-center justify-center py-4">
      <div id="station-main-ticker" class="splitflap-wrapper mb-6"></div>

      <!-- Tabla de Pasajeros / Ranking con estética Solari -->
      <div class="w-full max-w-4xl bg-[#111827] border-2 border-slate-800 rounded-2xl p-4 shadow-2xl overflow-hidden font-mono">
        <div class="grid grid-cols-12 gap-2 text-xs font-black text-amber-400/90 border-b border-slate-800 pb-2 mb-3 tracking-wider">
          <div class="col-span-2 text-center">VÍA</div>
          <div class="col-span-4">PASAJERO / ALUMNO</div>
          <div class="col-span-2 text-center">COLOR</div>
          <div class="col-span-2 text-right">PUNTOS</div>
          <div class="col-span-2 text-center">ESTADO</div>
        </div>
        <div id="station-board-rows" class="flex flex-col gap-2">
          <!-- Filas de pasajeros -->
        </div>
      </div>
    </div>

    <div class="text-center text-xs text-slate-500 font-mono">
      Sistema Analógico Inspirado en Tableros Solari di Udine • Ley de Miller 7 ± 2
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════════════
       7. MODAL DE CÓDIGO QR PARA CELULARES
       ════════════════════════════════════════════════════════════════════════ -->
  <div id="qr-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
    <div class="glass-modal max-w-md w-full rounded-3xl p-6 sm:p-8 text-center relative">
      <button onclick="closeQrModal()" class="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-800 text-slate-300 hover:text-white font-bold flex items-center justify-center">
        ✕
      </button>

      <span class="text-3xl mb-2 inline-block">📲</span>
      <h2 class="text-xl font-black text-white mb-1">ÚNETE CON TU CELULAR</h2>
      <p class="text-xs text-purple-200/80 mb-5">Escanea este código con la cámara de tu celular para responder en vivo.</p>

      <div class="bg-white p-4 rounded-2xl shadow-xl inline-block mb-4">
        <canvas id="qr-canvas" class="w-56 h-56"></canvas>
      </div>

      <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-xs font-mono text-purple-300 break-all mb-4">
        <span id="qr-url-text">http://localhost:5000/join.html</span>
      </div>

      <p class="text-[11px] text-slate-400">
        💡 Cada alumno elige su nombre, recibe un color al azar y sus respuestas impactan la pantalla al instante.
      </p>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════════════
       8. MODAL DE REPETIR PREGUNTAS (EXCLUSIVO PROFESOR)
       ════════════════════════════════════════════════════════════════════════ -->
  <div id="repeat-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
    <div class="glass-modal max-w-xl w-full rounded-3xl p-6 text-center relative">
      <button onclick="closeRepeatModal()" class="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-800 text-slate-300 hover:text-white font-bold flex items-center justify-center">
        ✕
      </button>
      <span class="text-2xl mb-1 inline-block">🔁</span>
      <h3 class="text-lg font-black text-white mb-1">REPETIR CUALQUIER PREGUNTA</h3>
      <p class="text-xs text-slate-400 mb-4">Selecciona el número de globo que deseas reabrir:</p>
      
      <div id="repeat-grid" class="grid grid-cols-8 gap-2 max-h-64 overflow-y-auto p-1">
        <!-- Botones 1-40 -->
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════════════
       9. MODAL DE TABLA DE PUNTUACIONES / AJUSTES (PROFESOR)
       ════════════════════════════════════════════════════════════════════════ -->
  <div id="score-table-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
    <div class="glass-modal max-w-2xl w-full rounded-3xl p-6 relative max-h-[85vh] overflow-y-auto">
      <div class="flex items-center justify-between border-b border-purple-500/20 pb-3 mb-4">
        <h3 class="text-lg font-black text-white flex items-center gap-2">
          <span>📊</span> Puntuaciones y Ajustes de Alumnos
        </h3>
        <button onclick="closeScoreTableModal()" class="w-8 h-8 rounded-full bg-slate-800 text-slate-300 hover:text-white font-bold flex items-center justify-center">
          ✕
        </button>
      </div>

      <div id="score-table-body" class="flex flex-col gap-2 mb-4">
        <!-- Lista de alumnos con controles de sumar/restar puntos -->
      </div>

      <div class="flex items-center justify-between border-t border-purple-500/20 pt-4 text-xs">
        <button onclick="resetAllScores()" class="px-3 py-2 rounded-xl bg-rose-950/60 text-rose-300 border border-rose-500/40 font-bold hover:bg-rose-900">
          ⚠️ Reiniciar Todas las Puntuaciones
        </button>
        <button onclick="closeScoreTableModal()" class="px-4 py-2 rounded-xl bg-purple-600 text-white font-bold hover:bg-purple-500">
          Listo
        </button>
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════════════
       10. SCRIPTS DEL SISTEMA: AUDIO, FÍSICA, REGLAS Y MULTIPLAYER
       ════════════════════════════════════════════════════════════════════════ -->
  <script>
    // ── BASE DE DATOS DE PREGUNTAS (40 REACTIVOS RIGUROSOS) ──
    const QUESTIONS = ''' + json.dumps(questions, ensure_ascii=False) + ''';

    // ── PALETA DE COLORES VIBRANTES PARA ALUMNOS ──
    const STUDENT_COLORS = [
      { name: "Rojo Carmesí", hex: "#f43f5e" },
      { name: "Naranja Fuego", hex: "#f97316" },
      { name: "Ámbar Dorado", hex: "#eab308" },
      { name: "Esmeralda Neón", hex: "#10b981" },
      { name: "Cian Eléctrico", hex: "#06b6d4" },
      { name: "Violeta Cyber", hex: "#8b5cf6" },
      { name: "Rosa Magenta", hex: "#ec4899" },
      { name: "Verde Lima", hex: "#84cc16" },
      { name: "Azul Glaciar", hex: "#0ea5e9" },
      { name: "Índigo Cósmico", hex: "#6366f1" },
      { name: "Turquesa Vivo", hex: "#14b8a6" },
      { name: "Oro Radiante", hex: "#f59e0b" }
    ];

    // ── ESTADO GLOBAL ──
    let userRole = null; // 'teacher' | 'player'
    let currentPlayer = { name: "Invitado", color: "#f43f5e", colorName: "Rojo Carmesí", score: 0 };
    let connectedPlayers = [];
    let poppedBalloons = new Array(40).fill(false);
    let activeQuestionIndex = null;
    let currentSimonTarget = [];
    let currentSimonUserSeq = [];
    let simonTimerInterval = null;

    // ── WEB AUDIO API: CLACKS MECÁNICOS Y EFECTOS ──
    let soundEnabled = true;
    let audioCtx = null;
    function getAudio() {
      if (!audioCtx) {
        const AudioC = window.AudioContext || window.webkitAudioContext;
        if (AudioC) audioCtx = new AudioC();
      }
      if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume().catch(()=>{});
      }
      return audioCtx;
    }

    function playMechanicalFlapSound() {
      if (!soundEnabled) return;
      try {
        const ctx = getAudio();
        if (!ctx) return;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(280 + Math.random() * 100, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(70, ctx.currentTime + 0.025);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.025);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.025);
      } catch(e){}
    }

    function playSuccessSound() {
      try {
        const ctx = getAudio();
        if (!ctx) return;
        const now = ctx.currentTime;
        [523.25, 659.25, 783.99, 1046.50].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + idx * 0.08);
          gain.gain.setValueAtTime(0.12, now + idx * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.25);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.08);
          osc.stop(now + idx * 0.08 + 0.25);
        });
      } catch(e){}
    }

    function playErrorSound() {
      try {
        const ctx = getAudio();
        if (!ctx) return;
        const now = ctx.currentTime;
        [220, 180].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(freq, now + idx * 0.12);
          gain.gain.setValueAtTime(0.1, now + idx * 0.12);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.22);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.12);
          osc.stop(now + idx * 0.12 + 0.22);
        });
      } catch(e){}
    }

    function toggleFlapSound() {
      soundEnabled = !soundEnabled;
      const btn = document.getElementById('btn-sound-toggle');
      if (btn) btn.textContent = soundEnabled ? '🔊 Sonido On' : '🔇 Sonido Off';
    }

    // ── ROLE GATEWAY LOGIC (PROFESOR VS JUGADOR) ──
    let selectedPlayerColorIdx = 0;

    function openRoleModal() {
      document.getElementById('role-modal').classList.remove('hidden');
    }

    function closeRoleModal() {
      document.getElementById('role-modal').classList.add('hidden');
    }

    function verifyTeacherLogin() {
      const input = document.getElementById('teacher-password-input');
      const errorMsg = document.getElementById('teacher-login-error');
      const pass = input ? input.value.trim() : '';

      if (pass === 'SoyGenesis') {
        userRole = 'teacher';
        errorMsg.classList.add('hidden');
        closeRoleModal();
        applyRolePermissions();
        localStorage.setItem('trivia_role', 'teacher');
      } else {
        errorMsg.classList.remove('hidden');
        if (input) input.classList.add('border-red-500');
      }
    }

    function rerollPlayerColor() {
      selectedPlayerColorIdx = (selectedPlayerColorIdx + 1) % STUDENT_COLORS.length;
      const c = STUDENT_COLORS[selectedPlayerColorIdx];
      document.getElementById('player-color-preview').style.background = c.hex;
      document.getElementById('player-color-name').textContent = c.name;
    }

    function enterAsPlayer() {
      const nameInput = document.getElementById('player-name-input');
      const name = nameInput ? nameInput.value.trim() : '';
      if (!name) {
        if (nameInput) {
          nameInput.focus();
          nameInput.classList.add('border-red-500');
        }
        return;
      }

      const c = STUDENT_COLORS[selectedPlayerColorIdx];
      currentPlayer = {
        id: 'p_' + Date.now().toString().slice(-6),
        name: name,
        color: c.hex,
        colorName: c.name,
        score: 0
      };

      userRole = 'player';
      closeRoleModal();
      applyRolePermissions();
      localStorage.setItem('trivia_role', 'player');
      localStorage.setItem('trivia_player_data', JSON.stringify(currentPlayer));

      // Registrar jugador con el servidor
      fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: currentPlayer.name,
          color: currentPlayer.color,
          colorName: currentPlayer.colorName
        })
      }).then(r => r.json()).then(data => {
        if (data && data.player) {
          currentPlayer.id = data.player.id;
        }
      }).catch(()=>{});
    }

    function applyRolePermissions() {
      const roleText = document.getElementById('role-text');
      const teacherActions = document.getElementById('teacher-actions');
      const instruction = document.getElementById('board-instruction');

      if (userRole === 'teacher') {
        roleText.textContent = '👨‍🏫 Profesor (Control Maestro)';
        roleText.parentElement.className = 'px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 bg-purple-900/60 border border-purple-500/40 text-purple-200';
        teacherActions.style.display = 'flex';
        instruction.textContent = 'Haz clic en cualquier globo para proyectar la pregunta en clase';
      } else {
        roleText.textContent = `🎓 Alumno: ${currentPlayer.name} (${currentPlayer.score} pts)`;
        roleText.parentElement.className = 'px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 bg-emerald-900/60 border border-emerald-500/40 text-emerald-200';
        teacherActions.style.display = 'none';
        instruction.textContent = 'Espera a que el profesor elija una pregunta en el proyector...';
      }
    }

    // ── CONSTRUCCIÓN DE LA MATRIZ DE 40 GLOBOS ──
    const BALLOON_COLORS = [
      { c1: "#06b6d4", c2: "#2563eb", glow: "rgba(6,182,212,0.4)" }, // 1-10 Básico
      { c1: "#8b5cf6", c2: "#4f46e5", glow: "rgba(139,92,246,0.4)" }, // 11-20 UX
      { c1: "#10b981", c2: "#059669", glow: "rgba(16,185,129,0.4)" }, // 21-30 V/F
      { c1: "#f97316", c2: "#ec4899", glow: "rgba(249,115,22,0.4)" }, // 31-39 Simón Dice
      { c1: "#fbbf24", c2: "#d97706", glow: "rgba(251,191,36,0.8)" }  // 40 Dorado
    ];

    function buildGrid() {
      const grid = document.getElementById('balloon-grid');
      if (!grid) return;
      grid.innerHTML = '';

      for (let i = 1; i <= 40; i++) {
        let palette;
        if (i <= 10) palette = BALLOON_COLORS[0];
        else if (i <= 20) palette = BALLOON_COLORS[1];
        else if (i <= 30) palette = BALLOON_COLORS[2];
        else if (i <= 39) palette = BALLOON_COLORS[3];
        else palette = BALLOON_COLORS[4];

        const isGolden = (i === 40);
        const isPopped = poppedBalloons[i - 1];

        const wrap = document.createElement('div');
        wrap.className = 'balloon-wrapper';

        const card = document.createElement('div');
        card.id = `balloon-${i}`;
        card.className = `balloon-card ${isGolden ? 'golden-balloon' : ''} ${isPopped ? 'balloon-popped' : ''}`;
        card.style.setProperty('--c1', palette.c1);
        card.style.setProperty('--c2', palette.c2);
        card.style.setProperty('--shadow-glow', palette.glow);
        card.style.animationDelay = `${(i * 0.08) % 2.5}s`;

        card.innerHTML = `
          <div class="shine"></div>
          <span class="z-10">${isGolden ? '🌟 40' : i}</span>
        `;

        card.onclick = () => onBalloonClick(i);

        const knot = document.createElement('div');
        knot.className = 'balloon-knot';
        knot.style.background = palette.c2;

        const string = document.createElement('div');
        string.className = 'balloon-string';

        wrap.appendChild(card);
        wrap.appendChild(knot);
        wrap.appendChild(string);
        grid.appendChild(wrap);
      }
    }

    function onBalloonClick(num) {
      if (userRole !== 'teacher') {
        alert('Solo el profesor autorizado puede elegir o reventar globos en el proyector.');
        return;
      }
      openQuestion(num - 1);
    }

    // ── APERTURA Y CONTROL DE PREGUNTAS ──
    function openQuestion(qIdx) {
      if (qIdx < 0 || qIdx >= QUESTIONS.length) return;
      activeQuestionIndex = qIdx;
      const q = QUESTIONS[qIdx];
      const num = qIdx + 1;

      // Marcar globo como reventado
      poppedBalloons[qIdx] = true;
      const balloonEl = document.getElementById(`balloon-${num}`);
      if (balloonEl) balloonEl.classList.add('balloon-popped');

      // Notificar al servidor para sincronizar móviles
      fetch('/api/pop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ num: num, question: q, points: q.points })
      }).catch(()=>{});

      // Configurar pantalla de pregunta
      const modal = document.getElementById('trivia-screen');
      document.getElementById('q-number-badge').textContent = `Globo #${num}`;
      document.getElementById('q-points-badge').textContent = `+${q.points} PTS`;
      document.getElementById('q-text').textContent = q.q;
      document.getElementById('q-instruction').textContent = q.instruction || 'Selecciona la opción correcta:';

      const optView = document.getElementById('q-options-view');
      const vfView = document.getElementById('q-vf-view');
      const simonView = document.getElementById('q-simon-view');
      const openView = document.getElementById('q-opentext-view');
      const feedback = document.getElementById('q-feedback-card');

      optView.classList.add('hidden');
      vfView.classList.add('hidden');
      simonView.classList.add('hidden');
      openView.classList.add('hidden');
      feedback.classList.add('hidden');

      if (q.isOpenText) {
        document.getElementById('q-category-badge').textContent = '🌟 Reflexión Abierta Final';
        openView.classList.remove('hidden');
        document.getElementById('q40-input-text').value = '';
      } else if (q.isSimon) {
        document.getElementById('q-category-badge').textContent = `🎮 Reto Simón Dice (${q.count} elementos)`;
        simonView.classList.remove('hidden');
        initSimonChallenge(q);
      } else if (q.type === 'vf') {
        document.getElementById('q-category-badge').textContent = 'Verdadero o Falso';
        vfView.classList.remove('hidden');
      } else {
        document.getElementById('q-category-badge').textContent = 'Opción Múltiple';
        optView.classList.remove('hidden');
        renderMultipleChoice(q);
      }

      modal.classList.remove('hidden');
    }

    function closeTriviaScreen() {
      document.getElementById('trivia-screen').classList.add('hidden');
      if (simonTimerInterval) clearInterval(simonTimerInterval);
      fetch('/api/close-question', { method: 'POST' }).catch(()=>{});
    }

    // ── RENDERIZADO DE OPCIÓN MÚLTIPLE ──
    function renderMultipleChoice(q) {
      const container = document.getElementById('q-options-view');
      container.innerHTML = '';
      const letters = ['A', 'B', 'C', 'D'];

      q.options.forEach((optText, idx) => {
        const btn = document.createElement('button');
        btn.className = 'p-4 rounded-2xl bg-slate-900/80 border border-purple-500/30 hover:border-purple-400 hover:bg-slate-800/90 text-left text-xs sm:text-sm font-semibold text-slate-200 transition flex items-start gap-3 active:scale-98';
        btn.innerHTML = `
          <span class="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center justify-center font-bold text-xs shrink-0">${letters[idx]}</span>
          <span>${optText}</span>
        `;
        btn.onclick = () => submitAnswer(idx === q.correct, q.answer, q.points);
        container.appendChild(btn);
      });
    }

    function handleVfAnswer(userChoice) {
      const q = QUESTIONS[activeQuestionIndex];
      const isCorrect = (userChoice === q.correct);
      submitAnswer(isCorrect, q.answer, q.points);
    }

    function submitAnswer(isCorrect, explanation, points) {
      const feed = document.getElementById('q-feedback-card');
      feed.classList.remove('hidden');

      if (isCorrect) {
        playSuccessSound();
        if (window.confetti) window.confetti({ particleCount: 80, spread: 70 });
        feed.className = 'p-4 rounded-2xl border text-sm font-semibold mb-3 bg-emerald-950/70 border-emerald-500 text-emerald-300';
        feed.innerHTML = `🎉 <strong>¡CORRECTO! (+${points} PTS)</strong><br><span class="text-xs text-emerald-200/90 font-normal">${explanation}</span>`;
        if (userRole === 'player') {
          currentPlayer.score += points;
          applyRolePermissions();
        }
      } else {
        playErrorSound();
        feed.className = 'p-4 rounded-2xl border text-sm font-semibold mb-3 bg-rose-950/70 border-rose-500 text-rose-300';
        feed.innerHTML = `❌ <strong>INCORRECTO</strong><br><span class="text-xs text-rose-200/90 font-normal">${explanation}</span>`;
      }
    }

    // ── MOTOR SIMÓN DICE INTERACTIVO CON SECUENCIA ALEATORIA ──
    function initSimonChallenge(q) {
      if (simonTimerInterval) clearInterval(simonTimerInterval);

      // Generar secuencia aleatoria única para esta ronda a partir del pool
      const pool = [...q.pool];
      // Mezclar aleatoriamente el pool
      for (let i = pool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [pool[i], pool[j]] = [pool[j], pool[i]];
      }
      currentSimonTarget = pool.slice(0, q.count);
      currentSimonUserSeq = [];

      const memoBox = document.getElementById('simon-memo-box');
      const inputBox = document.getElementById('simon-input-box');
      const displayItems = document.getElementById('simon-display-items');
      const timerBar = document.getElementById('simon-timer-bar');
      const countdownText = document.getElementById('simon-countdown-text');

      memoBox.classList.remove('hidden');
      inputBox.classList.add('hidden');
      timerBar.style.width = '100%';

      // Mostrar los elementos a memorizar
      displayItems.innerHTML = '';
      currentSimonTarget.forEach((item, idx) => {
        const badge = document.createElement('div');
        badge.className = 'flex flex-col items-center p-3 rounded-2xl bg-purple-900/40 border border-purple-400/50 shadow-md min-w-[70px] animate-in zoom-in duration-300';
        badge.innerHTML = `
          <span class="text-xs font-bold text-purple-300 mb-1">#${idx + 1}</span>
          <span class="text-3xl mb-1">${item.icon}</span>
          <span class="text-[11px] font-bold text-white text-center leading-tight">${item.label}</span>
        `;
        displayItems.appendChild(badge);
      });

      // Temporizador de 5 segundos
      let remaining = 5.0;
      countdownText.textContent = '5.0s';
      const step = 100;

      simonTimerInterval = setInterval(() => {
        remaining -= (step / 1000);
        if (remaining <= 0) {
          clearInterval(simonTimerInterval);
          startSimonInputPhase(q);
        } else {
          countdownText.textContent = remaining.toFixed(1) + 's';
          timerBar.style.width = (remaining / 5.0 * 100) + '%';
        }
      }, step);
    }

    function startSimonInputPhase(q) {
      document.getElementById('simon-memo-box').classList.add('hidden');
      document.getElementById('simon-input-box').classList.remove('hidden');

      renderSimonUserTray();
      renderSimonButtons(q);
    }

    function renderSimonUserTray() {
      const tray = document.getElementById('simon-user-tray');
      tray.innerHTML = '';

      if (currentSimonUserSeq.length === 0) {
        tray.innerHTML = '<span class="text-xs text-slate-500 italic">Toca los botones de abajo para formar tu secuencia...</span>';
        return;
      }

      currentSimonUserSeq.forEach((item, idx) => {
        const chip = document.createElement('div');
        chip.className = 'px-3 py-1.5 rounded-full bg-purple-600/30 border border-purple-400 text-purple-200 text-xs font-bold flex items-center gap-1.5 shadow-sm';
        chip.innerHTML = `
          <span class="text-[10px] text-purple-300 font-mono">${idx + 1}.</span>
          <span class="text-base">${item.icon}</span>
          <span>${item.label}</span>
        `;
        tray.appendChild(chip);
      });
    }

    function renderSimonButtons(q) {
      const box = document.getElementById('simon-interactive-buttons');
      box.innerHTML = '';

      // Mostrar los elementos del pool como botones táctiles
      q.pool.forEach(item => {
        const isSelected = currentSimonUserSeq.some(x => x.id === item.id);
        const btn = document.createElement('button');
        btn.disabled = isSelected;
        btn.className = `p-3 rounded-2xl border text-left flex items-center gap-2.5 text-xs font-bold transition ${
          isSelected 
            ? 'bg-slate-900/40 border-slate-800 text-slate-600 cursor-not-allowed' 
            : 'bg-slate-800/90 hover:bg-slate-700/90 border-purple-500/40 text-white active:scale-95 shadow-sm'
        }`;
        btn.innerHTML = `<span class="text-2xl">${item.icon}</span><span class="truncate">${item.label}</span>`;
        btn.onclick = () => {
          if (isSelected) return;
          currentSimonUserSeq.push(item);
          renderSimonUserTray();
          renderSimonButtons(q);
          if (currentSimonUserSeq.length === currentSimonTarget.length) {
            setTimeout(checkSimonFinal, 300);
          }
        };
        box.appendChild(btn);
      });
    }

    function undoSimonLast() {
      if (currentSimonUserSeq.length > 0) {
        currentSimonUserSeq.pop();
        const q = QUESTIONS[activeQuestionIndex];
        renderSimonUserTray();
        renderSimonButtons(q);
      }
    }

    function resetSimonPlayerInput() {
      currentSimonUserSeq = [];
      const q = QUESTIONS[activeQuestionIndex];
      renderSimonUserTray();
      renderSimonButtons(q);
    }

    function checkSimonFinal() {
      const q = QUESTIONS[activeQuestionIndex];
      if (currentSimonUserSeq.length === 0) return;

      const userIds = currentSimonUserSeq.map(i => i.id);
      const targetIds = currentSimonTarget.map(i => i.id);

      const isMatch = (userIds.length === targetIds.length) &&
                      userIds.every((val, idx) => val === targetIds[idx]);

      const targetIcons = currentSimonTarget.map(i => `${i.icon} ${i.label}`).join(' ➔ ');
      submitAnswer(isMatch, `Secuencia objetivo: ${targetIcons}`, q.points);
    }

    // ── PREGUNTA 40 (GLOBO DORADO FINAL - RESPUESTA ABIERTA) ──
    function submitQ40OpenText() {
      const textarea = document.getElementById('q40-input-text');
      const text = textarea ? textarea.value.trim() : '';

      if (text.length < 5) {
        alert('Por favor redacta tu conclusión sobre la Ley de Miller antes de enviar.');
        if (textarea) textarea.focus();
        return;
      }

      if (window.confetti) {
        window.confetti({ particleCount: 120, spread: 90, origin: { y: 0.5 } });
      }
      playSuccessSound();

      const feed = document.getElementById('q-feedback-card');
      feed.classList.remove('hidden');
      feed.className = 'p-5 rounded-2xl border text-sm font-semibold mb-3 bg-amber-950/70 border-amber-500 text-amber-200';
      feed.innerHTML = `
        🎉 <strong>¡RESPUESTA REGISTRADA CON ÉXITO! (+500 PTS)</strong><br>
        <span class="text-xs text-amber-100/90 font-normal">«${text}»</span><br>
        <span class="text-xs text-emerald-300 font-bold mt-1 inline-block">¡Felicidades por completar los 40 globos de la trivia!</span>
      `;

      if (userRole === 'player') {
        currentPlayer.score += 500;
        applyRolePermissions();
      }

      // Enviar reflexión al servidor para proyectar en el salón
      fetch('/api/answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          playerName: currentPlayer.name,
          playerColor: currentPlayer.color,
          isOpenText: true,
          openText: text,
          points: 500,
          isCorrect: true
        })
      }).catch(()=>{});
    }

    // ── REPETIR PREGUNTAS MODAL (PROFESOR) ──
    function openRepeatModal() {
      const grid = document.getElementById('repeat-grid');
      grid.innerHTML = '';
      for (let i = 1; i <= 40; i++) {
        const btn = document.createElement('button');
        btn.className = `p-2 rounded-xl text-xs font-bold transition border ${
          poppedBalloons[i - 1]
            ? 'bg-purple-900/60 border-purple-500/40 text-purple-200 hover:bg-purple-800'
            : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:bg-slate-700'
        }`;
        btn.textContent = (i === 40) ? '🌟 40' : `#${i}`;
        btn.onclick = () => {
          closeRepeatModal();
          openQuestion(i - 1);
        };
        grid.appendChild(btn);
      }
      document.getElementById('repeat-modal').classList.remove('hidden');
    }

    function closeRepeatModal() {
      document.getElementById('repeat-modal').classList.add('hidden');
    }

    // ── TABLA DE PUNTUACIONES Y AJUSTES (PROFESOR) ──
    function openScoreTableModal() {
      const body = document.getElementById('score-table-body');
      body.innerHTML = '';

      if (connectedPlayers.length === 0) {
        body.innerHTML = '<div class="text-xs text-slate-400 text-center py-6">Aún no hay alumnos registrados.</div>';
      } else {
        connectedPlayers.forEach(p => {
          const row = document.createElement('div');
          row.className = 'flex items-center justify-between p-3 rounded-2xl bg-slate-900/80 border border-slate-800';
          row.innerHTML = `
            <div class="flex items-center gap-3">
              <div class="w-4 h-4 rounded-full border border-white/30" style="background:${p.color || '#f43f5e'}"></div>
              <span class="text-sm font-bold text-white">${p.name}</span>
            </div>
            <div class="flex items-center gap-3">
              <span class="text-sm font-mono font-black text-amber-400">${p.score || 0} pts</span>
              <div class="flex items-center gap-1">
                <button onclick="adjustPlayerScore('${p.id}', -50)" class="w-7 h-7 rounded-lg bg-rose-900/40 text-rose-300 border border-rose-500/30 hover:bg-rose-800 font-black text-xs">-50</button>
                <button onclick="adjustPlayerScore('${p.id}', 100)" class="w-7 h-7 rounded-lg bg-emerald-900/40 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-800 font-black text-xs">+100</button>
              </div>
            </div>
          `;
          body.appendChild(row);
        });
      }

      document.getElementById('score-table-modal').classList.remove('hidden');
    }

    function closeScoreTableModal() {
      document.getElementById('score-table-modal').classList.add('hidden');
    }

    function adjustPlayerScore(playerId, amount) {
      fetch('/api/award', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerId: playerId, points: amount })
      }).then(() => openScoreTableModal()).catch(()=>{});
    }

    function resetAllScores() {
      if (confirm('¿Seguro que deseas reiniciar todos los puntajes a 0?')) {
        fetch('/api/reset', { method: 'POST' }).then(() => openScoreTableModal()).catch(()=>{});
      }
    }

    // ── MODAL QR CODE ──
    async function openQrModal() {
      const modal = document.getElementById('qr-modal');
      const canvas = document.getElementById('qr-canvas');
      let hostUrl = `${window.location.protocol}//${window.location.hostname}:${window.location.port || '5000'}/join.html`;

      try {
        const res = await fetch('/api/host-info');
        const info = await res.json();
        if (info && info.joinUrl) {
          hostUrl = info.joinUrl;
        }
      } catch(e){}

      document.getElementById('qr-url-text').textContent = hostUrl;

      if (window.QRCode && canvas) {
        QRCode.toCanvas(canvas, hostUrl, { width: 224, margin: 2 }, function(error) {
          if (error) console.error(error);
        });
      }
      modal.classList.remove('hidden');
    }

    function closeQrModal() {
      document.getElementById('qr-modal').classList.add('hidden');
    }

    // ── TABLERO DE TREN ANALÓGICO SOLARI DI UDINE (SPLIT-FLAP) ──
    class SplitFlapText {
      constructor(container, options = {}) {
        this.container = container;
        this.words = options.words || ["LAUNCH READY", "SYNC ONLINE", "SIGNAL LIVE"];
        this.flipDuration = options.flipDuration || 0.12;
        this.stagger = options.stagger || 0.06;
        this.cycleDelay = options.cycleDelay || 2400;
        this.flipsPerChar = options.flipsPerChar || 8;
        this.tileColor = options.tileColor || "#111827";
        this.textColor = options.textColor || "#f8fafc";
        this.tileRadius = options.tileRadius || 8;
        this.gap = options.gap || 6;
        this.padTo = options.padTo || 14;
        this.loop = options.loop !== false;
        this.isSmall = options.isSmall || false;

        this.currentWordIdx = 0;
        this.tiles = [];
        this.timer = null;
        this.init();
      }

      init() {
        this.container.innerHTML = '';
        this.container.style.gap = `${this.gap}px`;
        for (let i = 0; i < this.padTo; i++) {
          const tile = document.createElement('div');
          tile.className = 'splitflap-tile' + (this.isSmall ? ' sf-sm' : '');
          tile.style.background = this.tileColor;
          tile.style.borderRadius = `${this.tileRadius}px`;
          tile.innerHTML = `
            <div class="sf-half sf-top-back" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
            <div class="sf-half sf-bottom-back" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
            <div class="sf-half sf-top-flip" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
            <div class="sf-half sf-bottom-flip" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
          `;
          this.container.appendChild(tile);
          this.tiles.push({
            el: tile,
            currentChar: ' ',
            targetChar: ' '
          });
        }

        if (this.words && this.words.length > 0) {
          this.setText(this.words[0], false);
          if (this.loop && this.words.length > 1) {
            this.scheduleNext();
          }
        }
      }

      scheduleNext() {
        this.timer = setTimeout(() => {
          this.currentWordIdx = (this.currentWordIdx + 1) % this.words.length;
          this.setText(this.words[this.currentWordIdx], true);
          this.scheduleNext();
        }, this.cycleDelay);
      }

      setText(text, animate = true) {
        const formatted = (text || '').toUpperCase().padEnd(this.padTo, ' ').slice(0, this.padTo);
        for (let i = 0; i < this.padTo; i++) {
          const targetChar = formatted[i] || ' ';
          const tile = this.tiles[i];
          if (tile) {
            if (!animate) {
              this.setTileChar(tile, targetChar);
            } else {
              setTimeout(() => {
                this.flipTileTo(tile, targetChar, this.flipsPerChar);
              }, i * (this.stagger * 1000));
            }
          }
        }
      }

      setTileChar(tile, char) {
        tile.currentChar = char;
        tile.targetChar = char;
        const spans = tile.el.querySelectorAll('.sf-half span');
        spans.forEach(s => s.textContent = char);
      }

      flipTileTo(tile, targetChar, remainingFlips) {
        if (remainingFlips <= 0 && tile.currentChar === targetChar) return;
        const pool = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        const nextChar = (remainingFlips > 1) ? pool[Math.floor(Math.random() * pool.length)] : targetChar;

        tile.currentChar = nextChar;
        const spans = tile.el.querySelectorAll('.sf-half span');
        spans.forEach(s => s.textContent = nextChar);
        playMechanicalFlapSound();

        if (remainingFlips > 1 || tile.currentChar !== targetChar) {
          setTimeout(() => {
            this.flipTileTo(tile, targetChar, remainingFlips - 1);
          }, this.flipDuration * 600);
        }
      }
    }

    let stationTicker = null;
    let mainTicker = null;
    let stationClockInterval = null;

    function openStationBoard() {
      document.getElementById('station-board-modal').classList.remove('hidden');
      document.getElementById('station-board-modal').classList.add('flex');
      updateStationClock();
      if (!stationClockInterval) {
        stationClockInterval = setInterval(updateStationClock, 1000);
      }
      renderStationRows();
    }

    function closeStationBoard() {
      document.getElementById('station-board-modal').classList.add('hidden');
      document.getElementById('station-board-modal').classList.remove('flex');
    }

    function updateStationClock() {
      const clk = document.getElementById('station-clock');
      if (clk) {
        const now = new Date();
        clk.textContent = now.toTimeString().split(' ')[0];
      }
    }

    function renderStationRows() {
      const container = document.getElementById('station-board-rows');
      if (!container) return;
      container.innerHTML = '';

      if (connectedPlayers.length === 0) {
        container.innerHTML = '<div class="text-xs text-slate-500 text-center py-6 font-mono">SIN PASAJEROS A BORDO</div>';
        return;
      }

      const sorted = [...connectedPlayers].sort((a,b) => (b.score || 0) - (a.score || 0));

      sorted.forEach((p, idx) => {
        const row = document.createElement('div');
        row.className = 'grid grid-cols-12 gap-2 text-xs font-mono items-center py-1.5 border-b border-slate-800/60';
        row.innerHTML = `
          <div class="col-span-2 text-center text-amber-400 font-bold">VÍA 0${idx + 1}</div>
          <div class="col-span-4 text-white font-bold truncate">${p.name.toUpperCase()}</div>
          <div class="col-span-2 flex items-center justify-center gap-1.5">
            <span class="w-3 h-3 rounded-full" style="background:${p.color || '#f43f5e'}"></span>
            <span class="text-[10px] text-slate-400">${p.colorName || 'Color'}</span>
          </div>
          <div class="col-span-2 text-right font-black text-amber-300">${p.score || 0} PTS</div>
          <div class="col-span-2 text-center text-[10px] font-black text-emerald-400 uppercase tracking-wider">${p.status || 'A BORDO'}</div>
        `;
        container.appendChild(row);
      });
    }

    // ── FULLSCREEN TOGGLE ──
    function toggleFullscreen() {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(()=>{});
      } else {
        document.exitFullscreen().catch(()=>{});
      }
    }

    // ── SYNCHRONIZATION VIA SERVER SSE ──
    function connectEvents() {
      const ev = new EventSource('/api/events');

      ev.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          if (data.type === 'player_joined' || data.type === 'score_updated') {
            connectedPlayers = data.players || [];
            updatePlayersRibbon();
            renderStationRows();
          } else if (data.type === 'question_opened' && userRole === 'player') {
            // Si el alumno está conectado en esta pantalla, abrir pregunta
            const qIdx = data.num - 1;
            openQuestion(qIdx);
          } else if (data.type === 'open_text_submitted') {
            // Mostrar reflexión en proyector
            if (userRole === 'teacher' && window.confetti) {
              window.confetti({ particleCount: 100, spread: 80 });
            }
          }
        } catch(err){}
      };

      ev.onerror = () => {
        setTimeout(connectEvents, 4000);
      };
    }

    function updatePlayersRibbon() {
      const countEl = document.getElementById('players-count');
      const chipsEl = document.getElementById('players-chips');
      if (countEl) countEl.textContent = connectedPlayers.length;

      if (!chipsEl) return;
      chipsEl.innerHTML = '';

      if (connectedPlayers.length === 0) {
        chipsEl.innerHTML = '<span class="text-slate-500 italic text-[11px]">Esperando a que los alumnos escaneen el QR...</span>';
        return;
      }

      connectedPlayers.forEach(p => {
        const chip = document.createElement('div');
        chip.className = 'px-2.5 py-1 rounded-full bg-slate-900/90 border border-slate-700 text-xs font-bold text-white flex items-center gap-1.5 shadow-sm';
        chip.innerHTML = `
          <span class="w-2.5 h-2.5 rounded-full" style="background:${p.color || '#f43f5e'}"></span>
          <span>${p.name}</span>
          <span class="text-[10px] text-amber-400 font-mono">(${p.score || 0})</span>
        `;
        chipsEl.appendChild(chip);
      });
    }

    // ── INICIALIZACIÓN GENERAL AL CARGAR PÁGINA ──
    window.addEventListener('DOMContentLoaded', () => {
      // 1. Construir la cuadrícula de 40 globos
      buildGrid();

      // 2. Inicializar tickers analógicos Split-Flap
      const tickerEl = document.getElementById('splitflap-ticker');
      if (tickerEl) {
        mainTicker = new SplitFlapText(tickerEl, {
          words: ["LAUNCH READY", "SYNC ONLINE", "SIGNAL LIVE", "TRIVIA MILLER", "LEY DE 7+-2"],
          flipDuration: 0.12,
          stagger: 0.06,
          cycleDelay: 2400,
          flipsPerChar: 8,
          tileColor: "#111827",
          textColor: "#f8fafc",
          tileRadius: 8,
          gap: 6,
          padTo: 13,
          loop: true
        });
      }

      const stationTickerEl = document.getElementById('station-main-ticker');
      if (stationTickerEl) {
        stationTicker = new SplitFlapText(stationTickerEl, {
          words: ["ESTACION CENTRAL", "PROXIMAS SALIDAS", "HORARIOS MILLER", "MEMORIA LISTA"],
          flipDuration: 0.12,
          stagger: 0.06,
          cycleDelay: 3000,
          flipsPerChar: 8,
          tileColor: "#111827",
          textColor: "#f8fafc",
          tileRadius: 8,
          gap: 6,
          padTo: 16,
          loop: true
        });
      }

      // 3. Conectar al SSE del servidor para sincronización en tiempo real
      connectEvents();

      // 4. Mostrar de inmediato el selector de rol (Profesor vs Alumno)
      openRoleModal();
    });

    // ── FONDO DINÁMICO CANVAS DOT GRID ──
    (function initDotGrid() {
      const canvas = document.getElementById('dot-grid-canvas');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      let dots = [];
      let width = window.innerWidth;
      let height = window.innerHeight;

      function resize() {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
        dots = [];
        const step = 24;
        for (let x = 12; x < width; x += step) {
          for (let y = 12; y < height; y += step) {
            dots.push({ x, y, baseAlpha: 0.15 });
          }
        }
      }

      window.addEventListener('resize', resize);
      resize();

      function draw() {
        ctx.clearRect(0, 0, width, height);
        ctx.fillStyle = '#6366f1';
        for (let i = 0; i < dots.length; i++) {
          const d = dots[i];
          ctx.globalAlpha = d.baseAlpha;
          ctx.beginPath();
          ctx.arc(d.x, d.y, 1.5, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.globalAlpha = 1.0;
        requestAnimationFrame(draw);
      }
      draw();
    })();
  </script>
</body>
</html>
'''

with open('balloon_trivia.html', 'w', encoding='utf-8') as f:
    f.write(html_content.strip())

print("balloon_trivia.html generado limpiamente sin errores ni modales de equipo.")

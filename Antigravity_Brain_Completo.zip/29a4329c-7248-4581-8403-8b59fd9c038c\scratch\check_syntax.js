const fs = require('fs');

const html = fs.readFileSync('balloon_trivia.html', 'utf8');

// Extract all scripts
const scriptRegex = /<script\b[^>]*>([\s\S]*?)<\/script>/gi;
let match;
let scriptIndex = 0;

while ((match = scriptRegex.exec(html)) !== null) {
  const content = match[1];
  // Ignore external src scripts
  if (!content.trim()) continue;
  
  scriptIndex++;
  console.log(`Checking script #${scriptIndex}...`);
  fs.writeFileSync(`scratch/script_${scriptIndex}.js`, content);
  
  try {
    new Function(content);
    console.log(`Script #${scriptIndex}: SYNTAX OK!`);
  } catch (err) {
    console.error(`Script #${scriptIndex}: SYNTAX ERROR:`, err.message);
    console.error(err.stack);
  }
}

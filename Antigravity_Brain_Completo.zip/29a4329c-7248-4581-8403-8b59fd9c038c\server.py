
#!/usr/bin/env python3
"""
🎈🚂 Trivia Ley de Miller — Servidor Multiplayer Online con QR y Tablero Split-Flap
Compatible con Google Colab, Linux, macOS y Windows.
Requiere únicamente la librería estándar de Python (¡Cero dependencias pip obligatorias!).
"""

import http.server
import json
import os
import queue
import random
import socket
import sys
import threading
import time
import urllib.parse

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

# Puerto por defecto
PORT = int(os.environ.get("PORT", 5000))
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ── PALETA DE COLORES VIBRANTES PARA ALUMNOS ──
VIBRANT_COLORS = [
    {"name": "Rojo Carmesí", "hex": "#f43f5e"},
    {"name": "Naranja Fuego", "hex": "#f97316"},
    {"name": "Ámbar Dorado", "hex": "#eab308"},
    {"name": "Esmeralda Neón", "hex": "#10b981"},
    {"name": "Cian Eléctrico", "hex": "#06b6d4"},
    {"name": "Violeta Cyber", "hex": "#8b5cf6"},
    {"name": "Rosa Magenta", "hex": "#ec4899"},
    {"name": "Verde Lima", "hex": "#84cc16"},
    {"name": "Azul Glaciar", "hex": "#0ea5e9"},
    {"name": "Índigo Cósmico", "hex": "#6366f1"},
    {"name": "Turquesa Vivo", "hex": "#14b8a6"},
    {"name": "Oro Radiante", "hex": "#f59e0b"}
]

def get_lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

# ── ESTADO DEL JUEGO COMPARTIDO ──
class GameState:
    def __init__(self):
        self.lock = threading.Lock()
        self.players = {}  # id -> {id, name, color, colorName, score, correct, wrong, status, joined_at}
        self.active_question = None
        self.used_balloons = [False] * 40
        self.event_listeners = []  # List of queue.Queue

    def add_listener(self):
        q = queue.Queue(maxsize=100)
        with self.lock:
            self.event_listeners.append(q)
        return q

    def remove_listener(self, q):
        with self.lock:
            if q in self.event_listeners:
                self.event_listeners.remove(q)

    def broadcast(self, event_type, data):
        payload = json.dumps({"type": event_type, **data})
        with self.lock:
            for q in list(self.event_listeners):
                try:
                    q.put_nowait(payload)
                except queue.Full:
                    pass

    def register_player(self, name, custom_color=None, custom_color_name=None):
        with self.lock:
            player_id = "p_" + str(int(time.time() * 1000))[-7:] + str(random.randint(10, 99))
            color_choice = random.choice(VIBRANT_COLORS) if not custom_color else None
            color_hex = custom_color if custom_color else color_choice["hex"]
            color_name = custom_color_name if custom_color_name else (color_choice["name"] if color_choice else "Personalizado")

            player = {
                "id": player_id,
                "name": name[:18],
                "color": color_hex,
                "colorName": color_name,
                "score": 0,
                "correct": 0,
                "wrong": 0,
                "status": "A BORDO",
                "joined_at": time.time()
            }
            self.players[player_id] = player

        self.broadcast("player_joined", {"player": player, "players": list(self.players.values())})
        return player

    def record_answer(self, player_id, is_correct, points, q_num=None, is_open_text=False, open_text="", player_name=None, player_color=None):
        with self.lock:
            player = self.players.get(player_id)
            if not player and player_name:
                for p in self.players.values():
                    if p["name"].strip().lower() == player_name.strip().lower():
                        player = p
                        player_id = p["id"]
                        break
            if not player and player_name:
                player_id = "p_" + str(int(time.time() * 1000))[-7:]
                player = {
                    "id": player_id,
                    "name": player_name[:18],
                    "color": player_color or "#f43f5e",
                    "colorName": "Alumno",
                    "score": 0,
                    "correct": 0,
                    "wrong": 0,
                    "status": "A BORDO",
                    "joined_at": time.time()
                }
                self.players[player_id] = player

            if not player:
                return None

            if is_correct:
                player["score"] += points
                player["correct"] += 1
                player["status"] = "CORRECTO"
            else:
                player["wrong"] += 1
                player["status"] = "FALLO"
            new_score = player["score"]

        self.broadcast("score_updated", {
            "playerId": player_id,
            "playerName": player["name"],
            "isCorrect": is_correct,
            "points": points,
            "newScore": new_score,
            "players": list(self.players.values())
        })
        if is_open_text and open_text:
            self.broadcast("open_text_submitted", {
                "playerId": player_id,
                "playerName": player["name"],
                "playerColor": player.get("color", "#f59e0b"),
                "text": open_text
            })
        return player

    def open_question(self, q_data, num, points):
        with self.lock:
            self.active_question = {
                "num": num,
                "points": points,
                "q": q_data.get("q", ""),
                "type": q_data.get("type", "mc"),
                "options": q_data.get("options", []),
                "correct": q_data.get("correct"),
                "answer": q_data.get("answer", ""),
                "instruction": q_data.get("instruction", ""),
                "isSimon": q_data.get("isSimon", False),
                "pool": q_data.get("pool", []),
                "count": q_data.get("count", 0),
                "theme": q_data.get("theme", ""),
                "isOpenText": q_data.get("isOpenText", False)
            }
            if 1 <= num <= 40:
                self.used_balloons[num - 1] = True

        self.broadcast("question_opened", {
            "num": num,
            "points": points,
            "question": self.active_question
        })

    def close_question(self):
        with self.lock:
            self.active_question = None
        self.broadcast("question_closed", {})

    def award_points(self, player_id, points):
        with self.lock:
            player = self.players.get(player_id)
            if not player:
                return None
            player["score"] = max(0, player["score"] + points)
            player["status"] = "PREMIO" if points > 0 else "AJUSTE"
            new_score = player["score"]

        self.broadcast("score_updated", {
            "playerId": player_id,
            "playerName": player["name"],
            "isCorrect": points > 0,
            "points": points,
            "newScore": new_score,
            "players": list(self.players.values())
        })
        return player

    def reset_all(self):
        with self.lock:
            for p in self.players.values():
                p["score"] = 0
                p["correct"] = 0
                p["wrong"] = 0
                p["status"] = "A BORDO"
            self.used_balloons = [False] * 40
            self.active_question = None
        self.broadcast("game_reset", {"players": list(self.players.values())})


GAME = GameState()

# ── HTTP REQUEST HANDLER ──
class TriviaHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        if "/api/events" not in args[0]:
            sys.stderr.write("%s - - [%s] %s\n" % (self.address_string(), self.log_date_time_string(), format % args))

    def send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_cors_headers()
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        # 1. Host Projector View
        if path in ["/", "/host", "/balloon_trivia.html"]:
            host_path = os.path.join(BASE_DIR, "balloon_trivia.html")
            if os.path.exists(host_path):
                with open(host_path, "rb") as f:
                    content = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(content)
            else:
                self.send_error(404, "balloon_trivia.html no encontrado")
            return

        # 2. Mobile Join View
        elif path in ["/join", "/player", "/join.html"]:
            join_path = os.path.join(BASE_DIR, "join.html")
            if os.path.exists(join_path):
                with open(join_path, "rb") as f:
                    content = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(content)
            else:
                self.send_error(404, "join.html no encontrado")
            return

        # 3. Realtime SSE Stream
        elif path == "/api/events":
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_cors_headers()
            self.end_headers()

            q = GAME.add_listener()
            # Enviar sincronización inicial
            initial_sync = json.dumps({
                "type": "initial_sync",
                "players": list(GAME.players.values()),
                "activeQuestion": GAME.active_question,
                "usedBalloons": GAME.used_balloons
            })
            self.wfile.write(f"data: {initial_sync}\n\n".encode("utf-8"))
            self.wfile.flush()

            try:
                while True:
                    try:
                        msg = q.get(timeout=15)
                        self.wfile.write(f"data: {msg}\n\n".encode("utf-8"))
                        self.wfile.flush()
                    except queue.Empty:
                        self.wfile.write(b": heartbeat\n\n")
                        self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, Exception):
                pass
            finally:
                GAME.remove_listener(q)
            return

        # 4. Host Info / QR info
        elif path == "/api/host-info":
            ip = get_lan_ip()
            data = {
                "ip": ip,
                "port": PORT,
                "joinUrl": f"http://{ip}:{PORT}/join.html"
            }
            body = json.dumps(data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(body)
            return

        # 5. State API
        elif path == "/api/state":
            data = {
                "players": list(GAME.players.values()),
                "activeQuestion": GAME.active_question,
                "usedBalloons": GAME.used_balloons
            }
            body = json.dumps(data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(body)
            return

        # 6. Static Files
        else:
            clean_path = path.lstrip("/")
            file_path = os.path.join(BASE_DIR, clean_path)
            if os.path.exists(file_path) and os.path.isfile(file_path):
                ext = os.path.splitext(file_path)[1].lower()
                mimes = {
                    ".html": "text/html; charset=utf-8",
                    ".css": "text/css; charset=utf-8",
                    ".js": "application/javascript; charset=utf-8",
                    ".json": "application/json",
                    ".png": "image/png",
                    ".jpg": "image/jpeg",
                    ".svg": "image/svg+xml"
                }
                ctype = mimes.get(ext, "application/octet-stream")
                with open(file_path, "rb") as f:
                    content = f.read()
                self.send_response(200)
                self.send_header("Content-Type", ctype)
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(content)
            else:
                self.send_error(404, "No encontrado")

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        content_len = int(self.headers.get("Content-Length", 0))
        raw_body = self.rfile.read(content_len) if content_len > 0 else b"{}"
        try:
            body = json.loads(raw_body.decode("utf-8"))
        except Exception:
            body = {}

        if path == "/api/register":
            name = body.get("name", "Anónimo").strip()
            custom_color = body.get("color")
            custom_color_name = body.get("colorName")
            player = GAME.register_player(name, custom_color, custom_color_name)
            res = json.dumps({"success": True, "player": player}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(res)
            return

        elif path == "/api/pop":
            num = int(body.get("num", 1))
            points = int(body.get("points", 100))
            q_data = body.get("question") or body.get("q") or {}
            GAME.open_question(q_data, num, points)
            res = json.dumps({"success": True}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(res)
            return

        elif path in ["/api/close-question", "/api/close_question"]:
            GAME.close_question()
            res = json.dumps({"success": True}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(res)
            return

        elif path == "/api/answer":
            player_id = body.get("playerId")
            player_name = body.get("playerName")
            player_color = body.get("playerColor")
            is_correct = bool(body.get("isCorrect"))
            points = int(body.get("points", 0))
            q_num = body.get("questionNum")
            is_open_text = bool(body.get("isOpenText"))
            open_text = body.get("openText", "")
            player = GAME.record_answer(player_id, is_correct, points, q_num, is_open_text, open_text, player_name, player_color)
            res = json.dumps({"success": bool(player), "player": player}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(res)
            return

        elif path == "/api/award":
            player_id = body.get("playerId")
            points = int(body.get("points", 0))
            player = GAME.award_points(player_id, points)
            res = json.dumps({"success": bool(player), "player": player}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(res)
            return

        elif path == "/api/reset":
            GAME.reset_all()
            res = json.dumps({"success": True}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(res)
            return

        else:
            self.send_error(404, "Endpoint no encontrado")


def run_server(port=PORT):
    server_class = http.server.ThreadingHTTPServer
    server = server_class(("0.0.0.0", port), TriviaHandler)
    lan_ip = get_lan_ip()
    print("=" * 60)
    print(f" 🎈🚂 Servidor Trivia Ley de Miller Activo en puerto {port}")
    print(f" 🖥️  Pantalla Anfitrión (Proyector): http://localhost:{port}/")
    print(f" 📱  Pantalla Alumnos (Celular):   http://{lan_ip}:{port}/join.html")
    print("=" * 60)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")
        server.server_close()

if __name__ == "__main__":
    p = int(sys.argv[1]) if len(sys.argv) > 1 else PORT
    run_server(p)


// ══════════════════════════════════════════════════════════════
//  DOT GRID — Vanilla JS implementation
//  Parameters matching the React component:
//    dotSize=6, gap=11, baseColor="#6366F1", activeColor="#EF4444"
//    proximity=80, shockRadius=170, shockStrength=2
//    resistance=250, returnDuration=0.8
// ══════════════════════════════════════════════════════════════
(function initDotGrid() {
  const canvas  = document.getElementById('dot-grid-canvas');
  const ctx     = canvas.getContext('2d');

  const CFG = {
    dotSize:        6,
    gap:            11,
    baseColor:      '#6366F1',
    activeColor:    '#EF4444',
    proximity:      80,
    shockRadius:    170,
    shockStrength:  2,
    resistance:     250,   // maps to damping coefficient
    returnDuration: 0.8,   // seconds — target settling time
  };

  // Derived spring constants
  // We want a critically-damped spring that settles in ~returnDuration seconds.
  // Settling time ≈ 4 / ωn  →  ωn = 4 / T
  const wn  = 4 / CFG.returnDuration;    // natural frequency
  const K   = wn * wn;                   // spring stiffness
  const C   = 2 * wn;                    // critical damping (ζ=1)

  let dots      = [];
  let mouse     = { x: -9999, y: -9999 };
  let lastTime  = 0;
  let raf       = null;

  // ── Parse hex to rgb ──────────────────────────────────────
  function hexToRgb(hex) {
    const v = parseInt(hex.replace('#',''), 16);
    return { r:(v>>16)&255, g:(v>>8)&255, b:v&255 };
  }
  const BASE   = hexToRgb(CFG.baseColor);
  const ACTIVE = hexToRgb(CFG.activeColor);

  function lerpColor(a, b, t) {
    return `rgb(${a.r+(b.r-a.r)*t|0},${a.g+(b.g-a.g)*t|0},${a.b+(b.b-a.b)*t|0})`;
  }

  // ── Build dot grid ────────────────────────────────────────
  function buildDots() {
    const step = CFG.dotSize * 2 + CFG.gap;
    dots = [];
    const cols = Math.ceil(canvas.width  / step) + 1;
    const rows = Math.ceil(canvas.height / step) + 1;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const ox = CFG.dotSize + c * step;
        const oy = CFG.dotSize + r * step;
        dots.push({ ox, oy, x: ox, y: oy, vx: 0, vy: 0 });
      }
    }
  }

  // ── Resize handler ────────────────────────────────────────
  function resize() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
    buildDots();
  }

  // ── Shock wave ────────────────────────────────────────────
  function shock(cx, cy) {
    const { shockRadius, shockStrength } = CFG;
    for (const d of dots) {
      const dx   = d.x - cx;
      const dy   = d.y - cy;
      const dist = Math.sqrt(dx*dx + dy*dy);
      if (dist > 0 && dist < shockRadius) {
        const t     = 1 - dist / shockRadius;
        const force = shockStrength * t * 220;   // scale to pixel/s
        d.vx += (dx / dist) * force;
        d.vy += (dy / dist) * force;
      }
    }
  }

  // ── Physics update ────────────────────────────────────────
  function update(dt) {
    for (const d of dots) {
      // Spring force toward origin
      const fx = -K * (d.x - d.ox);
      const fy = -K * (d.y - d.oy);
      // Damping
      d.vx += (fx - C * d.vx) * dt;
      d.vy += (fy - C * d.vy) * dt;
      d.x  += d.vx * dt;
      d.y  += d.vy * dt;
    }
  }

  // ── Draw ──────────────────────────────────────────────────
  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (const d of dots) {
      const dx   = d.x - mouse.x;
      const dy   = d.y - mouse.y;
      const dist = Math.sqrt(dx*dx + dy*dy);
      const t    = dist < CFG.proximity ? 1 - dist / CFG.proximity : 0;

      const alpha  = 0.30 + t * 0.55;
      const radius = CFG.dotSize * (1 + t * 0.35);
      const color  = lerpColor(BASE, ACTIVE, t);

      ctx.beginPath();
      ctx.arc(d.x, d.y, radius, 0, Math.PI * 2);
      ctx.fillStyle = color.replace('rgb', 'rgba').replace(')', `,${alpha})`);
      ctx.fill();
    }
  }

  // ── Animation loop ────────────────────────────────────────
  function loop(ts) {
    const dt = Math.min((ts - lastTime) / 1000, 0.05);
    lastTime = ts;
    update(dt);
    draw();
    raf = requestAnimationFrame(loop);
  }

  // ── Events (window-level so they work behind UI) ──────────
  window.addEventListener('mousemove', (e) => {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
  });
  window.addEventListener('mouseleave', () => { mouse.x = -9999; mouse.y = -9999; });

  // Shock on click — but only when trivia overlay is NOT blocking
  window.addEventListener('click', (e) => {
    shock(e.clientX, e.clientY);
  });

  // Touch support
  window.addEventListener('touchmove', (e) => {
    const t = e.touches[0];
    mouse.x = t.clientX;
    mouse.y = t.clientY;
  }, { passive: true });
  window.addEventListener('touchstart', (e) => {
    const t = e.touches[0];
    shock(t.clientX, t.clientY);
  }, { passive: true });

  window.addEventListener('resize', resize);

  // ── Init ──────────────────────────────────────────────────
  resize();
  requestAnimationFrame((ts) => { lastTime = ts; loop(ts); });
})();


// ══════════════════════════════════════════
//  PREGUNTAS — Ley de Miller
// ══════════════════════════════════════════
const questions = [
  // ── Opción Múltiple ──────────────────────────────────────────
  { q:"¿Cómo se llama la ley que estamos estudiando?",
    type:"mc", points:100, options:["Ley de Parkinson","Ley de Miller","Ley de Fitts","Ley de Hick"], correct:1, answer:"Ley de Miller" },
  { q:"¿Quién propuso la Ley de Miller?",
    type:"mc", points:100, options:["Abraham Maslow","B.F. Skinner","George A. Miller","Alan Turing"], correct:2, answer:"George A. Miller" },
  { q:"¿Cuál es el número principal asociado con la Ley de Miller?",
    type:"mc", points:100, options:["5","9","12","7"], correct:3, answer:"7" },
  { q:"Completa: 7 más o menos ___.",
    type:"mc", points:100, options:["1","3","2","4"], correct:2, answer:"2" },
  { q:"¿Cuál es el mínimo aproximado de elementos según 7 ± 2?",
    type:"mc", points:200, options:["3","4","6","5"], correct:3, answer:"5" },
  { q:"¿Cuál es el máximo aproximado de elementos según 7 ± 2?",
    type:"mc", points:200, options:["7","10","9","11"], correct:2, answer:"9" },
  { q:"¿Cuál es el rango clásico de elementos planteado por Miller?",
    type:"mc", points:200, options:["De 3 a 7","De 4 a 8","De 6 a 10","De 5 a 9"], correct:3, answer:"De 5 a 9 elementos" },
  { q:"¿En qué año se publicó la investigación de Miller?",
    type:"mc", points:300, options:["1946","1966","1956","1976"], correct:2, answer:"1956" },
  { q:"¿La Ley de Miller está relacionada con la memoria?",
    type:"mc", points:100, options:["No","Solo con memoria visual","Solo con memoria auditiva","Sí"], correct:3, answer:"Sí" },
  { q:"¿Nuestra capacidad para mantener información inmediata es ilimitada?",
    type:"mc", points:200, options:["Sí, es ilimitada","Depende de la persona","Sí, solo en adultos","No, es limitada"], correct:3, answer:"No, es limitada" },
  { q:"¿Qué significa el símbolo ± en 7 ± 2?",
    type:"mc", points:200, options:["Multiplicado por","Dividido entre","Mayor que","Más o menos"], correct:3, answer:"Más o menos" },
  { q:"Si a 7 le restamos 2, ¿cuántos elementos obtenemos?",
    type:"mc", points:100, options:["4","5","6","3"], correct:1, answer:"5" },
  { q:"Si a 7 le sumamos 2, ¿cuántos elementos obtenemos?",
    type:"mc", points:100, options:["8","10","11","9"], correct:3, answer:"9" },
  { q:"¿Cómo se llama la estrategia de agrupar información para recordarla mejor?",
    type:"mc", points:300, options:["Encoding","Rehearsal","Chunking o agrupación","Retrieval"], correct:2, answer:"Chunking o agrupación" },
  { q:"Menciona un ejemplo de información que normalmente agrupamos para recordarla.",
    type:"mc", points:200, options:["El color del cielo","Un número telefónico","La gravedad","La temperatura"], correct:1, answer:"Número telefónico, fecha, código postal, etc." },
  { q:"¿Qué suele ser más fácil de recordar?",
    type:"mc", points:200, options:["Información desorganizada","No hay diferencia","Información breve siempre","Información organizada"], correct:3, answer:"Información organizada" },
  { q:"¿Por qué agrupamos información?",
    type:"mc", points:300, options:["Para hacerla más larga","Para decorar textos","Para facilitar su procesamiento y recuerdo","Para compartirla más rápido"], correct:2, answer:"Para facilitar su procesamiento y recuerdo" },
  { q:"¿La Ley de Miller puede relacionarse con el diseño de interfaces?",
    type:"mc", points:200, options:["No","Solo con interfaces de audio","Solo táctiles","Sí"], correct:3, answer:"Sí" },
  { q:"Menciona un elemento de una página web donde conviene organizar bien la información.",
    type:"mc", points:300, options:["El logo","El fondo de pantalla","La fuente del texto","Los menús de navegación"], correct:3, answer:"Menús, formularios, listas, categorías o navegación" },
  { q:"¿Qué puede ocurrir si presentamos demasiada información al mismo tiempo?",
    type:"mc", points:300, options:["Siempre se aprende más","La memoria mejora","No tiene efecto","Puede ser más difícil procesarla o recordarla"], correct:3, answer:"Puede ser más difícil procesarla o recordarla" },

  // ── Verdadero / Falso (1 intento) ────────────────────────────
  { q:"V/F: La Ley de Miller establece exactamente 7 elementos para TODAS las personas.",
    type:"vf", points:200, correct:false, answer:"Falso — es una aproximación (7 ± 2), no un número exacto universal." },
  { q:"V/F: La formulación clásica de Miller se representa como 7 ± 2.",
    type:"vf", points:100, correct:true, answer:"Verdadero — se escribe 7 ± 2." },
  { q:"V/F: El rango de 7 ± 2 es aproximadamente de 5 a 9.",
    type:"vf", points:100, correct:true, answer:"Verdadero — de 5 a 9 elementos." },
  { q:"V/F: El chunking consiste en separar información sin organizarla.",
    type:"vf", points:200, correct:false, answer:"Falso — el chunking AGRUPA y organiza la información." },
  { q:"V/F: Agrupar un número telefónico puede facilitar que lo recordemos.",
    type:"vf", points:100, correct:true, answer:"Verdadero — es un ejemplo clásico de chunking." },
  { q:"V/F: La investigación clásica de Miller fue publicada en 1956.",
    type:"vf", points:200, correct:true, answer:"Verdadero — publicada en 1956." },
  { q:"V/F: George A. Miller se relaciona con la idea clásica del \"número mágico\" 7 ± 2.",
    type:"vf", points:100, correct:true, answer:"Verdadero — Miller propuso el concepto." },
  { q:"V/F: Una interfaz siempre debe tener exactamente siete botones.",
    type:"vf", points:200, correct:false, answer:"Falso — la Ley de Miller es una guía, no una regla rígida." },
  { q:"V/F: Organizar la información puede facilitar su procesamiento.",
    type:"vf", points:100, correct:true, answer:"Verdadero — la organización mejora el procesamiento." },
  { q:"V/F: Mientras más información pongamos al mismo tiempo, siempre será más fácil recordarla.",
    type:"vf", points:200, correct:false, answer:"Falso — demasiada información dificulta el recuerdo." },

  // ── Retos Adaptados (Simón Dice y Respuesta Abierta) ─────────
  { q:"¡Reto Simón Dice! Toca los botones en el mismo orden que escuchas.",
    type:"reto", points:300, isSimon:true,
    instruction:"Di en voz alta: Perro – Casa – Sol – Mesa – Flor. El participante debe tocar los botones en ese orden exacto.",
    sequence:[
      {id:"perro", label:"Perro", icon:"🐶"},
      {id:"casa", label:"Casa", icon:"🏠"},
      {id:"sol", label:"Sol", icon:"☀️"},
      {id:"mesa", label:"Mesa", icon:"🪑"},
      {id:"flor", label:"Flor", icon:"🌸"}
    ],
    answer:"🐶 Perro ➔ 🏠 Casa ➔ ☀️ Sol ➔ 🪑 Mesa ➔ 🌸 Flor" },

  { q:"¡Reto Simón Dice de 7 Números! Memoriza y reproduce la secuencia.",
    type:"reto", points:400, isSimon:true,
    instruction:"Di en voz alta: 4 – 8 – 2 – 9 – 1 – 6 – 3. El participante debe presionar los números en ese orden.",
    sequence:[
      {id:"4", label:"4", icon:"4️⃣"},
      {id:"8", label:"8", icon:"8️⃣"},
      {id:"2", label:"2", icon:"2️⃣"},
      {id:"9", label:"9", icon:"9️⃣"},
      {id:"1", label:"1", icon:"1️⃣"},
      {id:"6", label:"6", icon:"6️⃣"},
      {id:"3", label:"3", icon:"3️⃣"}
    ],
    answer:"4️⃣ ➔ 8️⃣ ➔ 2️⃣ ➔ 9️⃣ ➔ 1️⃣ ➔ 6️⃣ ➔ 3️⃣" },

  { q:"¡Reto Simón Dice Extremo! Límite superior de Miller (9 letras).",
    type:"reto", points:500, isSimon:true,
    instruction:"Di en voz alta: A – F – M – P – R – T – B – L – S. Selecciona las 9 letras en el orden correcto.",
    sequence:[
      {id:"A", label:"A", icon:"🅰️"},
      {id:"F", label:"F", icon:"🇫"},
      {id:"M", label:"M", icon:"Ⓜ️"},
      {id:"P", label:"P", icon:"🅿️"},
      {id:"R", label:"R", icon:"🇷"},
      {id:"T", label:"T", icon:"🇹"},
      {id:"B", label:"B", icon:"🅱️"},
      {id:"L", label:"L", icon:"🇱"},
      {id:"S", label:"S", icon:"🇸"}
    ],
    answer:"A ➔ F ➔ M ➔ P ➔ R ➔ T ➔ B ➔ L ➔ S (9 letras)" },

  { q:"¡Reto de Chunking! Ordena los bloques lógicos de la serie 5520261956.",
    type:"reto", points:400, isSimon:true,
    instruction:"Agrupa la serie en bloques con sentido temporal/telefónico para memorizarla mejor.",
    sequence:[
      {id:"55", label:"55", icon:"📞"},
      {id:"2026", label:"2026 (Año actual)", icon:"📅"},
      {id:"1956", label:"1956 (Año de Miller)", icon:"🏛️"}
    ],
    answer:"📞 55 ➔ 📅 2026 ➔ 🏛️ 1956" },

  { q:"¡Reto de Percepción! Selecciona la serie mejor optimizada por Chunking.",
    type:"reto", points:300, isSimon:true,
    instruction:"Elige cuál presentación facilita el procesamiento inmediato según la Ley de Miller.",
    sequence:[
      {id:"B", label:"Opción B: 55 – 1234 – 5678 (Bloques estructurados)", icon:"🧩"}
    ],
    options:[
      {id:"A", label:"Opción A: 5 5 1 2 3 4 5 6 7 8 (Sin agrupar)", icon:"🎲"},
      {id:"B", label:"Opción B: 55 – 1234 – 5678 (Bloques estructurados)", icon:"🧩"}
    ],
    answer:"🧩 Opción B: 55 – 1234 – 5678 (Agrupada en chunks)" },

  { q:"¡Detecta el Cambio! Compara ambas listas y selecciona la palabra modificada.",
    type:"reto", points:400, isSimon:true,
    instruction:"Lista 1: perro, manzana, balón, carro, estrella.\nLista 2: perro, manzana, casa, carro, estrella.\n¿Qué elemento cambió?",
    sequence:[
      {id:"balon_casa", label:"Balón cambió por Casa", icon:"⚽➔🏠"}
    ],
    options:[
      {id:"perro_gato", label:"Perro cambió por Gato", icon:"🐶➔🐱"},
      {id:"balon_casa", label:"Balón cambió por Casa", icon:"⚽➔🏠"},
      {id:"manzana_platano", label:"Manzana cambió por Plátano", icon:"🍎➔🍌"},
      {id:"carro_bici", label:"Carro cambió por Bici", icon:"🚗➔🚲"}
    ],
    answer:"⚽➔🏠 Balón fue reemplazado por Casa" },

  { q:"¡Reto Simón Dice de 7 Colores! Reproduce la secuencia en orden.",
    type:"reto", points:400, isSimon:true,
    instruction:"Di en voz alta: Rojo – Verde – Azul – Amarillo – Rosa – Negro – Blanco. Toca los 7 colores en orden.",
    sequence:[
      {id:"rojo", label:"Rojo", icon:"🔴"},
      {id:"verde", label:"Verde", icon:"🟢"},
      {id:"azul", label:"Azul", icon:"🔵"},
      {id:"amarillo", label:"Amarillo", icon:"🟡"},
      {id:"rosa", label:"Rosa", icon:"🌸"},
      {id:"negro", label:"Negro", icon:"⚫"},
      {id:"blanco", label:"Blanco", icon:"⚪"}
    ],
    answer:"🔴 Rojo ➔ 🟢 Verde ➔ 🔵 Azul ➔ 🟡 Amarillo ➔ 🌸 Rosa ➔ ⚫ Negro ➔ ⚪ Blanco" },

  { q:"¡Reto Chunks de Letras! Agrupa las 12 letras en bloques de 3.",
    type:"reto", points:400, isSimon:true,
    instruction:"Serie original: B M Z A F Q L R W D N K. Toca los 4 bloques ordenados.",
    sequence:[
      {id:"BMZ", label:"BMZ", icon:"🔤"},
      {id:"AFQ", label:"AFQ", icon:"🔤"},
      {id:"LRW", label:"LRW", icon:"🔤"},
      {id:"DNK", label:"DNK", icon:"🔤"}
    ],
    answer:"🔤 BMZ ➔ 🔤 AFQ ➔ 🔤 LRW ➔ 🔤 DNK" },

  { q:"¡Reto de Aplicación UX! Ordena la mejor estrategia para un menú de 20 opciones.",
    type:"reto", points:500, isSimon:true,
    instruction:"Aplica la Ley de Miller en diseño web ordenando los 3 principios clave.",
    sequence:[
      {id:"categorizar", label:"1. Agrupar en 3 a 5 categorías", icon:"📂"},
      {id:"submenus", label:"2. Desplegar en submenús contextuales", icon:"📑"},
      {id:"limitar", label:"3. Mantener 7 ± 2 opciones visibles", icon:"✨"}
    ],
    answer:"📂 Categorías ➔ 📑 Submenús ➔ ✨ 7 ± 2 elementos por nivel" },

  { q:"🌟 ¡Globo Dorado Final! Explica con tus palabras la Ley de Miller.",
    type:"reto", points:500, isOpenText:true,
    instruction:"Pregunta abierta: Escribe tu explicación sobre la Ley de Miller (memoria de trabajo, 7 ± 2, chunking). ¡No tiene calificación automática, solo responde y envía!",
    answer:"🌟 Reto final completado: Explicación abierta registrada con éxito." },
];

// ══════════════════════════════════════════
//  ESTADO
// ══════════════════════════════════════════
// ══════════════════════════════════════════
//  EQUIPOS — Sistema de puntuación por equipo
// ══════════════════════════════════════════
const TEAM_COLORS  = ['#ef4444','#3b82f6','#22c55e','#eab308','#a855f7','#f97316'];
const TEAM_MEDALS  = ['🥇','🥈','🥉','4️⃣','5️⃣','6️⃣'];
let teams = [];        // [{name, color, score, correct, wrong}]
let activeTeamIdx = 0; // índice del equipo respondiendo
let lbInterval = null;
let lbCountdown = 5;
const LB_SECS = 5;     // intervalo de actualización del tablero

function selectTeamCount(n){
  document.querySelectorAll('.team-count-btn').forEach((b,i)=>{
    b.classList.toggle('active', i === n-1);
  });
  const container = document.getElementById('team-name-fields');
  container.innerHTML='';
  for(let i=0;i<n;i++){
    const color = TEAM_COLORS[i];
    container.innerHTML += `
      <div style="display:flex;align-items:center;gap:10px;">
        <div style="width:14px;height:14px;border-radius:50%;background:${color};flex-shrink:0;"></div>
        <input class="team-name-input" id="tname-${i}" type="text"
          placeholder="Nombre del equipo ${i+1}" value="Equipo ${i+1}" />
      </div>`;
  }
}

function startGame(){
  const inputs = document.querySelectorAll('.team-name-input');
  teams = Array.from(inputs).map((inp,i)=>({
    name: inp.value.trim() || `Equipo ${i+1}`,
    color: TEAM_COLORS[i],
    score:0, correct:0, wrong:0
  }));
  activeTeamIdx = 0;
  document.getElementById('team-setup-modal').style.display='none';
  document.getElementById('main-screen').style.display='block';
  if(teams.length > 1){
    document.getElementById('lb-panel').style.display='block';
    startLeaderboard();
  }
  renderTeamBar();
  buildGrid();
}

function renderTeamBar(){
  const bar = document.getElementById('active-team-bar');
  if(teams.length <= 1){ bar.style.display='none'; return; }
  bar.innerHTML = '<span style="font-size:0.72rem;font-weight:800;letter-spacing:1px;color:rgba(255,255,255,0.4);text-transform:uppercase;">Turno:</span>';
  teams.forEach((t,i)=>{
    const chip = document.createElement('button');
    chip.className = 'team-chip' + (i===activeTeamIdx?' active-chip':'');
    chip.style.background = t.color;
    chip.style.color = '#fff';
    chip.textContent = t.name;
    chip.onclick = ()=>{ activeTeamIdx=i; renderTeamBar(); };
    bar.appendChild(chip);
  });
}

function creditActiveTeam(pts){
  if(!teams.length) return;
  teams[activeTeamIdx].score += pts;
  teams[activeTeamIdx].correct++;
  // Auto-advance turn after correct answer if >1 team
  if(teams.length > 1){
    activeTeamIdx = (activeTeamIdx + 1) % teams.length;
  }
}

function penalizeActiveTeam(){
  if(!teams.length) return;
  teams[activeTeamIdx].wrong++;
  if(teams.length > 1){
    activeTeamIdx = (activeTeamIdx + 1) % teams.length;
  }
}

// ── Leaderboard ────────────────────────────────────────────────
function startLeaderboard(){
  updateLeaderboard();
  lbCountdown = LB_SECS;
  if(lbInterval) clearInterval(lbInterval);
  lbInterval = setInterval(()=>{
    lbCountdown--;
    const cd = document.getElementById('lb-countdown');
    if(cd) cd.textContent = lbCountdown > 0 ? `Actualizando en ${lbCountdown}s` : 'Actualizando…';
    if(lbCountdown <= 0){
      lbCountdown = LB_SECS;
      updateLeaderboard();
      // Restart CSS animation
      const fill = document.getElementById('lb-fill');
      if(fill){ fill.style.animation='none'; void fill.offsetWidth; fill.style.animation=''; }
    }
  }, 1000);
}

function updateLeaderboard(){
  const container = document.getElementById('lb-rows');
  if(!container) return;
  const sorted = [...teams].sort((a,b)=>b.score-a.score);
  container.innerHTML='';
  sorted.forEach((t,i)=>{
    const rowClass = i===0?'lb-first':i===1?'lb-second':i===2?'lb-third':'';
    const row = document.createElement('div');
    row.className = 'lb-row ' + rowClass;
    row.innerHTML = `
      <span class="lb-pos">${TEAM_MEDALS[i]||i+1}</span>
      <span class="lb-name" style="color:${t.color};">${t.name}</span>
      <span class="lb-score" style="color:${t.color};">${t.score.toLocaleString()}</span>
    `;
    container.appendChild(row);
  });
  renderTeamBar();
}

function toggleLeaderboard(){
  const panel = document.getElementById('lb-panel');
  panel.classList.toggle('open');
}

// ── Fullscreen ─────────────────────────────────────────────────
function toggleFullscreen(){
  const btn = document.getElementById('btn-fullscreen');
  if(!document.fullscreenElement){
    document.documentElement.requestFullscreen().catch(()=>{});
    btn.textContent='⊠';
    btn.title='Salir de pantalla completa';
  } else {
    document.exitFullscreen();
    btn.textContent='⛶';
    btn.title='Pantalla completa';
  }
}
document.addEventListener('fullscreenchange',()=>{
  const btn=document.getElementById('btn-fullscreen');
  if(btn) btn.textContent = document.fullscreenElement ? '⊠' : '⛶';
});

// ── Init setup modal team fields ────────────────────────────────
selectTeamCount(1);  // default: 1 equipo (modo individual)

let scoreCorrect=0, scoreWrong=0, totalScore=0;

let used=new Array(40).fill(false);
let attemptsLeft=3, currentQ=null, currentNum=null, answered=false;


const balloonColors=[
  ['#ff6b6b','#c0392b'],['#ff9f43','#e67e22'],['#feca57','#f39c12'],
  ['#48dbfb','#0abde3'],['#ff9ff3','#f368e0'],['#54a0ff','#2e86de'],
  ['#5f27cd','#341f97'],['#00d2d3','#00b894'],['#ff6348','#e84118'],
  ['#2ed573','#05c46b'],['#eccc68','#ffa502'],['#70a1ff','#5352ed'],
  ['#ff4757','#c0392b'],['#1e90ff','#0984e3'],['#a29bfe','#6c5ce7'],
  ['#fd79a8','#e84393'],['#00cec9','#00b894'],['#e17055','#d63031'],
  ['#74b9ff','#0984e3'],['#55efc4','#00b894'],
];

function buildGrid(){
  const grid=document.getElementById('balloon-grid');
  grid.innerHTML='';
  for(let i=1;i<=40;i++){
    const q=questions[i-1];
    const [c1,c2]=balloonColors[(i-1)%balloonColors.length];
    const isGold=(i===40);
    const glowColor=isGold?'#ffd700':c1;

    // Wrapper with perspective
    const wrap=document.createElement('div');
    wrap.className='balloon-wrapper';

    // Balloon
    const ball=document.createElement('div');
    ball.className='balloon-card'+(used[i-1]?' used':'')+(isGold&&!used[i-1]?' balloon-gold':'');
    ball.style.setProperty('--c1',isGold?'#ffd700':c1);
    ball.style.setProperty('--c2',isGold?'#e6a200':c2);
    ball.style.animationDelay=`${(i*0.19)%3}s`;
    ball.id=`balloon-${i}`;

    const typeEmoji=q.type==='mc'?'🟣':q.type==='vf'?'🔵':(i===40?'🌟':'⭐');
    ball.innerHTML=`
      <div class="shine"></div>
      <div class="balloon-glow" id="glow-${i}"></div>
      <div class="balloon-shimmer"></div>
      <div class="balloon-accent" style="background:linear-gradient(90deg,${glowColor}cc,transparent)"></div>
      <span style="position:relative;z-index:5;">${i}</span>
      <div class="type-badge" style="z-index:5;">${typeEmoji}</div>`;

    if(!used[i-1]){
      ball.onclick=()=>popBalloon(i,ball);

      // ── SpotlightCards: 3D tilt + glow on mousemove ──
      ball.addEventListener('mousemove',(e)=>{
        const r=ball.getBoundingClientRect();
        const nx=(e.clientX-r.left)/r.width;
        const ny=(e.clientY-r.top)/r.height;
        const rotY=(nx-0.5)*18;
        const rotX=(0.5-ny)*18;
        ball.style.transform=`rotateX(${rotX}deg) rotateY(${rotY}deg) scale(1.12) translateY(-4px)`;
        ball.style.animation='none';
        ball.style.boxShadow=`0 18px 36px rgba(0,0,0,0.45), inset 0 -4px 10px rgba(0,0,0,0.2), 0 0 24px ${glowColor}55`;
        const glow=document.getElementById(`glow-${i}`);
        if(glow){ glow.style.background=`radial-gradient(circle at ${nx*100}% ${ny*100}%, ${glowColor}55, transparent 70%)`; glow.style.opacity='1'; }
      });

      // ── mouseenter: dim siblings ──
      ball.addEventListener('mouseenter',()=>{
        document.querySelectorAll('.balloon-card:not(.used)').forEach(b=>{ if(b!==ball) b.classList.add('dimmed'); });
      });

      // ── mouseleave: reset tilt, unglow, undim ──
      ball.addEventListener('mouseleave',()=>{
        ball.style.transform='';
        ball.style.boxShadow='';
        ball.style.animation='';
        const glow=document.getElementById(`glow-${i}`);
        if(glow){ glow.style.opacity='0'; }
        document.querySelectorAll('.balloon-card').forEach(b=>b.classList.remove('dimmed'));
      });
    }

    const knot=document.createElement('div');
    knot.style.cssText='width:9px;height:5px;background:rgba(255,255,255,0.3);border-radius:50%;margin-top:2px;';
    wrap.appendChild(ball); wrap.appendChild(knot);
    grid.appendChild(wrap);
  }
}


function popBalloon(num,el){
  if(used[num-1]) return;
  el.classList.add('popping');
  setTimeout(()=>openTrivia(num),370);
}

function openTrivia(num){
  currentNum=num; currentQ=questions[num-1];
  attemptsLeft=3; answered=false;
  document.getElementById('trivia-num').textContent=num;
  document.getElementById('question-text').textContent=currentQ.q;
  document.getElementById('t-correct').textContent=scoreCorrect;
  document.getElementById('t-wrong').textContent=scoreWrong;
  const typeLabel=currentQ.type==='mc'?'🟣 Opción Múltiple':currentQ.type==='vf'?'🔵 Verdadero / Falso':(num===40?'🌟 Reto Especial':'⭐ Reto');
  document.getElementById('trivia-emoji').textContent=num===40?'🌟':'🎈';
  document.getElementById('trivia-type-label').textContent=typeLabel;
  document.getElementById('question-label').textContent=currentQ.type==='reto'?'RETO':'PREGUNTA';
  document.getElementById('answer-reveal').style.display='none';
  document.getElementById('mc-area').innerHTML='';
  document.getElementById('vf-area').style.display='none';
  document.getElementById('reto-area').style.display='none';
  document.getElementById('attempts-bar').style.display='flex';
  document.getElementById('attempts-bar').style.justifyContent='center';

  // ── Siempre resetear la visibilidad de la tarjeta de pregunta ──
  const qCard = document.querySelector('.question-card');
  qCard.classList.remove('hidden-q');
  qCard.style.filter = '';
  qCard.style.opacity = '';
  const oldCd = document.getElementById('question-countdown');
  if(oldCd) oldCd.remove();

  updateDots();

  if(currentQ.type==='mc'){ buildMCOptions(); }
  else if(currentQ.type==='vf'){
    document.getElementById('attempts-bar').style.display='none'; // 1 solo intento en V/F
    document.getElementById('vf-area').style.display='block';
    document.getElementById('btn-verdadero').disabled=false;
    document.getElementById('btn-falso').disabled=false;
    document.getElementById('btn-verdadero').className='vf-btn vf-v';
    document.getElementById('btn-falso').className='vf-btn vf-f';
  } else {

    document.getElementById('attempts-bar').style.display='none';
    document.getElementById('reto-area').style.display='block';
    document.getElementById('reto-instruction-text').innerText=currentQ.instruction;

    if (currentQ.isOpenText || num === 40) {
      document.getElementById('reto-open-container').style.display='block';
      document.getElementById('reto-simon-container').style.display='none';
      const ta = document.getElementById('q40-host-textarea');
      if (ta) ta.value = '';
      const sc = document.getElementById('q40-submitted-card');
      if (sc) sc.style.display = 'none';
    } else if (currentQ.isSimon || currentQ.sequence) {
      document.getElementById('reto-open-container').style.display='none';
      document.getElementById('reto-simon-container').style.display='block';
      initSimonChallenge(currentQ);
    } else {
      document.getElementById('reto-open-container').style.display='none';
      document.getElementById('reto-simon-container').style.display='none';
    }

    // Reset ✅ / ❌ buttons
    document.querySelectorAll('.btn-reto-correct,.btn-reto-wrong').forEach(b=>b.disabled=false);

    // Reset instruction visibility
    const instrText = document.getElementById('reto-instruction-text');
    const instrOverlay = document.getElementById('reto-reveal-overlay');
    instrText.style.filter=''; instrText.style.opacity='';
    instrOverlay.style.display='none';

    // ── Auto-hide question AND instruction after 5s ──
    const qCard = document.querySelector('.question-card');
    qCard.classList.remove('hidden-q');
    qCard.style.filter=''; qCard.style.opacity='';

    const oldCd = document.getElementById('question-countdown');
    if(oldCd) oldCd.remove();

    const cdEl = document.createElement('div');
    cdEl.id = 'question-countdown';
    let secs = 5;
    cdEl.innerHTML = `⏱ Se ocultará en <strong>${secs}s</strong> — ¡memoriza el reto!`;
    qCard.appendChild(cdEl);

    const timer = setInterval(()=>{
      secs--;
      if(secs > 0){
        cdEl.innerHTML = `⏱ Se ocultará en <strong>${secs}s</strong> — ¡memoriza el reto!`;
      } else {
        clearInterval(timer);
        cdEl.textContent = '🧠 ¡Aplica la Ley de Miller!';
        // Hide question card
        qCard.classList.add('hidden-q');
        // Hide instruction text with blur
        instrText.style.transition='filter 0.6s ease, opacity 0.6s ease';
        instrText.style.filter='blur(8px)';
        instrText.style.opacity='0.1';
        // Show reveal overlay
        instrOverlay.style.display='flex';
      }
    }, 1000);
  }
  document.getElementById('main-screen').style.display='none';
  document.getElementById('trivia-screen').style.display='block';
  document.getElementById('trivia-screen').scrollTop=0;
}

function showRetoInstruction(){
  const instrText = document.getElementById('reto-instruction-text');
  const instrOverlay = document.getElementById('reto-reveal-overlay');
  instrText.style.filter='';
  instrText.style.opacity='';
  instrOverlay.style.display='none';
}

function toggleRetoInstruction(){
  const instrText = document.getElementById('reto-instruction-text');
  const instrOverlay = document.getElementById('reto-reveal-overlay');
  const isHidden = instrOverlay.style.display === 'flex';
  if(isHidden){
    // Currently hidden → show it
    instrText.style.filter='';
    instrText.style.opacity='';
    instrOverlay.style.display='none';
  } else {
    // Currently visible → hide it
    instrText.style.transition='filter 0.5s ease, opacity 0.5s ease';
    instrText.style.filter='blur(8px)';
    instrText.style.opacity='0.1';
    instrOverlay.style.display='flex';
  }
}




function buildMCOptions(){
  const area=document.getElementById('mc-area');
  area.innerHTML='';
  currentQ.options.forEach((opt,idx)=>{
    const btn=document.createElement('button');
    btn.className='answer-option';
    btn.textContent=`${['A','B','C','D'][idx]}. ${opt}`;
    btn.onclick=()=>checkMC(idx,btn);
    area.appendChild(btn);
  });
}

function updateDots(){
  for(let i=1;i<=3;i++)
    document.getElementById(`dot${i}`).className='attempt-dot '+(i<=attemptsLeft?'alive':'dead');
}

function checkMC(idx,btn){
  if(answered) return;
  document.querySelectorAll('.answer-option').forEach(b=>b.disabled=true);
  if(idx===currentQ.correct){ btn.classList.add('correct'); handleCorrect(); }
  else{
    btn.classList.add('wrong');
    handleWrong(()=>{ btn.style.opacity='0.4'; document.querySelectorAll('.answer-option').forEach(b=>{ if(b!==btn) b.disabled=false; }); });
  }
}

function checkVF(userAnswer){
  if(answered) return;
  answered = true;
  document.getElementById('btn-verdadero').disabled=true;
  document.getElementById('btn-falso').disabled=true;
  const btnV=document.getElementById('btn-verdadero'), btnF=document.getElementById('btn-falso');
  if(userAnswer===currentQ.correct){
    if(userAnswer) btnV.className='vf-btn vf-v correct'; else btnF.className='vf-btn vf-f correct';
    scoreCorrect++; totalScore += currentQ.points||0;
    creditActiveTeam(currentQ.points||0);
    updateScoreboard();
    showPointsPopup(currentQ.points||0);
    showCorrectOverlay();
    setTimeout(()=>{ hideCorrectOverlay(); showReveal(); },1400);
  } else {
    if(userAnswer) btnV.className='vf-btn vf-v wrong'; else btnF.className='vf-btn vf-f wrong';
    scoreWrong++; penalizeActiveTeam(); updateScoreboard();
    showErrorOverlay('¡Incorrecto! Solo hay una oportunidad en V/F.');
    setTimeout(()=>{ hideErrorOverlay(); showReveal(); },1500);
  }
}

function retoResult(isCorrect){
  answered=true;
  document.querySelectorAll('.btn-reto-correct,.btn-reto-wrong').forEach(b=>b.disabled=true);
  if(isCorrect){
    scoreCorrect++; totalScore += currentQ.points||0;
    creditActiveTeam(currentQ.points||0);
    updateScoreboard();
    showPointsPopup(currentQ.points||0);
    showCorrectOverlay(); setTimeout(()=>{ hideCorrectOverlay(); showReveal(); },1400);
  } else {
    scoreWrong++; penalizeActiveTeam(); updateScoreboard();
    showErrorOverlay('El participante no respondió correctamente.'); setTimeout(()=>{ hideErrorOverlay(); showReveal(); },1500);
  }
}

function handleCorrect(){
  answered=true; scoreCorrect++; totalScore += currentQ.points||0;
  creditActiveTeam(currentQ.points||0);
  updateScoreboard();
  showPointsPopup(currentQ.points||0);
  showCorrectOverlay(); setTimeout(()=>{ hideCorrectOverlay(); showReveal(); },1400);
}
function handleWrong(onRetry){
  attemptsLeft--; updateDots();
  if(attemptsLeft>0){ showErrorOverlay(`¡Incorrecto! Te quedan ${attemptsLeft} oportunidad${attemptsLeft===1?'':'es'}.`); setTimeout(()=>{ hideErrorOverlay(); if(onRetry) onRetry(); },1000); }
  else{ answered=true; scoreWrong++; penalizeActiveTeam(); updateScoreboard(); showErrorOverlay('¡Sin más oportunidades!'); setTimeout(()=>{ hideErrorOverlay(); showReveal(); },1500); }
}


function showPointsPopup(pts){
  if(!pts) return;
  const pop = document.createElement('div');
  pop.textContent = `+${pts} pts`;
  pop.style.cssText=`position:fixed;top:50%;left:50%;transform:translate(-50%,-60px);
    background:linear-gradient(135deg,#22c55e,#16a34a);color:#fff;font-size:2rem;font-weight:900;
    padding:14px 32px;border-radius:50px;z-index:500;pointer-events:none;
    animation:pointsPop 1.2s ease forwards;font-family:inherit;box-shadow:0 8px 32px rgba(34,197,94,0.5);`;
  document.body.appendChild(pop);
  setTimeout(()=>pop.remove(),1200);
}

function showReveal(){
  if(currentQ.type==='mc') document.querySelectorAll('.answer-option')[currentQ.correct].classList.add('correct');
  else if(currentQ.type==='vf'){
    const btnV=document.getElementById('btn-verdadero'), btnF=document.getElementById('btn-falso');
    btnV.disabled=true; btnF.disabled=true;
    if(currentQ.correct) btnV.className='vf-btn vf-v correct'; else btnF.className='vf-btn vf-f correct';
  }
  document.getElementById('reveal-text').textContent=currentQ.answer;
  document.getElementById('answer-reveal').style.display='block';
  document.getElementById('trivia-screen').scrollTo({top:9999,behavior:'smooth'});
}

function showErrorOverlay(msg){ document.getElementById('error-msg').textContent=msg||'¡Incorrecto!'; document.getElementById('error-overlay').style.display='flex'; }
function hideErrorOverlay(){ document.getElementById('error-overlay').style.display='none'; }
function showCorrectOverlay(){ document.getElementById('correct-overlay').style.display='flex'; }
function hideCorrectOverlay(){ document.getElementById('correct-overlay').style.display='none'; }

function returnToGrid(){
  used[currentNum-1]=true; updateScoreboard();
  document.getElementById('trivia-screen').style.display='none';
  document.getElementById('main-screen').style.display='block';
  buildGrid();
  const el=document.getElementById(`balloon-${currentNum}`);
  if(el) el.scrollIntoView({behavior:'smooth',block:'center'});
}

function updateScoreboard(){
  document.getElementById('score-correct').textContent=scoreCorrect;
  document.getElementById('score-wrong').textContent=scoreWrong;
  const pending = 40 - used.filter(Boolean).length;
  document.getElementById('score-remaining').textContent=pending;
  document.getElementById('t-correct').textContent=scoreCorrect;
  document.getElementById('t-wrong').textContent=scoreWrong;
  const scoreEl = document.getElementById('total-score-display');
  if(scoreEl) scoreEl.textContent = totalScore.toLocaleString();

  // ── Animate Apple Activity rings ──────────────────────────
  const total = 40;
  const pctCorrect  = scoreCorrect / total;
  const pctWrong    = scoreWrong   / total;
  const pctPending  = pending      / total;

  const rCorrect  = document.getElementById('ring-correct');
  const rWrong    = document.getElementById('ring-wrong');
  const rPending  = document.getElementById('ring-pending');

  if (rCorrect)  rCorrect.style.strokeDashoffset  = (578.05  * (1 - pctCorrect)).toFixed(2);
  if (rWrong)    rWrong.style.strokeDashoffset    = (452.39  * (1 - pctWrong)).toFixed(2);
  if (rPending)  rPending.style.strokeDashoffset  = (326.73  * (1 - pctPending)).toFixed(2);
}




function openRepeatPicker(){
  const modal = document.getElementById('repeat-modal');
  const grid  = document.getElementById('repeat-grid');
  grid.innerHTML = '';
  for(let i = 1; i <= 40; i++){
    const btn = document.createElement('button');
    const isUsed = used[i-1];
    btn.textContent = i;
    btn.title = questions[i-1].q.substring(0, 60) + '…';
    btn.style.cssText = `
      border:none; border-radius:10px; padding:8px 0; font-size:0.85rem;
      font-weight:900; cursor:pointer; font-family:inherit; transition:all 0.18s;
      background:${isUsed ? 'rgba(192,132,252,0.25)' : 'rgba(255,255,255,0.08)'};
      color:${isUsed ? '#c084fc' : 'rgba(255,255,255,0.45)'};
      border:1px solid ${isUsed ? 'rgba(192,132,252,0.4)' : 'rgba(255,255,255,0.1)'};
    `;
    btn.onmouseover = () => { btn.style.background='rgba(192,132,252,0.4)'; btn.style.color='#fff'; };
    btn.onmouseout  = () => {
      btn.style.background = isUsed ? 'rgba(192,132,252,0.25)' : 'rgba(255,255,255,0.08)';
      btn.style.color = isUsed ? '#c084fc' : 'rgba(255,255,255,0.45)';
    };
    btn.onclick = () => { closeRepeatPicker(); openTrivia(i); };
    grid.appendChild(btn);
  }
  modal.style.display = 'flex';
}

function closeRepeatPicker(){
  document.getElementById('repeat-modal').style.display = 'none';
}

function openScoreTable(){
  const tbody = document.getElementById('score-table');
  const typeLabel = {mc:'Opción Múltiple', vf:'Verdadero / Falso', reto:'Reto'};
  const diffLabel = {100:'Fácil',200:'Medio',300:'Difícil',400:'Muy difícil',500:'Reto máx.'};
  tbody.innerHTML = `<tr>
    <th>#</th><th>Tipo</th><th>Pregunta</th><th>Puntos</th><th>Estado</th>
  </tr>`;
  questions.forEach((q, i)=>{
    const num = i+1;
    const isUsed = used[i];
    const pts = q.points||0;
    const tr = document.createElement('tr');
    if(isUsed) tr.className = 'stbl-used';
    tr.innerHTML = `
      <td style="font-weight:900;color:#c084fc;">${num}</td>
      <td style="color:rgba(255,255,255,0.5);white-space:nowrap;">${typeLabel[q.type]||q.type}</td>
      <td style="color:rgba(255,255,255,0.75);max-width:200px;">${q.q.substring(0,55)}${q.q.length>55?'…':''}</td>
      <td><span class="pts-badge pts-${pts}">${pts}</span></td>
      <td style="font-size:1.1rem;">${isUsed?'✅':'⬜'}</td>
    `;
    tbody.appendChild(tr);
  });
  document.getElementById('score-table-total').textContent = totalScore.toLocaleString();
  document.getElementById('score-table-modal').style.display='flex';
}

function closeScoreTable(){
  document.getElementById('score-table-modal').style.display='none';
}

// buildGrid() is called by startGame() after team setup.
// selectTeamCount(1) above already rendered the default input fields.


// ══════════════════════════════════════════════════════════════
//  SPLIT-FLAP ANALOG TRAIN STATION ENGINE (SOLARI DI UDINE STYLE)
//  Exact parameters from user specification:
//    tileColor: "#111827", textColor: "#f8fafc", tileRadius: 8, gap: 6,
//    cycleDelay: 2400, flipsPerChar: 8, flipDuration: 0.12, stagger: 0.06
// ══════════════════════════════════════════════════════════════

const CHARSET = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.:-!/*#";
let soundEnabled = true;
let audioCtx = null;

function getAudioContext() {
  if (!audioCtx) {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (AudioContext) audioCtx = new AudioContext();
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(()=>{});
  }
  return audioCtx;
}

function playMechanicalFlapSound() {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(260 + Math.random() * 120, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(70, ctx.currentTime + 0.028);
    gain.gain.setValueAtTime(0.045, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.028);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.028);
  } catch(e){}
}

function toggleFlapSound() {
  soundEnabled = !soundEnabled;
  const btn = document.getElementById('btn-sound-toggle');
  if (btn) btn.textContent = soundEnabled ? '🔊 Sonido On' : '🔇 Sonido Off';
}

class SplitFlapText {
  constructor(container, options = {}) {
    this.container = container;
    this.words = options.words || ["LAUNCH READY", "SYNC ONLINE", "SIGNAL LIVE"];
    this.flipDuration = options.flipDuration || 0.12;
    this.stagger = options.stagger || 0.06;
    this.cycleDelay = options.cycleDelay || 2400;
    this.charset = options.charset || "alphanumeric";
    this.flipsPerChar = options.flipsPerChar || 8;
    this.tileColor = options.tileColor || "#111827";
    this.textColor = options.textColor || "#f8fafc";
    this.tileRadius = options.tileRadius || 8;
    this.gap = options.gap || 6;
    this.padTo = options.padTo || 14;
    this.loop = options.loop !== false;
    this.isSmall = options.isSmall || false;

    this.currentWordIdx = 0;
    this.tiles = [];
    this.timer = null;
    this.init();
  }

  init() {
    this.container.innerHTML = '';
    this.container.style.gap = `${this.gap}px`;
    for (let i = 0; i < this.padTo; i++) {
      const tile = document.createElement('div');
      tile.className = 'splitflap-tile' + (this.isSmall ? ' sf-sm' : '');
      tile.style.background = this.tileColor;
      tile.style.borderRadius = `${this.tileRadius}px`;
      tile.innerHTML = `
        <div class="sf-half sf-top-back" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
        <div class="sf-half sf-bottom-back" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
        <div class="sf-half sf-top-flip" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
        <div class="sf-half sf-bottom-flip" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
      `;
      this.container.appendChild(tile);
      this.tiles.push({
        el: tile,
        currentChar: ' ',
        targetChar: ' ',
        isFlipping: false
      });
    }

    if (this.words && this.words.length > 0) {
      this.setText(this.words[0], false);
      if (this.loop && this.words.length > 1) {
        this.scheduleNext();
      }
    }
  }

  scheduleNext() {
    this.timer = setTimeout(() => {
      this.currentWordIdx = (this.currentWordIdx + 1) % this.words.length;
      this.setText(this.words[this.currentWordIdx], true);
      this.scheduleNext();
    }, this.cycleDelay);
  }

  setText(text, animate = true) {
    const formatted = (text || '').toUpperCase().padEnd(this.padTo, ' ').slice(0, this.padTo);
    for (let i = 0; i < this.padTo; i++) {
      const targetChar = formatted[i] || ' ';
      const tile = this.tiles[i];
      if (tile) {
        if (!animate) {
          this.setTileChar(tile, targetChar);
        } else {
          setTimeout(() => {
            this.flipTileTo(tile, targetChar, this.flipsPerChar);
          }, i * (this.stagger * 1000));
        }
      }
    }
  }

  setTileChar(tile, char) {
    tile.currentChar = char;
    tile.targetChar = char;
    const spans = tile.el.querySelectorAll('.sf-half span');
    spans.forEach(s => s.textContent = char);
    const topFlip = tile.el.querySelector('.sf-top-flip');
    const bottomFlip = tile.el.querySelector('.sf-bottom-flip');
    topFlip.style.transform = 'rotateX(0deg)';
    bottomFlip.style.transform = 'rotateX(90deg)';
  }

  flipTileTo(tile, targetChar, remainingFlips) {
    if (remainingFlips <= 0 && tile.currentChar === targetChar) return;

    let nextChar;
    if (remainingFlips > 1) {
      // Pick random alphanumeric character for intermediate flips
      const pool = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
      nextChar = pool[Math.floor(Math.random() * pool.length)];
    } else {
      nextChar = targetChar;
    }

    const curChar = tile.currentChar;
    tile.currentChar = nextChar;

    const topBackSpan = tile.el.querySelector('.sf-top-back span');
    const bottomBackSpan = tile.el.querySelector('.sf-bottom-back span');
    const topFlip = tile.el.querySelector('.sf-top-flip');
    const bottomFlip = tile.el.querySelector('.sf-bottom-flip');
    const topFlipSpan = topFlip.querySelector('span');
    const bottomFlipSpan = bottomFlip.querySelector('span');

    topBackSpan.textContent = nextChar;
    bottomBackSpan.textContent = curChar;
    topFlipSpan.textContent = curChar;
    bottomFlipSpan.textContent = nextChar;

    topFlip.style.transition = `transform ${this.flipDuration * 0.5}s ease-in`;
    bottomFlip.style.transition = `transform ${this.flipDuration * 0.5}s ease-out`;

    topFlip.style.transform = 'rotateX(0deg)';
    bottomFlip.style.transform = 'rotateX(90deg)';

    // Trigger step 1: top flap folds down
    requestAnimationFrame(() => {
      topFlip.style.transform = 'rotateX(-90deg)';
      playMechanicalFlapSound();

      setTimeout(() => {
        // Trigger step 2: bottom flap drops down
        bottomFlip.style.transform = 'rotateX(0deg)';

        setTimeout(() => {
          bottomBackSpan.textContent = nextChar;
          topFlip.style.transition = 'none';
          bottomFlip.style.transition = 'none';
          topFlip.style.transform = 'rotateX(0deg)';
          bottomFlip.style.transform = 'rotateX(90deg)';
          topFlipSpan.textContent = nextChar;

          if (remainingFlips > 1 || tile.currentChar !== targetChar) {
            this.flipTileTo(tile, targetChar, remainingFlips - 1);
          }
        }, this.flipDuration * 500);
      }, this.flipDuration * 500);
    });
  }
}

// ── INITIALIZE SPLITFLAP TICKER ──
let mainTicker = null;
function initSplitFlapTicker() {
  const tickerEl = document.getElementById('splitflap-ticker');
  if (tickerEl) {
    mainTicker = new SplitFlapText(tickerEl, {
      words: [
        "LAUNCH READY",
        "SYNC ONLINE",
        "SIGNAL LIVE",
        "TRIVIA MILLER",
        "EN ESTACION",
        "SALA CONECTA"
      ],
      flipDuration: 0.12,
      stagger: 0.06,
      cycleDelay: 2400,
      flipsPerChar: 8,
      tileColor: "#111827",
      textColor: "#f8fafc",
      tileRadius: 8,
      gap: 6,
      padTo: 13,
      loop: true
    });
  }
}

// ── MULTIPLAYER PLAYERS STATE & DEPARTURE BOARD ──
let connectedPlayers = [];
let stationClockInterval = null;

function openStationBoard() {
  document.getElementById('station-board-modal').style.display = 'flex';
  updateStationClock();
  if (!stationClockInterval) {
    stationClockInterval = setInterval(updateStationClock, 1000);
  }
  renderStationTable();
}

function closeStationBoard() {
  document.getElementById('station-board-modal').style.display = 'none';
}

function updateStationClock() {
  const clk = document.getElementById('station-clock');
  if (clk) {
    const now = new Date();
    clk.textContent = now.toTimeString().split(' ')[0];
  }
}

function renderStationTable() {
  const tbody = document.getElementById('station-table-body');
  const emptyMsg = document.getElementById('station-empty-msg');
  const counter = document.getElementById('station-passenger-count');
  if (!tbody) return;

  if (counter) counter.textContent = connectedPlayers.length;

  if (connectedPlayers.length === 0) {
    tbody.innerHTML = '';
    if (emptyMsg) emptyMsg.style.display = 'block';
    return;
  }
  if (emptyMsg) emptyMsg.style.display = 'none';

  // Sort by score descending
  const sorted = [...connectedPlayers].sort((a,b) => (b.score||0) - (a.score||0));
  tbody.innerHTML = '';

  sorted.forEach((p, idx) => {
    const tr = document.createElement('tr');
    tr.className = 'station-row';
    const via = String(idx + 1).padStart(2, '0');
    const scoreStr = String(p.score || 0).padStart(4, '0') + ' P';
    const status = p.status || 'ABORDA';

    tr.innerHTML = `
      <td><span style="font-weight:900;color:#f59e0b;font-family:'Roboto Mono',monospace;">${via}</span></td>
      <td>
        <div class="row-name-flap inline-flex" data-name="${p.name}"></div>
      </td>
      <td>
        <span style="display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:50px;background:${p.color}22;border:1px solid ${p.color}88;color:#fff;font-size:0.75rem;font-weight:bold;">
          <span style="width:8px;height:8px;border-radius:50%;background:${p.color};box-shadow:0 0 8px ${p.color};"></span>
          ${p.colorName || 'Color'}
        </span>
      </td>
      <td>
        <div class="row-score-flap inline-flex" data-score="${scoreStr}"></div>
      </td>
      <td>
        <div class="row-status-flap inline-flex" data-status="${status}"></div>
      </td>
    `;
    tbody.appendChild(tr);

    // Initialize SplitFlap tiles for each column
    const nameEl = tr.querySelector('.row-name-flap');
    const scoreEl = tr.querySelector('.row-score-flap');
    const statusEl = tr.querySelector('.row-status-flap');

    new SplitFlapText(nameEl, {
      words: [p.name], padTo: 10, isSmall: true, gap: 3, tileRadius: 5,
      tileColor: "#111827", textColor: "#f8fafc", flipsPerChar: 4, loop: false
    });
    new SplitFlapText(scoreEl, {
      words: [scoreStr], padTo: 6, isSmall: true, gap: 3, tileRadius: 5,
      tileColor: "#111827", textColor: "#4ade80", flipsPerChar: 4, loop: false
    });
    new SplitFlapText(statusEl, {
      words: [status], padTo: 6, isSmall: true, gap: 3, tileRadius: 5,
      tileColor: "#111827", textColor: "#f59e0b", flipsPerChar: 4, loop: false
    });
  });
}

// ── QR CODE MODAL ──
function getJoinUrl() {
  const origin = window.location.origin;
  if (!origin || origin.startsWith('file:')) {
    return 'http://localhost:5000/join';
  }
  return origin + '/join';
}

function openQrModal() {
  const modal = document.getElementById('qr-modal');
  const img = document.getElementById('qr-code-img');
  const txt = document.getElementById('qr-url-text');
  const counter = document.getElementById('qr-passenger-counter');

  const joinUrl = getJoinUrl();
  txt.textContent = joinUrl;
  img.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(joinUrl)}&margin=4`;
  if (counter) counter.textContent = connectedPlayers.length;

  modal.style.display = 'flex';
}

function closeQrModal() {
  document.getElementById('qr-modal').style.display = 'none';
}

function copyJoinUrl() {
  const url = getJoinUrl();
  navigator.clipboard.writeText(url).then(() => {
    const btn = document.getElementById('btn-copy-url');
    btn.textContent = '✅ ¡Copiado!';
    setTimeout(() => btn.textContent = '📋 Copiar Enlace', 2000);
  }).catch(() => {
    alert("Enlace: " + url);
  });
}

// ── SSE REALTIME CONNECTION WITH BACKEND SERVER ──
function initMultiplayerSync() {
  try {
    const evtSource = new EventSource('/api/events');
    evtSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        handleHostEvent(data);
      } catch(e){}
    };
    evtSource.onopen = () => {
      console.log("Multiplayer SSE connected to server.");
    };
  } catch(e){
    console.log("Running in offline/standalone mode.");
  }
}

function handleHostEvent(ev) {
  if (ev.type === 'initial_sync') {
    connectedPlayers = ev.players || [];
    renderStationTable();
    updateScoreboard();
  } else if (ev.type === 'player_joined') {
    connectedPlayers = ev.players || [];
    renderStationTable();
    const qrCount = document.getElementById('qr-passenger-counter');
    if (qrCount) qrCount.textContent = connectedPlayers.length;
    // Notify with soft clack
    playMechanicalFlapSound();
  } else if (ev.type === 'score_updated') {
    connectedPlayers = ev.players || [];
    renderStationTable();
    playMechanicalFlapSound();
  } else if (ev.type === 'open_text_submitted') {
    const card = document.getElementById('q40-submitted-card');
    const txtDisplay = document.getElementById('q40-submitted-text');
    if (card && txtDisplay) {
      card.style.display = 'block';
      txtDisplay.innerHTML = `<span style="color:${ev.playerColor};font-weight:900;">${ev.playerName}:</span> «${ev.text}»`;
    }
    if (window.confetti) window.confetti({ particleCount: 120, spread: 80 });
    playMechanicalFlapSound();
  }
}

// Hook into openTrivia to broadcast question to student phones
const originalOpenTrivia = window.openTrivia;
window.openTrivia = function(num) {
  if (typeof originalOpenTrivia === 'function') {
    originalOpenTrivia(num);
  }
  // Notify server so student phones get the question
  try {
    fetch('/api/pop', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        num: num,
        points: questions[num-1].points || 100,
        q: questions[num-1]
      })
    }).catch(()=>{});
  } catch(e){}
};

// Hook into returnToGrid to tell phones to return to waiting lounge
const originalReturnToGrid = window.returnToGrid;
window.returnToGrid = function() {
  if (typeof originalReturnToGrid === 'function') {
    originalReturnToGrid();
  }
  try {
    fetch('/api/close_question', { method: 'POST' }).catch(()=>{});
  } catch(e){}
};

// Initialize SplitFlap ticker and SSE when DOM is ready
window.addEventListener('DOMContentLoaded', () => {
  initSplitFlapTicker();
  initMultiplayerSync();
});
setTimeout(() => {
  if (!mainTicker) initSplitFlapTicker();
  initMultiplayerSync();
}, 600);


// ══════════════════════════════════════════════════════════════
//  SIMON SAYS SEQUENCE ORDERING & QUESTION 40 OPEN TEXT LOGIC
// ══════════════════════════════════════════════════════════════
let currentSimonTarget = [];
let userSimonSequence = [];
let currentSimonPool = [];

function initSimonChallenge(q) {
  const container = document.getElementById('reto-simon-container');
  const slots = document.getElementById('simon-selected-slots');
  const pool = document.getElementById('simon-buttons-pool');
  if (!container || !slots || !pool) return;

  container.style.display = 'block';
  document.getElementById('reto-open-container').style.display = 'none';

  userSimonSequence = [];
  currentSimonTarget = (q.sequence || []).map(item => item.id);

  let itemsToPool = q.options ? [...q.options] : [...(q.sequence || [])];
  currentSimonPool = itemsToPool.sort(() => Math.random() - 0.5);

  renderSimonPool();
  renderSimonSlots();
}

function renderSimonPool() {
  const pool = document.getElementById('simon-buttons-pool');
  if (!pool) return;
  pool.innerHTML = '';

  currentSimonPool.forEach((item) => {
    const isSelected = userSimonSequence.some(s => s.id === item.id);
    const btn = document.createElement('button');
    btn.className = 'simon-pool-btn';
    btn.disabled = isSelected;
    btn.style.cssText = `
      background: ${isSelected ? 'rgba(255,255,255,0.04)' : 'rgba(30,41,59,0.85)'};
      border: 1.5px solid ${isSelected ? 'rgba(255,255,255,0.08)' : 'rgba(168,85,247,0.4)'};
      border-radius: 14px; padding: 12px 14px;
      color: ${isSelected ? 'rgba(255,255,255,0.25)' : '#f8fafc'};
      font-weight: 800; font-size: 0.95rem; font-family: inherit;
      cursor: ${isSelected ? 'default' : 'pointer'};
      display: flex; align-items: center; gap: 10px; text-align: left;
      transition: all 0.15s ease;
      box-shadow: ${isSelected ? 'none' : '0 4px 12px rgba(0,0,0,0.3)'};
    `;
    btn.innerHTML = `<span style="font-size:1.4rem;flex-shrink:0;">${item.icon}</span><span style="flex:1;">${item.label}</span>`;

    btn.onclick = () => {
      if (isSelected) return;
      userSimonSequence.push(item);
      playMechanicalFlapSound();
      renderSimonPool();
      renderSimonSlots();

      if (userSimonSequence.length === currentSimonTarget.length) {
        setTimeout(checkSimonSequence, 350);
      }
    };
    pool.appendChild(btn);
  });
}

function renderSimonSlots() {
  const slots = document.getElementById('simon-selected-slots');
  if (!slots) return;
  slots.innerHTML = '';

  if (userSimonSequence.length === 0) {
    slots.innerHTML = '<span style="color:#64748b;font-size:0.8rem;font-style:italic;">Secuencia vacía... Toca los botones abajo en orden.</span>';
    return;
  }

  userSimonSequence.forEach((item, idx) => {
    const chip = document.createElement('div');
    chip.style.cssText = `
      display: inline-flex; align-items: center; gap: 6px;
      background: rgba(168,85,247,0.25); border: 1px solid #c084fc;
      border-radius: 50px; padding: 6px 14px; color: #fff;
      font-weight: 800; font-size: 0.82rem; font-family: inherit;
      box-shadow: 0 2px 8px rgba(168,85,247,0.3);
    `;
    chip.innerHTML = `
      <span style="background:rgba(255,255,255,0.15);width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.68rem;font-weight:900;">${idx+1}</span>
      <span>${item.icon}</span>
      <span>${item.label}</span>
    `;
    slots.appendChild(chip);
  });
}

function resetSimonSequence() {
  userSimonSequence = [];
  renderSimonPool();
  renderSimonSlots();
}

function checkSimonSequence() {
  if (userSimonSequence.length === 0) {
    alert("Toca los botones para armar la secuencia primero.");
    return;
  }

  const userIds = userSimonSequence.map(i => i.id);
  const isMatch = (userIds.length === currentSimonTarget.length) &&
                  userIds.every((val, idx) => val === currentSimonTarget[idx]);

  if (isMatch) {
    if (window.confetti) {
      window.confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    }
    const slots = document.getElementById('simon-selected-slots');
    slots.style.borderColor = '#22c55e';
    slots.style.background = 'rgba(34,197,94,0.15)';
    retoResult(true);
  } else {
    const slots = document.getElementById('simon-selected-slots');
    slots.style.borderColor = '#ef4444';
    slots.style.background = 'rgba(239,68,68,0.15)';
    showErrorOverlay('¡Orden incorrecto! Intenta nuevamente.');
    setTimeout(() => {
      hideErrorOverlay();
      slots.style.borderColor = 'rgba(255,255,255,0.2)';
      slots.style.background = 'rgba(0,0,0,0.4)';
      resetSimonSequence();
    }, 1200);
  }
}

// ── QUESTION 40: OPEN TEXT SUBMISSION ──
function submitQ40Host() {
  const textarea = document.getElementById('q40-host-textarea');
  const text = textarea ? textarea.value.trim() : '';

  if (!text || text.length < 3) {
    alert("Por favor escribe una respuesta antes de enviar.");
    if (textarea) textarea.focus();
    return;
  }

  const card = document.getElementById('q40-submitted-card');
  const txtDisplay = document.getElementById('q40-submitted-text');
  if (card && txtDisplay) {
    card.style.display = 'block';
    txtDisplay.textContent = `«${text}»`;
  }

  if (window.confetti) {
    window.confetti({ particleCount: 120, spread: 90, origin: { y: 0.5 } });
  }

  retoResult(true);
}



    // ── BASE DE DATOS DE PREGUNTAS (40 REACTIVOS RIGUROSOS) ──
    const QUESTIONS = [{"num": 1, "q": "¿Qué fenómeno de la mente humana describe principalmente la Ley de Miller?", "type": "mc", "points": 100, "options": ["La velocidad del olvido en la vejez", "La capacidad limitada de la memoria de trabajo inmediata", "El tiempo que tarda el cerebro en procesar un estímulo visual", "La cantidad de palabras que un niño aprende al día"], "correct": 1, "answer": "La capacidad limitada de la memoria de trabajo inmediata"}, {"num": 2, "q": "¿Quién fue el psicólogo cognitivo estadounidense que propuso esta ley en 1956?", "type": "mc", "points": 100, "options": ["Burrhus Frederic Skinner", "Jean Piaget", "George Armitage Miller", "Sigmund Freud"], "correct": 2, "answer": "George Armitage Miller"}, {"num": 3, "q": "¿Cuál es la expresión numérica clásica que define a la Ley de Miller?", "type": "mc", "points": 100, "options": ["5 ± 1 elementos", "7 ± 2 elementos", "10 ± 3 elementos", "3 ± 1 elementos"], "correct": 1, "answer": "7 ± 2 elementos (El número mágico 7 más o menos 2)"}, {"num": 4, "q": "Según el rango de 7 ± 2, ¿cuántos elementos independientes retiene en promedio la memoria inmediata?", "type": "mc", "points": 100, "options": ["Entre 1 y 4 elementos", "Entre 5 y 9 elementos", "Entre 10 y 14 elementos", "Exactamente 7 en todas las personas"], "correct": 1, "answer": "Entre 5 y 9 elementos"}, {"num": 5, "q": "¿Qué tipo de memoria es evaluada directamente en los experimentos de Miller?", "type": "mc", "points": 200, "options": ["Memoria a largo plazo o remota", "Memoria procedimental (habilidades motoras)", "Memoria de trabajo o memoria a corto plazo", "Memoria episódica autobiográfica"], "correct": 2, "answer": "Memoria de trabajo o memoria a corto plazo"}, {"num": 6, "q": "¿Cómo se llama la estrategia cognitiva que consiste en agrupar piezas sueltas en unidades con significado?", "type": "mc", "points": 200, "options": ["Condicionamiento operante", "Chunking (o agrupamiento)", "Efecto Stroop", "Priming semántico"], "correct": 1, "answer": "Chunking (o agrupamiento)"}, {"num": 7, "q": "¿En qué año se publicó el artículo seminal «The Magical Number Seven, Plus or Minus Two»?", "type": "mc", "points": 200, "options": ["1938", "1956", "1972", "1985"], "correct": 1, "answer": "1956 (Publicado en Psychological Review)"}, {"num": 8, "q": "¿Por qué recordamos más fácilmente un número telefónico como 55-1234-5678 que como 5512345678?", "type": "mc", "points": 200, "options": ["Porque los guiones eliminan los dígitos repetidos", "Porque el chunking reduce 10 dígitos individuales a solo 3 bloques significativos", "Porque activa la visión periférica", "Porque la mente solo lee números pares"], "correct": 1, "answer": "Porque el chunking reduce 10 dígitos individuales a solo 3 bloques significativos"}, {"num": 9, "q": "¿La capacidad de la memoria de trabajo inmediata es ilimitada si nos esforzamos al máximo?", "type": "mc", "points": 100, "options": ["Sí, con suficiente concentración mental", "No, tiene una restricción biológica y cognitiva estricta", "Solo es ilimitada en personas con título universitario", "Sí, si se escucha música clásica de fondo"], "correct": 1, "answer": "No, tiene una restricción biológica y cognitiva estricta"}, {"num": 10, "q": "En psicología cognitiva, ¿qué representa exactamente un «chunk» o trozo de información?", "type": "mc", "points": 200, "options": ["Una pérdida momentánea de recuerdos", "Una unidad cognitiva que enlaza varios elementos relacionados", "Un segundo exacto de retención en el reloj cerebral", "Un impulso eléctrico de una sola neurona"], "correct": 1, "answer": "Una unidad cognitiva que enlaza varios elementos relacionados"}, {"num": 11, "q": "¿Qué consecuencia directa ocurre cuando se satura la memoria de trabajo con demasiados estímulos a la vez?", "type": "mc", "points": 200, "options": ["Sobrecarga cognitiva, confusión y pérdida de la información reciente", "La información se graba de inmediato en la memoria permanente", "Aumenta la agudeza auditiva automáticamente", "El cerebro multiplica sus neuronas de inmediato"], "correct": 0, "answer": "Sobrecarga cognitiva, confusión y pérdida de la información reciente"}, {"num": 12, "q": "¿Cómo se aplica correctamente la Ley de Miller en el diseño de interfaces web y móviles (UX/UI)?", "type": "mc", "points": 200, "options": ["Obligando a que cada pantalla tenga exactamente 7 botones sin excepción", "Organizando menús y opciones en categorías breves para no saturar al usuario", "Eliminando el texto y usando únicamente iconos", "Haciendo que cada página desaparezca tras 7 segundos"], "correct": 1, "answer": "Organizando menús y opciones en categorías breves para no saturar al usuario"}, {"num": 13, "q": "Si debes memorizar una lista de compras de 15 productos distintos, ¿cuál es la mejor estrategia?", "type": "mc", "points": 200, "options": ["Repetirlos en voz alta a toda velocidad sin pausas", "Agruparlos en 3 o 4 categorías lógicas (frutas, lácteos, limpieza)", "Leer solo los primeros 3 y descartar los demás", "Cambiarles el orden cada minuto"], "correct": 1, "answer": "Agruparlos en 3 o 4 categorías lógicas (frutas, lácteos, limpieza)"}, {"num": 14, "q": "¿Cuál de los siguientes casos NO constituye un ejemplo de chunking?", "type": "mc", "points": 300, "options": ["Dividir una tarjeta de crédito en 4 bloques de 4 dígitos", "Aprender la sigla «UNAM» en vez de 4 palabras desvinculadas", "Intentar memorizar 12 letras al azar sin ningún patrón ni significado", "Agrupar los ingredientes de una receta por tiempos de cocción"], "correct": 2, "answer": "Intentar memorizar 12 letras al azar sin ningún patrón ni significado"}, {"num": 15, "q": "Revisiones contemporáneas (como Nelson Cowan en 2001) señalan que sin ensayo activo el límite puro ronda:", "type": "mc", "points": 300, "options": ["Aproximadamente 4 unidades (chunks)", "Más de 15 elementos independientes", "1 solo elemento a la vez", "Exactamente 20 elementos"], "correct": 0, "answer": "Aproximadamente 4 unidades (chunks)"}, {"num": 16, "q": "En diseño de software, ¿qué problema surge al mostrar 25 opciones en un solo menú desplegable?", "type": "mc", "points": 200, "options": ["Fatiga en la toma de decisiones por sobrecarga cognitiva", "Mayor consumo de batería en el monitor", "Aceleración no deseada del internet", "La pantalla se bloquea por falta de memoria RAM"], "correct": 0, "answer": "Fatiga en la toma de decisiones por sobrecarga cognitiva"}, {"num": 17, "q": "¿Por qué las placas de autos, RFCs y números de serie se segmentan con espacios o guiones?", "type": "mc", "points": 200, "options": ["Porque la ley prohíbe escribir textos continuos", "Para facilitar su lectura y retención dividiéndolos en chunks manejables", "Para que ocupen mayor superficie en el papel", "Porque los lectores ópticos no pueden leer más de 3 letras"], "correct": 1, "answer": "Para facilitar su lectura y retención dividiéndolos en chunks manejables"}, {"num": 18, "q": "¿Qué permite recordar una secuencia de 10 palabras con mayor facilidad en la memoria de trabajo?", "type": "mc", "points": 300, "options": ["Que formen una oración coherente con significado previo", "Que todas las palabras empiecen con la letra X", "Que pertenezcan a un idioma desconocido", "Que se pronuncien con voz extremadamente baja"], "correct": 0, "answer": "Que formen una oración coherente con significado previo"}, {"num": 19, "q": "¿En qué coinciden la Ley de Miller y la Ley de Hick en el diseño de experiencias de usuario?", "type": "mc", "points": 300, "options": ["Ambas afirman que a mayor número de opciones, mayor es el tiempo y esfuerzo mental necesario", "Ambas exigen que todas las pantallas sean de color azul", "Ambas sostienen que el usuario nunca lee los textos", "Son leyes contradictorias formuladas en física cuántica"], "correct": 0, "answer": "Ambas afirman que a mayor número de opciones, mayor es el tiempo y esfuerzo mental necesario"}, {"num": 20, "q": "¿Cuál es la enseñanza principal de la Ley de Miller para educadores y expositores?", "type": "mc", "points": 300, "options": ["Que se debe enseñar todo el contenido de golpe en los primeros 5 minutos", "Que la mente retiene mejor la información dosificada, jerarquizada y organizada en bloques pequeños", "Que las personas solo pueden aprender 7 conceptos en toda su vida", "Que el uso de diapositivas no tiene impacto en la atención"], "correct": 1, "answer": "Que la mente retiene mejor la información dosificada, jerarquizada y organizada en bloques pequeños"}, {"num": 21, "q": "V/F: La Ley de Miller establece que todas las personas recuerdan exactamente 7 elementos sin variación.", "type": "vf", "points": 100, "correct": false, "answer": "Falso — 7 es solo una media aproximada; el rango real varía típicamente entre 5 y 9 (7 ± 2)."}, {"num": 22, "q": "V/F: El chunking permite retener más datos en total sin rebasar el límite de slots de la memoria de trabajo.", "type": "vf", "points": 100, "correct": true, "answer": "Verdadero — Al comprimir datos en bloques con sentido, cada bloque ocupa un solo slot."}, {"num": 23, "q": "V/F: El rango clásico de elementos inmediatos planteado por George A. Miller va de 5 a 9.", "type": "vf", "points": 100, "correct": true, "answer": "Verdadero — 7 menos 2 equivale a 5, y 7 más 2 equivale a 9."}, {"num": 24, "q": "V/F: La Ley de Miller exige que los sitios web tengan obligatoriamente 7 botones de menú siempre.", "type": "vf", "points": 200, "correct": false, "answer": "Falso — Es una guía cognitiva de dosificación y simplicidad, no una regla rígida de diseño."}, {"num": 25, "q": "V/F: Separar los 16 dígitos de una tarjeta bancaria en grupos de 4 es un ejemplo funcional de chunking.", "type": "vf", "points": 100, "correct": true, "answer": "Verdadero — Transforma 16 dígitos independientes en 4 unidades manejables."}, {"num": 26, "q": "V/F: El artículo seminal de George Miller fue publicado en el año 1956.", "type": "vf", "points": 200, "correct": true, "answer": "Verdadero — Publicado en 1956, marcando el inicio de la psicología cognitiva moderna."}, {"num": 27, "q": "V/F: La sobrecarga cognitiva se produce cuando los datos exceden la capacidad de la memoria de trabajo.", "type": "vf", "points": 100, "correct": true, "answer": "Verdadero — Genera fatiga mental, confusión y pérdida de retención."}, {"num": 28, "q": "V/F: Presentar 20 opciones dispersas sin categorías facilita que el usuario las memorice más rápido.", "type": "vf", "points": 200, "correct": false, "answer": "Falso — La dispersión sin estructura satura la mente y multiplica los tiempos de búsqueda."}, {"num": 29, "q": "V/F: El acrónimo conocido «ONU» se almacena en la memoria como 1 solo chunk y no como 3 letras aisladas.", "type": "vf", "points": 100, "correct": true, "answer": "Verdadero — Posee un significado integrado y ocupa un único espacio mental."}, {"num": 30, "q": "V/F: La memoria de trabajo y la memoria a largo plazo comparten exactamente los mismos límites de capacidad.", "type": "vf", "points": 200, "correct": false, "answer": "Falso — La memoria de trabajo es sumamente limitada (7 ± 2), mientras que la de largo plazo es prácticamente ilimitada."}, {"num": 31, "q": "¡Reto Simón Dice: Nivel Básico (5 Elementos)! Memoriza y repite la secuencia exacta.", "type": "reto", "points": 300, "isSimon": true, "count": 5, "theme": "Objetos Cotidianos", "instruction": "Se mostrarán 5 elementos al azar durante unos segundos. Memoriza el orden y tócalos en la misma secuencia.", "pool": [{"id": "perro", "label": "Perro", "icon": "🐶"}, {"id": "casa", "label": "Casa", "icon": "🏠"}, {"id": "sol", "label": "Sol", "icon": "☀️"}, {"id": "mesa", "label": "Mesa", "icon": "🪑"}, {"id": "flor", "label": "Flor", "icon": "🌸"}, {"id": "manzana", "label": "Manzana", "icon": "🍎"}, {"id": "carro", "label": "Carro", "icon": "🚗"}, {"id": "balon", "label": "Balón", "icon": "⚽"}], "answer": "Secuencia de 5 elementos generada al azar para demostrar el límite inferior de Miller (7 - 2 = 5)."}, {"num": 32, "q": "¡Reto Simón Dice: El Número Mágico (7 Dígitos)! Memoriza y reproduce los dígitos en orden.", "type": "reto", "points": 400, "isSimon": true, "count": 7, "theme": "Dígitos Numéricos", "instruction": "Se presentará una serie de 7 números al azar. ¡Pon a prueba el número mágico de Miller repitiéndolos!", "pool": [{"id": "0", "label": "Cero", "icon": "0️⃣"}, {"id": "1", "label": "Uno", "icon": "1️⃣"}, {"id": "2", "label": "Dos", "icon": "2️⃣"}, {"id": "3", "label": "Tres", "icon": "3️⃣"}, {"id": "4", "label": "Cuatro", "icon": "4️⃣"}, {"id": "5", "label": "Cinco", "icon": "5️⃣"}, {"id": "6", "label": "Seis", "icon": "6️⃣"}, {"id": "7", "label": "Siete", "icon": "7️⃣"}, {"id": "8", "label": "Ocho", "icon": "8️⃣"}, {"id": "9", "label": "Nueve", "icon": "9️⃣"}], "answer": "Serie de 7 dígitos aleatorios representativa del promedio de retención de Miller (7)."}, {"num": 33, "q": "¡Reto Simón Dice Extremo: Límite Superior (9 Letras)! Supera el desafío de 9 elementos.", "type": "reto", "points": 500, "isSimon": true, "count": 9, "theme": "Letras del Alfabeto", "instruction": "9 letras aleatorias (límite superior 7 + 2 = 9). Memoriza con máxima concentración antes de que se oculten.", "pool": [{"id": "A", "label": "A", "icon": "🅰️"}, {"id": "B", "label": "B", "icon": "🅱️"}, {"id": "C", "label": "C", "icon": "🇨"}, {"id": "D", "label": "D", "icon": "🇩"}, {"id": "E", "label": "E", "icon": "🇪"}, {"id": "F", "label": "F", "icon": "🇫"}, {"id": "G", "label": "G", "icon": "🇬"}, {"id": "H", "label": "H", "icon": "🇭"}, {"id": "L", "label": "L", "icon": "🇱"}, {"id": "M", "label": "M", "icon": "Ⓜ️"}, {"id": "P", "label": "P", "icon": "🅿️"}, {"id": "R", "label": "R", "icon": "🇷"}, {"id": "S", "label": "S", "icon": "🇸"}, {"id": "T", "label": "T", "icon": "🇹"}], "answer": "Secuencia de 9 letras que demuestra el límite máximo teórico de retención inmediata sin chunking."}, {"num": 34, "q": "¡Reto Simón Dice: Chunking Numérico en 3 Bloques! Memoriza los 3 bloques con sentido.", "type": "reto", "points": 400, "isSimon": true, "count": 3, "theme": "Bloques Chunking", "instruction": "Memoriza los 3 bloques en que se dividió una secuencia de 10 dígitos y reprodúcelos en orden.", "pool": [{"id": "55", "label": "Lada (55)", "icon": "📞"}, {"id": "2026", "label": "Año Actual (2026)", "icon": "📅"}, {"id": "1956", "label": "Año Miller (1956)", "icon": "🏛️"}, {"id": "777", "label": "Triple Siete (777)", "icon": "🎰"}, {"id": "1200", "label": "Mediodía (1200)", "icon": "⏰"}], "answer": "Demostración de cómo el chunking comprime 10 cifras en solo 3 bloques fáciles de recordar."}, {"num": 35, "q": "¡Reto Simón Dice: 6 Iconos Cotidianos! Reproduce la secuencia de 6 elementos visuales.", "type": "reto", "points": 300, "isSimon": true, "count": 6, "theme": "Iconos Visuales", "instruction": "Se presentará una serie aleatoria de 6 iconos. Memorízalos y tócalos en el orden correspondiente.", "pool": [{"id": "pizza", "label": "Pizza", "icon": "🍕"}, {"id": "avion", "label": "Avión", "icon": "✈️"}, {"id": "guitarra", "label": "Guitarra", "icon": "🎸"}, {"id": "libro", "label": "Libro", "icon": "📚"}, {"id": "cafe", "label": "Café", "icon": "☕"}, {"id": "celular", "label": "Celular", "icon": "📱"}, {"id": "cohete", "label": "Cohete", "icon": "🚀"}, {"id": "diamante", "label": "Diamante", "icon": "💎"}], "answer": "Secuencia de 6 elementos que se ubica dentro de la franja óptima de Miller (5 a 9)."}, {"num": 36, "q": "¡Reto Simón Dice: 5 Conceptos Clave de la Psicología Cognitiva! Memoriza la secuencia de conceptos.", "type": "reto", "points": 400, "isSimon": true, "count": 5, "theme": "Conceptos Cognitivos", "instruction": "Aparecerán 5 conceptos esenciales de la memoria en orden aleatorio. ¡Retén la secuencia y márcala tocando los botones!", "pool": [{"id": "memoria", "label": "Memoria", "icon": "🧠"}, {"id": "chunking", "label": "Chunking", "icon": "🧩"}, {"id": "atencion", "label": "Atención", "icon": "🎯"}, {"id": "estimulo", "label": "Estímulo", "icon": "⚡"}, {"id": "capacidad", "label": "Capacidad", "icon": "📦"}, {"id": "percepcion", "label": "Percepción", "icon": "🔍"}, {"id": "retencion", "label": "Retención", "icon": "⏳"}], "answer": "Demuestra la retención de términos semánticos clave en la memoria de trabajo según el modelo cognitivo."}, {"num": 37, "q": "¡Reto Simón Dice: Los 7 Colores del Espectro! Ordena los 7 colores seleccionados al azar.", "type": "reto", "points": 400, "isSimon": true, "count": 7, "theme": "Paleta de Colores", "instruction": "Aparecerán 7 colores en un orden aleatorio. ¡Retén la secuencia cromática y márcala en orden!", "pool": [{"id": "rojo", "label": "Rojo", "icon": "🔴"}, {"id": "verde", "label": "Verde", "icon": "🟢"}, {"id": "azul", "label": "Azul", "icon": "🔵"}, {"id": "amarillo", "label": "Amarillo", "icon": "🟡"}, {"id": "rosa", "label": "Rosa", "icon": "🌸"}, {"id": "negro", "label": "Negro", "icon": "⚫"}, {"id": "blanco", "label": "Blanco", "icon": "⚪"}, {"id": "morado", "label": "Morado", "icon": "🟣"}, {"id": "naranja", "label": "Naranja", "icon": "🟠"}], "answer": "Serie de 7 colores aleatorios que evalúa la memoria de trabajo visual y semántica simultáneamente."}, {"num": 38, "q": "¡Reto Simón Dice: 4 Chunks de Letras Triples! Memoriza los 4 bloques de 3 letras.", "type": "reto", "points": 400, "isSimon": true, "count": 4, "theme": "Acrónimos Triples", "instruction": "En lugar de memorizar 12 letras sueltas, memoriza estos 4 bloques compactos de 3 letras en orden.", "pool": [{"id": "BMZ", "label": "BMZ", "icon": "🔤"}, {"id": "AFQ", "label": "AFQ", "icon": "🔤"}, {"id": "LRW", "label": "LRW", "icon": "🔤"}, {"id": "DNK", "label": "DNK", "icon": "🔤"}, {"id": "XPT", "label": "XPT", "icon": "🔤"}, {"id": "JKH", "label": "JKH", "icon": "🔤"}], "answer": "Demuestra el poder del chunking: transformar una tarea imposible de 12 letras en una fácil de 4 bloques."}, {"num": 39, "q": "¡Reto Simón Dice: Jerarquía de Diseño UX! Ordena los 4 pasos para simplificar un menú complejo.", "type": "reto", "points": 500, "isSimon": true, "count": 4, "theme": "Estrategia UX", "instruction": "Acomoda en orden los 4 principios de diseño para adaptar un menú de 20 opciones a la Ley de Miller.", "pool": [{"id": "1_cat", "label": "1. Agrupar en 3 a 5 categorías lógicas", "icon": "📂"}, {"id": "2_sub", "label": "2. Crear submenús contextuales", "icon": "📑"}, {"id": "3_lim", "label": "3. Limitar a 7 ± 2 elementos visibles", "icon": "✨"}, {"id": "4_act", "label": "4. Priorizar la acción más frecuente", "icon": "🎯"}], "answer": "📂 Categorías ➔ 📑 Submenús ➔ ✨ Límite 7 ± 2 ➔ 🎯 Acción prioritaria."}, {"num": 40, "q": "🌟 ¡Globo Dorado Final! Explica con tus propias palabras la Ley de Miller.", "type": "reto", "points": 500, "isOpenText": true, "instruction": "Pregunta de reflexión abierta final. Escribe tu explicación sobre la Ley de Miller (menciona la memoria de trabajo, el número 7 ± 2 y el chunking o agrupación). ¡No tiene calificación automática, pero debes responderla y enviarla para concluir la trivia!", "answer": "🌟 Reto final completado con éxito: Reflexión abierta registrada y proyectada en el salón."}];

    // ── PALETA DE COLORES VIBRANTES PARA ALUMNOS ──
    const STUDENT_COLORS = [
      { name: "Rojo Carmesí", hex: "#f43f5e" },
      { name: "Naranja Fuego", hex: "#f97316" },
      { name: "Ámbar Dorado", hex: "#eab308" },
      { name: "Esmeralda Neón", hex: "#10b981" },
      { name: "Cian Eléctrico", hex: "#06b6d4" },
      { name: "Violeta Cyber", hex: "#8b5cf6" },
      { name: "Rosa Magenta", hex: "#ec4899" },
      { name: "Verde Lima", hex: "#84cc16" },
      { name: "Azul Glaciar", hex: "#0ea5e9" },
      { name: "Índigo Cósmico", hex: "#6366f1" },
      { name: "Turquesa Vivo", hex: "#14b8a6" },
      { name: "Oro Radiante", hex: "#f59e0b" }
    ];

    // ── ESTADO GLOBAL (SESIONES INDEPENDIENTES) ──
    let userRole = null; // 'teacher' | 'player'
    let currentPlayer = { name: "Invitado", color: "#f43f5e", colorName: "Rojo Carmesí", score: 0 };
    let connectedPlayers = [];
    let poppedBalloons = new Array(40).fill(false); // Seguimiento independiente de esta sesión
    let activeQuestionIndex = null;
    let currentSimonTarget = [];
    let currentSimonUserSeq = [];
    let simonTimerInterval = null;

    // ── WEB AUDIO API: CLACKS MECÁNICOS Y EFECTOS ──
    let soundEnabled = true;
    let audioCtx = null;
    function getAudio() {
      if (!audioCtx) {
        const AudioC = window.AudioContext || window.webkitAudioContext;
        if (AudioC) audioCtx = new AudioC();
      }
      if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume().catch(()=>{});
      }
      return audioCtx;
    }

    function playMechanicalFlapSound() {
      if (!soundEnabled) return;
      try {
        const ctx = getAudio();
        if (!ctx) return;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(280 + Math.random() * 100, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(70, ctx.currentTime + 0.025);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.025);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.025);
      } catch(e){}
    }

    function playSuccessSound() {
      try {
        const ctx = getAudio();
        if (!ctx) return;
        const now = ctx.currentTime;
        [523.25, 659.25, 783.99, 1046.50].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + idx * 0.08);
          gain.gain.setValueAtTime(0.12, now + idx * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.25);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.08);
          osc.stop(now + idx * 0.08 + 0.25);
        });
      } catch(e){}
    }

    function playErrorSound() {
      try {
        const ctx = getAudio();
        if (!ctx) return;
        const now = ctx.currentTime;
        [220, 180].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(freq, now + idx * 0.12);
          gain.gain.setValueAtTime(0.1, now + idx * 0.12);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.22);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.12);
          osc.stop(now + idx * 0.12 + 0.22);
        });
      } catch(e){}
    }

    function toggleFlapSound() {
      soundEnabled = !soundEnabled;
      const btn = document.getElementById('btn-sound-toggle');
      if (btn) btn.textContent = soundEnabled ? '🔊 Sonido On' : '🔇 Sonido Off';
    }

    // ── ROLE GATEWAY LOGIC (PROFESOR VS JUGADOR) ──
    let selectedPlayerColorIdx = 0;

    function openRoleModal() {
      document.getElementById('role-modal').classList.remove('hidden');
    }

    function closeRoleModal() {
      document.getElementById('role-modal').classList.add('hidden');
    }

    function verifyTeacherLogin() {
      const input = document.getElementById('teacher-password-input');
      const errorMsg = document.getElementById('teacher-login-error');
      const pass = input ? input.value.trim() : '';

      if (pass === 'SoyGenesis') {
        userRole = 'teacher';
        errorMsg.classList.add('hidden');
        closeRoleModal();
        applyRolePermissions();
        localStorage.setItem('trivia_role', 'teacher');
      } else {
        errorMsg.classList.remove('hidden');
        if (input) input.classList.add('border-red-500');
      }
    }

    function rerollPlayerColor() {
      selectedPlayerColorIdx = (selectedPlayerColorIdx + 1) % STUDENT_COLORS.length;
      const c = STUDENT_COLORS[selectedPlayerColorIdx];
      document.getElementById('player-color-preview').style.background = c.hex;
      document.getElementById('player-color-name').textContent = c.name;
    }

    function enterAsPlayer() {
      const nameInput = document.getElementById('player-name-input');
      const name = nameInput ? nameInput.value.trim() : '';
      if (!name) {
        if (nameInput) {
          nameInput.focus();
          nameInput.classList.add('border-red-500');
        }
        return;
      }

      const c = STUDENT_COLORS[selectedPlayerColorIdx];
      currentPlayer = {
        id: 'p_' + Date.now().toString().slice(-6),
        name: name,
        color: c.hex,
        colorName: c.name,
        score: 0
      };

      userRole = 'player';
      closeRoleModal();
      applyRolePermissions();
      localStorage.setItem('trivia_role', 'player');
      localStorage.setItem('trivia_player_data', JSON.stringify(currentPlayer));

      // Registrar jugador con el servidor
      fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: currentPlayer.name,
          color: currentPlayer.color,
          colorName: currentPlayer.colorName
        })
      }).then(r => r.json()).then(data => {
        if (data && data.player) {
          currentPlayer.id = data.player.id;
        }
      }).catch(()=>{});
    }

    function applyRolePermissions() {
      const roleText = document.getElementById('role-text');
      const teacherActions = document.getElementById('teacher-actions');
      const instruction = document.getElementById('board-instruction');
      const progBadge = document.getElementById('player-progress-badge');

      if (userRole === 'teacher') {
        roleText.textContent = '👨‍🏫 Profesor (Control Maestro)';
        roleText.parentElement.className = 'px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 bg-purple-900/60 border border-purple-500/40 text-purple-200';
        teacherActions.style.display = 'flex';
        instruction.textContent = 'Haz clic en cualquier globo para proyectar la pregunta en clase';
        progBadge.classList.add('hidden');
      } else {
        roleText.textContent = `🎓 Alumno: ${currentPlayer.name}`;
        roleText.parentElement.className = 'px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 bg-emerald-900/60 border border-emerald-500/40 text-emerald-200';
        teacherActions.style.display = 'none';
        instruction.textContent = '¡Toca cualquier globo para responder en tu sesión independiente!';
        progBadge.classList.remove('hidden');
        updatePlayerStats();
      }
    }

    function updatePlayerStats() {
      const poppedCount = poppedBalloons.filter(Boolean).length;
      const countEl = document.getElementById('player-balloons-count');
      const ptsEl = document.getElementById('player-points-display');
      if (countEl) countEl.textContent = poppedCount;
      if (ptsEl) ptsEl.textContent = currentPlayer.score;
    }

    // ── CONSTRUCCIÓN DE LA MATRIZ DE 40 GLOBOS ──
    const BALLOON_COLORS = [
      { c1: "#06b6d4", c2: "#2563eb", glow: "rgba(6,182,212,0.4)" }, // 1-10 Básico
      { c1: "#8b5cf6", c2: "#4f46e5", glow: "rgba(139,92,246,0.4)" }, // 11-20 UX
      { c1: "#10b981", c2: "#059669", glow: "rgba(16,185,129,0.4)" }, // 21-30 V/F
      { c1: "#f97316", c2: "#ec4899", glow: "rgba(249,115,22,0.4)" }, // 31-39 Simón Dice
      { c1: "#fbbf24", c2: "#d97706", glow: "rgba(251,191,36,0.8)" }  // 40 Dorado
    ];

    function buildGrid() {
      const grid = document.getElementById('balloon-grid');
      if (!grid) return;
      grid.innerHTML = '';

      for (let i = 1; i <= 40; i++) {
        let palette;
        if (i <= 10) palette = BALLOON_COLORS[0];
        else if (i <= 20) palette = BALLOON_COLORS[1];
        else if (i <= 30) palette = BALLOON_COLORS[2];
        else if (i <= 39) palette = BALLOON_COLORS[3];
        else palette = BALLOON_COLORS[4];

        const isGolden = (i === 40);
        const isPopped = poppedBalloons[i - 1];

        const wrap = document.createElement('div');
        wrap.className = 'balloon-wrapper';

        const card = document.createElement('div');
        card.id = `balloon-${i}`;
        card.className = `balloon-card ${isGolden ? 'golden-balloon' : ''} ${isPopped ? 'balloon-popped' : ''}`;
        card.style.setProperty('--c1', palette.c1);
        card.style.setProperty('--c2', palette.c2);
        card.style.setProperty('--shadow-glow', palette.glow);
        card.style.animationDelay = `${(i * 0.08) % 2.5}s`;

        card.innerHTML = `
          <div class="shine"></div>
          <span class="z-10">${isPopped ? '✓ ' + i : (isGolden ? '🌟 40' : i)}</span>
        `;

        card.onclick = () => onBalloonClick(i);

        const knot = document.createElement('div');
        knot.className = 'balloon-knot';
        knot.style.background = palette.c2;

        const string = document.createElement('div');
        string.className = 'balloon-string';

        wrap.appendChild(card);
        wrap.appendChild(knot);
        wrap.appendChild(string);
        grid.appendChild(wrap);
      }
    }

    // ── CLICK EN GLOBO: CADA JUGADOR REVIENTA SUS PROPIOS GLOBOS INDEPENDIENTEMENTE ──
    function onBalloonClick(num) {
      const qIdx = num - 1;
      // Tanto el profesor como el alumno pueden reventar globos
      openQuestion(qIdx);
    }

    // ── APERTURA Y CONTROL DE PREGUNTAS ──
    function openQuestion(qIdx) {
      if (qIdx < 0 || qIdx >= QUESTIONS.length) return;
      activeQuestionIndex = qIdx;
      const q = QUESTIONS[qIdx];
      const num = qIdx + 1;

      // Marcar globo como reventado en la sesión de este participante
      poppedBalloons[qIdx] = true;
      const balloonEl = document.getElementById(`balloon-${num}`);
      if (balloonEl) {
        balloonEl.classList.add('balloon-popped');
        const span = balloonEl.querySelector('span');
        if (span) span.textContent = '✓ ' + num;
      }
      updatePlayerStats();

      // Si es profesor, notificar al servidor sobre la pregunta abierta
      if (userRole === 'teacher') {
        fetch('/api/pop', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ num: num, question: q, points: q.points })
        }).catch(()=>{});
      }

      // Configurar pantalla de pregunta
      const modal = document.getElementById('trivia-screen');
      document.getElementById('q-number-badge').textContent = `Globo #${num}`;
      document.getElementById('q-points-badge').textContent = `+${q.points} PTS`;
      document.getElementById('q-text').textContent = q.q;
      document.getElementById('q-instruction').textContent = q.instruction || 'Selecciona la opción correcta:';

      const optView = document.getElementById('q-options-view');
      const vfView = document.getElementById('q-vf-view');
      const simonView = document.getElementById('q-simon-view');
      const openView = document.getElementById('q-opentext-view');
      const feedback = document.getElementById('q-feedback-card');

      optView.classList.add('hidden');
      vfView.classList.add('hidden');
      simonView.classList.add('hidden');
      openView.classList.add('hidden');
      feedback.classList.add('hidden');

      if (q.isOpenText) {
        document.getElementById('q-category-badge').textContent = '🌟 Reflexión Abierta Final';
        openView.classList.remove('hidden');
        document.getElementById('q40-input-text').value = '';
      } else if (q.isSimon) {
        document.getElementById('q-category-badge').textContent = `🎮 Reto Simón Dice (${q.count} elementos)`;
        simonView.classList.remove('hidden');
        initSimonChallenge(q);
      } else if (q.type === 'vf') {
        document.getElementById('q-category-badge').textContent = 'Verdadero o Falso';
        vfView.classList.remove('hidden');
      } else {
        document.getElementById('q-category-badge').textContent = 'Opción Múltiple';
        optView.classList.remove('hidden');
        renderMultipleChoice(q);
      }

      modal.classList.remove('hidden');
    }

    function closeTriviaScreen() {
      document.getElementById('trivia-screen').classList.add('hidden');
      if (simonTimerInterval) clearInterval(simonTimerInterval);
    }

    // ── RENDERIZADO DE OPCIÓN MÚLTIPLE ──
    function renderMultipleChoice(q) {
      const container = document.getElementById('q-options-view');
      container.innerHTML = '';
      const letters = ['A', 'B', 'C', 'D'];

      q.options.forEach((optText, idx) => {
        const btn = document.createElement('button');
        btn.className = 'p-4 rounded-2xl bg-slate-900/80 border border-purple-500/30 hover:border-purple-400 hover:bg-slate-800/90 text-left text-xs sm:text-sm font-semibold text-slate-200 transition flex items-start gap-3 active:scale-98';
        btn.innerHTML = `
          <span class="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center justify-center font-bold text-xs shrink-0">${letters[idx]}</span>
          <span>${optText}</span>
        `;
        btn.onclick = () => submitAnswer(idx === q.correct, q.answer, q.points);
        container.appendChild(btn);
      });
    }

    function handleVfAnswer(userChoice) {
      const q = QUESTIONS[activeQuestionIndex];
      const isCorrect = (userChoice === q.correct);
      submitAnswer(isCorrect, q.answer, q.points);
    }

    function submitAnswer(isCorrect, explanation, points) {
      const feed = document.getElementById('q-feedback-card');
      feed.classList.remove('hidden');

      if (isCorrect) {
        playSuccessSound();
        if (window.confetti) window.confetti({ particleCount: 80, spread: 70 });
        feed.className = 'p-4 rounded-2xl border text-sm font-semibold mb-3 bg-emerald-950/70 border-emerald-500 text-emerald-300';
        feed.innerHTML = `🎉 <strong>¡CORRECTO! (+${points} PTS)</strong><br><span class="text-xs text-emerald-200/90 font-normal">${explanation}</span>`;
        if (userRole === 'player') {
          currentPlayer.score += points;
          updatePlayerStats();
        }
      } else {
        playErrorSound();
        feed.className = 'p-4 rounded-2xl border text-sm font-semibold mb-3 bg-rose-950/70 border-rose-500 text-rose-300';
        feed.innerHTML = `❌ <strong>INCORRECTO</strong><br><span class="text-xs text-rose-200/90 font-normal">${explanation}</span>`;
      }

      // Enviar resultado del alumno al servidor para que el tablero analógico se actualice
      if (userRole === 'player') {
        fetch('/api/answer', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            playerId: currentPlayer.id,
            playerName: currentPlayer.name,
            playerColor: currentPlayer.color,
            isCorrect: isCorrect,
            points: isCorrect ? points : 0,
            questionNum: activeQuestionIndex + 1
          })
        }).catch(()=>{});
      }
    }

    // ── MOTOR SIMÓN DICE INTERACTIVO CON SECUENCIA ALEATORIA ──
    function initSimonChallenge(q) {
      if (simonTimerInterval) clearInterval(simonTimerInterval);

      // Generar secuencia aleatoria única para esta persona y ronda
      const pool = [...q.pool];
      for (let i = pool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [pool[i], pool[j]] = [pool[j], pool[i]];
      }
      currentSimonTarget = pool.slice(0, q.count);
      currentSimonUserSeq = [];

      const memoBox = document.getElementById('simon-memo-box');
      const inputBox = document.getElementById('simon-input-box');
      const displayItems = document.getElementById('simon-display-items');
      const timerBar = document.getElementById('simon-timer-bar');
      const countdownText = document.getElementById('simon-countdown-text');

      memoBox.classList.remove('hidden');
      inputBox.classList.add('hidden');
      timerBar.style.width = '100%';

      // Mostrar los elementos a memorizar
      displayItems.innerHTML = '';
      currentSimonTarget.forEach((item, idx) => {
        const badge = document.createElement('div');
        badge.className = 'flex flex-col items-center p-3 rounded-2xl bg-purple-900/40 border border-purple-400/50 shadow-md min-w-[70px] animate-in zoom-in duration-300';
        badge.innerHTML = `
          <span class="text-xs font-bold text-purple-300 mb-1">#${idx + 1}</span>
          <span class="text-3xl mb-1">${item.icon}</span>
          <span class="text-[11px] font-bold text-white text-center leading-tight">${item.label}</span>
        `;
        displayItems.appendChild(badge);
      });

      // Temporizador de 5 segundos
      let remaining = 5.0;
      countdownText.textContent = '5.0s';
      const step = 100;

      simonTimerInterval = setInterval(() => {
        remaining -= (step / 1000);
        if (remaining <= 0) {
          clearInterval(simonTimerInterval);
          startSimonInputPhase(q);
        } else {
          countdownText.textContent = remaining.toFixed(1) + 's';
          timerBar.style.width = (remaining / 5.0 * 100) + '%';
        }
      }, step);
    }

    function startSimonInputPhase(q) {
      document.getElementById('simon-memo-box').classList.add('hidden');
      document.getElementById('simon-input-box').classList.remove('hidden');

      renderSimonUserTray();
      renderSimonButtons(q);
    }

    function renderSimonUserTray() {
      const tray = document.getElementById('simon-user-tray');
      tray.innerHTML = '';

      if (currentSimonUserSeq.length === 0) {
        tray.innerHTML = '<span class="text-xs text-slate-500 italic">Toca los botones de abajo para formar tu secuencia...</span>';
        return;
      }

      currentSimonUserSeq.forEach((item, idx) => {
        const chip = document.createElement('div');
        chip.className = 'px-3 py-1.5 rounded-full bg-purple-600/30 border border-purple-400 text-purple-200 text-xs font-bold flex items-center gap-1.5 shadow-sm';
        chip.innerHTML = `
          <span class="text-[10px] text-purple-300 font-mono">${idx + 1}.</span>
          <span class="text-base">${item.icon}</span>
          <span>${item.label}</span>
        `;
        tray.appendChild(chip);
      });
    }

    function renderSimonButtons(q) {
      const box = document.getElementById('simon-interactive-buttons');
      box.innerHTML = '';

      q.pool.forEach(item => {
        const isSelected = currentSimonUserSeq.some(x => x.id === item.id);
        const btn = document.createElement('button');
        btn.disabled = isSelected;
        btn.className = `p-3 rounded-2xl border text-left flex items-center gap-2.5 text-xs font-bold transition ${
          isSelected 
            ? 'bg-slate-900/40 border-slate-800 text-slate-600 cursor-not-allowed' 
            : 'bg-slate-800/90 hover:bg-slate-700/90 border-purple-500/40 text-white active:scale-95 shadow-sm'
        }`;
        btn.innerHTML = `<span class="text-2xl">${item.icon}</span><span class="truncate">${item.label}</span>`;
        btn.onclick = () => {
          if (isSelected) return;
          currentSimonUserSeq.push(item);
          renderSimonUserTray();
          renderSimonButtons(q);
          if (currentSimonUserSeq.length === currentSimonTarget.length) {
            setTimeout(checkSimonFinal, 300);
          }
        };
        box.appendChild(btn);
      });
    }

    function undoSimonLast() {
      if (currentSimonUserSeq.length > 0) {
        currentSimonUserSeq.pop();
        const q = QUESTIONS[activeQuestionIndex];
        renderSimonUserTray();
        renderSimonButtons(q);
      }
    }

    function resetSimonPlayerInput() {
      currentSimonUserSeq = [];
      const q = QUESTIONS[activeQuestionIndex];
      renderSimonUserTray();
      renderSimonButtons(q);
    }

    function checkSimonFinal() {
      const q = QUESTIONS[activeQuestionIndex];
      if (currentSimonUserSeq.length === 0) return;

      const userIds = currentSimonUserSeq.map(i => i.id);
      const targetIds = currentSimonTarget.map(i => i.id);

      const isMatch = (userIds.length === targetIds.length) &&
                      userIds.every((val, idx) => val === targetIds[idx]);

      const targetIcons = currentSimonTarget.map(i => `${i.icon} ${i.label}`).join(' ➔ ');
      submitAnswer(isMatch, `Secuencia objetivo: ${targetIcons}`, q.points);
    }

    // ── PREGUNTA 40 (GLOBO DORADO FINAL - RESPUESTA ABIERTA) ──
    function submitQ40OpenText() {
      const textarea = document.getElementById('q40-input-text');
      const text = textarea ? textarea.value.trim() : '';

      if (text.length < 5) {
        alert('Por favor redacta tu conclusión sobre la Ley de Miller antes de enviar.');
        if (textarea) textarea.focus();
        return;
      }

      if (window.confetti) {
        window.confetti({ particleCount: 120, spread: 90, origin: { y: 0.5 } });
      }
      playSuccessSound();

      const feed = document.getElementById('q-feedback-card');
      feed.classList.remove('hidden');
      feed.className = 'p-5 rounded-2xl border text-sm font-semibold mb-3 bg-amber-950/70 border-amber-500 text-amber-200';
      feed.innerHTML = `
        🎉 <strong>¡RESPUESTA REGISTRADA CON ÉXITO! (+500 PTS)</strong><br>
        <span class="text-xs text-amber-100/90 font-normal">«${text}»</span><br>
        <span class="text-xs text-emerald-300 font-bold mt-1 inline-block">¡Felicidades por completar los 40 globos de la trivia!</span>
      `;

      if (userRole === 'player') {
        currentPlayer.score += 500;
        updatePlayerStats();
      }

      // Enviar reflexión al servidor para proyectar en el salón
      fetch('/api/answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          playerId: currentPlayer.id,
          playerName: currentPlayer.name,
          playerColor: currentPlayer.color,
          isOpenText: true,
          openText: text,
          points: 500,
          isCorrect: true,
          questionNum: 40
        })
      }).catch(()=>{});
    }

    // ── REPETIR PREGUNTAS MODAL (PROFESOR) ──
    function openRepeatModal() {
      const grid = document.getElementById('repeat-grid');
      grid.innerHTML = '';
      for (let i = 1; i <= 40; i++) {
        const btn = document.createElement('button');
        btn.className = `p-2 rounded-xl text-xs font-bold transition border ${
          poppedBalloons[i - 1]
            ? 'bg-purple-900/60 border-purple-500/40 text-purple-200 hover:bg-purple-800'
            : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:bg-slate-700'
        }`;
        btn.textContent = (i === 40) ? '🌟 40' : `#${i}`;
        btn.onclick = () => {
          closeRepeatModal();
          openQuestion(i - 1);
        };
        grid.appendChild(btn);
      }
      document.getElementById('repeat-modal').classList.remove('hidden');
    }

    function closeRepeatModal() {
      document.getElementById('repeat-modal').classList.add('hidden');
    }

    // ── TABLA DE PUNTUACIONES Y AJUSTES (PROFESOR) ──
    function openScoreTableModal() {
      const body = document.getElementById('score-table-body');
      body.innerHTML = '';

      if (connectedPlayers.length === 0) {
        body.innerHTML = '<div class="text-xs text-slate-400 text-center py-6">Aún no hay alumnos registrados.</div>';
      } else {
        connectedPlayers.forEach(p => {
          const row = document.createElement('div');
          row.className = 'flex items-center justify-between p-3 rounded-2xl bg-slate-900/80 border border-slate-800';
          row.innerHTML = `
            <div class="flex items-center gap-3">
              <div class="w-4 h-4 rounded-full border border-white/30" style="background:${p.color || '#f43f5e'}"></div>
              <span class="text-sm font-bold text-white">${p.name}</span>
            </div>
            <div class="flex items-center gap-3">
              <span class="text-sm font-mono font-black text-amber-400">${p.score || 0} pts</span>
              <div class="flex items-center gap-1">
                <button onclick="adjustPlayerScore('${p.id}', -50)" class="w-7 h-7 rounded-lg bg-rose-900/40 text-rose-300 border border-rose-500/30 hover:bg-rose-800 font-black text-xs">-50</button>
                <button onclick="adjustPlayerScore('${p.id}', 100)" class="w-7 h-7 rounded-lg bg-emerald-900/40 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-800 font-black text-xs">+100</button>
              </div>
            </div>
          `;
          body.appendChild(row);
        });
      }

      document.getElementById('score-table-modal').classList.remove('hidden');
    }

    function closeScoreTableModal() {
      document.getElementById('score-table-modal').classList.add('hidden');
    }

    function adjustPlayerScore(playerId, amount) {
      fetch('/api/award', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerId: playerId, points: amount })
      }).then(() => openScoreTableModal()).catch(()=>{});
    }

    function resetAllScores() {
      if (confirm('¿Seguro que deseas reiniciar todos los puntajes a 0?')) {
        fetch('/api/reset', { method: 'POST' }).then(() => openScoreTableModal()).catch(()=>{});
      }
    }

    // ── MODAL QR CODE ──
    async function openQrModal() {
      const modal = document.getElementById('qr-modal');
      const canvas = document.getElementById('qr-canvas');
      let hostUrl = `${window.location.protocol}//${window.location.hostname}:${window.location.port || '5000'}/join.html`;

      try {
        const res = await fetch('/api/host-info');
        const info = await res.json();
        if (info && info.joinUrl) {
          hostUrl = info.joinUrl;
        }
      } catch(e){}

      document.getElementById('qr-url-text').textContent = hostUrl;

      if (window.QRCode && canvas) {
        QRCode.toCanvas(canvas, hostUrl, { width: 224, margin: 2 }, function(error) {
          if (error) console.error(error);
        });
      }
      modal.classList.remove('hidden');
    }

    function closeQrModal() {
      document.getElementById('qr-modal').classList.add('hidden');
    }

    // ── TABLERO DE TREN ANALÓGICO SOLARI DI UDINE (SPLIT-FLAP) ──
    class SplitFlapText {
      constructor(container, options = {}) {
        this.container = container;
        this.words = options.words || ["LAUNCH READY", "SYNC ONLINE", "SIGNAL LIVE"];
        this.flipDuration = options.flipDuration || 0.12;
        this.stagger = options.stagger || 0.06;
        this.cycleDelay = options.cycleDelay || 2400;
        this.flipsPerChar = options.flipsPerChar || 8;
        this.tileColor = options.tileColor || "#111827";
        this.textColor = options.textColor || "#f8fafc";
        this.tileRadius = options.tileRadius || 8;
        this.gap = options.gap || 6;
        this.padTo = options.padTo || 14;
        this.loop = options.loop !== false;
        this.isSmall = options.isSmall || false;

        this.currentWordIdx = 0;
        this.tiles = [];
        this.timer = null;
        this.init();
      }

      init() {
        this.container.innerHTML = '';
        this.container.style.gap = `${this.gap}px`;
        for (let i = 0; i < this.padTo; i++) {
          const tile = document.createElement('div');
          tile.className = 'splitflap-tile' + (this.isSmall ? ' sf-sm' : '');
          tile.style.background = this.tileColor;
          tile.style.borderRadius = `${this.tileRadius}px`;
          tile.innerHTML = `
            <div class="sf-half sf-top-back" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
            <div class="sf-half sf-bottom-back" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
            <div class="sf-half sf-top-flip" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
            <div class="sf-half sf-bottom-flip" style="background:${this.tileColor};color:${this.textColor};"><span> </span></div>
          `;
          this.container.appendChild(tile);
          this.tiles.push({
            el: tile,
            currentChar: ' ',
            targetChar: ' '
          });
        }

        if (this.words && this.words.length > 0) {
          this.setText(this.words[0], false);
          if (this.loop && this.words.length > 1) {
            this.scheduleNext();
          }
        }
      }

      scheduleNext() {
        this.timer = setTimeout(() => {
          this.currentWordIdx = (this.currentWordIdx + 1) % this.words.length;
          this.setText(this.words[this.currentWordIdx], true);
          this.scheduleNext();
        }, this.cycleDelay);
      }

      setText(text, animate = true) {
        const formatted = (text || '').toUpperCase().padEnd(this.padTo, ' ').slice(0, this.padTo);
        for (let i = 0; i < this.padTo; i++) {
          const targetChar = formatted[i] || ' ';
          const tile = this.tiles[i];
          if (tile) {
            if (!animate) {
              this.setTileChar(tile, targetChar);
            } else {
              setTimeout(() => {
                this.flipTileTo(tile, targetChar, this.flipsPerChar);
              }, i * (this.stagger * 1000));
            }
          }
        }
      }

      setTileChar(tile, char) {
        tile.currentChar = char;
        tile.targetChar = char;
        const spans = tile.el.querySelectorAll('.sf-half span');
        spans.forEach(s => s.textContent = char);
      }

      flipTileTo(tile, targetChar, remainingFlips) {
        if (remainingFlips <= 0 && tile.currentChar === targetChar) return;
        const pool = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        const nextChar = (remainingFlips > 1) ? pool[Math.floor(Math.random() * pool.length)] : targetChar;

        tile.currentChar = nextChar;
        const spans = tile.el.querySelectorAll('.sf-half span');
        spans.forEach(s => s.textContent = nextChar);
        playMechanicalFlapSound();

        if (remainingFlips > 1 || tile.currentChar !== targetChar) {
          setTimeout(() => {
            this.flipTileTo(tile, targetChar, remainingFlips - 1);
          }, this.flipDuration * 600);
        }
      }
    }

    let stationTicker = null;
    let mainTicker = null;
    let stationClockInterval = null;

    function openStationBoard() {
      document.getElementById('station-board-modal').classList.remove('hidden');
      document.getElementById('station-board-modal').classList.add('flex');
      updateStationClock();
      if (!stationClockInterval) {
        stationClockInterval = setInterval(updateStationClock, 1000);
      }
      renderStationRows();
    }

    function closeStationBoard() {
      document.getElementById('station-board-modal').classList.add('hidden');
      document.getElementById('station-board-modal').classList.remove('flex');
    }

    function updateStationClock() {
      const clk = document.getElementById('station-clock');
      if (clk) {
        const now = new Date();
        clk.textContent = now.toTimeString().split(' ')[0];
      }
    }

    function renderStationRows() {
      const container = document.getElementById('station-board-rows');
      if (!container) return;
      container.innerHTML = '';

      if (connectedPlayers.length === 0) {
        container.innerHTML = '<div class="text-xs text-slate-500 text-center py-6 font-mono">SIN PASAJEROS A BORDO</div>';
        return;
      }

      const sorted = [...connectedPlayers].sort((a,b) => (b.score || 0) - (a.score || 0));

      sorted.forEach((p, idx) => {
        const row = document.createElement('div');
        row.className = 'grid grid-cols-12 gap-2 text-xs font-mono items-center py-1.5 border-b border-slate-800/60';
        row.innerHTML = `
          <div class="col-span-2 text-center text-amber-400 font-bold">VÍA 0${idx + 1}</div>
          <div class="col-span-4 text-white font-bold truncate">${p.name.toUpperCase()}</div>
          <div class="col-span-2 flex items-center justify-center gap-1.5">
            <span class="w-3 h-3 rounded-full" style="background:${p.color || '#f43f5e'}"></span>
            <span class="text-[10px] text-slate-400">${p.colorName || 'Color'}</span>
          </div>
          <div class="col-span-2 text-right font-black text-amber-300">${p.score || 0} PTS</div>
          <div class="col-span-2 text-center text-[10px] font-black text-emerald-400 uppercase tracking-wider">${p.status || 'A BORDO'}</div>
        `;
        container.appendChild(row);
      });
    }

    // ── FULLSCREEN TOGGLE ──
    function toggleFullscreen() {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(()=>{});
      } else {
        document.exitFullscreen().catch(()=>{});
      }
    }

    // ── SYNCHRONIZATION VIA SERVER SSE ──
    function connectEvents() {
      const ev = new EventSource('/api/events');

      ev.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          if (data.type === 'player_joined' || data.type === 'score_updated') {
            connectedPlayers = data.players || [];
            updatePlayersRibbon();
            renderStationRows();
          } else if (data.type === 'open_text_submitted') {
            // Mostrar reflexión en proyector
            if (userRole === 'teacher' && window.confetti) {
              window.confetti({ particleCount: 100, spread: 80 });
            }
          }
        } catch(err){}
      };

      ev.onerror = () => {
        setTimeout(connectEvents, 4000);
      };
    }

    function updatePlayersRibbon() {
      const countEl = document.getElementById('players-count');
      const chipsEl = document.getElementById('players-chips');
      if (countEl) countEl.textContent = connectedPlayers.length;

      if (!chipsEl) return;
      chipsEl.innerHTML = '';

      if (connectedPlayers.length === 0) {
        chipsEl.innerHTML = '<span class="text-slate-500 italic text-[11px]">Esperando a que los alumnos se unan...</span>';
        return;
      }

      connectedPlayers.forEach(p => {
        const chip = document.createElement('div');
        chip.className = 'px-2.5 py-1 rounded-full bg-slate-900/90 border border-slate-700 text-xs font-bold text-white flex items-center gap-1.5 shadow-sm';
        chip.innerHTML = `
          <span class="w-2.5 h-2.5 rounded-full" style="background:${p.color || '#f43f5e'}"></span>
          <span>${p.name}</span>
          <span class="text-[10px] text-amber-400 font-mono">(${p.score || 0})</span>
        `;
        chipsEl.appendChild(chip);
      });
    }

    // ── INICIALIZACIÓN GENERAL AL CARGAR PÁGINA ──
    window.addEventListener('DOMContentLoaded', () => {
      // 1. Construir la cuadrícula de 40 globos
      buildGrid();

      // 2. Inicializar tickers analógicos Split-Flap
      const tickerEl = document.getElementById('splitflap-ticker');
      if (tickerEl) {
        mainTicker = new SplitFlapText(tickerEl, {
          words: ["LAUNCH READY", "SYNC ONLINE", "SIGNAL LIVE", "TRIVIA MILLER", "LEY DE 7+-2"],
          flipDuration: 0.12,
          stagger: 0.06,
          cycleDelay: 2400,
          flipsPerChar: 8,
          tileColor: "#111827",
          textColor: "#f8fafc",
          tileRadius: 8,
          gap: 6,
          padTo: 13,
          loop: true
        });
      }

      const stationTickerEl = document.getElementById('station-main-ticker');
      if (stationTickerEl) {
        stationTicker = new SplitFlapText(stationTickerEl, {
          words: ["ESTACION CENTRAL", "PROXIMAS SALIDAS", "HORARIOS MILLER", "MEMORIA LISTA"],
          flipDuration: 0.12,
          stagger: 0.06,
          cycleDelay: 3000,
          flipsPerChar: 8,
          tileColor: "#111827",
          textColor: "#f8fafc",
          tileRadius: 8,
          gap: 6,
          padTo: 16,
          loop: true
        });
      }

      // 3. Conectar al SSE del servidor para sincronización en tiempo real
      connectEvents();

      // 4. Mostrar el selector de rol (Profesor vs Alumno)
      openRoleModal();
    });

    // ── FONDO DINÁMICO CANVAS DOT GRID ──
    (function initDotGrid() {
      const canvas = document.getElementById('dot-grid-canvas');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      let dots = [];
      let width = window.innerWidth;
      let height = window.innerHeight;

      function resize() {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
        dots = [];
        const step = 24;
        for (let x = 12; x < width; x += step) {
          for (let y = 12; y < height; y += step) {
            dots.push({ x, y, baseAlpha: 0.15 });
          }
        }
      }

      window.addEventListener('resize', resize);
      resize();

      function draw() {
        ctx.clearRect(0, 0, width, height);
        ctx.fillStyle = '#6366f1';
        for (let i = 0; i < dots.length; i++) {
          const d = dots[i];
          ctx.globalAlpha = d.baseAlpha;
          ctx.beginPath();
          ctx.arc(d.x, d.y, 1.5, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.globalAlpha = 1.0;
        requestAnimationFrame(draw);
      }
      draw();
    })();
  
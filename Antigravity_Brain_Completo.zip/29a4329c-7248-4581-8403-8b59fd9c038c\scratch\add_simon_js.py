with open('balloon_trivia.html', 'r', encoding='utf-8') as f:
    html = f.read()

simon_js = '''
// ══════════════════════════════════════════════════════════════
//  SIMON SAYS SEQUENCE ORDERING & QUESTION 40 OPEN TEXT LOGIC
// ══════════════════════════════════════════════════════════════
let currentSimonTarget = [];
let userSimonSequence = [];
let currentSimonPool = [];

function initSimonChallenge(q) {
  const container = document.getElementById('reto-simon-container');
  const slots = document.getElementById('simon-selected-slots');
  const pool = document.getElementById('simon-buttons-pool');
  if (!container || !slots || !pool) return;

  container.style.display = 'block';
  document.getElementById('reto-open-container').style.display = 'none';

  userSimonSequence = [];
  currentSimonTarget = (q.sequence || []).map(item => item.id);

  let itemsToPool = q.options ? [...q.options] : [...(q.sequence || [])];
  currentSimonPool = itemsToPool.sort(() => Math.random() - 0.5);

  renderSimonPool();
  renderSimonSlots();
}

function renderSimonPool() {
  const pool = document.getElementById('simon-buttons-pool');
  if (!pool) return;
  pool.innerHTML = '';

  currentSimonPool.forEach((item) => {
    const isSelected = userSimonSequence.some(s => s.id === item.id);
    const btn = document.createElement('button');
    btn.className = 'simon-pool-btn';
    btn.disabled = isSelected;
    btn.style.cssText = `
      background: ${isSelected ? 'rgba(255,255,255,0.04)' : 'rgba(30,41,59,0.85)'};
      border: 1.5px solid ${isSelected ? 'rgba(255,255,255,0.08)' : 'rgba(168,85,247,0.4)'};
      border-radius: 14px; padding: 12px 14px;
      color: ${isSelected ? 'rgba(255,255,255,0.25)' : '#f8fafc'};
      font-weight: 800; font-size: 0.95rem; font-family: inherit;
      cursor: ${isSelected ? 'default' : 'pointer'};
      display: flex; align-items: center; gap: 10px; text-align: left;
      transition: all 0.15s ease;
      box-shadow: ${isSelected ? 'none' : '0 4px 12px rgba(0,0,0,0.3)'};
    `;
    btn.innerHTML = `<span style="font-size:1.4rem;flex-shrink:0;">${item.icon}</span><span style="flex:1;">${item.label}</span>`;

    btn.onclick = () => {
      if (isSelected) return;
      userSimonSequence.push(item);
      playMechanicalFlapSound();
      renderSimonPool();
      renderSimonSlots();

      if (userSimonSequence.length === currentSimonTarget.length) {
        setTimeout(checkSimonSequence, 350);
      }
    };
    pool.appendChild(btn);
  });
}

function renderSimonSlots() {
  const slots = document.getElementById('simon-selected-slots');
  if (!slots) return;
  slots.innerHTML = '';

  if (userSimonSequence.length === 0) {
    slots.innerHTML = '<span style="color:#64748b;font-size:0.8rem;font-style:italic;">Secuencia vacía... Toca los botones abajo en orden.</span>';
    return;
  }

  userSimonSequence.forEach((item, idx) => {
    const chip = document.createElement('div');
    chip.style.cssText = `
      display: inline-flex; align-items: center; gap: 6px;
      background: rgba(168,85,247,0.25); border: 1px solid #c084fc;
      border-radius: 50px; padding: 6px 14px; color: #fff;
      font-weight: 800; font-size: 0.82rem; font-family: inherit;
      box-shadow: 0 2px 8px rgba(168,85,247,0.3);
    `;
    chip.innerHTML = `
      <span style="background:rgba(255,255,255,0.15);width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.68rem;font-weight:900;">${idx+1}</span>
      <span>${item.icon}</span>
      <span>${item.label}</span>
    `;
    slots.appendChild(chip);
  });
}

function resetSimonSequence() {
  userSimonSequence = [];
  renderSimonPool();
  renderSimonSlots();
}

function checkSimonSequence() {
  if (userSimonSequence.length === 0) {
    alert("Toca los botones para armar la secuencia primero.");
    return;
  }

  const userIds = userSimonSequence.map(i => i.id);
  const isMatch = (userIds.length === currentSimonTarget.length) &&
                  userIds.every((val, idx) => val === currentSimonTarget[idx]);

  if (isMatch) {
    if (window.confetti) {
      window.confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    }
    const slots = document.getElementById('simon-selected-slots');
    slots.style.borderColor = '#22c55e';
    slots.style.background = 'rgba(34,197,94,0.15)';
    retoResult(true);
  } else {
    const slots = document.getElementById('simon-selected-slots');
    slots.style.borderColor = '#ef4444';
    slots.style.background = 'rgba(239,68,68,0.15)';
    showErrorOverlay('¡Orden incorrecto! Intenta nuevamente.');
    setTimeout(() => {
      hideErrorOverlay();
      slots.style.borderColor = 'rgba(255,255,255,0.2)';
      slots.style.background = 'rgba(0,0,0,0.4)';
      resetSimonSequence();
    }, 1200);
  }
}

// ── QUESTION 40: OPEN TEXT SUBMISSION ──
function submitQ40Host() {
  const textarea = document.getElementById('q40-host-textarea');
  const text = textarea ? textarea.value.trim() : '';

  if (!text || text.length < 3) {
    alert("Por favor escribe una respuesta antes de enviar.");
    if (textarea) textarea.focus();
    return;
  }

  const card = document.getElementById('q40-submitted-card');
  const txtDisplay = document.getElementById('q40-submitted-text');
  if (card && txtDisplay) {
    card.style.display = 'block';
    txtDisplay.textContent = `«${text}»`;
  }

  if (window.confetti) {
    window.confetti({ particleCount: 120, spread: 90, origin: { y: 0.5 } });
  }

  retoResult(true);
}
'''

old_open_trivia_reto = '''    document.getElementById('attempts-bar').style.display='none';
    document.getElementById('reto-area').style.display='block';
    document.getElementById('reto-instruction-text').innerText=currentQ.instruction;'''

new_open_trivia_reto = '''    document.getElementById('attempts-bar').style.display='none';
    document.getElementById('reto-area').style.display='block';
    document.getElementById('reto-instruction-text').innerText=currentQ.instruction;

    if (currentQ.isOpenText || num === 40) {
      document.getElementById('reto-open-container').style.display='block';
      document.getElementById('reto-simon-container').style.display='none';
      const ta = document.getElementById('q40-host-textarea');
      if (ta) ta.value = '';
      const sc = document.getElementById('q40-submitted-card');
      if (sc) sc.style.display = 'none';
    } else if (currentQ.isSimon || currentQ.sequence) {
      document.getElementById('reto-open-container').style.display='none';
      document.getElementById('reto-simon-container').style.display='block';
      initSimonChallenge(currentQ);
    } else {
      document.getElementById('reto-open-container').style.display='none';
      document.getElementById('reto-simon-container').style.display='none';
    }'''

if old_open_trivia_reto in html:
    html = html.replace(old_open_trivia_reto, new_open_trivia_reto)
    print("Hooked into openTrivia.")
else:
    print("Could not find old_open_trivia_reto.")

html = html.replace('</script>', simon_js + '\n</script>')

with open('balloon_trivia.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("Updated balloon_trivia.html with Simon and Q40 logic.")

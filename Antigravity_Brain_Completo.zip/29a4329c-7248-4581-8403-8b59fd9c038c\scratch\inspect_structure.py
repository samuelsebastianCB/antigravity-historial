import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('balloon_trivia.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()
print('Total lines:', len(lines))
for i, l in enumerate(lines):
    if '<script' in l or '</script>' in l or '<body' in l or ('id="' in l and any(k in l for k in ['modal', 'screen', 'board', 'setup', 'role', 'team'])):
        print(f'{i+1}: {l.strip()[:80]}')

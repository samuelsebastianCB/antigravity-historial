with open('balloon_trivia.html', 'r', encoding='utf-8') as f:
    html = f.read()

import re

# Find all getElementById
ids_used = set(re.findall(r"getElementById\(['\"]([^'\"]+)['\"]\)", html))
# Find all id="..." in HTML
ids_defined = set(re.findall(r'\bid=["\']([^"\']+)["\']', html))

missing_ids = ids_used - ids_defined
print("IDs used in JS but NOT defined in HTML:")
for mid in missing_ids:
    print(" -", mid)

# Find calls to buildGrid
print("\nCalls to buildGrid:")
for m in re.finditer(r'\bbuildGrid\(\)', html):
    line_no = html[:m.start()].count('\n') + 1
    print(f" Line {line_no}")

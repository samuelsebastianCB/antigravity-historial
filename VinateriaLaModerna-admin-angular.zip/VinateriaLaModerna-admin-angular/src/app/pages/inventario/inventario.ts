import { Component, OnInit,  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { NuevoProducto } from '../nuevo-producto/nuevo-producto';
import { InventarioService } from '../../services/inventario.service';
import { FourierService } from '../../services/fourier.service';

export interface ProductoInventario {
  id: string;
  nombre: string;
  categoria?: string;
  estatus: 'Activo' | 'Agotado' | 'Descontinuado';
  existencias: number;
  enPedido: number;
  precio: number;
  descripcion?: string;
  stockMin?: number;
  stockMax?: number;
  precioCompra?: number;
  fechaCaducidad?: string;
  fotoUrl?: string;
  alertaDemanda?: string;
}

@Component({
  selector: 'app-inventario',
  standalone: true,
  imports: [CommonModule, FormsModule, NuevoProducto],
  templateUrl: './inventario.html',
  styleUrl: './inventario.css'
})
export class Inventario implements OnInit {
  busqueda: string = '';
  filtroEstatus: string = 'all';
  mostrarModalNuevo: boolean = false;
  mostrarModalEditar: boolean = false;
  productoEdicion: ProductoInventario | null = null;

  productos: ProductoInventario[] = [];

  constructor(
    private router: Router,
    private inventarioService: InventarioService,
    private fourierService: FourierService
  ) {}

  ngOnInit(): void {
    this.cargarProductos();
  }

  cargarProductos(): void {
    this.inventarioService.obtenerProductos().subscribe({
      next: (res: any) => {
        if (res.status === 'success' && Array.isArray(res.productos)) {
          this.productos = res.productos.map((item: any) => {
            const rawEstado = item.estado ?? 'Activo';
            return {
              id: String(item.id ?? ''),
              nombre: item.nombre ?? 'Sin nombre',
              categoria: item.categoria ?? item.CATEGORY ?? 'Sin categoría',
              estatus: (rawEstado.includes('Activo') ? 'Activo' : rawEstado) as 'Activo' | 'Agotado' | 'Descontinuado',
              existencias: Number(item.stock ?? 0),
              enPedido: 0,
              precio: Number(item.precioVenta ?? 0),
              descripcion: item.descripcion ?? '',
              stockMin: Number(item.stockMin ?? 0),
              stockMax: Number(item.stockMax ?? 0),
              precioCompra: Number(item.precioCompra ?? 0),
              fechaCaducidad: item.caducidad ?? '',
              fotoUrl: item.foto ?? '',
              alertaDemanda: undefined
            };
          });

          // Cargar alertas de Fourier para el inventario
          this.fourierService.obtenerAlertasActivas().subscribe({
            next: (alrRes) => {
              if (alrRes.status === 'success' && Array.isArray(alrRes.alertas)) {
                const mapAlertas = new Map<number, string>();
                for (const a of alrRes.alertas) {
                  mapAlertas.set(Number(a.producto_id), a.mensaje);
                }
                this.productos.forEach(p => {
                  const idNum = Number(p.id);
                  if (mapAlertas.has(idNum)) {
                    p.alertaDemanda = mapAlertas.get(idNum);
                  }
                });
              }
            },
            error: () => {}
          });
        }
      },
      error: (err) => {
        console.error('Error al consultar inventario:', err);
      }
    });
  }

  productosFiltrados(): ProductoInventario[] {
    const termino = (this.busqueda || '').trim().toLowerCase();
    
    return this.productos.filter((p) => {
      const coincideTexto = !termino || 
                            p.nombre.toLowerCase().includes(termino) || 
                            p.id.toLowerCase().includes(termino);
      const coincideEstatus = this.filtroEstatus === 'all' || p.estatus === this.filtroEstatus;
      return coincideTexto && coincideEstatus;
    });
  }

  abrirNuevoProducto(): void {
    this.mostrarModalNuevo = true;
  }

  cerrarModalNuevo(): void {
    this.mostrarModalNuevo = false;
  }

  alGuardarNuevoProducto(nuevo: any): void {
    this.inventarioService.crearProducto(nuevo).subscribe({
      next: (res: any) => {
        if (res.status === 'success') {
          this.cargarProductos();
          this.mostrarModalNuevo = false;
        } else {
          alert(res.mensaje || 'Error al registrar producto.');
        }
      },
      error: (err: any) => alert(err.error?.mensaje || 'Error al conectar con el backend.')
    });
  }

  editarProducto(prod: ProductoInventario): void {
    this.productoEdicion = { ...prod };
    this.mostrarModalEditar = true;
  }

  cerrarModalEditar(): void {
    this.mostrarModalEditar = false;
    this.productoEdicion = null;
  }

  guardarEdicionProducto(): void {
    if (!this.productoEdicion) return;

    this.inventarioService.actualizarProducto(this.productoEdicion).subscribe({
      next: (res: any) => {
        if (res.status === 'success') {
          this.cargarProductos();
          this.cerrarModalEditar();
        } else {
          alert(res.mensaje || 'Error al actualizar producto.');
        }
      },
      error: (err: any) => alert(err.error?.mensaje || 'Error al conectar con el backend.')
    });
  }

  eliminarProducto(id: string): void {
    if (confirm(`¿Estás seguro de eliminar el producto #${id}?`)) {
      this.inventarioService.eliminarProducto(id).subscribe({
        next: (res: any) => {
          if (res.status === 'success') {
            this.cargarProductos();
          } else {
            alert(res.mensaje || 'Error al eliminar producto.');
          }
        },
        error: (err: any) => alert(err.error?.mensaje || 'Error al conectar con el backend.')
      });
    }
  }

  volver(): void {
    this.router.navigate(['/admin']);
  }
}
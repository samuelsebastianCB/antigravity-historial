import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-editar-producto',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './editar-producto.html',
  styleUrl: './editar-producto.css',
  encapsulation: ViewEncapsulation.None
})
export class EditarProducto implements OnInit {
  productoId: string = '';

  producto = {
    nombre: 'Cerveza Corona Extra',
    descripcion: 'Coronaa',
    stockActual: 0,
    stockMin: 2,
    stockMax: 20,
    precioCompra: 50.00,
    precioVenta: 60.00,
    fechaCaducidad: '2026-05-30',
    estatus: 'Activo'
  };

  constructor(
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params['id']) {
        this.productoId = params['id'];
      }
    });
  }

  actualizarProducto() {
    alert(`¡Producto "${this.producto.nombre}" actualizado correctamente!`);
    this.router.navigate(['/inventario']);
  }

  cancelar() {
    this.router.navigate(['/inventario']);
  }
}
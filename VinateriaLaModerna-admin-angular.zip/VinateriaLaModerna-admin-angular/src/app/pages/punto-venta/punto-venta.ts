import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { InventarioService, Producto as ProductoModel } from '../../services/inventario.service';
import { VentasService, VentaPayload } from '../../services/ventas.service';
import { CartService, ItemTicket, ProductoCart } from '../../services/cart.service';

interface TicketEmitido {
  folio: string | number;
  fecha: string;
  items: { producto_id: number; nombre: string; cantidad: number; precio: number; subtotal: number }[];
  total: number;
  tipo?: string;
  comprador?: string;
}

@Component({
  selector: 'app-punto-venta',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './punto-venta.html',
  styleUrl: './punto-venta.css'
})
export class PuntoVenta implements OnInit, OnDestroy {
  private router = inject(Router);
  private inventarioService = inject(InventarioService);
  private ventasService = inject(VentasService);
  cartService = inject(CartService);

  busqueda: string = '';
  folio: string = '00001';
  fechaHoraActual: string = '';
  private timer: any;

  // Compra interna
  esCompraInterna: boolean = false;
  compradorInterno: string = '';
  motivoInterno: string = '';

  productos: ProductoCart[] = [];
  cargando: boolean = false;

  // Modal de Ticket Impreso
  mostrarModalTicket: boolean = false;
  ticketFinalizado: TicketEmitido | null = null;

  get ticket() {
    return this.cartService.items();
  }

  get totalVenta() {
    return this.cartService.totalVenta();
  }

  ngOnInit() {
    this.actualizarReloj();
    this.timer = setInterval(() => this.actualizarReloj(), 1000);
    this.cargarCatalogoProductos();
  }

  ngOnDestroy() {
    if (this.timer) clearInterval(this.timer);
  }

  actualizarReloj() {
    const ahora = new Date();
    this.fechaHoraActual = ahora.toLocaleString('es-MX', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  }

  cargarCatalogoProductos() {
    this.cargando = true;
    this.inventarioService.obtenerProductos().subscribe({
      next: (res) => {
        this.cargando = false;
        if (res.status === 'success' && Array.isArray(res.productos)) {
          this.productos = res.productos
            .filter((p: ProductoModel) => p.estado?.includes('Activo') || p.estado === 'Activo')
            .map((p: ProductoModel) => ({
              id: Number(p.id),
              nombre: p.nombre,
              precio: Number(p.precioVenta) || 0,
              stock: Number(p.stock) || 0
            }));
        }
      },
      error: (err) => {
        this.cargando = false;
        console.error('Error al cargar catálogo:', err);
      }
    });
  }

  productosFiltrados(): ProductoCart[] {
    if (!this.busqueda.trim()) return this.productos;
    const term = this.busqueda.toLowerCase().trim();
    return this.productos.filter(p => 
      p.nombre.toLowerCase().includes(term) || String(p.id).includes(term)
    );
  }

  agregarAlTicket(producto: ProductoCart) {
    if (producto.stock <= 0) {
      alert(`El producto "${producto.nombre}" está agotado.`);
      return;
    }
    
    const existing = this.ticket.find(i => i.producto.id === producto.id);
    if (existing && existing.cantidad >= producto.stock) {
      alert(`Stock máximo alcanzado (${producto.stock} disponibles).`);
      return;
    }
    this.cartService.agregarAlTicket(producto);
  }

  incrementarCantidad(item: ItemTicket) {
    if (item.cantidad >= item.producto.stock) {
      alert(`Stock máximo alcanzado (${item.producto.stock} disponibles).`);
      return;
    }
    this.cartService.incrementarCantidad(item);
  }

  decrementarCantidad(index: number) {
    this.cartService.decrementarCantidad(index);
  }

  eliminarItem(index: number) {
    this.cartService.eliminarItem(index);
  }

  finalizarVenta() {
    console.log('--- EVENTO: FINALIZAR VENTA PULSADO ---');
    
    if (this.ticket.length === 0) {
      alert('El ticket está vacío.');
      return;
    }

    if (this.esCompraInterna && !this.compradorInterno.trim()) {
      alert('Debes indicar el nombre del empleado o responsable para registrar la compra interna.');
      return;
    }

    const itemsVenta = this.ticket.map(item => ({
      producto_id: Number(item.producto.id),
      nombre: item.producto.nombre,
      precio: Number(item.producto.precio),
      cantidad: Number(item.cantidad),
      subtotal: Number(item.producto.precio * item.cantidad)
    }));

    const totalCalculado = Number(this.totalVenta.toFixed(2));

    const payload: VentaPayload = {
      customer_id: null,
      employee_id: null,
      total: totalCalculado,
      items: itemsVenta,
      tipo: this.esCompraInterna ? 'INTERNA' : 'NORMAL',
      comprador_interno: this.esCompraInterna ? this.compradorInterno.trim() : undefined,
      motivo_interno: this.esCompraInterna ? this.motivoInterno.trim() : undefined
    };

    console.log('Payload enviado a registrar_venta.php:', payload);

    this.ventasService.registrarVenta(payload).subscribe({
      next: (res) => {
        console.log('Respuesta recibida del backend:', res);

        if (res.status === 'success') {
          this.ticketFinalizado = {
            folio: res.sale_id || this.folio,
            fecha: this.fechaHoraActual,
            items: itemsVenta,
            total: totalCalculado,
            tipo: this.esCompraInterna ? 'INTERNA' : 'NORMAL',
            comprador: this.esCompraInterna ? this.compradorInterno.trim() : undefined
          };
          this.mostrarModalTicket = true;

          // Limpiar mesa de cobro y recargar stock actualizado
          this.cartService.limpiarTicket();
          this.esCompraInterna = false;
          this.compradorInterno = '';
          this.motivoInterno = '';
          this.folio = String(Math.floor(10000 + Math.random() * 90000));
          this.cargarCatalogoProductos();
        } else {
          alert(res.mensaje || 'Error al procesar la venta.');
        }
      },
      error: (err) => {
        console.error('Error de red/servidor al registrar venta:', err);
        alert(err.error?.mensaje || 'No se pudo conectar con el servidor.');
      }
    });
  }

  imprimirTicket() {
    const elemento = document.getElementById('printable-receipt');
    if (!elemento) {
      window.print();
      return;
    }

    const ventanaImpresion = window.open('', '_blank', 'width=420,height=600');
    if (!ventanaImpresion) {
      alert('Por favor habilita las ventanas emergentes (pop-ups) en tu navegador para imprimir.');
      return;
    }

    ventanaImpresion.document.write(`
      <!DOCTYPE html>
      <html lang="es">
        <head>
          <meta charset="utf-8">
          <title>Ticket de Venta #V-${this.ticketFinalizado?.folio || ''}</title>
          <style>
            @page {
              margin: 4mm;
              size: auto;
            }
            body {
              font-family: 'Courier New', Courier, monospace;
              color: #000;
              margin: 0;
              padding: 0;
              background: #fff;
              display: flex;
              justify-content: center;
            }
            .receipt-paper {
              width: 100%;
              max-width: 320px;
              border: none !important;
              box-shadow: none !important;
              padding: 6px 12px;
              box-sizing: border-box;
              background: #fff;
            }
            .receipt-header {
              text-align: center;
            }
            .receipt-header h2 {
              margin: 0;
              font-size: 16px;
              font-weight: bold;
            }
            .receipt-header p {
              margin: 3px 0;
              font-size: 12px;
            }
            .receipt-divider {
              text-align: center;
              margin: 6px 0;
              font-size: 12px;
              letter-spacing: -1px;
            }
            .receipt-meta {
              font-size: 12px;
              line-height: 1.4;
            }
            .receipt-table {
              width: 100%;
              border-collapse: collapse;
              margin: 8px 0;
              font-size: 12px;
            }
            .receipt-table th {
              border-bottom: 1px dashed #333;
              padding-bottom: 4px;
            }
            .receipt-table td {
              padding: 4px 0;
            }
            .receipt-total-block {
              margin-top: 6px;
            }
            .receipt-total-line {
              display: flex;
              justify-content: space-between;
              font-size: 14px;
              font-weight: bold;
            }
            .receipt-notice {
              text-align: center;
              margin: 8px 0;
              font-size: 10px;
              line-height: 1.35;
            }
            .receipt-footer-msg {
              text-align: center;
              font-size: 11px;
              margin: 8px 0 0 0;
            }
          </style>
        </head>
        <body>
          <div class="receipt-paper">
            ${elemento.innerHTML}
          </div>
          <script>
            window.onload = function() {
              window.focus();
              window.print();
              window.close();
            };
          </script>
        </body>
      </html>
    `);

    ventanaImpresion.document.close();
  }

  cerrarModalTicket() {
    this.mostrarModalTicket = false;
    this.ticketFinalizado = null;
  }

  volver() {
    this.router.navigate(['/admin']);
  }
}
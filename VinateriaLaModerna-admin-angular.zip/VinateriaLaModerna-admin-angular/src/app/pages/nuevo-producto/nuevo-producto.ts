import { Component, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-nuevo-producto',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './nuevo-producto.html',
  styleUrl: './nuevo-producto.css',
  encapsulation: ViewEncapsulation.None
})
export class NuevoProducto {
  @Output() onCerrar = new EventEmitter<void>();
  @Output() onGuardado = new EventEmitter<any>();

  nuevoProd = {
    nombre: '',
    descripcion: '',
    stockActual: null,
    stockMin: null,
    stockMax: null,
    precioCompra: null,
    precioVenta: null,
    fechaCaducidad: '',
    estatus: 'Activo',
    categoria: ''
  };

  guardarProducto() {
    if (!this.nuevoProd.nombre) {
      alert('Por favor ingresa al menos el nombre del producto.');
      return;
    }
    this.onGuardado.emit({ ...this.nuevoProd });
  }

  cancelar() {
    this.onCerrar.emit();
  }
}
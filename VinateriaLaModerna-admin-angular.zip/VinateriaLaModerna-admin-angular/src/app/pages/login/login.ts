import { Component, inject, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login implements OnInit {
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private http = inject(HttpClient);
  

  private apiUrl = environment.apiUrl;

  email: string = '';
  password: string = '';
  cargando: boolean = false;
  errorMensaje: string = '';

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params['autoLogin'] === 'admin') {
        this.email = 'test';
        this.password = 'test';
        this.iniciarSesion();
      }
    });
  }

  iniciarSesion(): void {
    this.errorMensaje = '';

    const emailLimpio = (this.email || '').trim();
    const passLimpio = (this.password || '').trim();

    if (!emailLimpio || !passLimpio) {
      this.errorMensaje = 'Por favor ingresa tu correo y contraseña.';
      return;
    }

    this.cargando = true;

    // --- BYPASS TEMPORAL PARA PRUEBAS ---
    if (emailLimpio === 'test' && passLimpio === 'test') {
      this.cargando = false;
      localStorage.setItem('admin_sesion', JSON.stringify({ 
        id: 999, 
        nombre: 'Usuario de Prueba', 
        rol: 'Administrador' 
      }));
      this.router.navigate(['/admin']);
      return;
    }
    
    if (emailLimpio === 'tester' && passLimpio === 'tester') {
      window.location.assign('http://localhost:4201/login?autoLogin=tester');
      return;
    }
    // ------------------------------------

    const payload = {
      email: emailLimpio,
      password: passLimpio
    };

    this.http.post<any>(`${this.apiUrl}/login_admin.php`, payload).subscribe({
      next: (res) => {
        this.cargando = false;

        if (res.status === 'success' && res.es_admin) {
          localStorage.setItem('admin_sesion', JSON.stringify(res.admin));
          this.router.navigate(['/admin']);
        } else {
          this.errorMensaje = res.mensaje || 'Credenciales no autorizadas.';
        }
      },
      error: (err) => {
        this.cargando = false;
        this.errorMensaje = err.error?.mensaje || 'Error al conectar con el servidor.';
        console.error('Error en autenticación:', err);
      }
    });
  }
}
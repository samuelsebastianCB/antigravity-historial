import { ChangeDetectorRef, Component, ElementRef, HostListener, OnDestroy, inject, signal, viewChild } from '@angular/core';
import { Router } from '@angular/router';

type Prioridad = 'alta' | 'media' | 'baja';

interface ModuloDef {
  id: string;
  icon: string;
  titulo: string;
  descripcion: string;
  ruta: string;
  prioridad: Prioridad;
  cols: number;
  rows: number;
}

/** Posición/tamaño de una tarjeta dentro del Bento (lo que se guarda por usuario). */
interface TileLayout { id: string; cols: number; rows: number; }

const MAX_COLS = 6;
const MAX_ROWS = 3;
const STORAGE_PREFIX = 'admin_dashboard_layout_v1_';

/** Módulos reales del panel. El tamaño inicial sigue la jerarquía visual: alta > media > baja. */
const MODULOS: ModuloDef[] = [
  { id: 'puntoVenta', icon: '🛒', titulo: 'Punto de Venta', descripcion: 'Ventas rápidas y facturación', ruta: '/punto-venta', prioridad: 'alta', cols: 3, rows: 2 },
  { id: 'fourier', icon: '📈', titulo: 'Análisis de Fourier', descripcion: 'Patrones periódicos y estacionales de tus ventas', ruta: '/fourier', prioridad: 'alta', cols: 3, rows: 2 },
  { id: 'inventario', icon: '🍷', titulo: 'Inventario de Vinos', descripcion: 'Catálogo, precios y stock crítico', ruta: '/inventario', prioridad: 'alta', cols: 2, rows: 2 },
  { id: 'proveedores', icon: '📦', titulo: 'Compras y Proveedores', descripcion: 'Pedidos y recepción de mercancía', ruta: '/proveedores', prioridad: 'media', cols: 2, rows: 1 },
  { id: 'reportes', icon: '📊', titulo: 'Reportes y Registros', descripcion: 'Historial y cortes de caja', ruta: '/reportes', prioridad: 'media', cols: 2, rows: 1 },
  { id: 'empleados', icon: '👥', titulo: 'Gestión de Empleados', descripcion: 'Staff y permisos', ruta: '/empleados', prioridad: 'media', cols: 4, rows: 1 },
];

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [],
  templateUrl: './admin.html',
  styleUrl: './admin.css'
})
export class Admin implements OnDestroy {
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly grid = viewChild<ElementRef<HTMLElement>>('grid');

  readonly modulos = MODULOS;
  /** Distribución en edición (borrador) o la guardada si no se está editando. */
  readonly tiles = signal<TileLayout[]>(this.cargarLayout());
  readonly editMode = signal(false);
  readonly tool = signal<'move' | 'resize'>('move');
  readonly dragId = signal<string | null>(null);
  readonly columns = signal(this.columnasPara(typeof window !== 'undefined' ? window.innerWidth : 1280));
  readonly mensaje = signal('');
  readonly sideMenuOpen = signal(false);

  toggleSideMenu(): void {
    this.sideMenuOpen.update(v => !v);
  }

  closeSideMenu(): void {
    this.sideMenuOpen.set(false);
  }

  navegarA(modulo: string): void {
    this.closeSideMenu();
    if (modulo === 'dashboard') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    this.abrirModulo(modulo);
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    this.closeSideMenu();
  }

  private guardado: TileLayout[] = this.tiles();
  private grab = { x: 0, y: 0 };

  def(id: string): ModuloDef { return MODULOS.find(m => m.id === id)!; }
  spanCols(t: TileLayout): number { return Math.min(t.cols, this.columns()); }
  spanRows(t: TileLayout): number { return this.columns() === 1 ? 1 : t.rows; }

  @HostListener('window:resize')
  onResize(): void { this.columns.set(this.columnasPara(window.innerWidth)); }

  private columnasPara(ancho: number): number { return ancho > 1024 ? MAX_COLS : ancho > 640 ? 4 : 1; }

  // ───────────────────────── Navegación ─────────────────────────
  abrirModulo(modulo: string) {
    if (this.editMode()) return;
    if (modulo === 'puntoVenta') {
      this.router.navigate(['/punto-venta']);
    } else if (modulo === 'inventario') {
      this.router.navigate(['/inventario']);
    } else if (modulo === 'compras' || modulo === 'proveedores' || modulo === 'comprasProveedores') {
      this.router.navigate(['/proveedores']);
    } else if (modulo === 'reportes') {
      this.router.navigate(['/reportes']);
    } else if (modulo === 'fourier') {
      this.router.navigate(['/fourier']);
    } else if (modulo === 'empleados') {
      this.router.navigate(['/empleados']);
    }
  }

  cerrarSesion() {
    localStorage.removeItem('admin_sesion');
    this.router.navigate(['/login']);
  }

  // ───────────────────────── Modo edición ─────────────────────────
  personalizar(): void { this.guardado = this.tiles(); this.tool.set('move'); this.mensaje.set(''); this.editMode.set(true); }

  cancelar(): void { this.tiles.set(this.guardado); this.editMode.set(false); this.mensaje.set(''); }

  restaurar(): void { this.tiles.set(this.layoutPorDefecto()); this.mensaje.set('Distribución original restaurada. Pulsa «Guardar distribución» para conservarla.'); }

  guardar(): void {
    try { localStorage.setItem(this.storageKey(), JSON.stringify(this.tiles())); this.mensaje.set('Distribución guardada.'); }
    catch { this.mensaje.set('No se pudo guardar en este navegador.'); }
    this.guardado = this.tiles();
    this.editMode.set(false);
  }

  /** Mover una posición (alternativa accesible/táctil al arrastre). */
  shift(t: TileLayout, delta: number): void {
    const list = [...this.tiles()];
    const from = list.findIndex(x => x.id === t.id), to = from + delta;
    if (from < 0 || to < 0 || to >= list.length) return;
    this.animarReflujo(() => { list.splice(to, 0, list.splice(from, 1)[0]); this.tiles.set(list); });
  }

  resize(t: TileLayout, dim: 'cols' | 'rows', delta: number): void {
    const max = dim === 'cols' ? MAX_COLS : MAX_ROWS;
    this.animarReflujo(() => this.tiles.update(list => list.map(x => x.id === t.id
      ? { ...x, [dim]: Math.min(max, Math.max(1, x[dim] + delta)) } : x)));
  }

  // ───────────────────────── Drag & drop (pointer events) ─────────────────────────
  dragStart(ev: PointerEvent, t: TileLayout): void {
    if (!this.editMode() || (ev.pointerType === 'mouse' && ev.button !== 0)) return;
    ev.preventDefault();
    const el = this.el(t.id);
    if (!el) return;
    const r = el.getBoundingClientRect();
    this.grab = { x: ev.clientX - r.left, y: ev.clientY - r.top };
    this.dragId.set(t.id);
    window.addEventListener('pointermove', this.onMove);
    window.addEventListener('pointerup', this.onUp);
    window.addEventListener('pointercancel', this.onUp);
  }

  private onMove = (ev: PointerEvent): void => {
    const id = this.dragId();
    const grid = this.grid()?.nativeElement;
    const el = id ? this.el(id) : null;
    if (!id || !grid || !el) return;

    const target = this.tileEnPunto(ev.clientX, ev.clientY, id);
    if (target) this.moverA(id, target);

    // Posición del elemento arrastrado, limitada al área del dashboard.
    const g = grid.getBoundingClientRect();
    el.style.transform = 'none';
    const n = el.getBoundingClientRect();
    const left = Math.min(Math.max(ev.clientX - this.grab.x, g.left), Math.max(g.left, g.right - n.width));
    const top = Math.min(Math.max(ev.clientY - this.grab.y, g.top), Math.max(g.top, g.bottom - n.height));
    el.style.transform = `translate(${left - n.left}px, ${top - n.top}px)`;
  };

  private onUp = (): void => {
    window.removeEventListener('pointermove', this.onMove);
    window.removeEventListener('pointerup', this.onUp);
    window.removeEventListener('pointercancel', this.onUp);
    const id = this.dragId();
    const el = id ? this.el(id) : null;
    if (el) {
      const current = el.style.transform;
      el.style.transform = '';
      el.animate([{ transform: current || 'none' }, { transform: 'none' }], { duration: 180, easing: 'cubic-bezier(.22,.8,.3,1)' });
    }
    this.dragId.set(null);
  };

  private tileEnPunto(x: number, y: number, excluir: string): string | null {
    for (const t of this.tiles()) {
      if (t.id === excluir) continue;
      const r = this.el(t.id)?.getBoundingClientRect();
      if (r && x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return t.id;
    }
    return null;
  }

  private moverA(id: string, destinoId: string): void {
    const list = [...this.tiles()];
    const from = list.findIndex(t => t.id === id), to = list.findIndex(t => t.id === destinoId);
    if (from < 0 || to < 0 || from === to) return;
    this.animarReflujo(() => { list.splice(to, 0, list.splice(from, 1)[0]); this.tiles.set(list); });
  }

  /** FLIP: anima las demás tarjetas desde su posición anterior a la nueva tras reordenar/redimensionar. */
  private animarReflujo(mutar: () => void): void {
    const dragging = this.dragId();
    const ids = this.tiles().map(t => t.id).filter(id => id !== dragging);
    const antes = new Map(ids.map(id => [id, this.el(id)?.getBoundingClientRect()]));
    mutar();
    this.cdr.detectChanges();
    for (const id of ids) {
      const el = this.el(id), a = antes.get(id);
      if (!el || !a) continue;
      const b = el.getBoundingClientRect();
      const dx = a.left - b.left, dy = a.top - b.top;
      if (Math.abs(dx) > 1 || Math.abs(dy) > 1) {
        el.animate([{ transform: `translate(${dx}px, ${dy}px)` }, { transform: 'none' }], { duration: 220, easing: 'cubic-bezier(.22,.8,.3,1)' });
      }
    }
  }

  private el(id: string): HTMLElement | null {
    return this.grid()?.nativeElement.querySelector<HTMLElement>(`[data-id="${id}"]`) ?? null;
  }

  ngOnDestroy(): void {
    window.removeEventListener('pointermove', this.onMove);
    window.removeEventListener('pointerup', this.onUp);
    window.removeEventListener('pointercancel', this.onUp);
  }

  // ───────────────────────── Persistencia (por usuario) ─────────────────────────
  private storageKey(): string {
    let usuario = 'anon';
    try {
      const s = JSON.parse(localStorage.getItem('admin_sesion') ?? 'null');
      usuario = String(s?.id ?? s?.email ?? s?.nombre ?? 'anon');
    } catch { /* sesión ilegible: usa clave anónima */ }
    return STORAGE_PREFIX + usuario;
  }

  private layoutPorDefecto(): TileLayout[] { return MODULOS.map(m => ({ id: m.id, cols: m.cols, rows: m.rows })); }

  private cargarLayout(): TileLayout[] {
    const defecto = this.layoutPorDefecto();
    try {
      const raw = JSON.parse(localStorage.getItem(this.storageKey()) ?? 'null');
      if (!Array.isArray(raw)) return defecto;
      const clamp = (v: unknown, max: number, fallback: number) => {
        const n = Math.round(Number(v));
        return Number.isFinite(n) ? Math.min(max, Math.max(1, n)) : fallback;
      };
      const vistos = new Set<string>();
      const resultado: TileLayout[] = [];
      for (const item of raw) {
        const base = defecto.find(d => d.id === item?.id);
        if (!base || vistos.has(base.id)) continue;
        vistos.add(base.id);
        resultado.push({ id: base.id, cols: clamp(item.cols, MAX_COLS, base.cols), rows: clamp(item.rows, MAX_ROWS, base.rows) });
      }
      // Módulos nuevos que no estaban en el layout guardado.
      for (const d of defecto) if (!vistos.has(d.id)) resultado.push(d);
      return resultado;
    } catch { return defecto; }
  }
}
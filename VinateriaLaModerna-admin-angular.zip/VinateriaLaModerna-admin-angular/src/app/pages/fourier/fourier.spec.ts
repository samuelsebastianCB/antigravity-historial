import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { FourierComponent } from './fourier';
import { FourierService } from '../../services/fourier.service';
import { InventarioService } from '../../services/inventario.service';

describe('FourierComponent', () => {
  let component: FourierComponent;
  let fixture: ComponentFixture<FourierComponent>;

  const mockFourierService = {
    obtenerSerieVentas: () => of({
      status: 'success',
      serie: [
        { clave: '2026-01-01', valor: 10 },
        { clave: '2026-01-02', valor: 15 },
        { clave: '2026-01-03', valor: 25 },
        { clave: '2026-01-04', valor: 30 },
        { clave: '2026-01-05', valor: 20 },
        { clave: '2026-01-06', valor: 12 },
        { clave: '2026-01-07', valor: 18 },
      ],
      total_registros: 130,
      dataset_hash: 'a1b2c3d4e5f6',
    }),
    obtenerRegistrosVentas: () => of({
      status: 'success',
      registros: [],
      total_registros: 130,
    }),
    guardarAnalisis: () => of({
      status: 'success',
      analysis_id: 1,
    }),
    obtenerAnalisisGuardados: () => of({
      status: 'success',
      analisis: [],
    }),
    obtenerAnalisisPorId: () => of({
      status: 'success',
      analisis: null,
    }),
    obtenerAlertasActivas: () => of({
      status: 'success',
      alertas: [],
    }),
  };

  const mockInventarioService = {
    obtenerProductos: () => of({
      status: 'success',
      productos: [
        { id: 1, nombre: 'Tequila Don Julio', categoria: 'Tequila', stock: 15, precio_venta: 750 },
        { id: 2, nombre: 'Vino Tinto Malbec', categoria: 'Vino', stock: 24, precio_venta: 320 },
      ],
    }),
  };

  const mockRouter = {
    navigate: () => Promise.resolve(true),
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FourierComponent],
      providers: [
        { provide: FourierService, useValue: mockFourierService },
        { provide: InventarioService, useValue: mockInventarioService },
        { provide: Router, useValue: mockRouter },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(FourierComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('debe crearse e inicializarse correctamente', () => {
    expect(component).toBeTruthy();
  });

  it('debe inicializar fechas y cargar productos y serie al inicio', () => {
    expect(component.fechaDesde).toBeTruthy();
    expect(component.fechaHasta).toBeTruthy();
    expect(component.productos.length).toBe(2);
    expect(component.categorias).toContain('Tequila');
    expect(component.categorias).toContain('Vino');
  });

  it('debe ajustar la serie de Fourier con datos iniciales', () => {
    expect(component.puntosSerie.length).toBeGreaterThan(0);
    expect(component.ajuste).toBeTruthy();
    if (component.ajuste) {
      expect(component.ajuste.armonicos).toBe(component.armonicos);
      expect(component.ajuste.aproximado.length).toBe(component.puntosSerie.length);
    }
  });

  it('debe permitir cambiar de periodo rápido a 30 días', () => {
    component.setPeriodoRapido(30);
    expect(component.fechaDesde).toBeTruthy();
    expect(component.fechaHasta).toBeTruthy();
  });

  it('debe cambiar de pestaña activa', () => {
    component.pestanaActiva = 'patrones';
    expect(component.pestanaActiva).toBe('patrones');
    component.pestanaActiva = 'armonicos';
    expect(component.pestanaActiva).toBe('armonicos');
  });

  it('debe calcular coordenadas de la gráfica SVG correctamente', () => {
    expect(component.maxValorGrafica).toBeGreaterThan(0);
    const x0 = component.getCoordX(0);
    expect(x0).toBeGreaterThanOrEqual(70);
    const y0 = component.getCoordY(10);
    expect(y0).toBeLessThanOrEqual(320);
    expect(component.puntosRealesPolyline).toBeTruthy();
    expect(component.curvaFourierPolyline).toBeTruthy();
  });
});


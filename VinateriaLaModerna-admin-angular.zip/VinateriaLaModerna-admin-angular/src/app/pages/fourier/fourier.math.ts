/**
 * Núcleo matemático del módulo de análisis de ventas.
 *
 * ÚNICO método de análisis: Serie de Fourier.
 *   ŷ(t) = a0 + Σ_{k=1..K} [ a_k·cos(2π·k·t / P) + b_k·sin(2π·k·t / P) ]
 *
 * - t = 0..N-1 es el índice del intervalo (hora/día/semana/mes/año).
 * - P es el periodo base en intervalos (por defecto N = toda la ventana).
 * - Los coeficientes se obtienen por mínimos cuadrados (ecuaciones normales), lo que
 *   coincide con la DFT cuando P = N y evita el "leakage" cuando P no divide a N.
 * - El periodograma (espectro) usa el mismo ajuste sinusoidal para detectar periodos.
 *
 * Todo son funciones puras para poder probarlas sin navegador ni backend.
 */

export type Intervalo = 'hora' | 'dia' | 'semana' | 'mes' | 'anio';

export interface Cubeta {
  clave: string;
  valor: number;
}

export interface PuntoSerie {
  clave: string;
  etiqueta: string;
  valor: number;
}

export interface FilaArmonico {
  k: number;
  a: number;
  b: number;
  amplitud: number;
  fase: number;
  frecuencia: number;
  periodo: number;
}

export interface AjusteFourier {
  n: number;
  armonicos: number;
  periodoBase: number;
  media: number;
  a0: number;
  armonicosTabla: FilaArmonico[];
  aproximado: number[];
  rmse: number;
  r2: number;
}

export interface PuntoEspectral {
  periodo: number;
  amplitud: number;
  varianzaExplicada: number;
}

export type Fuerza = 'fuerte' | 'moderada' | 'débil';

export interface Patron {
  periodo: number;
  periodoDias: number;
  nombre: string;
  amplitud: number;
  amplitudRelativa: number;
  varianzaExplicada: number;
  fuerza: Fuerza;
  ciclos: number;
  descripcion: string;
  picos: string[];
  bajas: string[];
}

export interface ResultadoPatrones {
  patrones: Patron[];
  cambioPeriodicidad: string | null;
}

export interface PicoFuturo {
  paso: number;
  clave: string;
  etiqueta: string;
  valor: number;
}

export interface Alerta {
  activa: boolean;
  mensaje: string;
  detalle: string;
  proximoPico: PicoFuturo | null;
}

export const MENSAJE_ALERTA =
  '⚠️ Se detectó un patrón periódico de aumento de demanda para este producto. Revisar inventario y próximos pedidos.';

export const NOMBRES_DIA = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
export const NOMBRES_MES = [
  'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
  'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre',
];

const DIA_MS = 86_400_000;
const HORA_MS = 3_600_000;
export const MAX_PUNTOS = 20_000;
export const MIN_INTERVALOS = 14;

const DIAS_POR_INTERVALO: Record<Intervalo, number> = {
  hora: 1 / 24,
  dia: 1,
  semana: 7,
  mes: 30.4375,
  anio: 365.25,
};

const UNIDAD_PLURAL: Record<Intervalo, string> = {
  hora: 'horas',
  dia: 'días',
  semana: 'semanas',
  mes: 'meses',
  anio: 'años',
};

/* ------------------------------------------------------------------ */
/* Series temporales                                                   */
/* ------------------------------------------------------------------ */

/** Interpreta 'YYYY-MM-DD' o 'YYYY-MM-DD HH:MM:SS' como instante UTC "ingenuo" (sin zona/DST). */
export function parseClave(clave: string): number {
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}))?/.exec(clave);
  if (!m) {
    throw new Error(`Fecha no válida: "${clave}"`);
  }
  return Date.UTC(+m[1], +m[2] - 1, +m[3], m[4] ? +m[4] : 0);
}

const dos = (n: number): string => String(n).padStart(2, '0');

export function alinearInicio(ms: number, intervalo: Intervalo): number {
  const d = new Date(ms);
  switch (intervalo) {
    case 'hora':
      return Math.floor(ms / HORA_MS) * HORA_MS;
    case 'dia':
      return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
    case 'semana': {
      const dia = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
      const desdeLunes = (d.getUTCDay() + 6) % 7;
      return dia - desdeLunes * DIA_MS;
    }
    case 'mes':
      return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1);
    case 'anio':
      return Date.UTC(d.getUTCFullYear(), 0, 1);
  }
}

export function siguienteInicio(ms: number, intervalo: Intervalo): number {
  const d = new Date(ms);
  switch (intervalo) {
    case 'hora':
      return ms + HORA_MS;
    case 'dia':
      return ms + DIA_MS;
    case 'semana':
      return ms + 7 * DIA_MS;
    case 'mes':
      return Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1);
    case 'anio':
      return Date.UTC(d.getUTCFullYear() + 1, 0, 1);
  }
}

export function formatearClave(ms: number, intervalo: Intervalo): string {
  const d = new Date(ms);
  const fecha = `${d.getUTCFullYear()}-${dos(d.getUTCMonth() + 1)}-${dos(d.getUTCDate())}`;
  return intervalo === 'hora' ? `${fecha} ${dos(d.getUTCHours())}:00:00` : fecha;
}

export function formatearEtiqueta(ms: number, intervalo: Intervalo): string {
  const d = new Date(ms);
  const dd = dos(d.getUTCDate());
  const mm = dos(d.getUTCMonth() + 1);
  const yyyy = d.getUTCFullYear();
  switch (intervalo) {
    case 'hora':
      return `${dd}/${mm} ${dos(d.getUTCHours())}:00`;
    case 'dia':
      return `${dd}/${mm}/${yyyy}`;
    case 'semana':
      return `Sem. ${dd}/${mm}/${yyyy}`;
    case 'mes':
      return `${NOMBRES_MES[d.getUTCMonth()]} ${yyyy}`;
    case 'anio':
      return String(yyyy);
  }
}

/**
 * Convierte las cubetas dispersas del servidor en una serie continua,
 * rellenando con 0 los intervalos sin ventas entre `desde` y `hasta` (inclusive).
 * Sin este relleno la periodicidad se falsearía.
 */
export function rellenarSerie(
  cubetas: Cubeta[],
  desde: string,
  hasta: string,
  intervalo: Intervalo,
): PuntoSerie[] {
  const inicio = alinearInicio(parseClave(desde), intervalo);
  const fin = alinearInicio(parseClave(hasta), intervalo);
  if (fin < inicio) {
    throw new Error('La fecha final no puede ser anterior a la inicial.');
  }

  const mapa = new Map<number, number>();
  for (const c of cubetas) {
    const ms = alinearInicio(parseClave(c.clave), intervalo);
    mapa.set(ms, (mapa.get(ms) ?? 0) + Number(c.valor));
  }

  const serie: PuntoSerie[] = [];
  for (let ms = inicio; ms <= fin; ms = siguienteInicio(ms, intervalo)) {
    if (serie.length >= MAX_PUNTOS) {
      throw new Error(
        `El rango genera más de ${MAX_PUNTOS} intervalos. Reduce el periodo o usa un intervalo más grande.`,
      );
    }
    serie.push({
      clave: formatearClave(ms, intervalo),
      etiqueta: formatearEtiqueta(ms, intervalo),
      valor: mapa.get(ms) ?? 0,
    });
  }
  return serie;
}

/** Fecha/etiqueta del intervalo situado `pasos` posiciones después de `ultimaClave`. */
export function claveFutura(
  ultimaClave: string,
  intervalo: Intervalo,
  pasos: number,
): { clave: string; etiqueta: string } {
  let ms = alinearInicio(parseClave(ultimaClave), intervalo);
  for (let i = 0; i < pasos; i++) {
    ms = siguienteInicio(ms, intervalo);
  }
  return { clave: formatearClave(ms, intervalo), etiqueta: formatearEtiqueta(ms, intervalo) };
}

/** Devuelve un mensaje si los datos no alcanzan para un análisis fiable; null si son suficientes. */
export function validarSuficiencia(
  n: number,
  totalRegistros: number,
  periodoBase?: number,
): string | null {
  if (totalRegistros <= 0) {
    return 'No hay ventas registradas con los filtros seleccionados.';
  }
  if (n < MIN_INTERVALOS) {
    return `Datos insuficientes: se necesitan al menos ${MIN_INTERVALOS} intervalos y el rango seleccionado solo tiene ${n}. Amplía el periodo o usa un intervalo más pequeño.`;
  }
  if (periodoBase && periodoBase >= 2 && n < 2 * periodoBase) {
    return `Datos insuficientes para el periodo base elegido (${formatear(periodoBase)} intervalos): se necesitan al menos 2 ciclos completos (${formatear(2 * periodoBase)} intervalos) y hay ${n}.`;
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Álgebra mínima                                                      */
/* ------------------------------------------------------------------ */

/** Eliminación gaussiana con pivoteo parcial. Una columna singular recibe coeficiente 0. */
function resolverSistema(a: number[][], b: number[]): number[] {
  const n = b.length;
  const m = a.map((fila, i) => [...fila, b[i]]);

  for (let c = 0; c < n; c++) {
    let piv = c;
    for (let r = c + 1; r < n; r++) {
      if (Math.abs(m[r][c]) > Math.abs(m[piv][c])) {
        piv = r;
      }
    }
    if (Math.abs(m[piv][c]) < 1e-12) {
      continue;
    }
    [m[c], m[piv]] = [m[piv], m[c]];
    for (let r = c + 1; r < n; r++) {
      const f = m[r][c] / m[c][c];
      if (f === 0) {
        continue;
      }
      for (let k = c; k <= n; k++) {
        m[r][k] -= f * m[c][k];
      }
    }
  }

  const x = new Array<number>(n).fill(0);
  for (let i = n - 1; i >= 0; i--) {
    if (Math.abs(m[i][i]) < 1e-12) {
      x[i] = 0;
      continue;
    }
    let s = m[i][n];
    for (let j = i + 1; j < n; j++) {
      s -= m[i][j] * x[j];
    }
    x[i] = s / m[i][i];
  }
  return x;
}

const promedio = (v: number[]): number => (v.length ? v.reduce((s, x) => s + x, 0) / v.length : 0);

/* ------------------------------------------------------------------ */
/* Serie de Fourier                                                    */
/* ------------------------------------------------------------------ */

/**
 * Ajusta una Serie de Fourier con `armonicos` términos y periodo base `periodoBase`
 * (en intervalos; por defecto toda la ventana). Devuelve coeficientes, tabla de armónicos,
 * la aproximación en cada intervalo y métricas de error.
 */
export function ajustarFourier(
  y: number[],
  armonicos: number,
  periodoBase?: number,
): AjusteFourier {
  const n = y.length;
  if (n < 3) {
    throw new Error('Se necesitan al menos 3 intervalos para ajustar una serie de Fourier.');
  }

  const periodo = periodoBase && periodoBase >= 2 ? periodoBase : n;
  const kMax = Math.max(1, Math.min(Math.floor((n - 1) / 2), Math.floor(periodo / 2)));
  const K = Math.max(1, Math.min(Math.floor(armonicos) || 1, kMax));
  const p = 2 * K + 1;

  const cols: Float64Array[] = [new Float64Array(n).fill(1)];
  for (let k = 1; k <= K; k++) {
    const c = new Float64Array(n);
    const s = new Float64Array(n);
    const w = (2 * Math.PI * k) / periodo;
    for (let t = 0; t < n; t++) {
      c[t] = Math.cos(w * t);
      s[t] = Math.sin(w * t);
    }
    cols.push(c, s);
  }

  const G: number[][] = Array.from({ length: p }, () => new Array<number>(p).fill(0));
  const r = new Array<number>(p).fill(0);
  for (let i = 0; i < p; i++) {
    for (let j = i; j < p; j++) {
      let s = 0;
      for (let t = 0; t < n; t++) {
        s += cols[i][t] * cols[j][t];
      }
      G[i][j] = s;
      G[j][i] = s;
    }
    let s = 0;
    for (let t = 0; t < n; t++) {
      s += cols[i][t] * y[t];
    }
    r[i] = s;
  }

  const coef = resolverSistema(G, r);

  const aproximado = new Array<number>(n).fill(0);
  for (let t = 0; t < n; t++) {
    let v = 0;
    for (let i = 0; i < p; i++) {
      v += coef[i] * cols[i][t];
    }
    aproximado[t] = v;
  }

  const media = promedio(y);
  let sse = 0;
  let sst = 0;
  for (let t = 0; t < n; t++) {
    sse += (y[t] - aproximado[t]) ** 2;
    sst += (y[t] - media) ** 2;
  }

  const tabla: FilaArmonico[] = [];
  for (let k = 1; k <= K; k++) {
    const a = coef[2 * k - 1];
    const b = coef[2 * k];
    tabla.push({
      k,
      a,
      b,
      amplitud: Math.hypot(a, b),
      fase: Math.atan2(b, a),
      frecuencia: k / periodo,
      periodo: periodo / k,
    });
  }

  return {
    n,
    armonicos: K,
    periodoBase: periodo,
    media,
    a0: coef[0],
    armonicosTabla: tabla,
    aproximado,
    rmse: Math.sqrt(sse / n),
    r2: sst > 1e-12 ? Math.max(0, Math.min(1, 1 - sse / sst)) : 1,
  };
}

/** Evalúa la serie ajustada en el índice t (puede ser > N-1 para extrapolar hacia adelante). */
export function evaluarFourier(ajuste: AjusteFourier, t: number): number {
  let v = ajuste.a0;
  for (const h of ajuste.armonicosTabla) {
    const w = (2 * Math.PI * h.k * t) / ajuste.periodoBase;
    v += h.a * Math.cos(w) + h.b * Math.sin(w);
  }
  return v;
}

/* ------------------------------------------------------------------ */
/* Espectro / periodograma                                             */
/* ------------------------------------------------------------------ */

/** Ajuste sinusoidal único de periodo p (1, cos, sin) → amplitud y fracción de varianza explicada. */
function evaluarPeriodo(y: number[], p: number, media: number, sst: number, syy: number): PuntoEspectral {
  const n = y.length;
  const w = (2 * Math.PI) / p;
  let sc = 0, ss = 0, scc = 0, sss = 0, scs = 0, syc = 0, sys = 0, sy = 0;
  for (let t = 0; t < n; t++) {
    const c = Math.cos(w * t);
    const s = Math.sin(w * t);
    sc += c;
    ss += s;
    scc += c * c;
    sss += s * s;
    scs += c * s;
    syc += y[t] * c;
    sys += y[t] * s;
    sy += y[t];
  }
  const beta = resolverSistema(
    [
      [n, sc, ss],
      [sc, scc, scs],
      [ss, scs, sss],
    ],
    [sy, syc, sys],
  );
  const sse = syy - (beta[0] * sy + beta[1] * syc + beta[2] * sys);
  const ssr = Math.max(0, sst - Math.max(0, sse));
  void media;
  return {
    periodo: p,
    amplitud: Math.hypot(beta[1], beta[2]),
    varianzaExplicada: sst > 1e-12 ? Math.min(1, ssr / sst) : 0,
  };
}

/** Espectro: para cada periodo candidato (2..N/2 intervalos) la amplitud y la varianza que explica. */
export function periodograma(y: number[], periodosExtra: number[] = []): PuntoEspectral[] {
  const n = y.length;
  if (n < 6) {
    return [];
  }
  const maxP = n / 2;
  const candidatos = new Set<number>();
  for (let p = 2; p <= Math.min(60, Math.floor(maxP)); p++) {
    candidatos.add(p);
  }
  if (maxP > 60) {
    const pasos = 140;
    for (let i = 0; i <= pasos; i++) {
      candidatos.add(Math.round(60 * Math.pow(maxP / 60, i / pasos) * 100) / 100);
    }
  }
  for (const p of periodosExtra) {
    if (p >= 2 && p <= maxP) {
      candidatos.add(Math.round(p * 100) / 100);
    }
  }

  const media = promedio(y);
  let syy = 0;
  for (const v of y) {
    syy += v * v;
  }
  const sst = syy - n * media * media;

  return [...candidatos]
    .sort((a, b) => a - b)
    .map((p) => evaluarPeriodo(y, p, media, sst, syy));
}

/** Refina un máximo local del espectro con búsqueda ternaria entre sus vecinos. */
function refinarPico(y: number[], izq: number, der: number): PuntoEspectral {
  const media = promedio(y);
  let syy = 0;
  for (const v of y) {
    syy += v * v;
  }
  const sst = syy - y.length * media * media;
  let lo = izq;
  let hi = der;
  for (let i = 0; i < 18; i++) {
    const m1 = lo + (hi - lo) / 3;
    const m2 = hi - (hi - lo) / 3;
    const e1 = evaluarPeriodo(y, m1, media, sst, syy).varianzaExplicada;
    const e2 = evaluarPeriodo(y, m2, media, sst, syy).varianzaExplicada;
    if (e1 < e2) {
      lo = m1;
    } else {
      hi = m2;
    }
  }
  return evaluarPeriodo(y, (lo + hi) / 2, media, sst, syy);
}

/** Máximos locales del espectro con sentido (≥5% de la varianza), sin armónicos de otro pico más fuerte. */
export function picosDominantes(y: number[], espectro: PuntoEspectral[], maximo = 3): PuntoEspectral[] {
  const candidatos: PuntoEspectral[] = [];
  for (let i = 0; i < espectro.length; i++) {
    const v = espectro[i].varianzaExplicada;
    const prev = i > 0 ? espectro[i - 1].varianzaExplicada : -1;
    const next = i < espectro.length - 1 ? espectro[i + 1].varianzaExplicada : -1;
    if (v >= prev && v >= next && v >= 0.05) {
      const izq = i > 0 ? espectro[i - 1].periodo : espectro[i].periodo;
      const der = i < espectro.length - 1 ? espectro[i + 1].periodo : espectro[i].periodo;
      candidatos.push(izq < der ? refinarPico(y, izq, der) : espectro[i]);
    }
  }
  candidatos.sort((a, b) => b.varianzaExplicada - a.varianzaExplicada);

  const aceptados: PuntoEspectral[] = [];
  for (const c of candidatos) {
    const esArmonico = aceptados.some((a) => {
      for (let k = 2; k <= 6; k++) {
        if (Math.abs((c.periodo * k) / a.periodo - 1) < 0.07) {
          return true;
        }
      }
      return false;
    });
    if (!esArmonico) {
      aceptados.push(c);
    }
    if (aceptados.length >= maximo) {
      break;
    }
  }
  return aceptados;
}

/* ------------------------------------------------------------------ */
/* Lenguaje llano para el administrador                                */
/* ------------------------------------------------------------------ */

function formatear(n: number): string {
  return Number.isInteger(n) ? String(n) : n.toFixed(1);
}

const CALENDARIO: { dias: number; nombre: string }[] = [
  { dias: 1, nombre: 'diario' },
  { dias: 7, nombre: 'semanal' },
  { dias: 14, nombre: 'quincenal' },
  { dias: 30.4375, nombre: 'mensual' },
  { dias: 91.3125, nombre: 'trimestral' },
  { dias: 182.625, nombre: 'semestral' },
  { dias: 365.25, nombre: 'anual' },
];

const cercano = (a: number, b: number, tol = 0.12): boolean => Math.abs(a - b) / b <= tol;

export function nombrePeriodo(periodo: number, intervalo: Intervalo): string {
  const dias = periodo * DIAS_POR_INTERVALO[intervalo];
  const cal = CALENDARIO.find((c) => cercano(dias, c.dias));
  if (cal) {
    return cal.nombre;
  }
  if (dias < 1.5) {
    return `cada ${formatear(dias * 24)} horas`;
  }
  return `cada ${formatear(dias)} días`;
}

interface Perfil {
  picos: string[];
  bajas: string[];
}

/** Perfil por segmento del ciclo (día de la semana, hora del día, mes del año, día del mes). */
function perfilPorSegmento(puntos: PuntoSerie[], intervalo: Intervalo, periodoDias: number): Perfil | null {
  let clave: ((d: Date) => number) | null = null;
  let etiqueta: (k: number) => string = String;

  if ((intervalo === 'dia' || intervalo === 'hora') && cercano(periodoDias, 7)) {
    clave = (d) => d.getUTCDay();
    etiqueta = (k) => NOMBRES_DIA[k];
  } else if (intervalo === 'hora' && cercano(periodoDias, 1)) {
    clave = (d) => d.getUTCHours();
    etiqueta = (k) => `${dos(k)}:00`;
  } else if (intervalo === 'mes' && cercano(periodoDias, 365.25)) {
    clave = (d) => d.getUTCMonth();
    etiqueta = (k) => NOMBRES_MES[k];
  } else if (intervalo === 'dia' && cercano(periodoDias, 30.4375)) {
    clave = (d) => d.getUTCDate();
    etiqueta = (k) => `día ${k}`;
  }
  if (!clave) {
    return null;
  }

  const acum = new Map<number, { suma: number; cuenta: number }>();
  for (const p of puntos) {
    const k = clave(new Date(parseClave(p.clave)));
    const a = acum.get(k) ?? { suma: 0, cuenta: 0 };
    a.suma += p.valor;
    a.cuenta += 1;
    acum.set(k, a);
  }
  const media = promedio(puntos.map((p) => p.valor));
  if (media <= 0) {
    return null;
  }
  const prom = [...acum.entries()].map(([k, a]) => ({ k, v: a.suma / a.cuenta }));
  prom.sort((a, b) => b.v - a.v);

  const picos = prom.filter((x) => x.v > media * 1.1).slice(0, 2).map((x) => etiqueta(x.k));
  const bajas = prom
    .filter((x) => x.v < media * 0.9)
    .slice(-2)
    .reverse()
    .map((x) => etiqueta(x.k));
  return { picos, bajas };
}

function clasificarFuerza(varianza: number): Fuerza {
  if (varianza >= 0.35) {
    return 'fuerte';
  }
  if (varianza >= 0.15) {
    return 'moderada';
  }
  return 'débil';
}

function dominante(y: number[]): PuntoEspectral | null {
  const picos = picosDominantes(y, periodograma(y), 1);
  return picos.length && y.length >= 2 * picos[0].periodo ? picos[0] : null;
}

/**
 * Identifica periodicidades dominantes a partir del espectro de Fourier y las
 * describe en lenguaje llano (picos recurrentes, baja demanda, estacionalidad).
 */
export function detectarPatrones(puntos: PuntoSerie[], intervalo: Intervalo): ResultadoPatrones {
  const y = puntos.map((p) => p.valor);
  const n = y.length;
  const media = promedio(y);
  if (n < MIN_INTERVALOS || media <= 0) {
    return { patrones: [], cambioPeriodicidad: null };
  }

  const extras = CALENDARIO.map((c) => c.dias / DIAS_POR_INTERVALO[intervalo]);
  const espectro = periodograma(y, extras);
  const picos = picosDominantes(y, espectro, 3).filter((p) => n / p.periodo >= 2);

  const patrones: Patron[] = picos.map((p) => {
    const periodoDias = p.periodo * DIAS_POR_INTERVALO[intervalo];
    const nombre = nombrePeriodo(p.periodo, intervalo);
    const perfil = perfilPorSegmento(puntos, intervalo, periodoDias);
    const fuerza = clasificarFuerza(p.varianzaExplicada);
    const amplitudRelativa = p.amplitud / media;
    const partes = [
      `Patrón ${nombre} (se repite cada ${formatear(p.periodo)} ${UNIDAD_PLURAL[intervalo]}, ${formatear(n / p.periodo)} ciclos observados).`,
      `Explica ${(p.varianzaExplicada * 100).toFixed(0)}% de la variación de las ventas; las subidas y bajadas son de ±${(amplitudRelativa * 100).toFixed(0)}% respecto al promedio.`,
    ];
    if (perfil?.picos.length) {
      partes.push(`Picos recurrentes: ${perfil.picos.join(', ')}.`);
    }
    if (perfil?.bajas.length) {
      partes.push(`Baja demanda: ${perfil.bajas.join(', ')}.`);
    }
    return {
      periodo: p.periodo,
      periodoDias,
      nombre,
      amplitud: p.amplitud,
      amplitudRelativa,
      varianzaExplicada: p.varianzaExplicada,
      fuerza,
      ciclos: n / p.periodo,
      descripcion: partes.join(' '),
      picos: perfil?.picos ?? [],
      bajas: perfil?.bajas ?? [],
    };
  });

  let cambioPeriodicidad: string | null = null;
  if (n >= 4 * MIN_INTERVALOS / 2) {
    const mitad = Math.floor(n / 2);
    const a = dominante(y.slice(0, mitad));
    const b = dominante(y.slice(mitad));
    if (a && b) {
      const difPeriodo = Math.abs(a.periodo - b.periodo) / Math.max(a.periodo, b.periodo);
      const ratioAmp = Math.max(a.amplitud, b.amplitud) / Math.max(1e-9, Math.min(a.amplitud, b.amplitud));
      if (difPeriodo > 0.25) {
        cambioPeriodicidad = `La periodicidad dominante cambió: primera mitad ${nombrePeriodo(a.periodo, intervalo)}, segunda mitad ${nombrePeriodo(b.periodo, intervalo)}.`;
      } else if (ratioAmp > 1.5) {
        cambioPeriodicidad = `La intensidad del patrón ${nombrePeriodo(b.periodo, intervalo)} ${b.amplitud > a.amplitud ? 'aumentó' : 'disminuyó'} entre la primera y la segunda mitad del periodo.`;
      }
    } else if (a && !b) {
      cambioPeriodicidad = `El patrón ${nombrePeriodo(a.periodo, intervalo)} de la primera mitad ya no se aprecia en la segunda mitad.`;
    } else if (!a && b) {
      cambioPeriodicidad = `Apareció un patrón ${nombrePeriodo(b.periodo, intervalo)} en la segunda mitad del periodo.`;
    }
  }

  return { patrones, cambioPeriodicidad };
}

/* ------------------------------------------------------------------ */
/* Extrapolación de la misma serie y alerta de inventario              */
/* ------------------------------------------------------------------ */

export function pronosticarPico(
  ajuste: AjusteFourier,
  ultimaClave: string,
  intervalo: Intervalo,
  horizonte: number,
): PicoFuturo {
  let mejor = { paso: 1, valor: -Infinity };
  for (let paso = 1; paso <= Math.max(1, horizonte); paso++) {
    const v = evaluarFourier(ajuste, ajuste.n - 1 + paso);
    if (v > mejor.valor) {
      mejor = { paso, valor: v };
    }
  }
  const f = claveFutura(ultimaClave, intervalo, mejor.paso);
  return { paso: mejor.paso, clave: f.clave, etiqueta: f.etiqueta, valor: Math.max(0, mejor.valor) };
}

/**
 * Alerta administrativa: se activa si hay un patrón periódico dominante, no débil, con
 * oscilación ≥25% del promedio, y la propia serie de Fourier (con ese periodo como base)
 * proyecta un pico ≥15% sobre el promedio dentro del siguiente ciclo.
 */
export function generarAlerta(
  puntos: PuntoSerie[],
  patrones: Patron[],
  intervalo: Intervalo,
  unidad: string,
): Alerta {
  const sinAlerta: Alerta = { activa: false, mensaje: '', detalle: '', proximoPico: null };
  const y = puntos.map((p) => p.valor);
  const media = promedio(y);
  const dom = patrones[0];
  if (!dom || media <= 0 || dom.fuerza === 'débil' || dom.amplitudRelativa < 0.25) {
    return sinAlerta;
  }

  const ajuste = ajustarFourier(y, 3, dom.periodo);
  const pico = pronosticarPico(ajuste, puntos[puntos.length - 1].clave, intervalo, Math.ceil(dom.periodo));
  if (pico.valor < media * 1.15) {
    return sinAlerta;
  }

  return {
    activa: true,
    mensaje: MENSAJE_ALERTA,
    detalle: `Patrón ${dom.nombre}. Próximo pico estimado: ${pico.etiqueta} (≈ ${pico.valor.toFixed(1)} ${unidad} por intervalo, frente a un promedio de ${media.toFixed(1)}).`,
    proximoPico: pico,
  };
}

import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { FourierService, FiltrosFourier, RegistroVentaLinea, AnalisisGuardadoResumen } from '../../services/fourier.service';
import { InventarioService, Producto } from '../../services/inventario.service';
import {
  Intervalo,
  PuntoSerie,
  AjusteFourier,
  ResultadoPatrones,
  Alerta,
  rellenarSerie,
  validarSuficiencia,
  ajustarFourier,
  evaluarFourier,
  detectarPatrones,
  generarAlerta,
  NOMBRES_DIA,
  NOMBRES_MES
} from './fourier.math';

@Component({
  selector: 'app-fourier',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './fourier.html',
  styleUrl: './fourier.css'
})
export class FourierComponent implements OnInit {
  private router = inject(Router);
  private fourierService = inject(FourierService);
  private inventarioService = inject(InventarioService);

  // Filtros principales
  fechaDesde: string = '';
  fechaHasta: string = '';
  intervalo: Intervalo = 'dia';
  metrica: 'unidades' | 'ingresos' = 'unidades';
  productoId: number = 0;
  categoria: string = '';
  armonicos: number = 4;
  periodoBaseModo: 'auto' | 'semanal' | 'mensual' | 'anual' | 'personalizado' = 'auto';
  periodoBasePersonalizado: number = 7;
  incluirInternas: boolean = false;
  incluirDemo: boolean = false;

  // Catálogos
  productos: Producto[] = [];
  categorias: string[] = ['Vino', 'Tequila', 'Whisky', 'Vodka', 'Ron', 'Ginebra', 'Brandy', 'Cerveza', 'Licor', 'Otros'];

  // Estados de carga
  cargando: boolean = false;
  guardando: boolean = false;
  mensajeError: string = '';
  mensajeSuficiencia: string | null = null;
  mensajeExitoGuardado: string = '';

  // Datos reales y calculados
  puntosSerie: PuntoSerie[] = [];
  registrosVenta: RegistroVentaLinea[] = [];
  totalRegistros: number = 0;
  datasetHash: string = '';
  ajuste: AjusteFourier | null = null;
  resultadoPatrones: ResultadoPatrones | null = null;
  alerta: Alerta | null = null;

  // Interfaz de usuario
  pestanaActiva: 'grafica' | 'patrones' | 'armonicos' | 'tabla' | 'registros' = 'grafica';
  modalHistorialAbierto: boolean = false;
  historial: AnalisisGuardadoResumen[] = [];
  analisisActualId: number | null = null;

  // Tooltip interactivo en la gráfica
  tooltip = {
    visible: false,
    x: 0,
    y: 0,
    etiqueta: '',
    real: 0,
    fourier: 0,
    diff: 0
  };

  ngOnInit(): void {
    this.inicializarFechasPorDefecto();
    this.cargarCatalogoProductos();
    this.ejecutarAnalisis();
  }

  inicializarFechasPorDefecto(): void {
    const hoy = new Date();
    const hace90Dias = new Date();
    hace90Dias.setDate(hoy.getDate() - 90);

    this.fechaHasta = hoy.toISOString().slice(0, 10);
    this.fechaDesde = hace90Dias.toISOString().slice(0, 10);
  }

  setPeriodoRapido(dias: number): void {
    const hoy = new Date();
    const pasado = new Date();
    pasado.setDate(hoy.getDate() - dias);
    this.fechaHasta = hoy.toISOString().slice(0, 10);
    this.fechaDesde = pasado.toISOString().slice(0, 10);
    this.ejecutarAnalisis();
  }

  setPeriodoAnioActual(): void {
    const anio = new Date().getFullYear();
    this.fechaDesde = `${anio}-01-01`;
    this.fechaHasta = `${anio}-12-31`;
    this.ejecutarAnalisis();
  }

  cargarCatalogoProductos(): void {
    this.inventarioService.obtenerProductos().subscribe({
      next: (res) => {
        if (res.status === 'success' && Array.isArray(res.productos)) {
          this.productos = res.productos;
          // Extraer categorías únicas
          const cats = new Set<string>();
          for (const p of res.productos) {
            if (p.categoria && p.categoria.trim()) {
              cats.add(p.categoria.trim());
            }
          }
          if (cats.size > 0) {
            this.categorias = Array.from(cats).sort();
          }
        }
      },
      error: (err) => console.error('Error al cargar catálogo de productos:', err)
    });
  }

  obtenerPeriodoBaseCalculado(): number | undefined {
    if (this.periodoBaseModo === 'auto') {
      return undefined; // Toda la ventana (N)
    }
    if (this.periodoBaseModo === 'personalizado') {
      return Math.max(2, this.periodoBasePersonalizado || 7);
    }
    // Mapeo según el intervalo actual
    if (this.periodoBaseModo === 'semanal') {
      if (this.intervalo === 'hora') return 168; // 24 * 7
      if (this.intervalo === 'dia') return 7;
      return undefined;
    }
    if (this.periodoBaseModo === 'mensual') {
      if (this.intervalo === 'dia') return 30;
      if (this.intervalo === 'semana') return 4;
      return undefined;
    }
    if (this.periodoBaseModo === 'anual') {
      if (this.intervalo === 'mes') return 12;
      if (this.intervalo === 'semana') return 52;
      if (this.intervalo === 'dia') return 365;
      return undefined;
    }
    return undefined;
  }

  get resumenParametros(): string {
    const prodNom = this.productoId > 0 
      ? (this.productos.find(p => p.id === Number(this.productoId))?.nombre || `Producto #${this.productoId}`)
      : 'Todos los productos';
    const catNom = this.categoria ? ` · Categoría: ${this.categoria}` : '';
    const intNom = { hora: 'Horario', dia: 'Diario', semana: 'Semanal', mes: 'Mensual', anio: 'Anual' }[this.intervalo];
    const metNom = this.metrica === 'unidades' ? 'Unidades vendidas' : 'Ingresos ($ MXN)';
    return `Producto: ${prodNom}${catNom} · Periodo: ${this.fechaDesde} a ${this.fechaHasta} · Intervalo: ${intNom} · Métrica: ${metNom} · Armónicos: ${this.armonicos}`;
  }

  ejecutarAnalisis(): void {
    this.mensajeError = '';
    this.mensajeExitoGuardado = '';
    this.cargando = true;
    this.analisisActualId = null;

    const filtros: FiltrosFourier = {
      desde: this.fechaDesde,
      hasta: this.fechaHasta,
      intervalo: this.intervalo,
      metrica: this.metrica,
      producto_id: this.productoId > 0 ? this.productoId : undefined,
      categoria: this.categoria.trim() !== '' ? this.categoria : undefined,
      incluir_internas: this.incluirInternas,
      incluir_demo: this.incluirDemo
    };

    // 1. Obtener cubetas de ventas agrupadas
    this.fourierService.obtenerSerieVentas(filtros).subscribe({
      next: (res) => {
        if (res.status !== 'success') {
          this.cargando = false;
          this.mensajeError = res.mensaje || 'Error al obtener datos del servidor.';
          return;
        }

        this.totalRegistros = res.total_registros || 0;
        this.datasetHash = res.dataset_hash || '';

        try {
          // 2. Rellenar con 0 los intervalos sin ventas
          this.puntosSerie = rellenarSerie(res.serie || [], this.fechaDesde, this.fechaHasta, this.intervalo);
          
          const pBase = this.obtenerPeriodoBaseCalculado();
          this.mensajeSuficiencia = validarSuficiencia(this.puntosSerie.length, this.totalRegistros, pBase);

          if (this.puntosSerie.length < 3 || this.totalRegistros === 0) {
            this.ajuste = null;
            this.resultadoPatrones = null;
            this.alerta = null;
            this.cargando = false;
            return;
          }

          // 3. Ajuste mediante Serie de Fourier (mínimos cuadrados)
          const y = this.puntosSerie.map(p => p.valor);
          this.ajuste = ajustarFourier(y, this.armonicos, pBase);

          // 4. Detección de patrones y periodicidad en lenguaje llano
          this.resultadoPatrones = detectarPatrones(this.puntosSerie, this.intervalo);

          // 5. Generación de alerta administrativa de inventario
          const unidad = this.metrica === 'unidades' ? 'piezas' : 'MXN';
          this.alerta = generarAlerta(this.puntosSerie, this.resultadoPatrones.patrones, this.intervalo, unidad);

          this.cargando = false;
        } catch (e: any) {
          this.cargando = false;
          this.mensajeError = e.message || 'Error en el cálculo de la Serie de Fourier.';
        }
      },
      error: (err) => {
        this.cargando = false;
        this.mensajeError = err.error?.mensaje || 'Error al conectar con el backend.';
      }
    });

    // Cargar también las líneas individuales para la tabla de registros
    this.fourierService.obtenerRegistrosVentas(filtros, 500).subscribe({
      next: (resReg) => {
        if (resReg.status === 'success' && Array.isArray(resReg.registros)) {
          this.registrosVenta = resReg.registros;
        }
      },
      error: () => {}
    });
  }

  // Coordenadas para la gráfica SVG
  get maxValorGrafica(): number {
    if (!this.puntosSerie.length) return 10;
    const maxReal = Math.max(...this.puntosSerie.map(p => p.valor));
    const maxFourier = this.ajuste ? Math.max(...this.ajuste.aproximado) : 0;
    return Math.max(1, Math.max(maxReal, maxFourier) * 1.15);
  }

  getCoordX(index: number): number {
    const n = this.puntosSerie.length;
    if (n <= 1) return 80;
    return 70 + (index / (n - 1)) * 780;
  }

  getCoordY(valor: number): number {
    const max = this.maxValorGrafica;
    const clamped = Math.max(0, valor);
    return 320 - (clamped / max) * 260;
  }

  get puntosRealesPolyline(): string {
    return this.puntosSerie.map((p, i) => `${this.getCoordX(i)},${this.getCoordY(p.valor)}`).join(' ');
  }

  get curvaFourierPolyline(): string {
    if (!this.ajuste || this.puntosSerie.length < 2) return '';
    const n = this.puntosSerie.length;
    const puntos: string[] = [];
    const pasos = Math.min(600, n * 5); // Suavizado continuo
    for (let s = 0; s <= pasos; s++) {
      const t = (s / pasos) * (n - 1);
      const v = evaluarFourier(this.ajuste, t);
      const x = 70 + (t / (n - 1)) * 780;
      const y = this.getCoordY(v);
      puntos.push(`${x.toFixed(1)},${y.toFixed(1)}`);
    }
    return puntos.join(' ');
  }

  // Etiquetas del eje X (máximo 7 para no amontonar)
  get marcasEjeX(): { index: number; x: number; etiqueta: string }[] {
    const n = this.puntosSerie.length;
    if (n === 0) return [];
    if (n <= 7) {
      return this.puntosSerie.map((p, i) => ({ index: i, x: this.getCoordX(i), etiqueta: p.etiqueta }));
    }
    const paso = Math.ceil(n / 6);
    const marcas = [];
    for (let i = 0; i < n; i += paso) {
      marcas.push({ index: i, x: this.getCoordX(i), etiqueta: this.puntosSerie[i].etiqueta });
    }
    if (marcas[marcas.length - 1].index !== n - 1) {
      marcas.push({ index: n - 1, x: this.getCoordX(n - 1), etiqueta: this.puntosSerie[n - 1].etiqueta });
    }
    return marcas;
  }

  // Marcas del eje Y (5 niveles)
  get marcasEjeY(): { valor: number; y: number }[] {
    const max = this.maxValorGrafica;
    return [0, max * 0.25, max * 0.5, max * 0.75, max].map(v => ({
      valor: v,
      y: this.getCoordY(v)
    }));
  }

  activarTooltip(index: number, e: MouseEvent): void {
    if (!this.puntosSerie[index]) return;
    const real = this.puntosSerie[index].valor;
    const fourier = this.ajuste ? this.ajuste.aproximado[index] : 0;
    const diff = fourier - real;
    const svgEl = (e.currentTarget as SVGElement).ownerSVGElement;
    const rect = svgEl?.getBoundingClientRect();
    
    this.tooltip = {
      visible: true,
      x: e.clientX - (rect?.left || 0),
      y: e.clientY - (rect?.top || 0) - 40,
      etiqueta: this.puntosSerie[index].etiqueta,
      real: Number(real.toFixed(2)),
      fourier: Number(fourier.toFixed(2)),
      diff: Number(diff.toFixed(2))
    };
  }

  desactivarTooltip(): void {
    this.tooltip.visible = false;
  }

  // Trazabilidad: Guardar análisis
  guardarAnalisis(): void {
    if (!this.ajuste) {
      alert('Primero debes ejecutar un análisis con datos válidos.');
      return;
    }

    let usuarioActual = 'Administrador General';
    let usuarioId: number | null = null;
    try {
      const sesionRaw = localStorage.getItem('admin_sesion');
      if (sesionRaw) {
        const sesion = JSON.parse(sesionRaw);
        usuarioActual = sesion.nombre || sesion.email || usuarioActual;
        usuarioId = sesion.id ? Number(sesion.id) : null;
      }
    } catch {}

    const payload = {
      usuario_nombre: usuarioActual,
      usuario_id: usuarioId,
      desde: this.fechaDesde,
      hasta: this.fechaHasta,
      intervalo: this.intervalo,
      metrica: this.metrica,
      producto_id: this.productoId > 0 ? this.productoId : undefined,
      categoria: this.categoria.trim() !== '' ? this.categoria : undefined,
      armonicos: this.armonicos,
      periodo_base: this.ajuste.periodoBase,
      incluir_internas: this.incluirInternas,
      incluir_demo: this.incluirDemo,
      dataset_hash: this.datasetHash,
      alerta_activa: this.alerta?.activa ? 1 : 0,
      alerta_mensaje: this.alerta?.mensaje || '',
      parametros: {
        resumen: this.resumenParametros,
        total_puntos: this.puntosSerie.length,
        total_registros: this.totalRegistros,
        rmse: this.ajuste.rmse,
        r2: this.ajuste.r2
      },
      coeficientes: {
        a0: this.ajuste.a0,
        tabla: this.ajuste.armonicosTabla
      },
      serie: this.puntosSerie.map((p, i) => ({
        clave: p.clave,
        etiqueta: p.etiqueta,
        observado: p.valor,
        aproximado: this.ajuste?.aproximado[i]
      })),
      patrones: this.resultadoPatrones
    };

    this.guardando = true;
    this.fourierService.guardarAnalisis(payload).subscribe({
      next: (res) => {
        this.guardando = false;
        if (res.status === 'success') {
          this.analisisActualId = res.analysis_id || null;
          this.mensajeExitoGuardado = `✅ Análisis #${res.analysis_id} guardado con éxito con su hash de trazabilidad.`;
        } else {
          alert(res.mensaje || 'Error al guardar análisis.');
        }
      },
      error: (err) => {
        this.guardando = false;
        alert(err.error?.mensaje || 'Error al conectar con el servidor.');
      }
    });
  }

  // Trazabilidad: Historial y reproducción
  abrirModalHistorial(): void {
    this.modalHistorialAbierto = true;
    this.fourierService.obtenerAnalisisGuardados().subscribe({
      next: (res) => {
        if (res.status === 'success' && Array.isArray(res.analisis)) {
          this.historial = res.analisis;
        }
      },
      error: (err) => console.error('Error al cargar historial:', err)
    });
  }

  cerrarModalHistorial(): void {
    this.modalHistorialAbierto = false;
  }

  reproducirAnalisis(id: number): void {
    this.fourierService.obtenerAnalisisPorId(id).subscribe({
      next: (res) => {
        if (res.status === 'success' && res.analisis) {
          const a = res.analisis;
          this.fechaDesde = a.desde;
          this.fechaHasta = a.hasta;
          this.intervalo = a.intervalo;
          this.metrica = a.metrica;
          this.productoId = a.producto_id || 0;
          this.categoria = a.categoria || '';
          this.armonicos = a.armonicos;
          this.incluirInternas = a.incluir_internas;
          this.incluirDemo = a.incluir_demo;
          this.analisisActualId = a.analysis_id;

          this.cerrarModalHistorial();
          this.ejecutarAnalisis();
        }
      },
      error: (err) => alert('No se pudo cargar el análisis seleccionado.')
    });
  }

  exportarRegistrosCSV(): void {
    if (!this.registrosVenta.length) return;
    const filas = [
      ['ID Venta', 'Fecha', 'Hora', 'Tipo', 'ID Producto', 'Producto', 'Categoría', 'Cantidad', 'Precio Unitario', 'Subtotal', 'Total Venta'],
      ...this.registrosVenta.map(r => [
        r.sale_id,
        r.fecha,
        r.hora,
        r.tipo,
        r.producto_id,
        `"${r.producto.replace(/"/g, '""')}"`,
        `"${r.categoria.replace(/"/g, '""')}"`,
        r.cantidad,
        r.precio_unitario.toFixed(2),
        r.subtotal.toFixed(2),
        r.total_venta.toFixed(2)
      ])
    ];

    const contenidoCSV = 'data:text/csv;charset=utf-8,' + filas.map(e => e.join(',')).join('\n');
    const enlaceCodificado = encodeURI(contenidoCSV);
    const link = document.createElement('a');
    link.setAttribute('href', enlaceCodificado);
    link.setAttribute('download', `Registros_Ventas_Fourier_${this.fechaDesde}_${this.fechaHasta}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  volver(): void {
    this.router.navigate(['/admin']);
  }
}


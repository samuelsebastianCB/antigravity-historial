import {
  ajustarFourier,
  alinearInicio,
  claveFutura,
  detectarPatrones,
  evaluarFourier,
  generarAlerta,
  nombrePeriodo,
  parseClave,
  periodograma,
  picosDominantes,
  PuntoSerie,
  rellenarSerie,
  validarSuficiencia,
  MENSAJE_ALERTA,
} from './fourier.math';

const DIA = 86_400_000;

/** Serie diaria sintética que empieza el lunes 2026-01-05. */
function serieDiaria(n: number, valor: (t: number, diaSemana: number) => number): PuntoSerie[] {
  const inicio = Date.UTC(2026, 0, 5);
  const puntos: PuntoSerie[] = [];
  for (let t = 0; t < n; t++) {
    const ms = inicio + t * DIA;
    const d = new Date(ms);
    const clave = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
    puntos.push({ clave, etiqueta: clave, valor: valor(t, d.getUTCDay()) });
  }
  return puntos;
}

describe('fourier.math · series temporales', () => {
  it('rellena con 0 los intervalos sin ventas', () => {
    const serie = rellenarSerie(
      [
        { clave: '2026-03-01', valor: 5 },
        { clave: '2026-03-04', valor: 2 },
      ],
      '2026-03-01',
      '2026-03-05',
      'dia',
    );
    expect(serie.map((p) => p.valor)).toEqual([5, 0, 0, 2, 0]);
  });

  it('alinea las semanas al lunes y suma cubetas de la misma semana', () => {
    // 2026-01-07 es miércoles → semana del lunes 2026-01-05
    expect(new Date(alinearInicio(parseClave('2026-01-07'), 'semana')).toISOString().slice(0, 10)).toBe('2026-01-05');
    const serie = rellenarSerie(
      [
        { clave: '2026-01-05', valor: 3 },
        { clave: '2026-01-07', valor: 4 },
        { clave: '2026-01-14', valor: 1 },
      ],
      '2026-01-05',
      '2026-01-18',
      'semana',
    );
    expect(serie.map((p) => p.valor)).toEqual([7, 1]);
  });

  it('agrupa por mes y por hora', () => {
    const meses = rellenarSerie([{ clave: '2026-02-01', valor: 9 }], '2026-01-15', '2026-03-10', 'mes');
    expect(meses.map((p) => p.valor)).toEqual([0, 9, 0]);
    const horas = rellenarSerie([{ clave: '2026-01-01 02:00:00', valor: 4 }], '2026-01-01 00:00:00', '2026-01-01 03:00:00', 'hora');
    expect(horas.map((p) => p.valor)).toEqual([0, 0, 4, 0]);
  });

  it('calcula fechas futuras y valida suficiencia de datos', () => {
    expect(claveFutura('2026-01-31', 'dia', 2).clave).toBe('2026-02-02');
    expect(validarSuficiencia(10, 50)).toContain('insuficientes');
    expect(validarSuficiencia(30, 0)).toContain('No hay ventas');
    expect(validarSuficiencia(30, 40, 20)).toContain('2 ciclos');
    expect(validarSuficiencia(60, 100)).toBeNull();
  });
});

describe('fourier.math · serie de Fourier', () => {
  it('recupera media, amplitud, fase y periodo de una senoide conocida', () => {
    const y = Array.from({ length: 70 }, (_, t) => 10 + 5 * Math.cos((2 * Math.PI * t) / 7 - 0.5));
    const a = ajustarFourier(y, 1, 7);
    expect(a.a0).toBeCloseTo(10, 6);
    expect(a.armonicosTabla[0].amplitud).toBeCloseTo(5, 6);
    expect(a.armonicosTabla[0].fase).toBeCloseTo(0.5, 6);
    expect(a.armonicosTabla[0].periodo).toBeCloseTo(7, 9);
    expect(a.armonicosTabla[0].frecuencia).toBeCloseTo(1 / 7, 9);
    expect(a.rmse).toBeLessThan(1e-6);
    expect(a.r2).toBeCloseTo(1, 6);
  });

  it('con periodo base fijo no sufre leakage cuando la ventana no es múltiplo del periodo', () => {
    const y = Array.from({ length: 90 }, (_, t) => 20 + 8 * Math.sin((2 * Math.PI * t) / 7));
    const fijo = ajustarFourier(y, 1, 7);
    expect(fijo.armonicosTabla[0].amplitud).toBeCloseTo(8, 6);
    const auto = ajustarFourier(y, 1);
    expect(auto.r2).toBeLessThan(fijo.r2);
  });

  it('reproduce exactamente la serie con todos los armónicos posibles (N impar)', () => {
    const y = [3, 9, 1, 7, 4, 12, 0, 5, 8, 2, 6, 11, 3, 4, 10];
    const a = ajustarFourier(y, 99);
    expect(a.armonicos).toBe(7);
    a.aproximado.forEach((v, t) => expect(v).toBeCloseTo(y[t], 6));
    expect(evaluarFourier(a, 3)).toBeCloseTo(y[3], 6);
  });

  it('más armónicos nunca empeoran el ajuste', () => {
    const y = serieDiaria(84, (t, d) => (d === 5 || d === 6 ? 30 : 10) + (t % 5)).map((p) => p.valor);
    const r2 = [1, 2, 3, 5].map((k) => ajustarFourier(y, k, 7).r2);
    for (let i = 1; i < r2.length; i++) {
      expect(r2[i]).toBeGreaterThanOrEqual(r2[i - 1] - 1e-9);
    }
  });

  it('rechaza series demasiado cortas', () => {
    expect(() => ajustarFourier([1, 2], 1)).toThrow();
  });
});

describe('fourier.math · periodicidad y patrones', () => {
  it('el espectro encuentra el periodo semanal', () => {
    const y = Array.from({ length: 120 }, (_, t) => 15 + 6 * Math.cos((2 * Math.PI * t) / 7));
    const picos = picosDominantes(y, periodograma(y), 1);
    expect(picos[0].periodo).toBeCloseTo(7, 1);
    expect(picos[0].varianzaExplicada).toBeGreaterThan(0.95);
  });

  it('detecta patrón semanal con picos viernes/sábado y baja demanda entre semana', () => {
    const puntos = serieDiaria(126, (_t, d) => (d === 5 || d === 6 ? 30 : d === 1 || d === 2 ? 4 : 12));
    const { patrones } = detectarPatrones(puntos, 'dia');
    expect(patrones.length).toBeGreaterThan(0);
    expect(patrones[0].nombre).toBe('semanal');
    expect(patrones[0].fuerza).toBe('fuerte');
    expect(patrones[0].picos).toContain('viernes');
    expect(patrones[0].picos).toContain('sábado');
    expect(patrones[0].bajas.some((b) => b === 'lunes' || b === 'martes')).toBe(true);
  });

  it('una serie constante no genera patrones ni alerta', () => {
    const puntos = serieDiaria(60, () => 10);
    const { patrones } = detectarPatrones(puntos, 'dia');
    expect(patrones).toEqual([]);
    expect(generarAlerta(puntos, patrones, 'dia', 'unidades').activa).toBe(false);
  });

  it('genera la alerta administrativa cuando se proyecta un pico recurrente', () => {
    // termina un miércoles (t = 125 → día 2026-05-10 + ...), el siguiente pico llega en el ciclo siguiente
    const puntos = serieDiaria(123, (_t, d) => (d === 5 || d === 6 ? 30 : 8));
    const { patrones } = detectarPatrones(puntos, 'dia');
    const alerta = generarAlerta(puntos, patrones, 'dia', 'unidades');
    expect(alerta.activa).toBe(true);
    expect(alerta.mensaje).toBe(MENSAJE_ALERTA);
    expect(alerta.proximoPico).not.toBeNull();
    expect(alerta.proximoPico!.valor).toBeGreaterThan(20);
  });

  it('detecta patrón mensual y lo nombra en lenguaje llano', () => {
    expect(nombrePeriodo(30, 'dia')).toBe('mensual');
    expect(nombrePeriodo(7, 'dia')).toBe('semanal');
    expect(nombrePeriodo(12, 'mes')).toBe('anual');
    expect(nombrePeriodo(24, 'hora')).toBe('diario');
    expect(nombrePeriodo(52, 'semana')).toBe('anual');
  });

  it('señala un cambio de periodicidad entre mitades', () => {
    const y = Array.from({ length: 160 }, (_, t) =>
      t < 80 ? 20 + 8 * Math.cos((2 * Math.PI * t) / 7) : 20 + 8 * Math.cos((2 * Math.PI * t) / 14),
    );
    const puntos = serieDiaria(160, (t) => y[t]);
    const { cambioPeriodicidad } = detectarPatrones(puntos, 'dia');
    expect(cambioPeriodicidad).toContain('cambió');
  });
});


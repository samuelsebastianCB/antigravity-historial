import { Component, OnInit,  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { NuevoEmpleado } from '../nuevo-empleado/nuevo-empleado';
import { EmpleadosService, EmpleadoBackend } from '../../services/empleados.service';

export interface Empleado {
  id: string;
  foto: string;
  nombre: string;
  cargo: string;
  turno: string;
  email: string;
  rfc: string;
  curp?: string;
  calle?: string;
  colonia?: string;
  cp?: string;
  ciudad?: string;
  estado?: string;
  fechaNacimiento?: string;
  fechaIngreso: string;
  roleId?: number;
}

@Component({
  selector: 'app-empleados',
  standalone: true,
  imports: [CommonModule, FormsModule, NuevoEmpleado],
  templateUrl: './empleados.html',
  styleUrl: './empleados.css'
})
export class Empleados implements OnInit {
  busqueda: string = '';
  filtroCargo: string = '';
  filtroFecha: string = '';

  modalVisible: boolean = false;
  modalNuevoVisible: boolean = false;

  empleadoEdicion: Empleado | null = null;
  tempFotoUrl: string = '';

  readonly FOTO_INOVATEX = 'https://res.cloudinary.com/dhcwmbzso/image/upload/v1780031800/VinateriaLaModerna/Empleados/ciombcrhj47rbkxdg445.png';

  empleados: Empleado[] = [];

  constructor(
    private router: Router,
    private empleadosService: EmpleadosService,
    ) {}

  ngOnInit(): void {
    this.cargarEmpleados();
  }

  cargarEmpleados(): void {
    this.empleadosService.obtenerEmpleados().subscribe({
      next: (res) => {
        if (res.status === 'success' && Array.isArray(res.empleados)) {
          this.empleados = res.empleados.map((item: EmpleadoBackend) => {
            const nombreCompleto = [item.FIRST_NAME, item.LAST_NAME_1, item.LAST_NAME_2]
              .filter(Boolean)
              .join(' ')
              .trim();

            return {
              id: String(item.EMPLOYEE_ID),
              foto: item.FOTO_URL || this.FOTO_INOVATEX,
              nombre: nombreCompleto || 'Sin nombre',
              cargo: item.ROLE_NAME || (item.ROLE_ID === 1 ? 'Administrador' : 'Vendedor'),
              turno: item.WORK_SHIFT || 'Matutino',
              email: item.EMAIL || '',
              rfc: item.RFC || '',
              fechaIngreso: item.HIRE_DATE ? item.HIRE_DATE.substring(0, 10) : '',
              fechaNacimiento: item.BIRTH_DATE ? item.BIRTH_DATE.substring(0, 10) : '',
              calle: item.STREET || '',
              colonia: item.NEIGHBORHOOD || '',
              ciudad: item.CITY || '',
              estado: item.STATE || 'Estado de México',
              cp: item.ZIP_CODE || '',
              roleId: item.ROLE_ID
            };
          });
        }
      },
      error: (err) => console.error('Error al cargar empleados:', err)
    });
  }

  empleadosFiltrados(): Empleado[] {
    return this.empleados.filter(emp => {
      const termino = this.busqueda.trim().toLowerCase();
      const coincideTexto = !termino || 
                            emp.id.toLowerCase().includes(termino) || 
                            emp.nombre.toLowerCase().includes(termino);
      const coincideCargo = !this.filtroCargo || emp.cargo === this.filtroCargo;
      const coincideFecha = !this.filtroFecha || emp.fechaIngreso === this.filtroFecha;

      return coincideTexto && coincideCargo && coincideFecha;
    });
  }

  ejecutarBusqueda(): void {}

  abrirModalNuevo(): void {
    this.modalVisible = false;
    this.empleadoEdicion = null;
    this.modalNuevoVisible = true;
  }

  cerrarModalNuevo(): void {
    this.modalNuevoVisible = false;
  }

  alGuardarNuevoEmpleado(nuevo: any): void {
    const roleId = nuevo.cargo === 'Administrador' ? 1 : 2;

    const payload = {
      FIRST_NAME: nuevo.nombre,
      LAST_NAME_1: nuevo.apellido1 || '',
      LAST_NAME_2: nuevo.apellido2 || '',
      EMAIL: nuevo.email,
      WORK_SHIFT: nuevo.turno || 'Matutino',
      RFC: nuevo.rfc || 'XAXX010101000',
      CURP: nuevo.curp || '',
      BIRTH_DATE: nuevo.fechaNacimiento || null,
      HIRE_DATE: nuevo.fechaIngreso || new Date().toISOString().split('T')[0],
      FOTO_URL: this.FOTO_INOVATEX,
      ROLE_ID: roleId,
      PASSWORD: nuevo.password || '123456',
      STREET: nuevo.calle || '',
      NEIGHBORHOOD: nuevo.colonia || '',
      ZIP_CODE: nuevo.cp || '',
      CITY: nuevo.ciudad || '',
      STATE: nuevo.estado || 'Estado de México'
    };

    this.empleadosService.crearEmpleado(payload).subscribe({
      next: (res) => {
        if (res.status === 'success') {
          alert('Empleado registrado exitosamente.');
          this.cargarEmpleados();
          this.cerrarModalNuevo();
        } else {
          alert(res.mensaje || 'Error al registrar el empleado.');
        }
      },
      error: (err) => alert(err.error?.mensaje || 'Error al conectar con el servidor.')
    });
  }

  abrirEditarModal(emp: Empleado): void {
    this.modalNuevoVisible = false;
    this.empleadoEdicion = { ...emp };
    this.tempFotoUrl = emp.foto;
    this.modalVisible = true;
  }

  cerrarModal(): void {
    this.modalVisible = false;
    this.empleadoEdicion = null;
  }

  cerrarModalFuera(event: MouseEvent): void {
    if (event.target === event.currentTarget) {
      this.cerrarModal();
    }
  }

  aplicarFotoUrl(): void {
    if (this.empleadoEdicion && this.tempFotoUrl.trim()) {
      this.empleadoEdicion.foto = this.tempFotoUrl.trim();
    }
  }

  guardarEdicion(): void {
    if (!this.empleadoEdicion) return;

    const partes = this.empleadoEdicion.nombre.trim().split(/\s+/);
    const firstName = partes[0] || '';
    const lastName1 = partes[1] || '';
    const lastName2 = partes.slice(2).join(' ') || '';

    const payload = {
      employee_id: this.empleadoEdicion.id,
      first_name: firstName,
      last_name_1: lastName1,
      last_name_2: lastName2,
      email: this.empleadoEdicion.email,
      turno: this.empleadoEdicion.turno,
      rfc: this.empleadoEdicion.rfc,
      curp: this.empleadoEdicion.curp || '',
      hire_date: this.empleadoEdicion.fechaIngreso,
      birth_date: this.empleadoEdicion.fechaNacimiento,
      calle: this.empleadoEdicion.calle || '',
      colonia: this.empleadoEdicion.colonia || '',
      ciudad: this.empleadoEdicion.ciudad || '',
      estado: this.empleadoEdicion.estado || '',
      cp: this.empleadoEdicion.cp || '',
      foto_url: this.empleadoEdicion.foto,
      role_id: this.empleadoEdicion.cargo === 'Administrador' ? 1 : 2
    };

    this.empleadosService.actualizarEmpleado(payload).subscribe({
      next: (res) => {
        if (res.status === 'success') {
          alert('¡Empleado actualizado correctamente!');
          this.cargarEmpleados();
          this.cerrarModal();
        } else {
          alert(res.mensaje || 'Error al actualizar el empleado.');
        }
      },
      error: (err) => alert(err.error?.mensaje || 'Error al conectar con el backend.')
    });
  }

  eliminarEmpleado(id: string): void {
    if (confirm(`¿Estás seguro de que deseas eliminar al empleado con ID ${id}?`)) {
      this.empleadosService.eliminarEmpleado(id).subscribe({
        next: (res) => {
          if (res.status === 'success') {
            this.cargarEmpleados();
          } else {
            alert(res.mensaje || 'Error al eliminar.');
          }
        },
        error: (err) => alert(err.error?.mensaje || 'Error al eliminar empleado.')
      });
    }
  }

  exportarCSV(): void {
    const encabezados = ['ID', 'Empleado', 'Cargo', 'Turno', 'Email', 'RFC', 'Fecha de Ingreso'];
    const filas = this.empleadosFiltrados().map(e => [
      e.id,
      `"${e.nombre}"`,
      e.cargo,
      e.turno,
      e.email,
      e.rfc,
      e.fechaIngreso
    ]);

    const contenidoCSV = 'data:text/csv;charset=utf-8,' + 
      [encabezados.join(','), ...filas.map(f => f.join(','))].join('\n');

    const uriCodificada = encodeURI(contenidoCSV);
    const link = document.createElement('a');
    link.setAttribute('href', uriCodificada);
    link.setAttribute('download', `Plantilla_Empleados_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  volver(): void {
    this.router.navigate(['/admin']);
  }
}
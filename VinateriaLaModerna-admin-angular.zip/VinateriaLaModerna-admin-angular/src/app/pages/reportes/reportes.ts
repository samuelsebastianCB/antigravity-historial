import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';

interface ArticuloVenta {
  nombre: string;
  cantidad: number;
  subtotal: number;
}

interface Venta {
  folio: string;
  fechaHora: string;
  fechaSolo: string;
  total: number;
  tipo: string;
  comprador?: string;
  motivo?: string;
  articulos: ArticuloVenta[];
}

@Component({
  selector: 'app-reportes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reportes.html',
  styleUrl: './reportes.css'
})
export class Reportes implements OnInit {
  private router = inject(Router);
  private http = inject(HttpClient);
  

  private apiUrl = environment.apiUrl;

  pestanaActiva: 'ventas' | 'internas' = 'ventas';
  fechaFiltro: string = '';
  modalTicketAbierto: boolean = false;
  modalCorteAbierto: boolean = false;
  ventaSeleccionada: Venta | null = null;
  fechaCorteActual: string = '';
  cargando: boolean = false;

  ventas: Venta[] = [];

  ngOnInit(): void {
    this.cargarVentas();
  }

  cargarVentas(): void {
    this.cargando = true;
    this.http.get<any>(`${this.apiUrl}/obtener_ventas.php?tipo=todas`).subscribe({
      next: (res) => {
        this.cargando = false;
        if (res.status === 'success' && Array.isArray(res.ventas)) {
          this.ventas = res.ventas.map((v: any) => {
            const fechaObj = new Date(v.fecha);
            const fechaSolo = !isNaN(fechaObj.getTime())
              ? fechaObj.toISOString().slice(0, 10)
              : '';

            const fechaHora = !isNaN(fechaObj.getTime())
              ? fechaObj.toLocaleString('es-MX', {
                  day: '2-digit',
                  month: '2-digit',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit'
                })
              : v.fecha;

            return {
              folio: String(v.id || v.folio).replace(/^V-/, ''),
              fechaHora: fechaHora,
              fechaSolo: fechaSolo,
              total: Number(v.total) || 0,
              tipo: (v.tipo || v.SALE_TYPE || 'NORMAL').toUpperCase(),
              comprador: v.comprador || v.INTERNAL_BUYER || '',
              motivo: v.motivo || v.INTERNAL_REASON || '',
              articulos: Array.isArray(v.items)
                ? v.items.map((item: any) => ({
                    nombre: item.nombre,
                    cantidad: Number(item.cantidad),
                    subtotal: Number(item.subtotal)
                  }))
                : []
            };
          });
        }
      },
      error: (err) => {
        this.cargando = false;
        console.error('Error al cargar ventas:', err);
      }
    });
  }

  ventasNormalesFiltradas(): Venta[] {
    const lista = this.ventas.filter(v => v.tipo !== 'INTERNA');
    if (!this.fechaFiltro) return lista;
    return lista.filter(v => v.fechaSolo === this.fechaFiltro);
  }

  comprasInternasFiltradas(): Venta[] {
    const lista = this.ventas.filter(v => v.tipo === 'INTERNA');
    if (!this.fechaFiltro) return lista;
    return lista.filter(v => v.fechaSolo === this.fechaFiltro);
  }

  get totalVentas(): number {
    return this.ventasNormalesFiltradas().reduce((acc, v) => acc + v.total, 0);
  }

  get totalTransacciones(): number {
    return this.ventasNormalesFiltradas().length;
  }

  get totalComprasInternas(): number {
    return this.comprasInternasFiltradas().reduce((acc, v) => acc + v.total, 0);
  }

  abrirTicket(venta: Venta) {
    this.ventaSeleccionada = { ...venta };
    this.modalTicketAbierto = true;
  }

  cerrarTicket() {
    this.modalTicketAbierto = false;
    this.ventaSeleccionada = null;
  }

  imprimirTicket() {
    const elemento = document.getElementById('ticket-reimpresion');
    if (!elemento) {
      window.print();
      return;
    }

    const ventanaImpresion = window.open('', '_blank', 'width=420,height=600');
    if (!ventanaImpresion) {
      alert('Por favor habilita las ventanas emergentes (pop-ups) en tu navegador para imprimir.');
      return;
    }

    ventanaImpresion.document.write(`
      <!DOCTYPE html>
      <html lang="es">
        <head>
          <meta charset="utf-8">
          <title>Ticket de Venta #V-${this.ventaSeleccionada?.folio || ''}</title>
          <style>
            @page {
              margin: 4mm;
              size: auto;
            }
            body {
              font-family: 'Courier New', Courier, monospace;
              color: #000;
              margin: 0;
              padding: 0;
              background: #fff;
              display: flex;
              justify-content: center;
            }
            .receipt-paper {
              width: 100%;
              max-width: 320px;
              border: none !important;
              padding: 6px 12px;
              box-sizing: border-box;
            }
            .receipt-header {
              text-align: center;
            }
            .receipt-header h2 {
              margin: 0;
              font-size: 16px;
              font-weight: bold;
            }
            .receipt-header p {
              margin: 3px 0;
              font-size: 12px;
            }
            .receipt-divider {
              text-align: center;
              margin: 6px 0;
              font-size: 12px;
              letter-spacing: -1px;
            }
            .receipt-meta {
              font-size: 12px;
              line-height: 1.4;
            }
            .receipt-table {
              width: 100%;
              border-collapse: collapse;
              margin: 8px 0;
              font-size: 12px;
            }
            .receipt-table th {
              border-bottom: 1px dashed #333;
              padding-bottom: 4px;
            }
            .receipt-table td {
              padding: 4px 0;
            }
            .receipt-total-line {
              display: flex;
              justify-content: space-between;
              font-size: 14px;
              font-weight: bold;
            }
            .receipt-footer-msg {
              text-align: center;
              font-size: 11px;
              margin: 8px 0 0 0;
            }
          </style>
        </head>
        <body>
          <div class="receipt-paper">
            ${elemento.innerHTML}
          </div>
          <script>
            window.onload = function() {
              window.focus();
              window.print();
              window.close();
            };
          </script>
        </body>
      </html>
    `);

    ventanaImpresion.document.close();
  }

  abrirModalCorte() {
    const ahora = new Date();
    this.fechaCorteActual = ahora.toLocaleString('es-MX', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
    this.modalCorteAbierto = true;
  }

  cerrarModalCorte() {
    this.modalCorteAbierto = false;
  }

  exportarCSV() {
    const esInternas = this.pestanaActiva === 'internas';
    const lista = esInternas ? this.comprasInternasFiltradas() : this.ventasNormalesFiltradas();
    const encabezados = esInternas 
      ? ['Folio', 'Fecha y Hora', 'Comprador', 'Motivo', 'Total']
      : ['Folio', 'Fecha y Hora', 'Total'];

    const filas = [
      encabezados,
      ...lista.map(v => esInternas 
        ? [`#V-${v.folio}`, `"${v.fechaHora}"`, `"${v.comprador || ''}"`, `"${v.motivo || ''}"`, `$${v.total.toFixed(2)}`]
        : [`#V-${v.folio}`, `"${v.fechaHora}"`, `$${v.total.toFixed(2)}`])
    ];

    const contenidoCSV = 'data:text/csv;charset=utf-8,' + filas.map(e => e.join(',')).join('\n');
    const enlaceCodificado = encodeURI(contenidoCSV);
    const link = document.createElement('a');
    link.setAttribute('href', enlaceCodificado);
    link.setAttribute('download', `Reporte_${esInternas ? 'Compras_Internas' : 'Ventas'}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  volver() {
    this.router.navigate(['/admin']);
  }
}
import { Component, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-nuevo-empleado',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './nuevo-empleado.html',
  styleUrl: './nuevo-empleado.css',
  encapsulation: ViewEncapsulation.None // <-- ESTA LÍNEA PERMITE QUE EL MODO OSCURO GLOBAL ENTRE DIRECTO
})
export class NuevoEmpleado {
  @Output() onCerrar = new EventEmitter<void>();
  @Output() onGuardado = new EventEmitter<any>();

  empleado: any = {
    nombre: '',
    apellido1: '',
    apellido2: '',
    calle: '',
    colonia: '',
    cp: '',
    ciudad: '',
    estado: '',
    fechaNacimiento: '',
    fechaIngreso: '',
    curp: '',
    rfc: '',
    turno: 'Matutino',
    cargo: 'Vendedor',
    email: '',
    emailConf: '',
    password: '',
    passwordConf: ''
  };

  cancelar() {
    this.onCerrar.emit();
  }

  completarRegistro() {
    this.onGuardado.emit(this.empleado);
  }
}
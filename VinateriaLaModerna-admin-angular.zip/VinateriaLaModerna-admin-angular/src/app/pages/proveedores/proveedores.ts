import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ProveedoresService } from '../../services/proveedores.service';

interface ArticuloPedido {
  producto_id?: number;
  producto: string;
  cantidad: number;
  subtotal: number;
}

interface Pedido {
  folio: string;
  fecha: string;
  proveedor: string;
  total: number;
  estado: 'Pendiente' | 'Recibido';
  articulos: ArticuloPedido[];
  expandido?: boolean;
}

interface Proveedor {
  id: number;
  nombre: string;
  telefono: string;
  email: string;
}

@Component({
  selector: 'app-proveedores',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './proveedores.html',
  styleUrl: './proveedores.css'
})
export class Proveedores implements OnInit {
  private router = inject(Router);
  private proveedoresService = inject(ProveedoresService);
  

  modalCompraAbierto: boolean = false;
  modalProveedorAbierto: boolean = false;
  filtroProveedor: string = '';

  pedidos: Pedido[] = [];
  proveedores: Proveedor[] = [];

  nuevaCompra = {
    folio: null as number | null,
    proveedor: '',
    estado: 'Pendiente' as 'Pendiente' | 'Recibido',
    items: [
      { producto: '', cantidad: 1, subtotal: null as number | null }
    ]
  };

  nuevoProveedor: Proveedor = {
    id: 0,
    nombre: '',
    telefono: '',
    email: ''
  };

  constructor() {}

  ngOnInit(): void {
    this.cargarProveedores();
    this.cargarCompras();
  }

  cargarProveedores(): void {
    this.proveedoresService.obtenerProveedores().subscribe({
      next: (res) => {
        if (res.status === 'success' && Array.isArray(res.proveedores)) {
          this.proveedores = res.proveedores.map((item: any) => ({
            id: Number(item.SUPPLIER_ID || item.id),
            nombre: item.COMPANY_NAME || item.nombre || 'Sin nombre',
            telefono: item.PHONE || item.telefono || '',
            email: item.EMAIL || item.email || ''
          }));
        }
      },
      error: (err) => console.error('Error al cargar proveedores:', err)
    });
  }

  cargarCompras(): void {
    this.proveedoresService.obtenerCompras().subscribe({
      next: (res) => {
        if (res.status === 'success' && Array.isArray(res.compras)) {
          this.pedidos = res.compras.map((c: any) => ({
            folio: String(c.folio),
            fecha: c.fecha,
            proveedor: c.proveedor,
            total: Number(c.total) || 0,
            estado: c.estado || 'Pendiente',
            articulos: Array.isArray(c.articulos) ? c.articulos : [],
            expandido: false
          }));
        }
      },
      error: (err) => console.error('Error al cargar compras:', err)
    });
  }

  toggleDetalle(pedido: Pedido): void {
  pedido.expandido = !pedido.expandido;
 // <-- Obliga a Angular a renderizar el acordeón de inmediato
}

  abrirModalCompra() {
    this.modalCompraAbierto = true;
  }

  cerrarModalCompra() {
    this.modalCompraAbierto = false;
  }

  abrirModalProveedor() {
    this.nuevoProveedor = { id: 0, nombre: '', telefono: '', email: '' };
    this.modalProveedorAbierto = true;
  }

  cerrarModalProveedor() {
    this.modalProveedorAbierto = false;
  }

  agregarFilaProducto() {
    this.nuevaCompra.items.push({ producto: '', cantidad: 1, subtotal: null });
  }

  removerFilaProducto(index: number) {
    if (this.nuevaCompra.items.length > 1) {
      this.nuevaCompra.items.splice(index, 1);
    }
  }

  calcularTotalCompra(): number {
    return this.nuevaCompra.items.reduce((acc, item) => acc + (Number(item.subtotal) || 0), 0);
  }

  proveedoresFiltrados(): Proveedor[] {
    if (!this.filtroProveedor.trim()) return this.proveedores;
    return this.proveedores.filter(p =>
      p.nombre.toLowerCase().includes(this.filtroProveedor.toLowerCase())
    );
  }

  procesarCompra() {
    if (!this.nuevaCompra.folio || !this.nuevaCompra.proveedor) {
      alert('Por favor complete el folio y seleccione el proveedor.');
      return;
    }

    const provSeleccionado = this.proveedores.find(p => p.nombre === this.nuevaCompra.proveedor);
    if (!provSeleccionado) {
      alert('Proveedor inválido o no seleccionado.');
      return;
    }

    const articulosValidos = this.nuevaCompra.items.map(it => ({
      producto_id: 1,
      producto: it.producto || 'Producto Suministro',
      cantidad: Number(it.cantidad) || 1,
      subtotal: Number(it.subtotal) || 0
    }));

    const payload = {
      folio: Number(this.nuevaCompra.folio),
      supplier_id: provSeleccionado.id,
      fecha: new Date().toISOString().split('T')[0],
      estado: this.nuevaCompra.estado,
      total: this.calcularTotalCompra(),
      items: articulosValidos
    };

    this.proveedoresService.registrarCompra(payload).subscribe({
      next: (res) => {
        if (res.status === 'success') {
          alert(`¡Orden de compra #${payload.folio} registrada en la base de datos!`);
          this.cargarCompras();
          this.cerrarModalCompra();

          this.nuevaCompra = {
            folio: null,
            proveedor: '',
            estado: 'Pendiente',
            items: [{ producto: '', cantidad: 1, subtotal: null }]
          };
        } else {
          alert(res.mensaje || 'Error al procesar la compra.');
        }
      },
      error: (err) => {
        console.error(err);
        alert(err.error?.mensaje || 'Error al conectar con el backend de compras.');
      }
    });
  }

  guardarProveedor() {
    if (!this.nuevoProveedor.nombre.trim()) {
      alert('Por favor ingrese la razón social o nombre de la empresa proveedora.');
      return;
    }

    const payload = {
      SUPPLIER_ID: this.nuevoProveedor.id ? Number(this.nuevoProveedor.id) : null,
      COMPANY_NAME: this.nuevoProveedor.nombre.trim(),
      PHONE: this.nuevoProveedor.telefono ? this.nuevoProveedor.telefono.trim() : '',
      EMAIL: this.nuevoProveedor.email ? this.nuevoProveedor.email.trim() : ''
    };

    this.proveedoresService.registrarProveedor(payload).subscribe({
      next: (res) => {
        if (res.status === 'success') {
          alert(`¡Proveedor "${this.nuevoProveedor.nombre}" registrado con éxito!`);
          this.cargarProveedores();
          this.cerrarModalProveedor();
          this.nuevoProveedor = { id: 0, nombre: '', telefono: '', email: '' };
        } else {
          alert(res.mensaje || 'Error al guardar el proveedor.');
        }
      },
      error: (err) => {
        console.error(err);
        alert(err.error?.mensaje || 'Error al conectar con el servidor.');
      }
    });
  }

  volver() {
    this.router.navigate(['/admin']);
  }
}
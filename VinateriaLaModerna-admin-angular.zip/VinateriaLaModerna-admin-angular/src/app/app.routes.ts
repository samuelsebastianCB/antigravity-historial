import { Routes } from '@angular/router';
import { Login } from './pages/login/login';
import { Admin } from './pages/admin/admin';
import { PuntoVenta } from './pages/punto-venta/punto-venta';
import { Inventario } from './pages/inventario/inventario';
import { NuevoProducto } from './pages/nuevo-producto/nuevo-producto';
import { EditarProducto } from './pages/editar-producto/editar-producto';
import { Proveedores } from './pages/proveedores/proveedores';
import { Reportes } from './pages/reportes/reportes';
import { Empleados } from './pages/empleados/empleados';
import { NuevoEmpleado } from './pages/nuevo-empleado/nuevo-empleado';
import { FourierComponent } from './pages/fourier/fourier';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: Login },
  { path: 'admin', component: Admin, canActivate: [authGuard] },
  { path: 'punto-venta', component: PuntoVenta, canActivate: [authGuard] },
  { path: 'inventario', component: Inventario, canActivate: [authGuard] },
  { path: 'nuevo-producto', component: NuevoProducto, canActivate: [authGuard] },
  { path: 'editar-producto', component: EditarProducto, canActivate: [authGuard] },
  { path: 'proveedores', component: Proveedores, canActivate: [authGuard] },
  { path: 'reportes', component: Reportes, canActivate: [authGuard] },
  { path: 'fourier', component: FourierComponent, canActivate: [authGuard] },
  { path: 'empleados', component: Empleados, canActivate: [authGuard] },
  { path: 'nuevo-empleado', component: NuevoEmpleado, canActivate: [authGuard] },
  { path: '**', redirectTo: 'login' }
];
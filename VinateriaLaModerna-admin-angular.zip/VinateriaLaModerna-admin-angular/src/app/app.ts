import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ThemeService } from './services/theme.service';
import { SquishSwitchComponent } from './shared/squish-switch.component';
import { CartMenuComponent } from './shared/cart-menu.component';
import { DynamicIslandNavComponent } from './shared/dynamic-island-nav.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, SquishSwitchComponent, CartMenuComponent, DynamicIslandNavComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  constructor(public themeService: ThemeService) {}

  toggleTema() {
    this.themeService.toggleTheme();
  }

  // Obtenemos el estado para el switch
  get isDarkMode(): boolean {
    return this.themeService.isDarkMode();
  }

  setDarkMode(value: boolean) {
    if (value !== this.themeService.isDarkMode()) {
      this.themeService.toggleTheme();
    }
  }
}
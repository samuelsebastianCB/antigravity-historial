import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-squish-switch',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div 
      class="squish-switch" 
      [class.checked]="checked"
      [class.disabled]="disabled"
      [style.--track-color]="trackColor"
      [style.--track-on-color]="trackOnColor"
      [style.--thumb-color]="thumbColor"
      [style.--thumb-on-color]="thumbOnColor"
      [style.--switch-width.px]="width"
      [style.--switch-height.px]="height"
      [style.width.px]="width"
      [style.height.px]="height"
      [style.border-radius.px]="radius"
      (click)="toggle()"
    >
      <div 
        class="thumb"
        [style.width.px]="height - 8"
        [style.height.px]="height - 8"
        [style.border-radius.px]="radius - 4"
      ></div>
    </div>
  `,
  styles: [`
    .squish-switch {
      position: relative;
      cursor: pointer;
      background-color: var(--track-color);
      transition: background-color 0.3s ease, transform 0.2s ease;
      display: flex;
      align-items: center;
      padding: 4px;
      box-sizing: border-box;
      box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
    }
    .squish-switch:hover {
      transform: scale(1.035);
    }
    .squish-switch.checked {
      background-color: var(--track-on-color);
    }
    .squish-switch.disabled {
      opacity: 0.5;
      cursor: not-allowed;
      transform: none !important;
    }
    .thumb {
      position: absolute;
      left: 4px;
      background-color: var(--thumb-color);
      transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275), 
                  background-color 0.3s ease, 
                  width 0.2s ease, 
                  left 0.2s ease;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    
    /* Efecto "Squish" al presionar (se estira) */
    .squish-switch:active:not(.disabled) .thumb {
      width: calc(var(--switch-height) + 8px) !important;
    }
    
    /* Estado encendido */
    .squish-switch.checked .thumb {
      background-color: var(--thumb-on-color);
      /* Se mueve a la derecha: Ancho total - ancho del thumb - (padding * 2) */
      transform: translateX(calc(var(--switch-width) - var(--switch-height)));
    }

    /* Corrección del squish cuando está encendido (estirarse hacia la izquierda) */
    .squish-switch.checked:active:not(.disabled) .thumb {
      transform: translateX(calc(var(--switch-width) - var(--switch-height) - 16px));
    }
  `]
})
export class SquishSwitchComponent {
  @Input() checked = false;
  @Input() trackColor = '#27272a';
  @Input() trackOnColor = '#f5f5f5';
  @Input() thumbColor = '#4e4e51';
  @Input() thumbOnColor = '#27272a';
  @Input() width = 76;
  @Input() height = 38;
  @Input() radius = 19;
  @Input() disabled = false;
  
  @Output() checkedChange = new EventEmitter<boolean>();

  toggle() {
    if (!this.disabled) {
      this.checked = !this.checked;
      this.checkedChange.emit(this.checked);
    }
  }
}


import { Component, inject, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule, NavigationEnd } from '@angular/router';
import gsap from 'gsap';

@Component({
  selector: 'app-dynamic-island-nav',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    @if (mostrarNav) {
      <div class="island">
        <div class="island-logo--cont">
          <img class="island-logo" src="https://res.cloudinary.com/dhcwmbzso/image/upload/q_auto/f_auto/v1779417085/Vinater%C3%ADa_La_Moderna_n3xvsj.png" alt="" />
        </div>
        <button class="menu-btn" id="menuToggle" [attr.aria-expanded]="isOpen" (click)="toggleMenu()">
          <div class="button-cont">
            <svg id="menuIcon" width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <line class="bar bar-top" x1="2" y1="5" x2="14" y2="5" stroke="#BBBAA6" stroke-width="1.5" stroke-linecap="round" />
              <line class="bar bar-mid" x1="2" y1="8" x2="14" y2="8" stroke="#BBBAA6" stroke-width="1.5" stroke-linecap="round" />
              <line class="bar bar-bot" x1="2" y1="11" x2="14" y2="11" stroke="#BBBAA6" stroke-width="1.5" stroke-linecap="round" />
            </svg>
          </div>
        </button>
      </div>

      <div class="menu-overlay" id="menu-overlay" (click)="toggleMenu()" role="dialog" aria-modal="true" aria-label="Navigation menu">
        <div class="menu-backdrop"></div>
        <div class="menu-panel" (click)="$event.stopPropagation()">
          <nav>
            <a routerLink="/punto-venta" class="menu-link" (click)="toggleMenu()">
              <span>Punto de Venta</span><span class="link-num">01</span>
            </a>
            <a routerLink="/inventario" class="menu-link" (click)="toggleMenu()">
              <span>Inventario de Vinos</span><span class="link-num">02</span>
            </a>
            <a routerLink="/proveedores" class="menu-link" (click)="toggleMenu()">
              <span>Compras y Proveedores</span><span class="link-num">03</span>
            </a>
            <a routerLink="/reportes" class="menu-link" (click)="toggleMenu()">
              <span>Reportes y Registros</span><span class="link-num">04</span>
            </a>
            <a routerLink="/empleados" class="menu-link" (click)="toggleMenu()">
              <span>Gestión de Empleados</span><span class="link-num">05</span>
            </a>
            <a href="http://localhost:4201/" class="menu-link" style="border-top: 1px solid var(--color-surface25);">
              <span>Ir a Tienda de Clientes</span><span class="link-num">↗</span>
            </a>
            <a class="menu-link logout-link" (click)="cerrarSesion()">
              <span>Cerrar Sesión</span><span class="link-num" style="color: #ff4757;">X</span>
            </a>
          </nav>
        </div>
      </div>
    }
  `,
  styles: [`
    :host {
      --color-grey-dark: #222;
      --color-surface75: #eee;
      --color-surface50: #aaa;
      --color-surface25: #555;
      --color-shockingly-green: #D4AF88; /* Adaptado al color dorado del admin */
    }

    /* ── ISLAND ── */
    .island {
      position: fixed;
      top: 1.25rem; left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.5rem;
      background: var(--color-grey-dark);
      border: solid grey 1.5px;
      border-radius: 99px;
      white-space: nowrap;
      width: 50px; /* Base width before GSAP animates it to expandedWidth */
      overflow: hidden;
    }

    .island-logo--cont {
      position: relative;
      width: 0px;
      height: 20px;
      pointer-events: none;
    }

    .island-logo {
      position: absolute;
      width: 20px;
      flex-shrink: 0;
      opacity: 0;
      margin-left: 0.75rem;
      border-radius: 50%;
    }

    .menu-btn {
      width: 100%; height: 34px;
      margin: 0; padding: 0;
      background: transparent;
      border-radius: 50%;
      border: none; cursor: pointer;
      display: flex; align-items: center; justify-content: flex-end;
      flex-shrink: 0;
    }

    .button-cont {
      width: 34px; height: 34px;
      display: flex; align-items: center; justify-content: center;
    }

    .menu-btn:focus-visible { outline: 2px solid var(--color-shockingly-green); outline-offset: 3px; }
    .menu-btn svg { overflow: visible; display: block; }

    /* ── OVERLAY ── */
    .menu-overlay {
      position: fixed; inset: 0;
      z-index: 900;
      pointer-events: none;
    }
    .menu-backdrop {
      position: absolute; inset: 0;
      background: rgba(14,16,15,0.88);
      backdrop-filter: blur(3px);
      -webkit-backdrop-filter: blur(3px);
      opacity: 0;
    }

    /* ── PANEL ── */
    .menu-panel {
      border: solid grey 1.5px;
      position: absolute;
      visibility: hidden;
      top: 5rem; left: 50%;
      background: var(--color-grey-dark);
      border-radius: 18px;
      padding: 0.375rem;
      width: 90vw; max-width: 400px;
      transform: translateX(-50%);
    }

    /* ── LINKS ── */
    nav {
      display: flex;
      flex-direction: column;
    }
    .menu-link {
      display: flex; align-items: center; justify-content: space-between;
      padding: 0.8rem 1rem;
      border-radius: 10px;
      text-decoration: none;
      color: var(--color-surface75);
      font-weight: 500; font-size: 1.1rem; line-height: 1;
      cursor: pointer;
    }

    .menu-link + .menu-link { border-top: 1px solid var(--color-surface25); border-radius: 0; }
    .menu-link:first-child { border-radius: 10px 10px 0 0; }
    .menu-link:last-child  { border-radius: 0 0 10px 10px; }
    .menu-link:only-child  { border-radius: 10px; }
    .menu-link:hover { color: var(--color-shockingly-green); }
    .menu-link:focus-visible { outline: 2px solid var(--color-shockingly-green); outline-offset: -2px; border-radius: 10px; }

    .link-num {
      font-size: 0.75rem;
      color: var(--color-surface50);
      transition: color .15s;
    }
    .menu-link:hover .link-num { color: #fff; }
    
    .logout-link { margin-top: 10px; }
    .logout-link:hover { color: #ff4757; }
  `]
})
export class DynamicIslandNavComponent implements OnInit, OnDestroy {
  mostrarNav = false;
  isOpen = false;
  tl: any;
  private router = inject(Router);

  ngOnInit() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        const wasShowing = this.mostrarNav;
        this.mostrarNav = !event.urlAfterRedirects.includes('/login');
        if (this.isOpen) {
           this.toggleMenu();
        }
        if (this.mostrarNav && !wasShowing) {
           setTimeout(() => this.initGsap(), 100);
        }
      }
    });
    
    // Init si arranca logueado
    if (!this.router.url.includes('/login')) {
      this.mostrarNav = true;
      setTimeout(() => this.initGsap(), 100);
    }
  }

  ngOnDestroy() {
    if (this.tl) {
      this.tl.kill();
    }
  }

  initGsap() {
    if (this.tl) { this.tl.revert(); }
    const expandedWidth = Math.min(window.innerWidth * 0.9, 400);
    
    // The exact timeline logic requested by the user
    this.tl = gsap.timeline({ paused: true })
      .set('.menu-overlay', { pointerEvents: 'auto' })
      .to('.island', { width: expandedWidth, duration: 0.8, ease: 'back.out(2)', easeReverse: 'power2.out' }, 0)
      .to('.island-logo', { opacity: 1, rotation: 180, duration: 0.5, ease: 'back.out', easeReverse: 'power4.out' }, 0.12)
      .to('.bar-mid', { opacity: 0, duration: 0.15, ease: 'power2.in', easeReverse: true }, 0)
      .to('.bar-top', { attr: { x1: 3, y1: 3, x2: 13, y2: 13 }, duration: 0.28, ease: 'power3.inOut' }, 0)
      .to('.bar-bot', { attr: { x1: 13, y1: 3, x2: 3, y2: 13 }, duration: 0.28, ease: 'power3.inOut' }, 0)
      .to('.menu-backdrop', { opacity: 1, duration: 0.3, ease: 'power2.out' }, 0)
      .from('.menu-panel', { autoAlpha: 0, yPercent: -10, scale: 0.6, duration: 0.8, transformOrigin: 'top center', ease: 'back.out(2)', easeReverse: 'power3.out' }, 0.1)
      .from('.menu-link', { opacity: 0, y: 6, duration: 0.32, ease: 'power2.out', easeReverse: true, stagger: 0.05 }, 0.22);
  }

  toggleMenu() {
    if (!this.tl) return; // Not initialized yet
    
    this.isOpen = !this.isOpen;
    if (this.isOpen) {
      this.tl.timeScale(1).play();
    } else {
      this.tl.eventCallback('onReverseComplete', () => gsap.set('.menu-overlay', { pointerEvents: 'none' }));
      this.tl.timeScale(1.5).reverse();
    }
  }

  cerrarSesion() {
    this.toggleMenu();
    localStorage.removeItem('admin_sesion');
    this.router.navigate(['/login']);
  }
}

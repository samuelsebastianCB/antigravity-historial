import { Component, inject, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { trigger, style, animate, transition, query, stagger } from '@angular/animations';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-cart-menu',
  standalone: true,
  imports: [CommonModule],
  template: `
    <!-- Botón Flotante del Carrito -->
    <div class="cart-fab" [class.bounce]="cartService.itemAdded() > 0" (click)="toggleMenu()">
      <div class="cart-icon">🛒</div>
      @if (cartService.totalItems() > 0) {
        <span class="badge">{{ cartService.totalItems() }}</span>
      }
    </div>

    <!-- Menú Staggered -->
    @if (menuOpen) {
      <div class="cart-backdrop" (click)="cerrarMenu()"></div>
      <div class="staggered-menu" @slideIn>
        <div class="menu-header">
          <h3>Carrito de Compras</h3>
          <button class="close-btn" (click)="cerrarMenu()">✕</button>
        </div>

        <div class="menu-body" @staggerList>
          @if (cartService.items().length === 0) {
            <p class="empty-msg">Tu carrito está vacío.</p>
          }
          @for (item of cartService.items(); track item.producto.id; let idx = $index) {
            <div class="cart-item">
              <div class="item-info">
                <h4>{{ item.producto.nombre }}</h4>
                <div class="price">\${{ item.producto.precio | number:'1.2-2' }}</div>
              </div>
              <div class="qty-controls">
                <button (click)="cartService.decrementarCantidad(idx)">-</button>
                <span>{{ item.cantidad }}</span>
                <button (click)="cartService.incrementarCantidad(item)">+</button>
              </div>
              <button class="del-btn" (click)="cartService.eliminarItem(idx)">🗑️</button>
            </div>
          }
        </div>

        @if (cartService.items().length > 0) {
          <div class="menu-footer" @fadeIn>
            <div class="total-row">
              <span>Total:</span>
              <strong>\${{ cartService.totalVenta() | number:'1.2-2' }}</strong>
            </div>
            <!-- Idealmente, este botón navegaría al punto de venta -->
            <button class="checkout-btn" (click)="irAPagar()">Ir a Pagar</button>
          </div>
        }
      </div>
    }
  `,
  styles: [`
    /* Botón Flotante */
    .cart-fab {
      position: fixed;
      bottom: 30px;
      right: 30px;
      width: 60px;
      height: 60px;
      background: #5227FF;
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      box-shadow: 0 4px 12px rgba(82, 39, 255, 0.4);
      cursor: pointer;
      z-index: 9999;
      transition: transform 0.2s;
    }
    .cart-fab:hover {
      transform: scale(1.05);
    }
    .cart-icon {
      font-size: 1.8rem;
    }
    .badge {
      position: absolute;
      top: -5px;
      right: -5px;
      background: #ff6b6b;
      color: white;
      font-weight: bold;
      font-size: 0.8rem;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      border: 2px solid white;
    }
    .bounce {
      animation: bounce 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    @keyframes bounce {
      0%   { transform: scale(1); }
      50%  { transform: scale(1.3); }
      100% { transform: scale(1); }
    }

    /* Backdrop */
    .cart-backdrop {
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(0,0,0,0.5);
      z-index: 9998;
    }

    /* Menú Lateral */
    .staggered-menu {
      position: fixed;
      top: 0;
      right: 0;
      width: 350px;
      height: 100vh;
      background: #1a1a1a;
      color: white;
      z-index: 10000;
      display: flex;
      flex-direction: column;
      box-shadow: -5px 0 15px rgba(0,0,0,0.3);
    }
    .menu-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px;
      border-bottom: 1px solid #333;
    }
    .menu-header h3 { margin: 0; font-size: 1.2rem; }
    .close-btn { background: none; border: none; color: white; font-size: 1.5rem; cursor: pointer; }
    
    .menu-body {
      flex: 1;
      overflow-y: auto;
      padding: 20px;
    }
    .empty-msg { text-align: center; color: #888; margin-top: 50px; }
    
    .cart-item {
      display: flex;
      align-items: center;
      background: #27272a;
      padding: 15px;
      border-radius: 10px;
      margin-bottom: 15px;
      gap: 10px;
    }
    .item-info { flex: 1; }
    .item-info h4 { margin: 0 0 5px 0; font-size: 0.95rem; }
    .price { color: #B497CF; font-weight: bold; }
    
    .qty-controls {
      display: flex;
      align-items: center;
      gap: 10px;
      background: #1a1a1a;
      padding: 5px 10px;
      border-radius: 20px;
    }
    .qty-controls button {
      background: none; border: none; color: white; cursor: pointer; font-size: 1.2rem;
    }
    .del-btn { background: none; border: none; cursor: pointer; font-size: 1.2rem; opacity: 0.7; }
    .del-btn:hover { opacity: 1; }

    .menu-footer {
      padding: 20px;
      background: #27272a;
      border-top: 1px solid #333;
    }
    .total-row {
      display: flex;
      justify-content: space-between;
      font-size: 1.2rem;
      margin-bottom: 15px;
    }
    .checkout-btn {
      width: 100%;
      padding: 15px;
      background: #5227FF;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.2s;
    }
    .checkout-btn:hover {
      background: #6a44ff;
    }
  `],
  animations: [
    trigger('slideIn', [
      transition(':enter', [
        style({ transform: 'translateX(100%)' }),
        animate('0.4s cubic-bezier(0.25, 1, 0.5, 1)', style({ transform: 'translateX(0)' }))
      ]),
      transition(':leave', [
        animate('0.3s ease-in', style({ transform: 'translateX(100%)' }))
      ])
    ]),
    trigger('staggerList', [
      transition('* => *', [
        query(':enter', [
          style({ opacity: 0, transform: 'translateY(20px)' }),
          stagger('100ms', [
            animate('0.4s cubic-bezier(0.25, 1, 0.5, 1)', style({ opacity: 1, transform: 'translateY(0)' }))
          ])
        ], { optional: true })
      ])
    ]),
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('0.5s 0.3s ease', style({ opacity: 1 }))
      ])
    ])
  ]
})
export class CartMenuComponent {
  cartService = inject(CartService);
  menuOpen = false;

  private lastAdded = 0;

  constructor() {
    // Escuchar cambios en itemAdded para reiniciar la clase de animación
    // angular signals effect could be used, but simple is fine
  }

  toggleMenu() {
    this.menuOpen = !this.menuOpen;
  }

  cerrarMenu() {
    this.menuOpen = false;
  }

  irAPagar() {
    // Redirige al POS para facturar
    this.cerrarMenu();
    window.location.hash = '#/punto-venta';
  }
}


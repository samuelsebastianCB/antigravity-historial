import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface ProveedorBackend {
  SUPPLIER_ID?: number;
  COMPANY_NAME?: string;
  PHONE?: string;
  EMAIL?: string;
}

export interface RespuestaApiProveedores {
  status: 'success' | 'error';
  proveedores?: any[];
  compras?: any[];
  mensaje?: string;
  supplier_id?: number;
}

@Injectable({
  providedIn: 'root'
})
export class ProveedoresService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  obtenerProveedores(): Observable<RespuestaApiProveedores> {
    return this.http.get<RespuestaApiProveedores>(`${this.apiUrl}/obtener_proveedores.php`);
  }

  registrarProveedor(datos: any): Observable<RespuestaApiProveedores> {
    return this.http.post<RespuestaApiProveedores>(`${this.apiUrl}/registrar_proveedor.php`, datos);
  }

  obtenerCompras(): Observable<RespuestaApiProveedores> {
    return this.http.get<RespuestaApiProveedores>(`${this.apiUrl}/obtener_compras.php`);
  }

  registrarCompra(datos: any): Observable<RespuestaApiProveedores> {
    return this.http.post<RespuestaApiProveedores>(`${this.apiUrl}/registrar_compra.php`, datos);
  }
}
import { Injectable, signal, computed } from '@angular/core';

export interface ProductoCart {
  id: number;
  nombre: string;
  precio: number;
  stock: number;
  foto?: string;
}

export interface ItemTicket {
  producto: ProductoCart;
  cantidad: number;
}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  items = signal<ItemTicket[]>([]);
  
  // Agregamos un "trigger" para la animación cuando se añade algo nuevo
  itemAdded = signal<number>(0);

  totalVenta = computed(() => {
    return this.items().reduce((acc, item) => acc + (item.producto.precio * item.cantidad), 0);
  });

  totalItems = computed(() => {
    return this.items().reduce((acc, item) => acc + item.cantidad, 0);
  });

  agregarAlTicket(prod: ProductoCart) {
    if (prod.stock <= 0) return;

    this.items.update(actuales => {
      const index = actuales.findIndex(i => i.producto.id === prod.id);
      if (index > -1) {
        if (actuales[index].cantidad < prod.stock) {
          const nuevos = [...actuales];
          nuevos[index] = { ...nuevos[index], cantidad: nuevos[index].cantidad + 1 };
          return nuevos;
        }
        return actuales; // No hay suficiente stock
      }
      return [...actuales, { producto: prod, cantidad: 1 }];
    });
    
    // Disparamos la animación
    this.itemAdded.update(n => n + 1);
  }

  incrementarCantidad(item: ItemTicket) {
    if (item.cantidad < item.producto.stock) {
      this.items.update(actuales => 
        actuales.map(i => i.producto.id === item.producto.id 
          ? { ...i, cantidad: i.cantidad + 1 } 
          : i)
      );
    }
  }

  decrementarCantidad(idx: number) {
    this.items.update(actuales => {
      const nuevos = [...actuales];
      if (nuevos[idx].cantidad > 1) {
        nuevos[idx] = { ...nuevos[idx], cantidad: nuevos[idx].cantidad - 1 };
      } else {
        nuevos.splice(idx, 1);
      }
      return nuevos;
    });
  }

  eliminarItem(idx: number) {
    this.items.update(actuales => {
      const nuevos = [...actuales];
      nuevos.splice(idx, 1);
      return nuevos;
    });
  }

  limpiarTicket() {
    this.items.set([]);
  }
}


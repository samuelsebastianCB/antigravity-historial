import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export interface Producto {
  id: number;
  nombre: string;
  descripcion: string;
  stockMin: number;
  stockMax: number;
  stock: number;
  precioCompra: number;
  precioVenta: number;
  caducidad: string;
  estado: string;
  foto: string | null;
  categoria?: string;
}

export interface RespuestaApi {
  status: 'success' | 'error';
  productos?: Producto[];
  mensaje?: string;
  id?: number;
  product_id?: number;
}

@Injectable({
  providedIn: 'root'
})
export class InventarioService {
  private http = inject(HttpClient);
  private apiUrl = environment.apiUrl;

  obtenerProductos(): Observable<RespuestaApi> {
    return this.http.get<any>(`${this.apiUrl}/obtener_productos.php`).pipe(
      map(res => {
        if (res.status === 'success' && Array.isArray(res.productos)) {
          const productosNormalizados: Producto[] = res.productos.map((p: any) => ({
            id: Number(p.id ?? p.PRODUCT_ID ?? 0),
            nombre: p.nombre ?? p.PRODUCT_NAME ?? p.NAME ?? 'Sin nombre',
            descripcion: p.descripcion ?? p.DESCRIPTION ?? '',
            stockMin: Number(p.stockMin ?? p.MIN_STOCK ?? 0),
            stockMax: Number(p.stockMax ?? p.MAX_STOCK ?? 0),
            stock: Number(p.stock ?? p.CURRENT_STOCK ?? p.STOCK ?? 0),
            precioCompra: Number(p.precioCompra ?? p.PURCHASE_PRICE ?? 0),
            precioVenta: Number(p.precioVenta ?? p.SALE_PRICE ?? p.PRICE ?? p.RETAIL_PRICE ?? 0),
            caducidad: p.caducidad ?? p.EXPIRY_DATE ?? p.EXPIRATION_DATE ?? '',
            estado: p.estado ?? p.STATUS ?? p.PRODUCT_STATUS ?? 'Activo',
            foto: p.foto ?? p.IMAGE ?? p.FOTO_URL ?? null,
            categoria: p.categoria ?? p.CATEGORY ?? 'Sin categoría'
          }));
          return { ...res, productos: productosNormalizados };
        }
        return res;
      })
    );
  }

  crearProducto(datos: any): Observable<RespuestaApi> {
    const payload = {
      PRODUCT_NAME: datos.nombre || datos.PRODUCT_NAME || '',
      DESCRIPTION: datos.descripcion || datos.DESCRIPTION || 'Sin descripción',
      CURRENT_STOCK: Number(datos.stock ?? datos.existencias ?? datos.CURRENT_STOCK ?? 0),
      MIN_STOCK: Number(datos.stockMin ?? datos.MIN_STOCK ?? 0),
      MAX_STOCK: Number(datos.stockMax ?? datos.MAX_STOCK ?? 100),
      PURCHASE_PRICE: Number(datos.precioCompra ?? datos.PURCHASE_PRICE ?? 0),
      RETAIL_PRICE: Number(datos.precioVenta ?? datos.precio ?? datos.RETAIL_PRICE ?? 0),
      EXPIRATION_DATE: datos.caducidad || datos.fechaCaducidad || datos.EXPIRATION_DATE || '2099-12-31',
      PRODUCT_STATUS: datos.estado || datos.estatus || datos.PRODUCT_STATUS || 'Activo (Disponible)',
      FOTO_URL: datos.foto || datos.fotoUrl || datos.FOTO_URL || null,
      CATEGORY: datos.categoria || datos.CATEGORY || ''
    };
    return this.http.post<RespuestaApi>(`${this.apiUrl}/guardar_producto.php`, payload);
  }

  actualizarProducto(datos: any): Observable<RespuestaApi> {
    const payload = {
      PRODUCT_ID: Number(datos.id || datos.PRODUCT_ID),
      PRODUCT_NAME: datos.nombre || datos.PRODUCT_NAME || '',
      DESCRIPTION: datos.descripcion || datos.DESCRIPTION || 'Sin descripción',
      CURRENT_STOCK: Number(datos.stock ?? datos.existencias ?? datos.CURRENT_STOCK ?? 0),
      MIN_STOCK: Number(datos.stockMin ?? datos.MIN_STOCK ?? 0),
      MAX_STOCK: Number(datos.stockMax ?? datos.MAX_STOCK ?? 100),
      PURCHASE_PRICE: Number(datos.precioCompra ?? datos.PURCHASE_PRICE ?? 0),
      RETAIL_PRICE: Number(datos.precioVenta ?? datos.precio ?? datos.RETAIL_PRICE ?? 0),
      EXPIRATION_DATE: datos.caducidad || datos.fechaCaducidad || datos.EXPIRATION_DATE || '2099-12-31',
      PRODUCT_STATUS: datos.estado || datos.estatus || datos.PRODUCT_STATUS || 'Activo (Disponible)',
      FOTO_URL: datos.foto || datos.fotoUrl || datos.FOTO_URL || null,
      CATEGORY: datos.categoria || datos.CATEGORY || ''
    };
    return this.http.post<RespuestaApi>(`${this.apiUrl}/guardar_producto.php`, payload);
  }

  eliminarProducto(id: string | number): Observable<RespuestaApi> {
    return this.http.post<RespuestaApi>(`${this.apiUrl}/eliminar_producto.php`, { id: Number(id) });
  }
}
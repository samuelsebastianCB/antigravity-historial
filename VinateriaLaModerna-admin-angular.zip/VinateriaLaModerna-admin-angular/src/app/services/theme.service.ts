import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private readonly CLAVE = 'tema-lamoderna';
  isDarkMode = signal<boolean>(false);

  constructor() {
    this.inicializarTema();
  }

  private inicializarTema() {
    const temaGuardado = localStorage.getItem(this.CLAVE) || 'claro';
    const esOscuro = temaGuardado === 'oscuro';
    this.isDarkMode.set(esOscuro);
    this.aplicarClase(esOscuro);
  }

  toggleTheme() {
    const nuevoEstado = !this.isDarkMode();
    this.isDarkMode.set(nuevoEstado);
    localStorage.setItem(this.CLAVE, nuevoEstado ? 'oscuro' : 'claro');
    this.aplicarClase(nuevoEstado);
  }

  private aplicarClase(esOscuro: boolean) {
    if (esOscuro) {
      document.documentElement.classList.add('dark-mode');
    } else {
      document.documentElement.classList.remove('dark-mode');
    }
  }
}
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface ItemVenta {
  producto_id: number;
  nombre?: string;
  precio: number;
  cantidad: number;
  subtotal: number;
}

export interface VentaPayload {
  customer_id?: number | null;
  employee_id?: number | null;
  total: number;
  items: ItemVenta[];
  tipo?: 'NORMAL' | 'INTERNA';
  comprador_interno?: string;
  motivo_interno?: string;
}

export interface RespuestaApiVenta {
  status: 'success' | 'error';
  mensaje?: string;
  sale_id?: number;
  tipo?: string;
  ventas?: any[];
}

@Injectable({
  providedIn: 'root'
})
export class VentasService {
  private http = inject(HttpClient);
  private apiUrl = environment.apiUrl;

  registrarVenta(datos: VentaPayload): Observable<RespuestaApiVenta> {
    return this.http.post<RespuestaApiVenta>(`${this.apiUrl}/registrar_venta.php`, datos);
  }

  obtenerVentas(tipo: 'normal' | 'interna' | 'todas' = 'normal'): Observable<RespuestaApiVenta> {
    return this.http.get<RespuestaApiVenta>(`${this.apiUrl}/obtener_ventas.php?tipo=${tipo}`);
  }

  obtenerComprasInternas(): Observable<{ status: 'success' | 'error'; compras: any[]; mensaje?: string }> {
    return this.http.get<any>(`${this.apiUrl}/obtener_compras_internas.php`);
  }
}
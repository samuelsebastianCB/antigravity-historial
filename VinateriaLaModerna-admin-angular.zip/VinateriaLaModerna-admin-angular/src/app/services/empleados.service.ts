import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface EmpleadoBackend {
  EMPLOYEE_ID: string | number;
  FIRST_NAME: string;
  LAST_NAME_1: string;
  LAST_NAME_2?: string;
  EMAIL?: string;
  WORK_SHIFT?: string;
  BIRTH_DATE?: string;
  HIRE_DATE?: string;
  RFC?: string;
  FOTO_URL?: string;
  ROLE_ID?: number;
  ROLE_NAME?: string;
  PHONE?: string;
  STREET?: string;
  NEIGHBORHOOD?: string;
  CITY?: string;
  STATE?: string;
  ZIP_CODE?: string;
}

export interface RespuestaApiEmpleados {
  status: 'success' | 'error';
  empleados?: EmpleadoBackend[];
  mensaje?: string;
  employee_id?: number;
}

@Injectable({
  providedIn: 'root'
})
export class EmpleadosService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  obtenerEmpleados(): Observable<RespuestaApiEmpleados> {
    return this.http.get<RespuestaApiEmpleados>(`${this.apiUrl}/obtener_empleados.php`);
  }

  crearEmpleado(datos: any): Observable<RespuestaApiEmpleados> {
    return this.http.post<RespuestaApiEmpleados>(`${this.apiUrl}/registrar_empleado.php`, datos);
  }

  actualizarEmpleado(datos: any): Observable<RespuestaApiEmpleados> {
    return this.http.post<RespuestaApiEmpleados>(`${this.apiUrl}/actualizar_empleado.php`, datos);
  }

  eliminarEmpleado(id: string | number): Observable<RespuestaApiEmpleados> {
    return this.http.delete<RespuestaApiEmpleados>(`${this.apiUrl}/eliminar_empleado.php?id=${id}`);
  }
}
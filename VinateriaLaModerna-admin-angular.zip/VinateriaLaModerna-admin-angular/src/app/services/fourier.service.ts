import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Cubeta, Intervalo } from '../pages/fourier/fourier.math';

export interface FiltrosFourier {
  desde: string;
  hasta: string;
  intervalo: Intervalo;
  metrica: 'unidades' | 'ingresos';
  producto_id?: number;
  categoria?: string;
  incluir_internas?: boolean;
  incluir_demo?: boolean;
}

export interface RespuestaSerieVentas {
  status: 'success' | 'error';
  serie?: Cubeta[];
  total_registros?: number;
  dataset_hash?: string;
  mensaje?: string;
}

export interface RegistroVentaLinea {
  sale_id: number;
  fecha: string;
  hora: string;
  tipo: string;
  producto_id: number;
  producto: string;
  categoria: string;
  cantidad: number;
  precio_unitario: number;
  subtotal: number;
  total_venta: number;
}

export interface RespuestaRegistrosVentas {
  status: 'success' | 'error';
  registros?: RegistroVentaLinea[];
  total_registros?: number;
  mostrados?: number;
  dataset_hash?: string;
  mensaje?: string;
}

export interface AnalisisGuardadoResumen {
  analysis_id: number;
  fecha_ejecucion: string;
  usuario: string;
  producto_id: number | null;
  producto: string | null;
  categoria: string | null;
  desde: string;
  hasta: string;
  intervalo: Intervalo;
  metrica: 'unidades' | 'ingresos';
  armonicos: number;
  periodo_base: number;
  incluir_internas: boolean;
  incluir_demo: boolean;
  dataset_hash: string;
  total_registros: number;
  alerta_activa: boolean;
}

export interface AlertaProducto {
  producto_id: number;
  analysis_id: number;
  fecha_ejecucion: string;
  mensaje: string;
}

@Injectable({
  providedIn: 'root'
})
export class FourierService {
  private http = inject(HttpClient);
  private apiUrl = environment.apiUrl;

  obtenerSerieVentas(filtros: FiltrosFourier): Observable<RespuestaSerieVentas> {
    let params = new HttpParams()
      .set('desde', filtros.desde)
      .set('hasta', filtros.hasta)
      .set('intervalo', filtros.intervalo)
      .set('metrica', filtros.metrica)
      .set('incluir_internas', filtros.incluir_internas ? '1' : '0')
      .set('incluir_demo', filtros.incluir_demo ? '1' : '0');

    if (filtros.producto_id && filtros.producto_id > 0) {
      params = params.set('producto_id', filtros.producto_id.toString());
    }
    if (filtros.categoria && filtros.categoria.trim() !== '') {
      params = params.set('categoria', filtros.categoria.trim());
    }

    return this.http.get<RespuestaSerieVentas>(`${this.apiUrl}/obtener_serie_ventas.php`, { params });
  }

  obtenerRegistrosVentas(filtros: FiltrosFourier, limite = 1000): Observable<RespuestaRegistrosVentas> {
    let params = new HttpParams()
      .set('desde', filtros.desde)
      .set('hasta', filtros.hasta)
      .set('incluir_internas', filtros.incluir_internas ? '1' : '0')
      .set('incluir_demo', filtros.incluir_demo ? '1' : '0')
      .set('limite', limite.toString());

    if (filtros.producto_id && filtros.producto_id > 0) {
      params = params.set('producto_id', filtros.producto_id.toString());
    }
    if (filtros.categoria && filtros.categoria.trim() !== '') {
      params = params.set('categoria', filtros.categoria.trim());
    }

    return this.http.get<RespuestaRegistrosVentas>(`${this.apiUrl}/obtener_registros_ventas.php`, { params });
  }

  guardarAnalisis(payload: any): Observable<{ status: string; mensaje?: string; analysis_id?: number }> {
    return this.http.post<any>(`${this.apiUrl}/guardar_analisis_fourier.php`, payload);
  }

  obtenerAnalisisGuardados(productoId?: number): Observable<{ status: string; analisis?: AnalisisGuardadoResumen[]; mensaje?: string }> {
    let params = new HttpParams();
    if (productoId && productoId > 0) {
      params = params.set('producto_id', productoId.toString());
    }
    return this.http.get<any>(`${this.apiUrl}/obtener_analisis_fourier.php`, { params });
  }

  obtenerAnalisisPorId(id: number): Observable<{ status: string; analisis?: any; mensaje?: string }> {
    return this.http.get<any>(`${this.apiUrl}/obtener_analisis_fourier.php?id=${id}`);
  }

  obtenerAlertasActivas(): Observable<{ status: string; alertas?: AlertaProducto[]; mensaje?: string }> {
    return this.http.get<any>(`${this.apiUrl}/obtener_analisis_fourier.php?alertas=1`);
  }
}


import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  
  if (typeof window !== 'undefined') {
    const session = localStorage.getItem('admin_sesion');
    if (session) {
      return true; // Hay sesión activa
    }
  }

  // Si no hay sesión, regresamos a login
  router.navigate(['/login']);
  return false;
};


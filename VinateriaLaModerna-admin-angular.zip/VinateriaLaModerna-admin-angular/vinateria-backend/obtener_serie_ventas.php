<?php
require_once __DIR__ . '/config/analisis_ventas.php';
cabecerasJson('GET, OPTIONS');
require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/esquema.php';

/**
 * Serie temporal de ventas agrupada por intervalo (hora/dia/semana/mes/anio).
 * Devuelve cubetas dispersas (solo intervalos con ventas); el relleno con ceros lo hace el
 * módulo de Fourier. Incluye la huella (hash) del conjunto de datos usado.
 */
try {
    asegurarEsquema($conexion);
    $f = leerFiltrosVentas();

    $intervalo = $_GET['intervalo'] ?? 'dia';
    $metrica   = $_GET['metrica'] ?? 'unidades';

    $expresionesIntervalo = [
        'hora'   => "DATE_FORMAT(s.SALE_DATE, '%Y-%m-%d %H:00:00')",
        'dia'    => "DATE_FORMAT(s.SALE_DATE, '%Y-%m-%d')",
        'semana' => "DATE_FORMAT(DATE_SUB(DATE(s.SALE_DATE), INTERVAL WEEKDAY(s.SALE_DATE) DAY), '%Y-%m-%d')",
        'mes'    => "DATE_FORMAT(s.SALE_DATE, '%Y-%m-01')",
        'anio'   => "DATE_FORMAT(s.SALE_DATE, '%Y-01-01')",
    ];
    $expresionesMetrica = [
        'unidades' => 'SUM(sd.QUANTITY_SOLD)',
        'ingresos' => 'SUM(sd.SUBTOTAL)',
    ];
    if (!isset($expresionesIntervalo[$intervalo])) {
        responderError('Intervalo no válido. Usa: hora, dia, semana, mes o anio.');
    }
    if (!isset($expresionesMetrica[$metrica])) {
        responderError('Métrica no válida. Usa: unidades o ingresos.');
    }

    [$where, $tipos, $vals] = construirWhereVentas($f);
    $res = ejecutarPreparada(
        $conexion,
        "SELECT {$expresionesIntervalo[$intervalo]} AS clave, {$expresionesMetrica[$metrica]} AS valor
         FROM SALE s
         JOIN SALE_DETAIL sd ON sd.SALE_ID = s.SALE_ID
         JOIN PRODUCT p ON p.PRODUCT_ID = sd.PRODUCT_ID
         WHERE $where
         GROUP BY clave
         ORDER BY clave",
        $tipos,
        $vals
    );

    $serie = [];
    while ($r = $res->fetch_assoc()) {
        $serie[] = ['clave' => $r['clave'], 'valor' => (float)$r['valor']];
    }

    $huella = huellaConjuntoDatos($conexion, $f);

    echo json_encode([
        'status'         => 'success',
        'serie'          => $serie,
        'total_registros' => $huella['registros'],
        'dataset_hash'   => $huella['hash'],
        'parametros'     => $f + ['intervalo' => $intervalo, 'metrica' => $metrica],
    ], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    responderError($e->getMessage());
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}


<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if (ob_get_length()) ob_clean();

require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/esquema.php';
asegurarEsquema($conexion);

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => "No se recibieron datos de la venta."], JSON_UNESCAPED_UNICODE);
    exit();
}

$items = isset($data['items']) && is_array($data['items']) ? $data['items'] : (isset($data['productos']) ? $data['productos'] : []);
if (empty($items)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => "La venta debe incluir al menos un producto."], JSON_UNESCAPED_UNICODE);
    exit();
}

$totalAmount = isset($data['total']) ? (float)$data['total'] : 0.00;
$saleDate    = !empty($data['fecha']) ? $data['fecha'] : date('Y-m-d H:i:s');

// Validar CUSTOMER_ID (si viene y existe, se usa; si no, queda en NULL)
$customerId = null;
if (!empty($data['customer_id'])) {
    $cid = (int)$data['customer_id'];
    $checkCust = $conexion->query("SELECT CUSTOMER_ID FROM CUSTOMER WHERE CUSTOMER_ID = $cid LIMIT 1");
    if ($checkCust && $checkCust->num_rows > 0) {
        $customerId = $cid;
    }
}

// Validar EMPLOYEE_ID (si viene y existe, se usa; si no, queda en NULL)
$employeeId = null;
$eid = isset($data['employee_id']) ? (int)$data['employee_id'] : (isset($data['empleado_id']) ? (int)$data['empleado_id'] : 0);
if ($eid > 0) {
    $checkEmp = $conexion->query("SELECT EMPLOYEE_ID FROM EMPLOYEE WHERE EMPLOYEE_ID = $eid LIMIT 1");
    if ($checkEmp && $checkEmp->num_rows > 0) {
        $employeeId = $eid;
    }
}

// Tipo de operación (NORMAL de cliente o INTERNA de empleados/administrador)
$saleType = (!empty($data['tipo']) && strtoupper($data['tipo']) === 'INTERNA') ? 'INTERNA' : 'NORMAL';
$internalBuyer = ($saleType === 'INTERNA') ? trim((string)($data['comprador_interno'] ?? ($data['comprador'] ?? ''))) : null;
$internalReason = ($saleType === 'INTERNA') ? trim((string)($data['motivo_interno'] ?? ($data['motivo'] ?? ''))) : null;

if ($saleType === 'INTERNA' && empty($internalBuyer)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => "Las compras internas requieren indicar el nombre del empleado o responsable."], JSON_UNESCAPED_UNICODE);
    exit();
}

// 1. INICIAR OPERACIÓN
$conexion->begin_transaction();

// Arreglo en memoria para recolectar posibles alertas sin dispararlas de inmediato
$alertasInventarioBajo = [];
$umbralStockBajo = 3; // Límite para considerar inventario crítico

try {
    // 1. Insertar en SALE
    $stmtSale = $conexion->prepare("INSERT INTO SALE (SALE_DATE, TOTAL_AMOUNT, CUSTOMER_ID, EMPLOYEE_ID, SALE_TYPE, INTERNAL_BUYER, INTERNAL_REASON) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if (!$stmtSale) {
        throw new Exception("Error al preparar venta: " . $conexion->error);
    }

    $stmtSale->bind_param("sdiisss", $saleDate, $totalAmount, $customerId, $employeeId, $saleType, $internalBuyer, $internalReason);
    if (!$stmtSale->execute()) {
        throw new Exception("Error al guardar venta: " . $stmtSale->error);
    }

    $nuevoSaleId = $conexion->insert_id;
    $stmtSale->close();

    // 2. Preparar sentencias con bloqueo de concurrencia
    // FOR UPDATE bloquea la fila del producto para evitar venta simultánea de la última botella
    $stmtLock   = $conexion->prepare("SELECT CURRENT_STOCK, PRODUCT_NAME FROM PRODUCT WHERE PRODUCT_ID = ? FOR UPDATE");
    $stmtDetail = $conexion->prepare("INSERT INTO SALE_DETAIL (SALE_ID, PRODUCT_ID, QUANTITY_SOLD, SUBTOTAL) VALUES (?, ?, ?, ?)");
    $stmtStock  = $conexion->prepare("UPDATE PRODUCT SET CURRENT_STOCK = CURRENT_STOCK - ? WHERE PRODUCT_ID = ?");

    if (!$stmtLock || !$stmtDetail || !$stmtStock) {
        throw new Exception("Error al preparar operaciones transaccionales: " . $conexion->error);
    }

    foreach ($items as $item) {
        $prodId = (int)($item['PRODUCT_ID'] ?? ($item['id'] ?? ($item['producto_id'] ?? 0)));
        $qty    = (int)($item['cantidad'] ?? ($item['quantity'] ?? 1));
        $precio = (float)($item['precio'] ?? ($item['RETAIL_PRICE'] ?? ($item['unit_price'] ?? 0.00)));
        $sub    = (float)($item['subtotal'] ?? ($qty * $precio));

        if ($prodId <= 0) {
            continue;
        }

        // Consultar stock bloqueando la fila
        $stmtLock->bind_param("i", $prodId);
        $stmtLock->execute();
        $resLock = $stmtLock->get_result()->fetch_assoc();

        if (!$resLock) {
            throw new Exception("El producto ID #$prodId no existe en el catálogo.");
        }

        $stockDisponible = (int)$resLock['CURRENT_STOCK'];
        $nombreProducto  = $resLock['PRODUCT_NAME'] ?? "Producto #$prodId";

        // Si otro empleado ganó la última botella, revierte y cancela la operación
        if ($stockDisponible < $qty) {
            throw new Exception("Stock insuficiente para: $nombreProducto. Disponibles: $stockDisponible.");
        }

        // Insertar detalle exacto
        $stmtDetail->bind_param("iiid", $nuevoSaleId, $prodId, $qty, $sub);
        if (!$stmtDetail->execute()) {
            throw new Exception("Error al registrar partida del producto #$prodId: " . $stmtDetail->error);
        }

        // 2. MODIFICAR EXISTENCIAS
        $stmtStock->bind_param("ii", $qty, $prodId);
        if (!$stmtStock->execute()) {
            throw new Exception("Error al descontar existencias de #$prodId: " . $stmtStock->error);
        }

        // Pre-cálculo de existencia restante para encolar la alerta (sin emitirla todavía)
        $stockRestante = $stockDisponible - $qty;
        if ($stockRestante <= $umbralStockBajo) {
            $alertasInventarioBajo[] = [
                "producto_id" => $prodId,
                "nombre"      => $nombreProducto,
                "stock_final" => $stockRestante
            ];
        }
    }

    $stmtLock->close();
    $stmtDetail->close();
    $stmtStock->close();

    // 3. CONFIRMAR CAMBIOS (Persistencia definitiva garantizada)
    $conexion->commit();

    // 4. GENERAR ALERTA (Solo se ejecuta si el commit fue exitoso)
    // Al ejecutarse después de commit(), se evita comunicar un cambio que pudo haberse revertido
    echo json_encode([
        "status"              => "success",
        "mensaje"             => ($saleType === 'INTERNA' ? "Compra interna registrada con éxito." : "Venta procesada con éxito."),
        "sale_id"             => $nuevoSaleId,
        "folio"               => $nuevoSaleId,
        "tipo"                => $saleType,
        "comprador_interno"   => $internalBuyer,
        "alertas_stock_bajo"  => $alertasInventarioBajo
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    // 3. REVERTIR CAMBIOS (Si algo falló o faltó inventario, se deshace la operación)
    $conexion->rollback();

    // La tarjeta "Generar alerta" se omite: el arreglo $alertasInventarioBajo se destruye aquí
    http_response_code(409);
    echo json_encode([
        "status"             => "error",
        "mensaje"            => $e->getMessage(),
        "alertas_stock_bajo" => []
    ], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}
?>
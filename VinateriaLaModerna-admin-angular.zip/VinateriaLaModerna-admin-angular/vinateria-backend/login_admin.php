<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if (ob_get_length()) ob_clean();

require_once __DIR__ . '/config/conexion.php';

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => "No se recibieron datos de acceso."], JSON_UNESCAPED_UNICODE);
    exit();
}

$email    = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');

if (empty($email) || empty($password)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => "Por favor ingresa correo y contraseña."], JSON_UNESCAPED_UNICODE);
    exit();
}

try {
    $stmt = $conexion->prepare("SELECT 
                                    ADMIN_ID, 
                                    FIRST_NAME, 
                                    LAST_NAME_1, 
                                    LAST_NAME_2, 
                                    EMAIL, 
                                    USER_PASSWORD, 
                                    ROLE_ID, 
                                    FOTO_URL 
                                FROM ADMIN 
                                WHERE EMAIL = ? LIMIT 1");
    if (!$stmt) {
        throw new Exception("Error al preparar consulta: " . $conexion->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res && $admin = $res->fetch_assoc()) {
        $hashGuardado = $admin['USER_PASSWORD'];

        // Soporta tanto contraseñas en texto plano como con hash bcrypt
        $valida = ($password === $hashGuardado) || password_verify($password, $hashGuardado);

        if ($valida) {
            $nombreCompleto = trim($admin['FIRST_NAME'] . ' ' . $admin['LAST_NAME_1'] . ' ' . ($admin['LAST_NAME_2'] ?? ''));

            echo json_encode([
                "status"   => "success",
                "es_admin" => true,
                "mensaje"  => "Bienvenido al panel administrativo.",
                "admin"    => [
                    "id"       => (int)$admin['ADMIN_ID'],
                    "nombre"   => $nombreCompleto,
                    "email"    => $admin['EMAIL'],
                    "role_id"  => (int)$admin['ROLE_ID'],
                    "foto_url" => $admin['FOTO_URL']
                ]
            ], JSON_UNESCAPED_UNICODE);
            exit();
        } else {
            http_response_code(401);
            echo json_encode(["status" => "error", "mensaje" => "Contraseña incorrecta."], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    http_response_code(404);
    echo json_encode(["status" => "error", "mensaje" => "Administrador no encontrado."], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($stmt) && $stmt instanceof mysqli_stmt) {
        $stmt->close();
    }
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}
?>
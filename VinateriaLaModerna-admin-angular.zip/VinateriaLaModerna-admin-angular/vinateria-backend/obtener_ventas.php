<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if (ob_get_length()) ob_clean();

require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/esquema.php';

try {
    asegurarEsquema($conexion);

    $tipoFiltro = strtolower($_GET['tipo'] ?? 'normal');
    $where = [];
    if ($tipoFiltro === 'normal') {
        $where[] = "s.SALE_TYPE = 'NORMAL'";
    } elseif ($tipoFiltro === 'interna') {
        $where[] = "s.SALE_TYPE = 'INTERNA'";
    }

    $whereSql = count($where) ? "WHERE " . implode(" AND ", $where) : "";

    $sql = "SELECT 
                s.SALE_ID, 
                s.SALE_DATE, 
                s.TOTAL_AMOUNT, 
                s.CUSTOMER_ID, 
                s.EMPLOYEE_ID,
                s.SALE_TYPE,
                s.INTERNAL_BUYER,
                s.INTERNAL_REASON,
                COALESCE(CONCAT(e.FIRST_NAME, ' ', e.LAST_NAME), 'Cajero General') AS EMPLEADO_NOMBRE
            FROM SALE s
            LEFT JOIN EMPLOYEE e ON s.EMPLOYEE_ID = e.EMPLOYEE_ID
            $whereSql
            ORDER BY s.SALE_ID DESC";

    $res = $conexion->query($sql);
    if (!$res) {
        throw new Exception("Error al consultar ventas: " . $conexion->error);
    }

    $ventas = [];
    $ids = [];
    while ($fila = $res->fetch_assoc()) {
        $id = (int)$fila['SALE_ID'];
        $ids[] = $id;
        $ventas[$id] = [
            // Formato BD original
            "SALE_ID"         => $id,
            "SALE_DATE"       => $fila['SALE_DATE'],
            "TOTAL_AMOUNT"    => (float)$fila['TOTAL_AMOUNT'],
            "CUSTOMER_ID"     => $fila['CUSTOMER_ID'] !== null ? (int)$fila['CUSTOMER_ID'] : null,
            "EMPLOYEE_ID"     => $fila['EMPLOYEE_ID'] !== null ? (int)$fila['EMPLOYEE_ID'] : null,
            "EMPLEADO"        => $fila['EMPLEADO_NOMBRE'],
            "SALE_TYPE"       => $fila['SALE_TYPE'] ?? 'NORMAL',
            "INTERNAL_BUYER"  => $fila['INTERNAL_BUYER'],
            "INTERNAL_REASON" => $fila['INTERNAL_REASON'],

            // Alias en minúsculas compatibles con Angular
            "folio"           => $id,
            "id"              => $id,
            "sale_id"         => $id,
            "fecha"           => $fila['SALE_DATE'],
            "total"           => (float)$fila['TOTAL_AMOUNT'],
            "total_amount"    => (float)$fila['TOTAL_AMOUNT'],
            "cajero"          => $fila['EMPLEADO_NOMBRE'],
            "tipo"            => $fila['SALE_TYPE'] ?? 'NORMAL',
            "comprador"       => $fila['INTERNAL_BUYER'],
            "motivo"          => $fila['INTERNAL_REASON'],
            "items"           => []
        ];
    }

    if (!empty($ids)) {
        // Cargar ítems de las ventas
        $inList = implode(',', array_map('intval', $ids));
        $sqlDet = "SELECT 
                    sd.SALE_ID,
                    sd.PRODUCT_ID,
                    sd.QUANTITY_SOLD,
                    sd.SUBTOTAL,
                    COALESCE(p.PRODUCT_NAME, CONCAT('Producto #', sd.PRODUCT_ID)) AS NOMBRE_PRODUCTO,
                    COALESCE(p.CATEGORY, 'Sin categoría') AS CATEGORIA
                   FROM SALE_DETAIL sd
                   LEFT JOIN PRODUCT p ON sd.PRODUCT_ID = p.PRODUCT_ID
                   WHERE sd.SALE_ID IN ($inList)";
        $resDet = $conexion->query($sqlDet);
        if ($resDet) {
            while ($det = $resDet->fetch_assoc()) {
                $saleId = (int)$det['SALE_ID'];
                if (isset($ventas[$saleId])) {
                    $cant = (int)$det['QUANTITY_SOLD'];
                    $sub  = (float)$det['SUBTOTAL'];
                    $precioUnit = $cant > 0 ? round($sub / $cant, 2) : $sub;
                    $ventas[$saleId]['items'][] = [
                        'producto_id' => (int)$det['PRODUCT_ID'],
                        'nombre'      => $det['NOMBRE_PRODUCTO'],
                        'categoria'   => $det['CATEGORIA'],
                        'cantidad'    => $cant,
                        'precio'      => $precioUnit,
                        'subtotal'    => $sub
                    ];
                }
            }
        }
    }

    echo json_encode([
        "status" => "success",
        "ventas" => array_values($ventas)
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}
?>
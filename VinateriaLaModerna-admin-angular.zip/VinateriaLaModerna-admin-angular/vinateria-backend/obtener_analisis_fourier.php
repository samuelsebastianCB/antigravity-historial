<?php
require_once __DIR__ . '/config/analisis_ventas.php';
cabecerasJson('GET, OPTIONS');
require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/esquema.php';

/**
 * Consulta de análisis guardados:
 *   ?id=N          → análisis completo (coeficientes, serie observada/aproximada, patrones)
 *   ?alertas=1     → último análisis de cada producto SI quedó con alerta (para Inventario)
 *   (sin más)      → historial resumido; filtros: producto_id, solo_alerta=1, limite
 */
try {
    asegurarEsquema($conexion);

    if (isset($_GET['id'])) {
        $res = ejecutarPreparada($conexion, 'SELECT * FROM FOURIER_ANALYSIS WHERE ANALYSIS_ID = ?', 'i', [(int)$_GET['id']]);
        $r = $res->fetch_assoc();
        if (!$r) {
            responderError('El análisis solicitado no existe.', 404);
        }
        echo json_encode(['status' => 'success', 'analisis' => [
            'analysis_id'      => (int)$r['ANALYSIS_ID'],
            'fecha_ejecucion'  => $r['RUN_AT'],
            'usuario_id'       => $r['USER_ID'] !== null ? (int)$r['USER_ID'] : null,
            'usuario'          => $r['USER_NAME'],
            'producto_id'      => $r['PRODUCT_ID'] !== null ? (int)$r['PRODUCT_ID'] : null,
            'producto'         => $r['PRODUCT_NAME'],
            'categoria'        => $r['CATEGORY'],
            'desde'            => $r['DATE_FROM'],
            'hasta'            => $r['DATE_TO'],
            'intervalo'        => $r['INTERVAL_TYPE'],
            'metrica'          => $r['METRIC'],
            'armonicos'        => (int)$r['HARMONICS'],
            'periodo_base'     => (float)$r['BASE_PERIOD'],
            'incluir_internas' => (bool)$r['INCLUDE_INTERNAL'],
            'incluir_demo'     => (bool)$r['INCLUDE_DEMO'],
            'dataset_hash'     => $r['DATASET_HASH'],
            'total_registros'  => (int)$r['DATASET_ROWS'],
            'alerta_activa'    => (bool)$r['ALERT_FLAG'],
            'alerta_mensaje'   => $r['ALERT_MESSAGE'],
            'parametros'       => json_decode($r['PARAMS_JSON'], true),
            'coeficientes'     => json_decode($r['COEFFICIENTS_JSON'], true),
            'serie'            => json_decode($r['SERIES_JSON'], true),
            'patrones'         => json_decode($r['PATTERNS_JSON'], true),
        ]], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if (($_GET['alertas'] ?? '') === '1') {
        $res = $conexion->query(
            'SELECT a.PRODUCT_ID, a.ANALYSIS_ID, a.RUN_AT, a.ALERT_MESSAGE
             FROM FOURIER_ANALYSIS a
             WHERE a.PRODUCT_ID IS NOT NULL AND a.ALERT_FLAG = 1
               AND a.ANALYSIS_ID = (SELECT MAX(b.ANALYSIS_ID) FROM FOURIER_ANALYSIS b WHERE b.PRODUCT_ID = a.PRODUCT_ID)'
        );
        if (!$res) {
            throw new Exception('Error al consultar alertas: ' . $conexion->error);
        }
        $alertas = [];
        while ($r = $res->fetch_assoc()) {
            $alertas[] = [
                'producto_id'     => (int)$r['PRODUCT_ID'],
                'analysis_id'     => (int)$r['ANALYSIS_ID'],
                'fecha_ejecucion' => $r['RUN_AT'],
                'mensaje'         => $r['ALERT_MESSAGE'],
            ];
        }
        echo json_encode(['status' => 'success', 'alertas' => $alertas], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $where = ['1=1'];
    $tipos = '';
    $vals  = [];
    if (!empty($_GET['producto_id'])) {
        $where[] = 'PRODUCT_ID = ?';
        $tipos  .= 'i';
        $vals[]  = (int)$_GET['producto_id'];
    }
    if (($_GET['solo_alerta'] ?? '') === '1') {
        $where[] = 'ALERT_FLAG = 1';
    }
    $tipos .= 'i';
    $vals[] = isset($_GET['limite']) ? max(1, min(200, (int)$_GET['limite'])) : 50;

    $res = ejecutarPreparada(
        $conexion,
        'SELECT ANALYSIS_ID, RUN_AT, USER_NAME, PRODUCT_ID, PRODUCT_NAME, CATEGORY, DATE_FROM, DATE_TO,
                INTERVAL_TYPE, METRIC, HARMONICS, BASE_PERIOD, INCLUDE_INTERNAL, INCLUDE_DEMO,
                DATASET_HASH, DATASET_ROWS, ALERT_FLAG
         FROM FOURIER_ANALYSIS WHERE ' . implode(' AND ', $where) . ' ORDER BY ANALYSIS_ID DESC LIMIT ?',
        $tipos,
        $vals
    );
    $lista = [];
    while ($r = $res->fetch_assoc()) {
        $lista[] = [
            'analysis_id'      => (int)$r['ANALYSIS_ID'],
            'fecha_ejecucion'  => $r['RUN_AT'],
            'usuario'          => $r['USER_NAME'],
            'producto_id'      => $r['PRODUCT_ID'] !== null ? (int)$r['PRODUCT_ID'] : null,
            'producto'         => $r['PRODUCT_NAME'],
            'categoria'        => $r['CATEGORY'],
            'desde'            => $r['DATE_FROM'],
            'hasta'            => $r['DATE_TO'],
            'intervalo'        => $r['INTERVAL_TYPE'],
            'metrica'          => $r['METRIC'],
            'armonicos'        => (int)$r['HARMONICS'],
            'periodo_base'     => (float)$r['BASE_PERIOD'],
            'incluir_internas' => (bool)$r['INCLUDE_INTERNAL'],
            'incluir_demo'     => (bool)$r['INCLUDE_DEMO'],
            'dataset_hash'     => $r['DATASET_HASH'],
            'total_registros'  => (int)$r['DATASET_ROWS'],
            'alerta_activa'    => (bool)$r['ALERT_FLAG'],
        ];
    }
    echo json_encode(['status' => 'success', 'analisis' => $lista], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    responderError($e->getMessage());
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}


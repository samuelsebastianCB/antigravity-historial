<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if (ob_get_length()) ob_clean();

require_once __DIR__ . '/config/conexion.php';

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => "No se recibieron datos válidos."], JSON_UNESCAPED_UNICODE);
    exit();
}

$id      = isset($data['SUPPLIER_ID']) ? (int)$data['SUPPLIER_ID'] : (isset($data['id']) ? (int)$data['id'] : 0);
$empresa = trim($data['COMPANY_NAME'] ?? ($data['empresa'] ?? ($data['nombre'] ?? '')));
$tel     = trim($data['PHONE'] ?? ($data['telefono'] ?? ''));
$correo  = trim($data['EMAIL'] ?? ($data['correo'] ?? ''));

if (empty($empresa)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => "El nombre de la empresa/proveedor es obligatorio."], JSON_UNESCAPED_UNICODE);
    exit();
}

try {
    if ($id > 0) {
        // Actualización si ya existe ID
        $stmt = $conexion->prepare("INSERT INTO SUPPLIER (SUPPLIER_ID, COMPANY_NAME, PHONE, EMAIL) 
                                   VALUES (?, ?, ?, ?) 
                                   ON DUPLICATE KEY UPDATE 
                                     COMPANY_NAME = VALUES(COMPANY_NAME), 
                                     PHONE = VALUES(PHONE), 
                                     EMAIL = VALUES(EMAIL)");
        $stmt->bind_param("isss", $id, $empresa, $tel, $correo);
    } else {
        // Inserción nuevo autoincremental o manual
        $stmt = $conexion->prepare("INSERT INTO SUPPLIER (COMPANY_NAME, PHONE, EMAIL) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $empresa, $tel, $correo);
    }

    if (!$stmt->execute()) {
        throw new Exception("Error al registrar proveedor: " . $stmt->error);
    }

    $nuevoId = $id > 0 ? $id : $conexion->insert_id;
    $stmt->close();

    echo json_encode([
        "status" => "success",
        "mensaje" => "Proveedor guardado correctamente.",
        "supplier_id" => $nuevoId
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}
?>
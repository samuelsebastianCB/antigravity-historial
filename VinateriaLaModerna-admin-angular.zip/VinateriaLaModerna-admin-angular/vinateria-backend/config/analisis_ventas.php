<?php
/**
 * Utilidades compartidas para el análisis de ventas (Fourier).
 *
 * REGLA DE NEGOCIO: las compras internas (SALE_TYPE='INTERNA') NUNCA se mezclan con las ventas
 * normales. Solo entran al análisis si el usuario las pide explícitamente (incluir_internas=1).
 * Las ventas de demostración (IS_DEMO=1) tampoco, salvo incluir_demo=1.
 */

function cabecerasJson(string $metodos = 'GET, OPTIONS'): void
{
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Methods: $metodos");
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    header('Content-Type: application/json; charset=utf-8');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit();
    }
    if (ob_get_length()) {
        ob_clean();
    }
}

function responderError(string $mensaje, int $codigo = 400): void
{
    http_response_code($codigo);
    echo json_encode(['status' => 'error', 'mensaje' => $mensaje], JSON_UNESCAPED_UNICODE);
    exit();
}

function fechaValida(?string $f): bool
{
    if ($f === null || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $f)) {
        return false;
    }
    [$y, $m, $d] = array_map('intval', explode('-', $f));
    return checkdate($m, $d, $y);
}

function bandera($v): bool
{
    return in_array($v, ['1', 1, true, 'true'], true);
}

/** Lee y valida los filtros comunes (por defecto del querystring; también acepta el cuerpo JSON). */
function leerFiltrosVentas(?array $src = null): array
{
    $src   = $src ?? $_GET;
    $desde = (string)($src['desde'] ?? '');
    $hasta = (string)($src['hasta'] ?? '');
    if (!fechaValida($desde) || !fechaValida($hasta)) {
        responderError('Indica una fecha inicial y final válidas (AAAA-MM-DD).');
    }
    if ($hasta < $desde) {
        responderError('La fecha final no puede ser anterior a la inicial.');
    }
    $categoria = trim((string)($src['categoria'] ?? ''));
    if (mb_strlen($categoria) > 60) {
        responderError('Categoría no válida.');
    }
    return [
        'desde'            => $desde,
        'hasta'            => $hasta,
        'producto_id'      => isset($src['producto_id']) && $src['producto_id'] !== '' ? (int)$src['producto_id'] : 0,
        'categoria'        => $categoria,
        'incluir_internas' => bandera($src['incluir_internas'] ?? '0'),
        'incluir_demo'     => bandera($src['incluir_demo'] ?? '0'),
    ];
}

/**
 * Construye el WHERE (con marcadores ?) para ventas por línea.
 * Alias esperados: s = SALE, sd = SALE_DETAIL, p = PRODUCT.
 * @return array{0:string,1:string,2:array} [where, tipos, valores]
 */
function construirWhereVentas(array $f): array
{
    $where = ['s.SALE_DATE >= ?', 's.SALE_DATE < DATE_ADD(?, INTERVAL 1 DAY)'];
    $tipos = 'ss';
    $vals  = [$f['desde'], $f['hasta']];

    $where[] = $f['incluir_internas'] ? "s.SALE_TYPE IN ('NORMAL','INTERNA')" : "s.SALE_TYPE = 'NORMAL'";
    if (!$f['incluir_demo']) {
        $where[] = 's.IS_DEMO = 0';
    }
    if ($f['producto_id'] > 0) {
        $where[] = 'sd.PRODUCT_ID = ?';
        $tipos  .= 'i';
        $vals[]  = $f['producto_id'];
    }
    if ($f['categoria'] !== '') {
        $where[] = 'p.CATEGORY = ?';
        $tipos  .= 's';
        $vals[]  = $f['categoria'];
    }
    return [implode(' AND ', $where), $tipos, $vals];
}

function ejecutarPreparada(mysqli $c, string $sql, string $tipos, array $vals): mysqli_result
{
    $stmt = $c->prepare($sql);
    if (!$stmt) {
        throw new Exception('Error al preparar consulta: ' . $c->error);
    }
    if ($tipos !== '') {
        $stmt->bind_param($tipos, ...$vals);
    }
    if (!$stmt->execute()) {
        throw new Exception('Error al ejecutar consulta: ' . $stmt->error);
    }
    $res = $stmt->get_result();
    $stmt->close();
    return $res;
}

/**
 * Hash SHA-256 y conteo del conjunto de datos exacto que alimenta el análisis
 * (una línea por producto vendido), con el mismo orden y filtros que la serie.
 * Permite probar después si los datos cambiaron desde que se corrió el análisis.
 */
function huellaConjuntoDatos(mysqli $c, array $f): array
{
    [$where, $tipos, $vals] = construirWhereVentas($f);
    $res = ejecutarPreparada(
        $c,
        "SELECT s.SALE_ID, s.SALE_DATE, s.SALE_TYPE, sd.PRODUCT_ID, sd.QUANTITY_SOLD, sd.SUBTOTAL
         FROM SALE s
         JOIN SALE_DETAIL sd ON sd.SALE_ID = s.SALE_ID
         JOIN PRODUCT p ON p.PRODUCT_ID = sd.PRODUCT_ID
         WHERE $where
         ORDER BY s.SALE_ID, sd.PRODUCT_ID, sd.QUANTITY_SOLD, sd.SUBTOTAL",
        $tipos,
        $vals
    );
    $ctx = hash_init('sha256');
    $n = 0;
    while ($r = $res->fetch_assoc()) {
        hash_update($ctx, implode('|', [
            $r['SALE_ID'], $r['SALE_DATE'], $r['SALE_TYPE'], $r['PRODUCT_ID'],
            $r['QUANTITY_SOLD'], number_format((float)$r['SUBTOTAL'], 2, '.', ''),
        ]) . "\n");
        $n++;
    }
    return ['hash' => hash_final($ctx), 'registros' => $n];
}

<?php
$servidor  = "127.0.0.1";
$usuario   = "root";
$password  = "root";
$baseDatos = "vinaterialamoderna_local";
$puerto    = 8889;

$conexion = new mysqli($servidor, $usuario, $password, $baseDatos, $puerto);

if ($conexion->connect_error) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "mensaje" => "Error de conexión MySQL: " . $conexion->connect_error
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

$conexion->set_charset("utf8mb4");
?>
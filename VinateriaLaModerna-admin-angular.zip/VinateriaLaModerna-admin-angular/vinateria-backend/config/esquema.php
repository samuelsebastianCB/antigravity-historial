<?php
/**
 * Esquema necesario para el análisis de Fourier, las compras internas y la categoría.
 * Idempotente: solo aplica lo que falta. Equivale a sql/fourier_migration.sql.
 * IMPORTANTE: llamar ANTES de iniciar transacciones (ALTER TABLE hace commit implícito).
 */

function categoriaPorNombre(string $nombre): string
{
    $n = mb_strtolower($nombre, 'UTF-8');
    $reglas = [
        'Tequila'  => '/\b(tequila|mezcal)\b|\bjose cuervo\b|\bdon julio\b|\bpatr[oó]n\b/u',
        'Whisky'   => '/\b(whisky|whiskey|bourbon|scotch|jack daniel|johnnie walker|buchanan|chivas)\b/u',
        'Vodka'    => '/\b(vodka|smirnoff|absolut)\b/u',
        'Ron'      => '/\b(ron|bacardi|havana club|captain morgan)\b/u',
        'Ginebra'  => '/\b(ginebra|gin|bombay|tanqueray|beefeater)\b/u',
        'Brandy'   => '/\b(brandy|co[gñ]ac|torres|presidente|hennessy|martell)\b/u',
        'Vino'     => '/\b(vino|tinto|blanco|rosado|espumoso|champagne|cava|malbec|merlot|cabernet|chardonnay)\b/u',
        'Cerveza'  => '/\b(cerveza|lager|ipa|stout|corona|modelo|victoria|heineken|indio|pacifico|pac[ií]fico)\b/u',
        'Licor'    => '/\b(licor|amaretto|baileys|kahlua|kahl[uú]a|jager|j[aä]germeister|sambuca)\b/u',
    ];
    foreach ($reglas as $categoria => $regex) {
        if (preg_match($regex, $n)) {
            return $categoria;
        }
    }
    return 'Otros';
}

function asegurarEsquema(mysqli $c): void
{
    static $hecho = false;
    if ($hecho) {
        return;
    }

    $cols = [];
    $res = $c->query(
        "SELECT TABLE_NAME, COLUMN_NAME FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND ((TABLE_NAME = 'SALE' AND COLUMN_NAME IN ('SALE_TYPE','INTERNAL_BUYER','INTERNAL_REASON','IS_DEMO'))
             OR (TABLE_NAME = 'PRODUCT' AND COLUMN_NAME = 'CATEGORY'))"
    );
    if (!$res) {
        throw new Exception('No se pudo inspeccionar el esquema: ' . $c->error);
    }
    while ($f = $res->fetch_assoc()) {
        $cols[$f['TABLE_NAME'] . '.' . $f['COLUMN_NAME']] = true;
    }

    $alters = [
        'SALE.SALE_TYPE'       => "ALTER TABLE SALE ADD COLUMN SALE_TYPE VARCHAR(10) NOT NULL DEFAULT 'NORMAL'",
        'SALE.INTERNAL_BUYER'  => 'ALTER TABLE SALE ADD COLUMN INTERNAL_BUYER VARCHAR(120) NULL',
        'SALE.INTERNAL_REASON' => 'ALTER TABLE SALE ADD COLUMN INTERNAL_REASON VARCHAR(255) NULL',
        'SALE.IS_DEMO'         => 'ALTER TABLE SALE ADD COLUMN IS_DEMO TINYINT(1) NOT NULL DEFAULT 0',
        'PRODUCT.CATEGORY'     => 'ALTER TABLE PRODUCT ADD COLUMN CATEGORY VARCHAR(60) NULL',
    ];
    $categoriaNueva = false;
    foreach ($alters as $clave => $sql) {
        if (!isset($cols[$clave])) {
            if (!$c->query($sql)) {
                throw new Exception("No se pudo actualizar el esquema ($clave): " . $c->error .
                    ' Ejecuta vinateria-backend/sql/fourier_migration.sql con un usuario con permisos ALTER.');
            }
            if ($clave === 'PRODUCT.CATEGORY') {
                $categoriaNueva = true;
            }
        }
    }

    $idx = $c->query("SELECT 1 FROM information_schema.STATISTICS
                      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'SALE' AND INDEX_NAME = 'idx_sale_date_type' LIMIT 1");
    if ($idx && $idx->num_rows === 0) {
        $c->query('CREATE INDEX idx_sale_date_type ON SALE (SALE_DATE, SALE_TYPE)'); // no crítico
    }

    $ok = $c->query("CREATE TABLE IF NOT EXISTS FOURIER_ANALYSIS (
        ANALYSIS_ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        RUN_AT DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        USER_ID INT NULL,
        USER_NAME VARCHAR(150) NOT NULL,
        PRODUCT_ID INT NULL,
        PRODUCT_NAME VARCHAR(150) NULL,
        CATEGORY VARCHAR(60) NULL,
        DATE_FROM DATE NOT NULL,
        DATE_TO DATE NOT NULL,
        INTERVAL_TYPE VARCHAR(10) NOT NULL,
        METRIC VARCHAR(10) NOT NULL,
        HARMONICS INT NOT NULL,
        BASE_PERIOD DOUBLE NOT NULL,
        INCLUDE_INTERNAL TINYINT(1) NOT NULL DEFAULT 0,
        INCLUDE_DEMO TINYINT(1) NOT NULL DEFAULT 0,
        DATASET_HASH CHAR(64) NOT NULL,
        DATASET_ROWS INT NOT NULL,
        ALERT_FLAG TINYINT(1) NOT NULL DEFAULT 0,
        ALERT_MESSAGE VARCHAR(500) NULL,
        PARAMS_JSON LONGTEXT NOT NULL,
        COEFFICIENTS_JSON LONGTEXT NOT NULL,
        SERIES_JSON LONGTEXT NOT NULL,
        PATTERNS_JSON LONGTEXT NOT NULL,
        INDEX idx_fa_product (PRODUCT_ID, ANALYSIS_ID),
        INDEX idx_fa_run (RUN_AT)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (!$ok) {
        throw new Exception('No se pudo crear FOURIER_ANALYSIS: ' . $c->error);
    }

    // Categorías iniciales (solo la primera vez que se crea la columna): se infieren del nombre
    // y quedan editables desde Inventario.
    if ($categoriaNueva) {
        $prods = $c->query('SELECT PRODUCT_ID, PRODUCT_NAME FROM PRODUCT');
        $upd = $c->prepare('UPDATE PRODUCT SET CATEGORY = ? WHERE PRODUCT_ID = ?');
        if ($prods && $upd) {
            while ($p = $prods->fetch_assoc()) {
                $cat = categoriaPorNombre((string)$p['PRODUCT_NAME']);
                $pid = (int)$p['PRODUCT_ID'];
                $upd->bind_param('si', $cat, $pid);
                $upd->execute();
            }
            $upd->close();
        }
    }

    $hecho = true;
}


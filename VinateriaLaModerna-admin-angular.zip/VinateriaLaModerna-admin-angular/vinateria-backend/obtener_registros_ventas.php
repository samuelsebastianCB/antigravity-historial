<?php
require_once __DIR__ . '/config/analisis_ventas.php';
cabecerasJson('GET, OPTIONS');
require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/esquema.php';

/**
 * Registros de venta a nivel línea (los datos que alimentan el análisis):
 * fecha, hora, venta, producto, categoría, cantidad, precio, subtotal y total de la venta.
 */
try {
    asegurarEsquema($conexion);
    $f = leerFiltrosVentas();
    $limite = isset($_GET['limite']) ? max(1, min(5000, (int)$_GET['limite'])) : 1000;

    [$where, $tipos, $vals] = construirWhereVentas($f);
    $tipos .= 'i';
    $vals[] = $limite;

    $res = ejecutarPreparada(
        $conexion,
        "SELECT s.SALE_ID, s.SALE_DATE, s.SALE_TYPE, s.TOTAL_AMOUNT,
                sd.PRODUCT_ID, p.PRODUCT_NAME, p.CATEGORY, sd.QUANTITY_SOLD, sd.SUBTOTAL
         FROM SALE s
         JOIN SALE_DETAIL sd ON sd.SALE_ID = s.SALE_ID
         JOIN PRODUCT p ON p.PRODUCT_ID = sd.PRODUCT_ID
         WHERE $where
         ORDER BY s.SALE_DATE, s.SALE_ID, sd.PRODUCT_ID
         LIMIT ?",
        $tipos,
        $vals
    );

    $registros = [];
    while ($r = $res->fetch_assoc()) {
        $cant = (int)$r['QUANTITY_SOLD'];
        $sub  = (float)$r['SUBTOTAL'];
        $registros[] = [
            'sale_id'         => (int)$r['SALE_ID'],
            'fecha'           => substr((string)$r['SALE_DATE'], 0, 10),
            'hora'            => strlen((string)$r['SALE_DATE']) >= 19 ? substr((string)$r['SALE_DATE'], 11, 8) : '',
            'tipo'            => $r['SALE_TYPE'],
            'producto_id'     => (int)$r['PRODUCT_ID'],
            'producto'        => $r['PRODUCT_NAME'],
            'categoria'       => $r['CATEGORY'] ?? 'Sin categoría',
            'cantidad'        => $cant,
            'precio_unitario' => $cant > 0 ? round($sub / $cant, 2) : $sub,
            'subtotal'        => $sub,
            'total_venta'     => (float)$r['TOTAL_AMOUNT'],
        ];
    }

    $huella = huellaConjuntoDatos($conexion, $f);

    echo json_encode([
        'status'          => 'success',
        'registros'       => $registros,
        'total_registros' => $huella['registros'],
        'mostrados'       => count($registros),
        'dataset_hash'    => $huella['hash'],
    ], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    responderError($e->getMessage());
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}


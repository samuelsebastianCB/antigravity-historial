<?php
require_once __DIR__ . '/config/analisis_ventas.php';
cabecerasJson('GET, OPTIONS');
require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/esquema.php';

/**
 * Historial de compras internas (consumo de empleados/administradores/dueño).
 * Se consulta POR SEPARADO de las ventas normales. Afectan inventario y quedan registradas.
 */
try {
    asegurarEsquema($conexion);

    $where = ["s.SALE_TYPE = 'INTERNA'"];
    $tipos = '';
    $vals  = [];
    $desde = $_GET['desde'] ?? '';
    $hasta = $_GET['hasta'] ?? '';
    if ($desde !== '') {
        if (!fechaValida($desde)) {
            responderError('Fecha inicial no válida.');
        }
        $where[] = 's.SALE_DATE >= ?';
        $tipos  .= 's';
        $vals[]  = $desde;
    }
    if ($hasta !== '') {
        if (!fechaValida($hasta)) {
            responderError('Fecha final no válida.');
        }
        $where[] = 's.SALE_DATE < DATE_ADD(?, INTERVAL 1 DAY)';
        $tipos  .= 's';
        $vals[]  = $hasta;
    }
    $tipos .= 'i';
    $vals[] = 500;

    $res = ejecutarPreparada(
        $conexion,
        "SELECT s.SALE_ID, s.SALE_DATE, s.TOTAL_AMOUNT, s.INTERNAL_BUYER, s.INTERNAL_REASON, s.EMPLOYEE_ID,
                COALESCE(CONCAT(e.FIRST_NAME, ' ', e.LAST_NAME), 'Sin empleado') AS EMPLEADO
         FROM SALE s
         LEFT JOIN EMPLOYEE e ON e.EMPLOYEE_ID = s.EMPLOYEE_ID
         WHERE " . implode(' AND ', $where) . "
         ORDER BY s.SALE_ID DESC
         LIMIT ?",
        $tipos,
        $vals
    );

    $compras = [];
    $ids = [];
    while ($r = $res->fetch_assoc()) {
        $id = (int)$r['SALE_ID'];
        $ids[] = $id;
        $compras[$id] = [
            'sale_id'          => $id,
            'folio'            => $id,
            'fecha'            => $r['SALE_DATE'],
            'total'            => (float)$r['TOTAL_AMOUNT'],
            'comprador'        => $r['INTERNAL_BUYER'] ?? 'Sin especificar',
            'motivo'           => $r['INTERNAL_REASON'] ?? '',
            'registrado_por'   => $r['EMPLEADO'],
            'tipo'             => 'INTERNA',
            'etiqueta'         => 'OPERACIÓN INTERNA',
            'afecta_inventario' => true,
            'items'            => [],
        ];
    }

    if ($ids) {
        $in = implode(',', array_map('intval', $ids)); // enteros ya saneados
        $det = $conexion->query(
            "SELECT sd.SALE_ID, sd.PRODUCT_ID, p.PRODUCT_NAME, p.CATEGORY, sd.QUANTITY_SOLD, sd.SUBTOTAL
             FROM SALE_DETAIL sd
             LEFT JOIN PRODUCT p ON p.PRODUCT_ID = sd.PRODUCT_ID
             WHERE sd.SALE_ID IN ($in)"
        );
        while ($det && $d = $det->fetch_assoc()) {
            $cant = (int)$d['QUANTITY_SOLD'];
            $sub  = (float)$d['SUBTOTAL'];
            $compras[(int)$d['SALE_ID']]['items'][] = [
                'producto_id' => (int)$d['PRODUCT_ID'],
                'nombre'      => $d['PRODUCT_NAME'] ?? ('Producto #' . $d['PRODUCT_ID']),
                'categoria'   => $d['CATEGORY'] ?? 'Sin categoría',
                'cantidad'    => $cant,
                'precio'      => $cant > 0 ? round($sub / $cant, 2) : $sub,
                'subtotal'    => $sub,
            ];
        }
    }

    echo json_encode(['status' => 'success', 'compras' => array_values($compras)], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    responderError($e->getMessage());
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}


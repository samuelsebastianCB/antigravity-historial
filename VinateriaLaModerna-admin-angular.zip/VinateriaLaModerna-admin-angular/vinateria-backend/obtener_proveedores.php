<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if (ob_get_length()) ob_clean();

require_once __DIR__ . '/config/conexion.php';

try {
    $sql = "SELECT SUPPLIER_ID, COMPANY_NAME, PHONE, EMAIL FROM SUPPLIER ORDER BY SUPPLIER_ID DESC";
    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception("Error al consultar proveedores: " . $conexion->error);
    }

    $proveedores = [];
    while ($fila = $res->fetch_assoc()) {
        $proveedores[] = $fila;
    }

    echo json_encode([
        "status" => "success",
        "proveedores" => $proveedores
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}
?>
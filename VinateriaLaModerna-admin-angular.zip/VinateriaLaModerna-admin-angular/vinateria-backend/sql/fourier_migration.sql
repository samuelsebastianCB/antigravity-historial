-- =====================================================================
-- Migración: Análisis de Fourier, compras internas y categoría de producto
-- Base de datos: vinaterialamoderna_local (MySQL)
--
-- NOTA: vinateria-backend/config/esquema.php aplica estos mismos cambios
-- automáticamente (solo si faltan) la primera vez que se usa un endpoint.
-- Este archivo es la referencia manual. MySQL no soporta
-- "ADD COLUMN IF NOT EXISTS": ejecútalo UNA sola vez.
-- =====================================================================

-- 1) Ventas: tipo de operación (NORMAL = cliente, INTERNA = consumo interno)
ALTER TABLE SALE
  ADD COLUMN SALE_TYPE       VARCHAR(10)  NOT NULL DEFAULT 'NORMAL',
  ADD COLUMN INTERNAL_BUYER  VARCHAR(120) NULL,
  ADD COLUMN INTERNAL_REASON VARCHAR(255) NULL,
  ADD COLUMN IS_DEMO         TINYINT(1)   NOT NULL DEFAULT 0;

-- Las ventas existentes quedan como NORMAL (DEFAULT). Índice para el análisis:
CREATE INDEX idx_sale_date_type ON SALE (SALE_DATE, SALE_TYPE);

-- 2) Productos: categoría
ALTER TABLE PRODUCT
  ADD COLUMN CATEGORY VARCHAR(60) NULL;

-- 3) Trazabilidad de cada análisis de Fourier
CREATE TABLE IF NOT EXISTS FOURIER_ANALYSIS (
  ANALYSIS_ID       INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
  RUN_AT            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  USER_ID           INT          NULL,
  USER_NAME         VARCHAR(150) NOT NULL,
  PRODUCT_ID        INT          NULL,
  PRODUCT_NAME      VARCHAR(150) NULL,
  CATEGORY          VARCHAR(60)  NULL,
  DATE_FROM         DATE         NOT NULL,
  DATE_TO           DATE         NOT NULL,
  INTERVAL_TYPE     VARCHAR(10)  NOT NULL,
  METRIC            VARCHAR(10)  NOT NULL,
  HARMONICS         INT          NOT NULL,
  BASE_PERIOD       DOUBLE       NOT NULL,
  INCLUDE_INTERNAL  TINYINT(1)   NOT NULL DEFAULT 0,
  INCLUDE_DEMO      TINYINT(1)   NOT NULL DEFAULT 0,
  DATASET_HASH      CHAR(64)     NOT NULL,
  DATASET_ROWS      INT          NOT NULL,
  ALERT_FLAG        TINYINT(1)   NOT NULL DEFAULT 0,
  ALERT_MESSAGE     VARCHAR(500) NULL,
  PARAMS_JSON       LONGTEXT     NOT NULL,
  COEFFICIENTS_JSON LONGTEXT     NOT NULL,
  SERIES_JSON       LONGTEXT     NOT NULL,
  PATTERNS_JSON     LONGTEXT     NOT NULL,
  INDEX idx_fa_product (PRODUCT_ID, ANALYSIS_ID),
  INDEX idx_fa_run (RUN_AT)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


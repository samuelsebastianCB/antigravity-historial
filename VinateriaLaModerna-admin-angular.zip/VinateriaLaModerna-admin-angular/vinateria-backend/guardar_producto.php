<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if (ob_get_length()) ob_clean();

require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/esquema.php';

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => "No se recibieron datos JSON válidos."], JSON_UNESCAPED_UNICODE);
    exit();
}

// Mapeo flexible de parámetros recibidos desde Angular
$id             = isset($data['PRODUCT_ID']) ? (int)$data['PRODUCT_ID'] : (isset($data['id']) ? (int)$data['id'] : 0);
$nombre         = trim($data['PRODUCT_NAME'] ?? ($data['nombre'] ?? ''));
$descripcion    = trim($data['DESCRIPTION'] ?? ($data['descripcion'] ?? ''));
$stockActual    = isset($data['CURRENT_STOCK']) ? (int)$data['CURRENT_STOCK'] : (int)($data['stock'] ?? ($data['stockActual'] ?? 0));
$stockMin       = isset($data['MIN_STOCK']) ? (int)$data['MIN_STOCK'] : (int)($data['min_stock'] ?? ($data['stockMin'] ?? 5));
$stockMax       = isset($data['MAX_STOCK']) ? (int)$data['MAX_STOCK'] : (int)($data['max_stock'] ?? ($data['stockMax'] ?? 50));
$precioCompra   = isset($data['PURCHASE_PRICE']) ? (float)$data['PURCHASE_PRICE'] : (float)($data['purchase_price'] ?? ($data['precioCompra'] ?? 0.00));
$precioVenta    = isset($data['RETAIL_PRICE']) ? (float)$data['RETAIL_PRICE'] : (float)($data['retail_price'] ?? ($data['precioVenta'] ?? 0.00));
$fechaCaducidad = !empty($data['EXPIRATION_DATE']) ? $data['EXPIRATION_DATE'] : (!empty($data['expiration_date']) ? $data['expiration_date'] : date('Y-m-d', strtotime('+1 year')));
$estado         = !empty($data['PRODUCT_STATUS']) ? $data['PRODUCT_STATUS'] : (!empty($data['product_status']) ? $data['product_status'] : 'Activo');
$fotoUrl        = $data['FOTO_URL'] ?? ($data['foto_url'] ?? null);

if (empty($nombre)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => "El nombre del producto es obligatorio."], JSON_UNESCAPED_UNICODE);
    exit();
}

// Generar ID único si no se proporcionó uno
if ($id <= 0) {
    $id = mt_rand(10000, 99999);
}

try {
    asegurarEsquema($conexion);

    // Categoría: la indicada por el usuario; si falta, se infiere del nombre (editable después).
    $categoriaIn = trim((string)($data['CATEGORY'] ?? ($data['categoria'] ?? '')));
    $categoria   = $categoriaIn !== '' ? mb_substr($categoriaIn, 0, 60) : categoriaPorNombre($nombre);
    $categoriaExplicita = $categoriaIn !== '';

    $sql = "INSERT INTO PRODUCT (
                PRODUCT_ID, PRODUCT_NAME, DESCRIPTION, CURRENT_STOCK, 
                MIN_STOCK, MAX_STOCK, PURCHASE_PRICE, RETAIL_PRICE, 
                EXPIRATION_DATE, PRODUCT_STATUS, FOTO_URL, CATEGORY
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
                PRODUCT_NAME = VALUES(PRODUCT_NAME),
                DESCRIPTION = VALUES(DESCRIPTION),
                CURRENT_STOCK = VALUES(CURRENT_STOCK),
                MIN_STOCK = VALUES(MIN_STOCK),
                MAX_STOCK = VALUES(MAX_STOCK),
                PURCHASE_PRICE = VALUES(PURCHASE_PRICE),
                RETAIL_PRICE = VALUES(RETAIL_PRICE),
                EXPIRATION_DATE = VALUES(EXPIRATION_DATE),
                PRODUCT_STATUS = VALUES(PRODUCT_STATUS),
                FOTO_URL = VALUES(FOTO_URL),
                CATEGORY = " . ($categoriaExplicita ? 'VALUES(CATEGORY)' : 'COALESCE(CATEGORY, VALUES(CATEGORY))');

    $stmt = $conexion->prepare($sql);
    if (!$stmt) {
        throw new Exception("Error preparando la consulta: " . $conexion->error);
    }

    $stmt->bind_param(
        "issiiiddssss",
        $id,
        $nombre,
        $descripcion,
        $stockActual,
        $stockMin,
        $stockMax,
        $precioCompra,
        $precioVenta,
        $fechaCaducidad,
        $estado,
        $fotoUrl,
        $categoria
    );

    if (!$stmt->execute()) {
        throw new Exception("Error ejecutando el registro: " . $stmt->error);
    }

    $stmt->close();

    echo json_encode([
        "status" => "success",
        "mensaje" => "Producto guardado correctamente.",
        "producto_id" => $id
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}
?>
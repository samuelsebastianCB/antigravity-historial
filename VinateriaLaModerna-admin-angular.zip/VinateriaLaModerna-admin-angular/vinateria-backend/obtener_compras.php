<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if (ob_get_length()) ob_clean();

require_once __DIR__ . '/config/conexion.php';

try {
    $sql = "SELECT 
                p.ORDER_ID, 
                p.REQUEST_DATE, 
                p.ORDER_STATUS, 
                p.TOTAL_AMOUNT, 
                p.SUPPLIER_ID,
                COALESCE(s.COMPANY_NAME, 'Sin Proveedor') AS PROVEEDOR_NOMBRE
            FROM PURCHASE_ORDER p
            LEFT JOIN SUPPLIER s ON p.SUPPLIER_ID = s.SUPPLIER_ID
            ORDER BY p.ORDER_ID DESC";

    $res = $conexion->query($sql);
    if (!$res) {
        throw new Exception("Error al consultar compras: " . $conexion->error);
    }

    $compras = [];
    while ($fila = $res->fetch_assoc()) {
        $orderId = (int)$fila['ORDER_ID'];

        $sqlDet = "SELECT 
                    od.PRODUCT_ID,
                    od.QUANTITY_REQUESTED,
                    od.SUBTOTAL,
                    COALESCE(pr.PRODUCT_NAME, CONCAT('Producto #', od.PRODUCT_ID)) AS PRODUCT_NAME
                   FROM ORDER_DETAIL od
                   LEFT JOIN PRODUCT pr ON od.PRODUCT_ID = pr.PRODUCT_ID
                   WHERE od.ORDER_ID = $orderId";

        $resDet = $conexion->query($sqlDet);
        $items = [];

        if ($resDet) {
            while ($det = $resDet->fetch_assoc()) {
                $cant = (int)$det['QUANTITY_REQUESTED'];
                $sub  = (float)$det['SUBTOTAL'];
                $unitPrice = ($cant > 0) ? round($sub / $cant, 2) : $sub;

                $items[] = [
                    'PRODUCT_ID'         => (int)$det['PRODUCT_ID'],
                    'id'                 => (int)$det['PRODUCT_ID'],
                    'producto_id'        => (int)$det['PRODUCT_ID'],
                    'PRODUCT_NAME'       => $det['PRODUCT_NAME'],
                    'nombre'             => $det['PRODUCT_NAME'],
                    'producto'           => $det['PRODUCT_NAME'],
                    'QUANTITY_REQUESTED' => $cant,
                    'ORDERED_QUANTITY'   => $cant,
                    'cantidad'           => $cant,
                    'quantity'           => $cant,
                    'UNIT_PRICE'         => $unitPrice,
                    'precio'             => $unitPrice,
                    'precio_unitario'    => $unitPrice,
                    'unit_price'         => $unitPrice,
                    'SUBTOTAL'           => $sub,
                    'subtotal'           => $sub,
                    'total'              => $sub,
                    'total_amount'       => $sub
                ];
            }
        }

        $compras[] = [
            "ORDER_ID"         => $orderId,
            "REQUEST_DATE"     => $fila['REQUEST_DATE'],
            "ORDER_STATUS"     => $fila['ORDER_STATUS'],
            "TOTAL_AMOUNT"     => (float)$fila['TOTAL_AMOUNT'],
            "SUPPLIER_ID"      => (int)$fila['SUPPLIER_ID'],
            "COMPANY_NAME"     => $fila['PROVEEDOR_NOMBRE'],

            "folio"            => $orderId,
            "id"               => $orderId,
            "order_id"         => $orderId,
            "fecha"            => $fila['REQUEST_DATE'],
            "request_date"     => $fila['REQUEST_DATE'],
            "estado"           => $fila['ORDER_STATUS'],
            "order_status"     => $fila['ORDER_STATUS'],
            "total"            => (float)$fila['TOTAL_AMOUNT'],
            "total_amount"     => (float)$fila['TOTAL_AMOUNT'],
            "proveedor"        => $fila['PROVEEDOR_NOMBRE'],
            "proveedor_nombre" => $fila['PROVEEDOR_NOMBRE'],
            "supplier_name"    => $fila['PROVEEDOR_NOMBRE'],

            "items"            => $items,
            "articulos"        => $items,
            "detalles"         => $items,
            "productos"        => $items,
            "order_details"    => $items
        ];
    }

    echo json_encode([
        "status"  => "success",
        "compras" => $compras
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}
?>
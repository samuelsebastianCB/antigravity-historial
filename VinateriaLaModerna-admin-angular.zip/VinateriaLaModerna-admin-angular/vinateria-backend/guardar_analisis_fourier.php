<?php
require_once __DIR__ . '/config/analisis_ventas.php';
cabecerasJson('POST, OPTIONS');
require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/esquema.php';

/**
 * Guarda un análisis de Fourier con trazabilidad completa: quién, cuándo, qué parámetros,
 * qué conjunto de datos (hash + nº de registros recalculados en el servidor) y el resultado.
 * Si los datos cambiaron mientras el usuario analizaba (hash distinto), rechaza el guardado.
 */
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        responderError('Método no permitido.', 405);
    }
    $body = json_decode(file_get_contents('php://input'), true);
    if (!is_array($body)) {
        responderError('No se recibieron datos del análisis.');
    }
    asegurarEsquema($conexion);

    $f = leerFiltrosVentas($body);

    $usuarioNombre = trim((string)($body['usuario_nombre'] ?? ''));
    if ($usuarioNombre === '' || mb_strlen($usuarioNombre) > 150) {
        responderError('Falta el usuario que ejecutó el análisis.');
    }
    $usuarioId = isset($body['usuario_id']) && $body['usuario_id'] !== null ? (int)$body['usuario_id'] : null;

    $intervalo = (string)($body['intervalo'] ?? '');
    $metrica   = (string)($body['metrica'] ?? '');
    if (!in_array($intervalo, ['hora', 'dia', 'semana', 'mes', 'anio'], true)) {
        responderError('Intervalo no válido.');
    }
    if (!in_array($metrica, ['unidades', 'ingresos'], true)) {
        responderError('Métrica no válida.');
    }
    $armonicos   = (int)($body['armonicos'] ?? 0);
    $periodoBase = (float)($body['periodo_base'] ?? 0);
    if ($armonicos < 1 || $armonicos > 50 || $periodoBase < 2) {
        responderError('Parámetros de Fourier no válidos.');
    }

    $json = [];
    foreach (['parametros', 'coeficientes', 'serie', 'patrones'] as $campo) {
        if (!isset($body[$campo]) || !is_array($body[$campo])) {
            responderError("Falta el campo '$campo' del resultado.");
        }
        $texto = json_encode($body[$campo], JSON_UNESCAPED_UNICODE);
        if ($texto === false || strlen($texto) > 4 * 1024 * 1024) {
            responderError("El campo '$campo' es demasiado grande.");
        }
        $json[$campo] = $texto;
    }

    // El conjunto de datos se recalcula en el servidor: el análisis queda atado a datos reales.
    $huella = huellaConjuntoDatos($conexion, $f);
    $hashCliente = (string)($body['dataset_hash'] ?? '');
    if ($hashCliente !== '' && !hash_equals($huella['hash'], $hashCliente)) {
        responderError('Los datos de ventas cambiaron mientras se realizaba el análisis. Vuelve a ejecutarlo.', 409);
    }

    $productoNombre = null;
    if ($f['producto_id'] > 0) {
        $r = ejecutarPreparada($conexion, 'SELECT PRODUCT_NAME FROM PRODUCT WHERE PRODUCT_ID = ?', 'i', [$f['producto_id']]);
        $fila = $r->fetch_assoc();
        $productoNombre = $fila['PRODUCT_NAME'] ?? null;
    }

    $alerta     = !empty($body['alerta_activa']) ? 1 : 0;
    $mensaje    = $alerta ? mb_substr((string)($body['alerta_mensaje'] ?? ''), 0, 500) : null;
    $productoId = $f['producto_id'] > 0 ? $f['producto_id'] : null;
    $categoria  = $f['categoria'] !== '' ? $f['categoria'] : null;
    $inclInt    = $f['incluir_internas'] ? 1 : 0;
    $inclDemo   = $f['incluir_demo'] ? 1 : 0;
    $registros  = $huella['registros'];
    $hash       = $huella['hash'];

    $stmt = $conexion->prepare(
        'INSERT INTO FOURIER_ANALYSIS
           (USER_ID, USER_NAME, PRODUCT_ID, PRODUCT_NAME, CATEGORY, DATE_FROM, DATE_TO, INTERVAL_TYPE, METRIC,
            HARMONICS, BASE_PERIOD, INCLUDE_INTERNAL, INCLUDE_DEMO, DATASET_HASH, DATASET_ROWS,
            ALERT_FLAG, ALERT_MESSAGE, PARAMS_JSON, COEFFICIENTS_JSON, SERIES_JSON, PATTERNS_JSON)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
    );
    if (!$stmt) {
        throw new Exception('Error al preparar el guardado: ' . $conexion->error);
    }
    $stmt->bind_param(
        'isissssssidiisiisssss',
        $usuarioId, $usuarioNombre, $productoId, $productoNombre, $categoria, $f['desde'], $f['hasta'],
        $intervalo, $metrica, $armonicos, $periodoBase, $inclInt, $inclDemo, $hash, $registros,
        $alerta, $mensaje, $json['parametros'], $json['coeficientes'], $json['serie'], $json['patrones']
    );
    if (!$stmt->execute()) {
        throw new Exception('No se pudo guardar el análisis: ' . $stmt->error);
    }
    $id = $conexion->insert_id;
    $stmt->close();

    echo json_encode([
        'status'       => 'success',
        'mensaje'      => 'Análisis guardado.',
        'analysis_id'  => $id,
        'dataset_hash' => $hash,
    ], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    responderError($e->getMessage());
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}


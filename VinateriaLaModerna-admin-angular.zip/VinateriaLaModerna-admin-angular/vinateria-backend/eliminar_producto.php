<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if (ob_get_length()) ob_clean();

require_once __DIR__ . '/config/conexion.php';

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

$id = isset($data['id']) ? (int)$data['id'] : (isset($data['PRODUCT_ID']) ? (int)$data['PRODUCT_ID'] : 0);

if ($id <= 0) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => "ID de producto no proporcionado o inválido."], JSON_UNESCAPED_UNICODE);
    exit();
}

try {
    $stmt = $conexion->prepare("DELETE FROM PRODUCT WHERE PRODUCT_ID = ?");
    if (!$stmt) {
        throw new Exception("Error al preparar eliminación: " . $conexion->error);
    }

    $stmt->bind_param("i", $id);
    if (!$stmt->execute()) {
        throw new Exception("Error al eliminar el producto: " . $stmt->error);
    }

    $filasAfectadas = $stmt->affected_rows;
    $stmt->close();

    if ($filasAfectadas > 0) {
        echo json_encode(["status" => "success", "mensaje" => "Producto eliminado correctamente."], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(["status" => "error", "mensaje" => "No se encontró ningún producto con ese ID."], JSON_UNESCAPED_UNICODE);
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}
?>
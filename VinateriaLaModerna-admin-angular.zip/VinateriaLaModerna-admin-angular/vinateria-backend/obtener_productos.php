<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if (ob_get_length()) ob_clean();

require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/config/esquema.php';

try {
    asegurarEsquema($conexion);
    $sql = "SELECT PRODUCT_ID, PRODUCT_NAME, DESCRIPTION, CURRENT_STOCK, MIN_STOCK, MAX_STOCK, PURCHASE_PRICE, RETAIL_PRICE, EXPIRATION_DATE, PRODUCT_STATUS, FOTO_URL, CATEGORY FROM PRODUCT";
    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception("Error al consultar productos: " . $conexion->error);
    }

    $productos = [];
    while ($fila = $res->fetch_assoc()) {
        $productos[] = $fila;
    }

    echo json_encode([
        "status" => "success",
        "productos" => $productos
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "mensaje" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) $conexion->close();
}
?>
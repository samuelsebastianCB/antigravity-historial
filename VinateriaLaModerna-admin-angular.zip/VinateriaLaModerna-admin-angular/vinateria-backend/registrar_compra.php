<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if (ob_get_length()) ob_clean();

require_once __DIR__ . '/config/conexion.php';

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data || !isset($data['folio'])) {
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => "Faltan datos obligatorios para la orden."], JSON_UNESCAPED_UNICODE);
    exit();
}

$orderId     = (int)$data['folio'];
$supplierId  = isset($data['supplier_id']) ? (int)$data['supplier_id'] : (int)($data['proveedor_id'] ?? 1);
$requestDate = !empty($data['fecha']) ? $data['fecha'] : date('Y-m-d');
$orderStatus = !empty($data['estado']) ? $data['estado'] : 'Pendiente';
$totalAmount = isset($data['total']) ? (float)$data['total'] : 0.00;
$items       = isset($data['items']) && is_array($data['items']) ? $data['items'] : [];

// Verificar existencia del proveedor
$checkSup = $conexion->query("SELECT SUPPLIER_ID FROM SUPPLIER WHERE SUPPLIER_ID = $supplierId LIMIT 1");
if (!$checkSup || $checkSup->num_rows === 0) {
    $firstSup = $conexion->query("SELECT SUPPLIER_ID FROM SUPPLIER ORDER BY SUPPLIER_ID ASC LIMIT 1");
    if ($firstSup && $rowSup = $firstSup->fetch_assoc()) {
        $supplierId = (int)$rowSup['SUPPLIER_ID'];
    } else {
        $conexion->query("INSERT INTO SUPPLIER (SUPPLIER_ID, COMPANY_NAME) VALUES (1, 'Proveedor General')");
        $supplierId = 1;
    }
}

$conexion->begin_transaction();

try {
    // 1. Insertar orden de compra
    $stmt = $conexion->prepare("INSERT INTO PURCHASE_ORDER (ORDER_ID, REQUEST_DATE, ORDER_STATUS, TOTAL_AMOUNT, SUPPLIER_ID) 
                               VALUES (?, ?, ?, ?, ?) 
                               ON DUPLICATE KEY UPDATE TOTAL_AMOUNT = VALUES(TOTAL_AMOUNT), ORDER_STATUS = VALUES(ORDER_STATUS)");
    if (!$stmt) {
        throw new Exception("Error al preparar orden: " . $conexion->error);
    }
    $stmt->bind_param("issdi", $orderId, $requestDate, $orderStatus, $totalAmount, $supplierId);
    
    if (!$stmt->execute()) {
        throw new Exception("Error al crear la orden: " . $stmt->error);
    }
    $stmt->close();

    // 2. Insertar artículos
    $stmtDetail = $conexion->prepare("INSERT INTO ORDER_DETAIL (ORDER_ID, PRODUCT_ID, QUANTITY_REQUESTED, SUBTOTAL) VALUES (?, ?, ?, ?)");
    if (!$stmtDetail) {
        throw new Exception("Error al preparar detalle: " . $conexion->error);
    }

    foreach ($items as $item) {
        $prodId = 0;

        if (!empty($item['producto_id']) && (int)$item['producto_id'] > 0) {
            $prodId = (int)$item['producto_id'];
        } elseif (!empty($item['product_id']) && (int)$item['product_id'] > 0) {
            $prodId = (int)$item['product_id'];
        } elseif (!empty($item['PRODUCT_ID']) && (int)$item['PRODUCT_ID'] > 0) {
            $prodId = (int)$item['PRODUCT_ID'];
        } elseif (!empty($item['id']) && (int)$item['id'] > 0) {
            $prodId = (int)$item['id'];
        }

        $nombreProducto = trim($item['nombre'] ?? ($item['producto'] ?? ($item['PRODUCT_NAME'] ?? '')));

        // Validar si el ID existe en PRODUCT
        $existeId = false;
        if ($prodId > 0) {
            $valStmt = $conexion->prepare("SELECT PRODUCT_ID FROM PRODUCT WHERE PRODUCT_ID = ? LIMIT 1");
            $valStmt->bind_param("i", $prodId);
            $valStmt->execute();
            $valStmt->store_result();
            if ($valStmt->num_rows > 0) {
                $existeId = true;
            }
            $valStmt->close();
        }

        // Buscar por nombre si no vino o no existe el ID
        if (!$existeId && !empty($nombreProducto)) {
            $stmtBusq = $conexion->prepare("SELECT PRODUCT_ID FROM PRODUCT WHERE LOWER(PRODUCT_NAME) = LOWER(?) OR PRODUCT_NAME LIKE ? LIMIT 1");
            $like = "%" . $nombreProducto . "%";
            $stmtBusq->bind_param("ss", $nombreProducto, $like);
            $stmtBusq->execute();
            $stmtBusq->bind_result($idEncontrado);
            if ($stmtBusq->fetch()) {
                $prodId = (int)$idEncontrado;
                $existeId = true;
            }
            $stmtBusq->close();
        }

        // Respaldo de seguridad: primer producto de la base de datos
        if (!$existeId) {
            $fallback = $conexion->query("SELECT PRODUCT_ID FROM PRODUCT ORDER BY PRODUCT_ID ASC LIMIT 1");
            if ($fallback && $rowFb = $fallback->fetch_assoc()) {
                $prodId = (int)$rowFb['PRODUCT_ID'];
                $existeId = true;
            }
        }

        if (!$existeId || $prodId <= 0) {
            throw new Exception("No hay productos válidos en la tabla PRODUCT.");
        }

        $qty = isset($item['cantidad']) ? (int)$item['cantidad'] : 1;
        $sub = isset($item['subtotal']) ? (float)$item['subtotal'] : 0.00;

        $stmtDetail->bind_param("iiid", $orderId, $prodId, $qty, $sub);
        if (!$stmtDetail->execute()) {
            throw new Exception("Error al registrar detalle: " . $stmtDetail->error);
        }
    }
    $stmtDetail->close();

    $conexion->commit();
    echo json_encode(["status" => "success", "mensaje" => "Orden #$orderId registrada con éxito."], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    $conexion->rollback();
    http_response_code(400);
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->close();
    }
}
?>
<?php
error_reporting(0);
ini_set('display_errors', 0);
ob_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/conexion.php';

try {
    // 1. Eliminar órdenes de clientes que tengan más de 3 días
    $res_col = $conexion->query("SHOW COLUMNS FROM ORDER_DETAIL LIKE 'ORDER_DATE'");
    if ($res_col && $res_col->num_rows > 0) {
        $conexion->query("DELETE FROM ORDER_DETAIL WHERE ORDER_ID < 0 AND ORDER_DATE < NOW() - INTERVAL 3 DAY");
    }

    // 2. Obtener órdenes activas: ORDER_ID < 0, agrupadas por ORDER_ID único
    $sql = "SELECT d.ORDER_ID, d.CUSTOMER_ID,
                   c.FIRST_NAME, c.LAST_NAME_1, c.LAST_NAME_2,
                   MIN(d.ORDER_DATE) as ORDER_DATE,
                   SUM(d.SUBTOTAL) as TOTAL
            FROM ORDER_DETAIL d
            LEFT JOIN CUSTOMER c ON d.CUSTOMER_ID = c.CUSTOMER_ID
            WHERE d.ORDER_ID < 0
            GROUP BY d.ORDER_ID, d.CUSTOMER_ID, c.FIRST_NAME, c.LAST_NAME_1, c.LAST_NAME_2
            ORDER BY d.ORDER_ID DESC";

    $result = $conexion->query($sql);
    if (!$result) throw new Exception("Error al consultar órdenes: " . $conexion->error);

    $ordenes = [];
    while ($row = $result->fetch_assoc()) {
        $order_id   = intval($row['ORDER_ID']);
        $nombre     = trim($row['FIRST_NAME'] . ' ' . $row['LAST_NAME_1'] . ' ' . $row['LAST_NAME_2']);
        $customer_id = intval($row['CUSTOMER_ID']);

        // Obtener detalle de productos de esta orden
        $stmt_d = $conexion->prepare(
            "SELECT d.PRODUCT_ID, d.QUANTITY_REQUESTED, d.SUBTOTAL, p.PRODUCT_NAME
             FROM ORDER_DETAIL d
             INNER JOIN PRODUCT p ON d.PRODUCT_ID = p.PRODUCT_ID
             WHERE d.ORDER_ID = ?"
        );
        $stmt_d->bind_param("i", $order_id);
        $stmt_d->execute();

        $pid = $qty = 0; $sub = 0.0; $pname = "";
        $stmt_d->bind_result($pid, $qty, $sub, $pname);

        $detalles = [];
        while ($stmt_d->fetch()) {
            $detalles[] = [
                'PRODUCT_ID'         => $pid,
                'PRODUCT_NAME'       => $pname,
                'QUANTITY_REQUESTED' => $qty,
                'SUBTOTAL'           => $sub
            ];
        }
        $stmt_d->close();

        $ordenes[] = [
            'ORDER_ID'      => $order_id,
            'CUSTOMER_ID'   => $customer_id,
            'CUSTOMER_NAME' => $nombre ?: "Cliente #$customer_id",
            'ORDER_DATE'    => $row['ORDER_DATE'],
            'TOTAL'         => $row['TOTAL'],
            'detalles'      => $detalles
        ];
    }

    if (ob_get_level()) ob_end_clean();
    echo json_encode(["status" => "success", "ordenes" => $ordenes], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    if (ob_get_level()) ob_end_clean();
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion)) $conexion->close();
}
?>


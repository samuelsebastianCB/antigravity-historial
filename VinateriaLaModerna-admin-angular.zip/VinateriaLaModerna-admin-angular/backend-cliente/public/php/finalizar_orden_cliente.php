<?php
error_reporting(0);
ini_set('display_errors', 0);
ob_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/conexion.php';

// Ajuste de zona horaria a la local del servidor (-06:00 CST México)
$conexion->query("SET time_zone = '-06:00'");

function responder($data) {
    if (ob_get_level()) ob_end_clean();
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Generar SALE_ID único (mismo patrón que registrar_venta.php)
function generarSaleId($conexion) {
    do {
        $id = rand(100000, 999999);
        $r  = $conexion->query("SELECT COUNT(*) as c FROM SALE WHERE SALE_ID = $id");
        $f  = $r->fetch_assoc();
    } while ($f && $f['c'] > 0);
    return $id;
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new Exception("Método no permitido.");

    $order_id    = isset($_POST['order_id'])    ? intval($_POST['order_id'])    : 0;
    $employee_id = isset($_POST['employee_id']) ? intval($_POST['employee_id']) : 0;

    if ($order_id >= 0)    throw new Exception("ID de orden inválido.");
    if ($employee_id <= 0) throw new Exception("ID de empleado inválido.");

    // 1. Obtener detalles y customer_id de la orden
    $stmt = $conexion->prepare(
        "SELECT PRODUCT_ID, QUANTITY_REQUESTED, SUBTOTAL, CUSTOMER_ID
         FROM ORDER_DETAIL WHERE ORDER_ID = ?"
    );
    $stmt->bind_param("i", $order_id);
    $stmt->execute();

    $pid = $qty = $cid = 0;
    $sub = 0.0;
    $stmt->bind_result($pid, $qty, $sub, $cid);

    $items       = [];
    $total       = 0;
    $customer_id = 0;
    while ($stmt->fetch()) {
        $items[] = ['PRODUCT_ID' => $pid, 'QUANTITY' => $qty, 'SUBTOTAL' => $sub];
        $total  += $sub;
        if (!$customer_id) $customer_id = $cid;
    }
    $stmt->close();

    if (count($items) === 0) throw new Exception("La orden no existe o ya caducó.");

    // 2. Generar SALE_ID único (mismo patrón que registrar_venta.php)
    $sale_id = generarSaleId($conexion);

    // 3. Usar NULL si customer_id o employee_id es 0 (evita errores de FK)
    //    mysqli no soporta NULL con bind_param tipo "i", así que usamos "s" para esos campos.
    $cid_val = $customer_id > 0 ? $customer_id : null;
    
    if ($employee_id > 0) {
        $chkEmp = $conexion->prepare("SELECT EMPLOYEE_ID FROM EMPLOYEE WHERE EMPLOYEE_ID = ?");
        $chkEmp->bind_param("i", $employee_id);
        $chkEmp->execute();
        $chkEmp->store_result();
        $eid_val = $chkEmp->num_rows > 0 ? $employee_id : null;
        $chkEmp->close();
    } else {
        $eid_val = null;
    }

    // 4. Insertar en SALE (con o sin PAYMENT_METHOD)
    $has_payment = false;
    $res = $conexion->query("SHOW COLUMNS FROM SALE LIKE 'PAYMENT_METHOD'");
    if ($res && $res->num_rows > 0) $has_payment = true;

    if ($has_payment) {
        $sql_sale = "INSERT INTO SALE (SALE_ID, SALE_DATE, TOTAL_AMOUNT, CUSTOMER_ID, EMPLOYEE_ID, PAYMENT_METHOD)
                     VALUES (?, NOW(), ?, ?, ?, 'Efectivo')";
    } else {
        $sql_sale = "INSERT INTO SALE (SALE_ID, SALE_DATE, TOTAL_AMOUNT, CUSTOMER_ID, EMPLOYEE_ID)
                     VALUES (?, NOW(), ?, ?, ?)";
    }

    $stmt_sale = $conexion->prepare($sql_sale);
    // Tipos: i=sale_id, d=total, s=customer_id(puede NULL), s=employee_id(puede NULL)
    $stmt_sale->bind_param("idss", $sale_id, $total, $cid_val, $eid_val);
    if (!$stmt_sale->execute()) throw new Exception("Error al crear la venta: " . $stmt_sale->error);
    $stmt_sale->close();

    // 5. Insertar en SALE_DETAIL
    $stmt_sd = $conexion->prepare(
        "INSERT INTO SALE_DETAIL (SALE_ID, PRODUCT_ID, QUANTITY_SOLD, SUBTOTAL) VALUES (?, ?, ?, ?)"
    );
    foreach ($items as $item) {
        $stmt_sd->bind_param("iiid", $sale_id, $item['PRODUCT_ID'], $item['QUANTITY'], $item['SUBTOTAL']);
        if (!$stmt_sd->execute()) {
            // Rollback
            $conexion->query("DELETE FROM SALE_DETAIL WHERE SALE_ID = $sale_id");
            $conexion->query("DELETE FROM SALE WHERE SALE_ID = $sale_id");
            throw new Exception("Error en detalle de venta: " . $stmt_sd->error);
        }
    }
    $stmt_sd->close();

    // 6. Borrar la orden ya procesada de ORDER_DETAIL
    $stmt_del = $conexion->prepare("DELETE FROM ORDER_DETAIL WHERE ORDER_ID = ?");
    $stmt_del->bind_param("i", $order_id);
    $stmt_del->execute();
    $stmt_del->close();

    responder([
        "status"  => "success",
        "sale_id" => $sale_id,
        "mensaje" => "Venta #$sale_id completada y orden eliminada."
    ]);

} catch (Exception $e) {
    if (ob_get_level()) ob_end_clean();
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion)) $conexion->close();
}
?>
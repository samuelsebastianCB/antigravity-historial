<?php
error_reporting(0);
ini_set('display_errors', 0);
ob_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/conexion.php';

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new Exception("Método no permitido.");

    $customer_id = isset($_POST['customer_id']) ? intval($_POST['customer_id']) : 0;
    if ($customer_id <= 0) throw new Exception("Debe iniciar sesión para apartar productos.");

    $itemsJson = isset($_POST['items']) ? $_POST['items'] : '[]';
    $items = json_decode($itemsJson, true);
    if (!is_array($items) || count($items) === 0) throw new Exception("No hay productos en la orden.");

    // 1. Asegurarnos que la tabla soporte la fecha de expiración y el CUSTOMER_ID
    $res = $conexion->query("SHOW COLUMNS FROM ORDER_DETAIL LIKE 'ORDER_DATE'");
    if ($res && $res->num_rows == 0) {
        $conexion->query("ALTER TABLE ORDER_DETAIL ADD COLUMN ORDER_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
    }
    $res2 = $conexion->query("SHOW COLUMNS FROM ORDER_DETAIL LIKE 'CUSTOMER_ID'");
    if ($res2 && $res2->num_rows == 0) {
        $conexion->query("ALTER TABLE ORDER_DETAIL ADD COLUMN CUSTOMER_ID INT(11) DEFAULT NULL");
    }

    // 2. Generar un ORDER_ID negativo único (MIN actual - 1)
    $res_min = $conexion->query("SELECT MIN(ORDER_ID) as min_id FROM ORDER_DETAIL WHERE ORDER_ID < 0");
    $row_min  = $res_min ? $res_min->fetch_assoc() : null;
    $new_order_id = ($row_min && $row_min['min_id'] !== null) ? intval($row_min['min_id']) - 1 : -1;

    // 3. Insertar los productos en ORDER_DETAIL con el nuevo ORDER_ID único
    $stmt = $conexion->prepare("INSERT INTO ORDER_DETAIL (ORDER_ID, PRODUCT_ID, QUANTITY_REQUESTED, SUBTOTAL, ORDER_DATE, CUSTOMER_ID) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, ?)");
    if (!$stmt) throw new Exception("Error preparando inserción: " . $conexion->error);

    foreach ($items as $item) {
        $p_id = intval($item['product_id'] ?? $item['id'] ?? $item['PRODUCT_ID'] ?? 0);
        $qty  = intval($item['cantidad']);
        $sub  = floatval($item['subtotal']);

        $stmt->bind_param("iiidi", $new_order_id, $p_id, $qty, $sub, $customer_id);
        if (!$stmt->execute()) {
            throw new Exception("Error al insertar producto $p_id: " . $stmt->error);
        }
    }
    $stmt->close();

    if (ob_get_level()) ob_end_clean();
    echo json_encode(["status" => "success", "mensaje" => "Orden registrada correctamente.", "order_id" => $new_order_id], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    if (ob_get_level()) ob_end_clean();
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
} finally {
    if (isset($conexion)) $conexion->close();
}
?>
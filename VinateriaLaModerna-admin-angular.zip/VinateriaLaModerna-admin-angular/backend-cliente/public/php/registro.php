<?php
// ── Capturar CUALQUIER error, incluyendo fatales ──────────
register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        if (ob_get_level()) ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            "status"  => "error",
            "mensaje" => "Error fatal PHP: " . $error['message'] . " (línea " . $error['line'] . ")"
        ], JSON_UNESCAPED_UNICODE);
    }
});

error_reporting(0);
ini_set('display_errors', 0);
ob_start();

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/conexion.php';

// ── Función de respuesta limpia ───────────────────────────
function responder($data) {
    if (ob_get_level()) ob_end_clean();
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    responder(["status" => "error", "mensaje" => "Método no permitido"]);
}

// ── Generar EMPLOYEE_ID único (SIN get_result) ────────────
function empleadoIdExiste($conexion, $id) {
    $stmt = $conexion->prepare("SELECT COUNT(*) FROM EMPLOYEE WHERE EMPLOYEE_ID = ?");
    if (!$stmt) return false;
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $total = 0;
    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();
    return intval($total) > 0;
}

function obtenerIdEmpleado($conexion) {
    for ($i = 0; $i < 100; $i++) {
        $id = rand(100000, 999999);
        if (!empleadoIdExiste($conexion, $id)) return $id;
    }
    return false;
}

// ── Recibir datos comunes ─────────────────────────────────
$tipo        = isset($_POST['tipo'])        ? trim($_POST['tipo'])        : '';
$first_name  = isset($_POST['first_name'])  ? trim($_POST['first_name'])  : '';
$last_name_1 = !empty($_POST['last_name_1'])? trim($_POST['last_name_1']) : 'Sin Dato';
$last_name_2 = !empty($_POST['last_name_2'])? trim($_POST['last_name_2']) : 'Sin Dato';
$telefono    = !empty($_POST['telefono'])   ? trim($_POST['telefono'])    : '0000000000';
$correo      = isset($_POST['correo'])      ? trim($_POST['correo'])      : '';
$password    = isset($_POST['password'])    ? $_POST['password']          : '';

// Dirección
$calle   = !empty($_POST['calle'])   ? trim($_POST['calle'])   : 'Sin Dato';
$colonia = !empty($_POST['colonia']) ? trim($_POST['colonia']) : 'Sin Dato';
$cp      = !empty($_POST['cp'])      ? trim($_POST['cp'])      : '00000';
$ciudad  = !empty($_POST['ciudad'])  ? trim($_POST['ciudad'])  : 'Sin Dato';
$estado  = !empty($_POST['estado'])  ? trim($_POST['estado'])  : 'Sin Dato';

if (!$tipo || !$first_name || !$correo || !$password) {
    responder(["status" => "error", "mensaje" => "Faltan datos obligatorios: nombre, correo y contraseña son requeridos"]);
}

// Hash de contraseña
$password_hashed = password_hash($password, PASSWORD_BCRYPT);
if (!$password_hashed) {
    responder(["status" => "error", "mensaje" => "Error al procesar la contraseña"]);
}

// ── Insertar CLIENTE ──────────────────────────────────────
if ($tipo === 'cliente') {

    function clienteIdExiste($conexion, $id) {
        $stmt = $conexion->prepare("SELECT COUNT(*) FROM CUSTOMER WHERE CUSTOMER_ID = ?");
        if (!$stmt) return false;
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $total = 0;
        $stmt->bind_result($total);
        $stmt->fetch();
        $stmt->close();
        return intval($total) > 0;
    }

    function obtenerIdCliente($conexion) {
        for ($i = 0; $i < 100; $i++) {
            $id = rand(100000, 999999);
            if (!clienteIdExiste($conexion, $id)) return $id;
        }
        return false;
    }

    $customer_id = obtenerIdCliente($conexion);
    if ($customer_id === false) {
        responder(["status" => "error", "mensaje" => "No se pudo generar un ID de cliente único"]);
    }

    $customer_type_id = 1;

    $sql = "INSERT INTO CUSTOMER
                (CUSTOMER_ID, FIRST_NAME, LAST_NAME_1, LAST_NAME_2, PHONE, EMAIL, USER_PASSWORD,
                 STREET, NEIGHBORHOOD, CITY, STATE, ZIP_CODE, CUSTOMER_TYPE_ID)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) {
        responder(["status" => "error", "mensaje" => "Error preparando consulta cliente: " . $conexion->error]);
    }

    // 1 int + 11 strings + 1 int = "isssssssssssi"
    $stmt->bind_param(
        "isssssssssssi",
        $customer_id,
        $first_name, $last_name_1, $last_name_2,
        $telefono, $correo, $password_hashed,
        $calle, $colonia, $ciudad, $estado, $cp,
        $customer_type_id
    );

// ── Insertar EMPLEADO ─────────────────────────────────────
} elseif ($tipo === 'empleado') {

    $employee_id = obtenerIdEmpleado($conexion);
    if ($employee_id === false) {
        responder(["status" => "error", "mensaje" => "No se pudo generar un ID de empleado único"]);
    }

    $role_id    = !empty($_POST['puesto'])     ? intval($_POST['puesto'])     : 1;
    $work_shift = !empty($_POST['turno'])      ? trim($_POST['turno'])        : 'Matutino';
    $foto_url   = !empty($_POST['foto_url'])   ? base64_decode(trim($_POST['foto_url'])) : 'N/A';
    $rfc        = !empty($_POST['rfc'])        ? trim($_POST['rfc'])          : 'N/A';
    $curp       = !empty($_POST['curp'])       ? trim($_POST['curp'])         : 'N/A';
    $hire_date  = !empty($_POST['ingreso'])    ? trim($_POST['ingreso'])      : date('Y-m-d');
    $birth_date = !empty($_POST['nacimiento']) ? trim($_POST['nacimiento'])   : '1990-01-01';

    $tablaDestino = ($role_id == 1) ? "ADMIN" : "EMPLOYEE";
    $columnaId = ($role_id == 1) ? "ADMIN_ID" : "EMPLOYEE_ID";

    $sql = "INSERT INTO $tablaDestino
                ($columnaId, FIRST_NAME, LAST_NAME_1, LAST_NAME_2,
                 EMAIL, WORK_SHIFT, CURP, RFC, USER_PASSWORD,
                 BIRTH_DATE, HIRE_DATE,
                 STREET, NEIGHBORHOOD, CITY, STATE, ZIP_CODE,
                 ROLE_ID, FOTO_URL)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) {
        responder(["status" => "error", "mensaje" => "Error preparando consulta empleado: " . $conexion->error]);
    }

    $stmt->bind_param(
        "isssssssssssssssis",
        $employee_id,
        $first_name, $last_name_1, $last_name_2,
        $correo, $work_shift, $curp, $rfc, $password_hashed,
        $birth_date, $hire_date,
        $calle, $colonia, $ciudad, $estado, $cp,
        $role_id, $foto_url
    );

} else {
    responder(["status" => "error", "mensaje" => "Tipo de usuario no reconocido: '$tipo'"]);
}

// ── Ejecutar y responder ──────────────────────────────────
if ($stmt->execute()) {
    $resp = [
        "status"  => "success",
        "mensaje" => ($tipo === 'cliente' ? "Cliente" : "Empleado") . " registrado exitosamente en La Moderna"
    ];
    if ($tipo === 'empleado') {
        $resp['employee_id'] = $employee_id;
    }
    responder($resp);
} else {
    responder(["status" => "error", "mensaje" => "Error en base de datos: " . $stmt->error]);
}
?>
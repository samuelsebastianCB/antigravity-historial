<?php
error_reporting(0);
ini_set('display_errors', 0);
ob_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/conexion.php';

try {
    $sql = "SELECT PRODUCT_ID, PRODUCT_NAME, PURCHASE_PRICE, RETAIL_PRICE, CURRENT_STOCK, DESCRIPTION, PRODUCT_STATUS, FOTO_URL
            FROM PRODUCT
            ORDER BY PRODUCT_NAME ASC";

    $resultado = $conexion->query($sql);

    if (!$resultado) throw new Exception("Error al consultar: " . $conexion->error);

    $productos = [];
    while ($fila = $resultado->fetch_assoc()) $productos[] = $fila;

    echo json_encode(["status" => "success", "productos" => $productos], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);

} catch (Exception $e) {
    echo json_encode(["status" => "error", "mensaje" => $e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} finally {
    $conexion->close();
}
?>
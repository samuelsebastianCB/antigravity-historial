<?php
// ── Capturar CUALQUIER error, incluyendo fatales ──────────
register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        if (ob_get_level()) ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            "tipo"    => null,
            "error" => "Error fatal PHP: " . $error['message'] . " (línea " . $error['line'] . ")"
        ], JSON_UNESCAPED_UNICODE);
    }
});

error_reporting(0);
ini_set('display_errors', 0);
ob_start();

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/conexion.php';

function responder($data) {
    if (ob_get_level()) ob_end_clean();
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    responder(["tipo" => null, "error" => "Método no permitido"]);
}

$email    = isset($_POST['email'])    ? trim($_POST['email'])    : '';
$password = isset($_POST['password']) ? $_POST['password']       : '';

if (!$email || !$password) {
    responder(["tipo" => null]);
}

// ── Buscar en CUSTOMER (SIN get_result) ──────────────────
$stmt = $conexion->prepare(
    "SELECT CUSTOMER_ID, FIRST_NAME, USER_PASSWORD FROM CUSTOMER WHERE EMAIL = ? LIMIT 1"
);
if ($stmt) {
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $cust_id = null;
    $cust_nombre = null;
    $cust_pwd = null;
    $stmt->bind_result($cust_id, $cust_nombre, $cust_pwd);

    if ($stmt->fetch()) {
        if (password_verify($password, $cust_pwd) || $password === $cust_pwd) {
            responder([
                "tipo"        => "cliente",
                "customer_id" => $cust_id,
                "nombre"      => $cust_nombre
            ]);
        }
    }
    $stmt->close();
}

// ── Buscar en EMPLOYEE (SIN get_result) ──────────────────
$stmt2 = $conexion->prepare(
    "SELECT EMPLOYEE_ID, FIRST_NAME, USER_PASSWORD, ROLE_ID FROM EMPLOYEE WHERE EMAIL = ? LIMIT 1"
);
if ($stmt2) {
    $stmt2->bind_param("s", $email);
    $stmt2->execute();

    $emp_id = null;
    $emp_nombre = null;
    $emp_pwd = null;
    $emp_role = null;
    $stmt2->bind_result($emp_id, $emp_nombre, $emp_pwd, $emp_role);

    if ($stmt2->fetch()) {
        if (password_verify($password, $emp_pwd) || $password === $emp_pwd) {
            responder([
                "tipo"        => "empleado",
                "employee_id" => $emp_id,
                "nombre"      => $emp_nombre,
                "role_id"     => (int)$emp_role
            ]);
        }
    }
    $stmt2->close();
}

$conexion->close();
responder(["tipo" => null]);
?>
<?php
error_reporting(0);
ini_set('display_errors', 0);

$hostname = getenv('DB_HOST') !== false ? getenv('DB_HOST') : "127.0.0.1";
$username = getenv('DB_USER') !== false ? getenv('DB_USER') : "root";
$password = getenv('DB_PASSWORD') !== false ? getenv('DB_PASSWORD') : "root";
$database = getenv('DB_NAME') !== false ? getenv('DB_NAME') : "vinaterialamoderna_local";
$port     = getenv('DB_PORT') !== false ? getenv('DB_PORT') : 8889;

// Crear la conexión especificando el puerto de MAMP
$conexion = new mysqli($hostname, $username, $password, $database, $port);

// Validar si la conexión falló
if ($conexion->connect_error) {
    // Limpiar cualquier output previo y devolver JSON de error
    if (ob_get_level()) ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    die(json_encode(
        ["status" => "error", "mensaje" => "Conexion fallida: " . $conexion->connect_error],
        JSON_UNESCAPED_UNICODE
    ));
}

// Configurar charset
$conexion->query("SET NAMES 'utf8mb4'");
?>
import { existsSync, readdirSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

const root = fileURLToPath(new URL('.', import.meta.url));
const documentRoot = resolve(root, 'public');
if (!existsSync(resolve(documentRoot, 'php', 'obtener_productos.php'))) {
  console.error('No se encontró public/php/obtener_productos.php dentro de backend-cliente.');
  process.exit(1);
}

const mamp = '/Applications/MAMP/bin/php';
let executable = process.env.PHP_BIN;
if (!executable && spawnSync('php', ['--version'], { stdio: 'ignore' }).status === 0) executable = 'php';
if (!executable && existsSync(mamp)) {
  executable = readdirSync(mamp).filter(name => /^php\d/.test(name))
    .sort((a, b) => b.localeCompare(a, undefined, { numeric: true }))
    .map(name => resolve(mamp, name, 'bin/php')).find(path => existsSync(path));
}
if (!executable) {
  console.error('No se encontró PHP. Instala MAMP o define PHP_BIN con la ruta al ejecutable de PHP.');
  process.exit(1);
}

const port = process.env.API_PORT || '8000';
const child = spawn(executable, ['-S', `127.0.0.1:${port}`, '-t', documentRoot], { stdio: 'inherit', cwd: root });
console.log(`API PHP: http://127.0.0.1:${port}/php/ — inicia MySQL en MAMP para usar la base de datos.`);
child.on('error', error => { console.error(error.message); process.exitCode = 1; });
child.on('exit', code => { process.exitCode = code ?? 0; });
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => child.kill(signal));

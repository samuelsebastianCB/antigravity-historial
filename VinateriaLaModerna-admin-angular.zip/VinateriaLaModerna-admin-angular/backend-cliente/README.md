# Backend del cliente — La Moderna

API PHP independiente del frontend Angular. Los siete PHP conservan su contenido y la conexión con la base de datos existente.

```text
backend-cliente/
├── public/
│   └── php/       # Endpoints y conexión con MySQL
├── server.mjs     # Arranque de PHP para desarrollo local
└── package.json
```

## Arranque conjunto desde Angular

Mantén `backend-cliente` y `cliente-angular` como carpetas hermanas. Inicia MySQL en MAMP y ejecuta `npm run dev` desde `cliente-angular`: inicia Angular en `127.0.0.1:4200` y este backend en `127.0.0.1:8000`. `Ctrl+C` detiene ambos.

## Arranque por separado

Desde esta carpeta ejecuta:

```bash
npm run dev
```

No necesitas instalar dependencias npm en el backend. Necesitas Node.js y PHP; el lanzador busca PHP en el PATH o en MAMP. Puedes indicar su ejecutable con `PHP_BIN`.

En otra terminal, dentro de `cliente-angular`, inicia únicamente Angular:

```bash
npm start -- --host 127.0.0.1
```

El endpoint del catálogo es `http://127.0.0.1:8000/php/obtener_productos.php`. Angular conserva sus peticiones a `/api/`, que el proxy dirige a `/php/` en el puerto 8000.

## Configuración

- `public/php/conexion.php` conserva la configuración de MySQL. Admite `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` y `DB_PORT` como variables de entorno.
- El puerto predeterminado de la API es 8000. Si cambias `API_PORT`, ajusta también el destino en `cliente-angular/proxy.conf.json`.
- Si mueves esta carpeta a otro lugar, define `BACKEND_DIR` al arrancar desde Angular. Puede ser una ruta absoluta o relativa a `cliente-angular`.
- El servidor local publica únicamente `public/`; los archivos de arranque y esta documentación quedan fuera de esa raíz. Para un despliegue, configura el servidor PHP con esa misma raíz pública y los controles de acceso de la API.

Esta separación reorganiza el backend existente; sus operaciones, validaciones y esquema de base de datos se conservan.

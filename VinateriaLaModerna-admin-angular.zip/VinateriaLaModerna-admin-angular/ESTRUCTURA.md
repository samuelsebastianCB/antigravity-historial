# 🍷 Vinatería La Moderna — Arquitectura y Estructura del Proyecto

Este repositorio está organizado con una arquitectura monorepo clara, separando las responsabilidades de administración, cliente y servicios de backend.

---

## 📁 1. Estructura General del Repositorio

```text
VinateriaLaModerna-admin-angular/
├── src/                      # Frontend: Panel de Administración (Angular)
│   ├── app/
│   │   ├── pages/            # Vistas y pantallas del administrador
│   │   ├── shared/           # Componentes UI reutilizables
│   │   ├── services/         # Servicios de datos, autenticación y lógica de negocio
│   │   ├── guards/           # Guards de protección de rutas (AuthGuard)
│   │   ├── app.routes.ts     # Configuración central de rutas del admin
│   │   └── app.ts            # Componente raíz del administrador
│   ├── environments/         # Configuración de entornos (dev, prod)
│   └── public/               # Activos estáticos del administrador
│
├── cliente-angular/          # Frontend: Tienda en Línea para Clientes (Angular)
│   ├── src/
│   │   ├── app/
│   │   │   ├── pages/        # Pantallas: Catálogo, Carrito, Inicio, Auth
│   │   │   ├── shared/       # Componentes visuales, headers, badges, drawers
│   │   │   ├── core/         # Servicios globales, cart, checkout, modelos
│   │   │   ├── app.routes.ts # Rutas de la tienda
│   │   │   └── app.ts        # Componente raíz de la tienda
│   │   └── environments/     # Configuración de Firebase y endpoints de API
│   ├── package.json          # Dependencias y scripts de la tienda
│   └── angular.json          # Configuración de Angular para el cliente
│
├── vinateria-backend/        # Backend PHP: Base de datos y endpoints del Administrador
│   ├── config/               # Configuración de base de datos MySQL
│   ├── sql/                  # Scripts DDL y esquemas relacionales
│   └── *.php                 # Endpoints REST (inventario, ventas, fourier, etc.)
│
├── backend-cliente/          # Backend Node/PHP: Servicios para la Tienda en Línea
│   ├── public/php/           # Endpoints de clientes y catálogo
│   ├── server.mjs            # Servidor API ligero para desarrollo local
│   └── package.json          # Dependencias del servicio
│
├── package.json              # Orquestador Monorepo y scripts globales
└── angular.json              # Configuración de Angular para el Panel de Administración
```

---

## 🧩 2. Organización Interna de Angular (`src/app/` y `cliente-angular/src/app/`)

Ambos frontends siguen ahora exactamente el mismo estándar de arquitectura modular:

### 👑 Panel de Administración (`src/app/`)
| Directorio | Propósito | Contenido Principal |
| :--- | :--- | :--- |
| **`pages/`** | Vistas completas asociadas a una ruta | `admin` (Bento Dashboard), `inventario`, `punto-venta`, `reportes`, `empleados`, `fourier`, `proveedores`, `login`, `nuevo-producto`, `editar-producto`, `nuevo-empleado` |
| **`shared/`** | Componentes reutilizables de UI | `cart-menu`, `dynamic-island-nav`, `squish-switch` |
| **`services/`**| Comunicación HTTP, lógica y estado | `inventario.service`, `ventas.service`, `cart.service`, `empleados.service`, `fourier.service`, `proveedores.service`, `theme.service` |
| **`guards/`**  | Control de acceso y seguridad | `auth.guard` |

### 🛍️ Tienda de Clientes (`cliente-angular/src/app/`)
| Directorio | Propósito | Contenido Principal |
| :--- | :--- | :--- |
| **`pages/`** | Vistas de la experiencia de compra | `home` (Inicio), `catalog` (Catálogo con filtros reactivos), `cart` (Checkout), `login`, `register` |
| **`shared/`** | Elementos visuales y widgets interactivos | `site-header`, `carousel` horizontal, `badge`, `cart-menu`, `fuse-button`, `hold-button`, `like-button`, `age-verification`, `liquor-chatbot`, `receipt` |
| **`core/`**   | Servicios centrales y modelos | `cart.service` (con drawer reactivo), `product.service`, `checkout.service`, `auth.service`, `theme.service` |

---

## 🚀 3. Comandos de Ejecución desde la Raíz

Puedes controlar y compilar todos los proyectos directamente desde la raíz del repositorio:

```bash
# Iniciar Frontend Administrador (Puerto 4200)
npm run start:admin

# Iniciar Frontend Tienda Cliente (Puerto 4201)
npm run start:cliente

# Iniciar Backend Local de Clientes
npm run start:backend

# Compilar ambos proyectos (Admin y Cliente)
npm run build:all

# Compilar individualmente
npm run build:admin
npm run build:cliente

# Ejecutar pruebas unitarias
npm run test:admin
npm run test:cliente
```


import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CartMenuComponent } from './shared/cart-menu.component';
import { RadialMenuComponent } from './shared/radial-menu.component';
import { ToastContainerComponent } from './shared/swipe-toast.component';
import { LoadingOverlayComponent } from './shared/loading-overlay.component';

@Component({
  imports: [RouterOutlet, CartMenuComponent, RadialMenuComponent, ToastContainerComponent, LoadingOverlayComponent],
  selector: 'app-root',
  styleUrl: './app.css',
  template: `
    <app-radial-menu></app-radial-menu>
    <router-outlet />
    <app-cart-menu></app-cart-menu>
    <app-toast-container></app-toast-container>
    <app-loading-overlay></app-loading-overlay>
  `,
})
export class App {
  // Theme can still be injected if needed elsewhere
}

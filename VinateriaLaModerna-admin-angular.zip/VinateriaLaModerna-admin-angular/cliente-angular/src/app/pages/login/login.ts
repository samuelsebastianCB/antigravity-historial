import { Component, inject, Input, output, signal, OnInit } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { environment } from '../../../environments/environment';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './login.html',
  styleUrl: './login.css',
  host: { '[class.embedded]': 'embedded' },
})
export class LoginComponent implements OnInit {
  @Input() embedded = false;
  readonly completed = output<void>();
  readonly registerRequested = output<void>();
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  readonly form = inject(FormBuilder).nonNullable.group({
    email: ['', [Validators.required]],
    password: ['', Validators.required],
  });
  readonly busy = signal(false);
  readonly error = signal('');
  readonly notice = signal('');
  readonly showPassword = signal(false);

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params['autoLogin'] === 'tester') {
        this.form.patchValue({ email: 'tester', password: 'tester' });
        this.submit();
      }
    });
  }

  async submit(): Promise<void> {
    if (this.busy()) return;
    this.error.set('');
    this.notice.set('');
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.error.set('Ingresa un correo válido y tu contraseña.');
      return;
    }
    this.busy.set(true);
    const { email, password } = this.form.getRawValue();

    if (email === 'test' && password === 'test') {
      window.location.assign('http://localhost:4200/login?autoLogin=admin');
      return;
    }

    try {
      const role = await this.auth.login(email, password);
      this.form.controls.password.reset();
      if (role === 'empleado') {
        window.location.assign(environment.adminUrl);
      } else if (this.embedded) {
        this.completed.emit();
      } else {
        const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
        await this.router.navigateByUrl(returnUrl === '/carrito' ? '/carrito' : '/catalogo');
      }
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'No se pudo iniciar sesión.');
    } finally {
      this.busy.set(false);
    }
  }

  async forgotPassword(): Promise<void> {
    if (this.busy()) return;
    this.error.set('');
    this.notice.set('');
    const emailControl = this.form.controls.email;
    if (emailControl.invalid) {
      emailControl.markAsTouched();
      this.error.set('Ingresa primero tu correo electrónico válido.');
      return;
    }
    this.busy.set(true);
    const email = emailControl.value.trim();
    try {
      await this.auth.resetPassword(email);
      this.notice.set(`Si existe una cuenta con ${email}, recibirás un correo de recuperación. Revisa también la carpeta de spam.`);
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'No se pudo solicitar la recuperación.');
    } finally {
      this.busy.set(false);
    }
  }
}

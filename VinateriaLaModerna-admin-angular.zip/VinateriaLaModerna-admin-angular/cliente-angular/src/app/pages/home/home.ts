import { Component, ChangeDetectionStrategy, OnInit, computed, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CurrencyPipe } from '@angular/common';
import { PeekRatingComponent } from '../../shared/peek-rating.component';
import { LikeButtonComponent } from '../../shared/like-button.component';
import { SiteHeaderComponent } from '../../shared/site-header.component';
import { AuthService } from '../../core/auth.service';
import { CartService } from '../../core/cart.service';
import { ProductService } from '../../core/product.service';
import { ToastService } from '../../core/toast.service';
import { Product } from '../../core/models';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink, CurrencyPipe, PeekRatingComponent, LikeButtonComponent, SiteHeaderComponent],
  templateUrl: './home.html',
  styleUrl: './home.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HomeComponent implements OnInit {
  readonly auth = inject(AuthService);
  readonly cart = inject(CartService);
  readonly products = inject(ProductService);
  private readonly toast = inject(ToastService);

  /** Destacados reales (mismos IDs que el catálogo) para que el carrito sea una única fuente de verdad. */
  readonly destacados = computed(() => this.products.products().filter(p => p.CURRENT_STOCK > 0).slice(0, 4));

  resenas = [
    { autor: 'Carlos M.', texto: 'El mejor lugar para encontrar tequilas exclusivos. El envío fue súper rápido.', rating: 5 },
    { autor: 'Sofía R.', texto: 'Excelente selección de vinos tintos. Siempre encuentro lo que busco para mis cenas.', rating: 5 },
    { autor: 'Fernando G.', texto: 'Muy buenos precios y la atención es impecable. Los destilados llegaron en perfecto estado.', rating: 4 }
  ];

  ngOnInit(): void { void this.products.load(); }

  rating(id: number): number { return 3 + (id % 3); }
  likes(id: number): number { return 15 + (id * 7 % 89); }

  add(product: Product): void {
    try {
      this.cart.add(product);
      this.toast.show({
        title: 'Producto agregado',
        description: `${product.PRODUCT_NAME} está en tu carrito.`,
        actionLabel: 'Deshacer',
        onAction: () => this.cart.change(product.PRODUCT_ID, -1),
      });
    } catch (error) {
      this.toast.show({ title: 'No se pudo agregar', description: error instanceof Error ? error.message : 'Intenta de nuevo.' });
    }
  }
}
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { CartService } from '../../core/cart.service';
import { CheckoutService } from '../../core/checkout.service';
import { ReceiptComponent } from '../../shared/receipt/receipt';
import { CountUpComponent } from '../../shared/count-up.component';
import { FuseButtonComponent } from '../../shared/fuse-button.component';
import { HoldButtonComponent } from '../../shared/hold-button.component';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterLink, CountUpComponent, FuseButtonComponent, HoldButtonComponent],
  templateUrl: './cart.html',
  styleUrl: './cart.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CartComponent {
  readonly auth = inject(AuthService);
  readonly cart = inject(CartService);
  readonly checkout = inject(CheckoutService);
  readonly message = signal('');
  readonly failedImages = signal<ReadonlySet<number>>(new Set());

  private readonly currency = new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  currentStep = signal(1);
  deliveryMethod = signal<'pickup' | 'delivery'>('pickup');
  paymentMethod = signal<'card' | 'cash'>('card');
  address = signal('');
  cardNumber = signal('');

  money(value: number): string {
    return this.currency.format(value);
  }

  imageFailed(productId: number): void {
    this.failedImages.update((ids) => new Set([...ids, productId]));
  }

  changeQuantity(productId: number, delta: number): void {
    if (this.checkout.busy()) return;
    this.message.set('');
    try {
      this.cart.change(productId, delta);
    } catch (error) {
      this.message.set(error instanceof Error ? error.message : 'No se pudo cambiar la cantidad.');
    }
  }

  remove(productId: number): void {
    if (this.checkout.busy()) return;
    this.message.set('');
    this.cart.remove(productId);
  }

  nextStep(): void {
    if (this.currentStep() === 1 && this.cart.items().length === 0) {
      this.message.set('Tu carrito está vacío.');
      return;
    }
    if (this.currentStep() === 2 && this.deliveryMethod() === 'delivery' && !this.address().trim()) {
      this.message.set('Por favor ingresa tu dirección de envío.');
      return;
    }
    this.message.set('');
    this.currentStep.set(this.currentStep() + 1);
  }

  prevStep(): void {
    if (this.currentStep() > 1) {
      this.currentStep.set(this.currentStep() - 1);
    }
  }

  async submit(): Promise<void> {
    this.message.set('');
    // For mock testing, we just advance to the thank you step without hitting the real backend
    // since the real backend might be down.
    this.currentStep.set(4);
    this.cart.clear(); // Empty cart after successful mock order
  }
}

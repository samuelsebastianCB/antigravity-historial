import { computed, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { describe, beforeEach, expect, it, vi } from 'vitest';
import { AuthService } from '../../core/auth.service';
import { CartService } from '../../core/cart.service';
import { CheckoutService } from '../../core/checkout.service';
import { Product, CartItem, Receipt } from '../../core/models';
import { ProductService } from '../../core/product.service';
import { CatalogComponent } from './catalog';

function product(id: number, name: string, price: number, category = 'Vino', description = ''): Product {
  return { PRODUCT_ID: id, PRODUCT_NAME: name, RETAIL_PRICE: price, CATEGORY_NAME: category,
    DESCRIPTION: description, CURRENT_STOCK: 10, FOTO_URL: '', PRODUCT_STATUS: 'activo' };
}

describe('CatalogComponent: catálogo y filtros', () => {
  let component: CatalogComponent;
  const products = signal<Product[]>([]);
  const items = signal<CartItem[]>([]);
  const customer = signal<{ id: number; nombre: string } | null>(null);
  const submit = vi.fn();
  const load = vi.fn().mockResolvedValue(undefined);

  beforeEach(() => {
    products.set([
      product(1, 'Tequila Don Julio', 699.99, 'Tequila', 'Reposado de agave'),
      product(2, 'Vino tinto Malbec', 299.99, 'Vino', 'Selección de Mendoza'),
      product(3, 'Vino blanco Chardonnay', 300, 'Vino', 'Selección fresca'),
      product(4, 'Vino rosado Reserva', 700, 'Vino', 'Cava de la casa'),
      product(5, 'Whisky Escocés', 1499.99, 'Whisky'),
      product(6, 'Vino tinto Gran Reserva', 1500, 'Vino', 'Selección especial'),
    ]);
    items.set([]);
    customer.set(null);
    submit.mockReset();
    load.mockClear();
    TestBed.configureTestingModule({ providers: [
      { provide: ProductService, useValue: { products, loading: signal(false), error: signal(''), load } },
      { provide: CartService, useValue: { items, count: computed(() => items().reduce((sum, item) => sum + item.cantidad, 0)),
        total: computed(() => items().reduce((sum, item) => sum + item.subtotal, 0)), quantity: vi.fn().mockReturnValue(0),
        add: vi.fn(), change: vi.fn(), remove: vi.fn(), clear: vi.fn() } },
      { provide: CheckoutService, useValue: { busy: signal(false), error: signal(''), receipt: signal<Receipt | null>(null), submit } },
      { provide: AuthService, useValue: { customer, isCustomer: computed(() => customer() !== null), logout: vi.fn() } },
    ] });
    component = TestBed.runInInjectionContext(() => new CatalogComponent());
  });

  it('combina búsqueda sin acentos, categoría superior, categorías laterales y precio con glider', () => {
    component.search.set(' SELECCION ');
    component.category.set('Vino');
    component.toggleFilter('category', 'Vino', true);
    component.toggleFilter('category', 'Whisky', true);
    component.maxPrice.set(300);
    expect(component.filteredProducts().map(item => item.PRODUCT_ID)).toEqual([2, 3]);
    component.maxPrice.set(1500);
    expect(component.filteredProducts().map(item => item.PRODUCT_ID)).toEqual([2, 3, 6]);
  });

  it('busca también categorías aunque no estén en el nombre o descripción', () => {
    products.set([product(11, 'Etiqueta de la casa', 350, 'Tequila')]);
    component.search.set('TEQUILA');
    expect(component.filteredProducts().map(item => item.PRODUCT_ID)).toEqual([11]);
  });

  it('filtra productos según el planeador de precio máximo (glider)', () => {
    const prices = [0, 299, 300, 700, 1500, 2000];
    products.set(prices.map((price, index) => product(index + 1, `Botella ${index + 1}`, price)));
    component.maxPrice.set(300);
    expect(component.filteredProducts().map(item => item.RETAIL_PRICE)).toEqual([0, 299, 300]);
    component.maxPrice.set(1500);
    expect(component.filteredProducts().map(item => item.RETAIL_PRICE)).toEqual([0, 299, 300, 700, 1500]);
  });

  it('ordena por precio ascendente y descendente sin alterar el orden del catálogo original', () => {
    const original = products().map(item => item.PRODUCT_ID);
    component.sort.set('precio-menor');
    expect(component.filteredProducts().map(item => item.PRODUCT_ID)).toEqual([2, 3, 1, 4, 5, 6]);
    component.sort.set('precio-mayor');
    expect(component.filteredProducts().map(item => item.PRODUCT_ID)).toEqual([6, 5, 4, 1, 3, 2]);
    expect(products().map(item => item.PRODUCT_ID)).toEqual(original);
    component.sort.set('relevancia');
    expect(component.filteredProducts().map(item => item.PRODUCT_ID)).toEqual(original);
  });

  it('ordena nombres con reglas de español y filtra resultados vacíos', () => {
    products.set([product(1, 'Zarza', 100), product(2, 'Álamo', 100), product(3, 'Bodega', 100)]);
    component.sort.set('nombre');
    expect(component.filteredProducts().map(item => item.PRODUCT_NAME)).toEqual(['Álamo', 'Bodega', 'Zarza']);
    component.search.set('sin coincidencias');
    expect(component.filteredProducts()).toEqual([]);
  });

  it('limpia todos los criterios para recuperar los productos', () => {
    component.search.set('whisky');
    component.category.set('Whisky');
    component.toggleFilter('category', 'Whisky', true);
    component.maxPrice.set(1000);
    expect(component.hasFilters()).toBe(true);
    component.clearFilters();
    expect(component.hasFilters()).toBe(false);
    expect(component.filteredProducts()).toHaveLength(6);
  });

  it('solicita sesión para el ticket y conserva el carrito sin enviar una orden anónima', async () => {
    items.set([{ product_id: 1, nombre: 'Tequila Don Julio', precio: 699.99, cantidad: 1, subtotal: 699.99, foto: '' }]);
    component.openCart();
    await component.submitOrder();
    expect(submit).not.toHaveBeenCalled();
    expect(items()).toHaveLength(1);
    expect(component.accountOpen()).toBe(true);
    expect(component.drawerOpen()).toBe(false);
    customer.set({ id: 7, nombre: 'Cliente' });
    component.onLoginCompleted();
    expect(component.accountOpen()).toBe(false);
    expect(component.drawerOpen()).toBe(true);
    expect(submit).not.toHaveBeenCalled();
  });

  it('conserva las cantidades cuando se intenta modificar el carrito durante el pedido', () => {
    component.checkout.busy.set(true);
    component.add(products()[0]);
    component.change(1, 1);
    component.change(1, -1);
    component.remove(1);
    expect(component.cart.add).not.toHaveBeenCalled();
    expect(component.cart.change).not.toHaveBeenCalled();
    expect(component.cart.remove).not.toHaveBeenCalled();

    component.checkout.busy.set(false);
    component.add(products()[0]);
    component.change(1, 1);
    component.remove(1);
    expect(component.cart.add).toHaveBeenCalledOnce();
    expect(component.cart.change).toHaveBeenCalledWith(1, 1);
    expect(component.cart.remove).toHaveBeenCalledWith(1);
  });
});

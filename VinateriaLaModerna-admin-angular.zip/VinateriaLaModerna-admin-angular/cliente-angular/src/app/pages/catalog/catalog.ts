import { CurrencyPipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, ElementRef, inject, OnInit, signal, viewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { CartService } from '../../core/cart.service';
import { CheckoutService } from '../../core/checkout.service';
import { ProductService } from '../../core/product.service';
import { Product } from '../../core/models';
import { RegisterComponent } from '../register/register';
import { ReceiptComponent } from '../../shared/receipt/receipt';
import { AgeVerificationComponent } from '../../shared/age-verification/age-verification';
import { LiquorChatbotComponent } from '../../shared/liquor-chatbot/liquor-chatbot';
import { PeekRatingComponent } from '../../shared/peek-rating.component';
import { LikeButtonComponent } from '../../shared/like-button.component';
import { SiteHeaderComponent } from '../../shared/site-header.component';
import { BadgeComponent } from '../../shared/badge.component';
import { WakeSliderComponent } from '../../shared/wake-slider.component';
import { ToastService } from '../../core/toast.service';
import { CarouselComponent } from '../../shared/carousel.component';
import { FuseButtonComponent } from '../../shared/fuse-button.component';
import { HoldButtonComponent } from '../../shared/hold-button.component';


/** Valor "sin límite" del precio máximo (se conserva por compatibilidad con el estado previo). */
export const PRICE_UNLIMITED = 20000;

export interface ActiveFilter { kind: 'search' | 'category' | 'price' | 'origin' | 'feature'; value: string; label: string; }
export interface ProductBadge { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline'; icon?: string; }

@Component({
  selector: 'app-catalog',
  standalone: true,
  imports: [CurrencyPipe, FormsModule, RouterLink, RegisterComponent, ReceiptComponent, AgeVerificationComponent, PeekRatingComponent, LikeButtonComponent, SiteHeaderComponent, BadgeComponent, WakeSliderComponent, CarouselComponent, FuseButtonComponent, HoldButtonComponent],
  templateUrl: './catalog.html',
  styleUrl: './catalog.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '(document:keydown.escape)': 'closeOverlays()',
    '(document:click)': 'closeAccountOutside($event)',
  },
})
export class CatalogComponent implements OnInit {
  readonly products = inject(ProductService);
  readonly cart = inject(CartService);
  readonly checkout = inject(CheckoutService);
  readonly auth = inject(AuthService);
  readonly toast = inject(ToastService);
  readonly userArea = viewChild<ElementRef<HTMLElement>>('userArea');

  readonly search = signal('');
  readonly category = signal('todos');
  readonly sort = signal('relevancia');
  readonly checkedCategories = signal<string[]>([]);
  readonly maxPrice = signal<number>(PRICE_UNLIMITED);
  readonly minPrice = signal<number>(0);
  readonly selectedOrigins = signal<string[]>([]);
  readonly selectedFeatures = signal<string[]>([]);
  readonly accountOpen = signal(false);

  carouselItems = [
    { title: 'Selección Exclusiva', description: 'Los mejores vinos y licores del mundo.', image: 'https://res.cloudinary.com/dhcwmbzso/image/upload/q_auto/f_auto/v1779417085/Vinater%C3%ADa_La_Moderna_n3xvsj.png' },
    { title: 'Tequilas Premium', description: 'Añejos y cristalinos para paladares exigentes.', image: 'https://images.unsplash.com/photo-1516594915697-87eb3b1c14ea?q=80&w=1200&auto=format&fit=crop' },
    { title: 'Cerveza Artesanal', description: 'Descubre notas únicas de cervecerías locales e internacionales.', image: 'https://images.unsplash.com/photo-1535958636474-b021ee887b13?q=80&w=1200&auto=format&fit=crop' }
  ];
  readonly registerOpen = signal(false);
  readonly drawerOpen = this.cart.drawerOpen;
  readonly selectedProduct = signal<Product | null>(null);
  readonly failedImages = signal<Set<string>>(new Set());
  readonly notice = signal('');
  readonly logoutBusy = signal(false);
  readonly awaitingCustomer = signal(false);

  readonly categories = [
    { value: 'todos', label: 'Todos los productos' },
    { value: 'Ofertas', label: 'Ofertas' },
    { value: 'Vino', label: 'Vinos' },
    { value: 'Destilados', label: 'Destilados' },
    { value: 'Tequila', label: 'Tequila' },
    { value: 'Whisky', label: 'Whisky' },
    { value: 'Ron', label: 'Ron' },
    { value: 'Cerveza', label: 'Cervezas' },
    { value: 'Otros', label: 'Acompañamientos' },
  ];
  readonly sidebarCategories = this.categories.filter(({ value }) => ['Vino', 'Tequila', 'Whisky', 'Ron', 'Cerveza'].includes(value));
  readonly activeLabel = computed(() => this.categories.find(({ value }) => value === this.category())?.label ?? 'Todos los productos');

  selectQuickCategory(cat: string): void {
    if (cat === 'todos') {
      this.category.set('todos');
      this.checkedCategories.set([]);
    } else if (this.category() === cat || (this.checkedCategories().length === 1 && this.checkedCategories()[0] === cat)) {
      this.category.set('todos');
      this.checkedCategories.set([]);
    } else {
      this.category.set(cat);
      this.checkedCategories.set([cat]);
    }
  }

  isQuickCategoryActive(cat: string): boolean {
    if (cat === 'todos') {
      return this.category() === 'todos' && this.checkedCategories().length === 0;
    }
    return this.category() === cat || (this.checkedCategories().length === 1 && this.checkedCategories()[0] === cat);
  }

  readonly priceRanges = [
    { id: '0-500', label: '$0–$500', min: 0, max: 500 },
    { id: '500-1000', label: '$500–$1,000', min: 500, max: 1000 },
    { id: '1000+', label: '+$1,000', min: 1000, max: PRICE_UNLIMITED },
  ];
  readonly origins = [{ value: 'mexico', label: 'México' }, { value: 'importado', label: 'Importado' }];
  readonly featureOptions = [
    { value: 'oferta', label: 'Oferta' },
    { value: 'disponible', label: 'Disponible' },
    { value: 'ultimas', label: 'Últimas unidades' },
  ];

  /** Tope del slider: el producto más caro redondeado a 100 (mínimo 1,000). */
  readonly priceCeiling = computed(() => {
    const top = Math.max(0, ...this.products.products().map(product => product.RETAIL_PRICE));
    return Math.max(1000, Math.ceil(top / 100) * 100);
  });
  readonly sliderValue = computed(() => Math.min(this.maxPrice(), this.priceCeiling()));
  private readonly priceFilterActive = computed(() => this.minPrice() > 0 || this.maxPrice() < PRICE_UNLIMITED);

  readonly hasFilters = computed(() => !!this.search().trim() || this.category() !== 'todos' || this.checkedCategories().length > 0
    || this.priceFilterActive() || this.selectedOrigins().length > 0 || this.selectedFeatures().length > 0);

  readonly activeFilters = computed<ActiveFilter[]>(() => {
    const list: ActiveFilter[] = [];
    if (this.search().trim()) list.push({ kind: 'search', value: '', label: `“${this.search().trim()}”` });
    if (this.category() !== 'todos') list.push({ kind: 'category', value: '__top', label: this.activeLabel() });
    for (const value of this.checkedCategories()) {
      list.push({ kind: 'category', value, label: this.categories.find(c => c.value === value)?.label ?? value });
    }
    if (this.priceFilterActive()) list.push({ kind: 'price', value: '', label: this.priceLabel() });
    for (const value of this.selectedOrigins()) list.push({ kind: 'origin', value, label: this.origins.find(o => o.value === value)?.label ?? value });
    for (const value of this.selectedFeatures()) list.push({ kind: 'feature', value, label: this.featureOptions.find(f => f.value === value)?.label ?? value });
    return list;
  });

  readonly filteredProducts = computed(() => {
    const term = this.normalize(this.search().trim());
    const origins = this.selectedOrigins(), features = this.selectedFeatures();
    const result = this.products.products().filter(product => {
      const searchable = this.productText(product);
      return (this.category() === 'todos' || this.matchesCategory(product, this.category()))
        && (!this.checkedCategories().length || this.checkedCategories().some(category => this.matchesCategory(product, category)))
        && (product.RETAIL_PRICE >= this.minPrice() && product.RETAIL_PRICE <= this.maxPrice())
        && (!origins.length || origins.includes(this.originOf(product) ?? ''))
        && features.every(feature => this.hasFeature(product, feature))
        && (!term || searchable.includes(term));
    });
    switch (this.sort()) {
      case 'precio-menor': return result.sort((a, b) => a.RETAIL_PRICE - b.RETAIL_PRICE);
      case 'precio-mayor': return result.sort((a, b) => b.RETAIL_PRICE - a.RETAIL_PRICE);
      case 'nombre': return result.sort((a, b) => a.PRODUCT_NAME.localeCompare(b.PRODUCT_NAME, 'es', { sensitivity: 'base' }));
      default: return result;
    }
  });

  ngOnInit(): void {
    void this.products.load();
  }

  normalize(value: string): string {
    return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  }

  private productText(product: Product): string {
    return this.normalize([product.PRODUCT_NAME, product.DESCRIPTION, product.CATEGORY_NAME, product.TIPO].filter(Boolean).join(' '));
  }

  private matchesCategory(product: Product, category: string): boolean {
    const text = this.productText(product);
    if (category === 'Destilados') {
      return ['destilad', 'tequila', 'whisky', 'whiskey', 'ron', 'mezcal', 'vodka', 'ginebra', 'brandy', 'cognac', 'aguardiente'].some(word => text.includes(word));
    }
    if (category === 'Ofertas') return text.includes('oferta') || text.includes('promocion');
    if (category === 'Otros') return text.includes('otros') || text.includes('acompanamiento');
    return text.includes(this.normalize(category));
  }

  getFilterClass(product: Product): string {
    const classes = [];
    for (const cat of this.sidebarCategories) {
       if (this.matchesCategory(product, cat.value)) {
          classes.push('filter-' + this.normalize(cat.value));
       }
    }
    return classes.join(' ');
  }

  getMockRating(productId: number): number {
    // Generate a consistent pseudo-random rating between 3 and 5 based on product ID
    return 3 + (productId % 3);
  }

  getMockLikes(productId: number): number {
    return 15 + (productId * 7 % 89);
  }

  toggleFilter(kind: 'category', value: string, checked: boolean): void {
    const selected = this.checkedCategories;
    selected.update(values => checked ? [...new Set([...values, value])] : values.filter(item => item !== value));
  }

  toggleIn(target: 'origin' | 'feature', value: string): void {
    const state = target === 'origin' ? this.selectedOrigins : this.selectedFeatures;
    state.update(values => values.includes(value) ? values.filter(item => item !== value) : [...values, value]);
  }

  isRangeActive(range: { min: number; max: number }): boolean {
    return this.minPrice() === range.min && this.maxPrice() === range.max;
  }

  toggleRange(range: { min: number; max: number }): void {
    if (this.isRangeActive(range)) { this.minPrice.set(0); this.maxPrice.set(PRICE_UNLIMITED); return; }
    this.minPrice.set(range.min);
    this.maxPrice.set(range.max);
  }

  /** WakeSlider → precio máximo real. En el tope del slider se interpreta como "sin límite". */
  onSliderChange(value: number): void {
    const next = value >= this.priceCeiling() ? PRICE_UNLIMITED : value;
    this.maxPrice.set(next);
    if (this.minPrice() > next) this.minPrice.set(0);
  }

  priceLabel(): string {
    const fmt = (n: number) => '$' + n.toLocaleString('es-MX');
    const min = this.minPrice(), max = this.maxPrice();
    if (max >= PRICE_UNLIMITED) return min > 0 ? `+${fmt(min)}` : 'Cualquier precio';
    return `${fmt(min)}–${fmt(max)}`;
  }

  removeFilter(filter: ActiveFilter): void {
    switch (filter.kind) {
      case 'search': this.search.set(''); break;
      case 'category':
        if (filter.value === '__top') this.category.set('todos');
        else this.toggleFilter('category', filter.value, false);
        break;
      case 'price': this.minPrice.set(0); this.maxPrice.set(PRICE_UNLIMITED); break;
      case 'origin': this.toggleIn('origin', filter.value); break;
      case 'feature': this.toggleIn('feature', filter.value); break;
    }
  }

  clearFilters(): void {
    this.search.set('');
    this.category.set('todos');
    this.checkedCategories.set([]);
    this.maxPrice.set(PRICE_UNLIMITED);
    this.minPrice.set(0);
    this.selectedOrigins.set([]);
    this.selectedFeatures.set([]);
  }

  /** Origen inferido del nombre/descripción/categoría; `undefined` si no hay información suficiente. */
  originOf(product: Product): 'mexico' | 'importado' | undefined {
    const text = this.productText(product);
    if (/mexic|tequila|mezcal|sotol|raicilla/.test(text)) return 'mexico';
    if (/importad|whisk|scotch|bourbon|vodka|ginebra|cognac|brandy|champagne|escoces|frances|italian|espanol|chile|argentin/.test(text)) return 'importado';
    return undefined;
  }

  hasFeature(product: Product, feature: string): boolean {
    switch (feature) {
      case 'oferta': return this.matchesCategory(product, 'Ofertas');
      case 'disponible': return product.CURRENT_STOCK > 0;
      case 'ultimas': return product.CURRENT_STOCK > 0 && product.CURRENT_STOCK < 5;
      default: return false;
    }
  }

  /** Etiquetas informativas del producto: categoría, precio, origen y características reales. */
  badgesFor(product: Product): ProductBadge[] {
    const badges: ProductBadge[] = [{ label: this.categoryLabel(product), variant: 'default', icon: '🍷' }];
    badges.push({ label: '$' + product.RETAIL_PRICE.toLocaleString('es-MX', { maximumFractionDigits: 2 }), variant: 'secondary' });
    const origin = this.originOf(product);
    if (origin) badges.push({ label: origin === 'mexico' ? 'México' : 'Importado', variant: 'outline', icon: origin === 'mexico' ? '🇲🇽' : '🌎' });
    if (this.hasFeature(product, 'oferta')) badges.push({ label: 'Oferta', variant: 'destructive', icon: '🏷️' });
    if (product.CURRENT_STOCK <= 0) badges.push({ label: 'Agotado', variant: 'outline' });
    else if (this.hasFeature(product, 'ultimas')) badges.push({ label: `Últimas ${product.CURRENT_STOCK}`, variant: 'destructive' });
    else badges.push({ label: 'Disponible', variant: 'outline', icon: '✓' });
    return badges;
  }

  categoryLabel(product: Product): string {
    return product.CATEGORY_NAME || product.TIPO || 'Licor';
  }

  pricePart(product: Product, part: number): string {
    return product.RETAIL_PRICE.toFixed(2).split('.')[part] ?? '00';
  }

  imageFailed(url: string): void {
    this.failedImages.update(images => new Set([...images, url]));
  }

  imageAvailable(url: string): boolean {
    return !!url && !this.failedImages().has(url);
  }

  add(product: Product): void {
    if (this.checkout.busy()) return;
    this.notice.set('');
    try { 
      this.cart.add(product); 
      this.cart.openDrawer();
      this.toast.show({
        title: 'Producto agregado',
        description: `${product.PRODUCT_NAME} está en tu carrito.`,
        actionLabel: 'Ver carrito',
        onAction: () => this.cart.openDrawer()
      });
    }
    catch (error) { this.notice.set(error instanceof Error ? error.message : 'No se pudo agregar el producto.'); }
  }

  change(id: number, delta: number): void {
    if (this.checkout.busy()) return;
    this.notice.set('');
    try { this.cart.change(id, delta); }
    catch (error) { this.notice.set(error instanceof Error ? error.message : 'No se pudo actualizar la cantidad.'); }
  }

  setQuantity(id: number, quantity: string | number): void {
    if (this.checkout.busy()) return;
    this.notice.set('');
    try {
      const q = typeof quantity === 'string' ? parseInt(quantity, 10) : quantity;
      if (!isNaN(q)) {
        this.cart.setQuantity(id, q);
      }
    } catch (error) {
      this.notice.set(error instanceof Error ? error.message : 'No se pudo actualizar la cantidad.');
    }
  }

  remove(id: number): void {
    if (this.checkout.busy()) return;
    this.notice.set('');
    this.cart.remove(id);
  }

  maximumReached(id: number, quantity: number, knownStock?: number): boolean {
    const stock = this.products.products().find(product => product.PRODUCT_ID === id)?.CURRENT_STOCK ?? knownStock;
    return stock !== undefined && quantity >= stock;
  }

  openCart(): void {
    this.accountOpen.set(false);
    this.cart.openDrawer();
    this.notice.set('');
  }

  openRegister(): void {
    this.accountOpen.set(false);
    this.registerOpen.set(true);
  }

  openLogin(): void {
    this.registerOpen.set(false);
    this.accountOpen.set(true);
  }

  onLoginCompleted(): void {
    this.accountOpen.set(false);
    this.notice.set('');
    if (this.awaitingCustomer()) {
      this.awaitingCustomer.set(false);
      this.cart.openDrawer();
    }
  }

  async logout(): Promise<void> {
    this.logoutBusy.set(true);
    try {
      await this.auth.logout();
      this.accountOpen.set(false);
      this.notice.set('Tu sesión se ha cerrado.');
    } catch (error) {
      this.notice.set(error instanceof Error ? error.message : 'No se pudo cerrar la sesión.');
    } finally { this.logoutBusy.set(false); }
  }

  async submitOrder(): Promise<void> {
    if (!this.cart.items().length || this.checkout.busy()) return;
    if (!this.auth.isCustomer()) {
      this.cart.closeDrawer();
      this.awaitingCustomer.set(true);
      this.accountOpen.set(true);
      this.notice.set('Inicia sesión como cliente para generar tu ticket de prepago.');
      return;
    }
    const receipt = await this.checkout.submit();
    if (receipt) {
      this.cart.closeDrawer();
      void this.products.load();
    }
  }

  closeOverlays(): void {
    this.accountOpen.set(false);
    this.registerOpen.set(false);
    this.cart.closeDrawer();
    this.selectedProduct.set(null);
  }

  closeAccountOutside(event: MouseEvent): void {
    if (event.target instanceof Node && this.accountOpen() && !this.userArea()?.nativeElement.contains(event.target)) {
      this.accountOpen.set(false);
    }
  }
}

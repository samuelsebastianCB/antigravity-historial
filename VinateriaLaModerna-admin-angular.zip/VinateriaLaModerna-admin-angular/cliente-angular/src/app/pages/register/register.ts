import { Component, inject, Input, output, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AuthService, RegistrationResult } from '../../core/auth.service';
import { MEXICAN_STATES, RegistrationData } from '../../core/registration';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './register.html',
  styleUrl: './register.css',
  host: { '[class.embedded]': 'embedded' },
})
export class RegisterComponent {
  @Input() embedded = false;
  readonly completed = output<void>();
  readonly loginRequested = output<void>();
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  readonly employeeAllowed = inject(ActivatedRoute).snapshot.queryParamMap.get('origen') === 'employees' && this.auth.isAdmin;
  readonly states = MEXICAN_STATES;
  readonly busy = signal(false);
  readonly error = signal('');
  readonly result = signal<RegistrationResult | null>(null);
  readonly form = inject(FormBuilder).nonNullable.group({
    tipo: [this.employeeAllowed ? 'empleado' : 'cliente'],
    first_name: ['', Validators.required],
    last_name_1: [''], last_name_2: [''],
    telefono: [''],
    calle: [''], colonia: [''], cp: [''], ciudad: [''], estado: [''],
    correo: ['', [Validators.required, Validators.pattern(/^[a-zA-Z0-9._%+-]+@gmail\.com$/)]],
    correo_confirmation: ['', Validators.required],
    password: ['', [Validators.required, Validators.minLength(6)]],
    password_confirmation: ['', Validators.required],
    nacimiento: [''], ingreso: [''], curp: [''], rfc: [''],
    turno: ['Matutino'], puesto: ['1'],
  });

  get isEmployee(): boolean { return this.form.controls.tipo.value === 'empleado'; }
  get emailsMatch(): boolean {
    return this.form.controls.correo.valid && this.form.controls.correo.value.trim() === this.form.controls.correo_confirmation.value.trim();
  }
  get passwordsMatch(): boolean {
    return this.form.controls.password.valid && this.form.controls.password.value === this.form.controls.password_confirmation.value;
  }

  async submit(): Promise<void> {
    if (this.busy() || this.result()) return;
    this.error.set('');
    const values = this.form.getRawValue();
    this.form.markAllAsTouched();
    if (!values.first_name.trim()) {
      this.error.set('El nombre es obligatorio.');
      return;
    }
    if (!/^[a-zA-Z0-9._%+-]+@gmail\.com$/.test(values.correo.trim())) {
      this.error.set('El correo debe ser una dirección válida de @gmail.com.');
      return;
    }
    if (!this.isEmployee && !/^\d{10}$/.test(values.telefono.trim())) {
      this.error.set('El número de teléfono debe tener exactamente 10 dígitos.');
      return;
    }
    if (values.correo.trim() !== values.correo_confirmation.trim()) {
      this.error.set('Los correos no coinciden.');
      return;
    }
    if (values.password.length < 6) {
      this.error.set('La contraseña debe tener al menos 6 caracteres.');
      return;
    }
    if (values.password !== values.password_confirmation) {
      this.error.set('Las contraseñas no coinciden.');
      return;
    }
    if (this.isEmployee && !this.employeeAllowed) {
      this.error.set('No tienes permisos para registrar empleados.');
      return;
    }
    const data: RegistrationData = {
      tipo: this.isEmployee ? 'empleado' : 'cliente',
      first_name: values.first_name.trim(), last_name_1: values.last_name_1.trim(),
      last_name_2: values.last_name_2.trim(), telefono: values.telefono.trim(),
      correo: values.correo.trim(), password: values.password,
      calle: values.calle.trim(), colonia: values.colonia.trim(), cp: values.cp.trim(),
      ciudad: values.ciudad.trim(), estado: values.estado,
      ...(this.isEmployee ? {
        nacimiento: values.nacimiento, ingreso: values.ingreso,
        curp: values.curp.trim(), rfc: values.rfc.trim(),
        turno: values.turno, puesto: values.puesto,
      } : {}),
    };
    this.busy.set(true);
    try {
      this.result.set(await this.auth.register(data));
      this.form.controls.password.reset();
      this.form.controls.password_confirmation.reset();
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'No se pudo completar el registro.');
    } finally {
      this.busy.set(false);
    }
  }

  async finish(): Promise<void> {
    if (this.embedded) this.completed.emit();
    else await this.router.navigate(['/login']);
  }
}

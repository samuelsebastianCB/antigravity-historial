import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'inicio' },
  { path: 'inicio', title: 'Inicio | La Moderna', loadComponent: () => import('./pages/home/home').then(module => module.HomeComponent) },
  { path: 'login', title: 'Iniciar sesión | La Moderna', loadComponent: () => import('./pages/login/login').then(module => module.LoginComponent) },
  { path: 'registro', title: 'Registro | La Moderna', loadComponent: () => import('./pages/register/register').then(module => module.RegisterComponent) },
  { path: 'catalogo', title: 'Nuestra cava | La Moderna', loadComponent: () => import('./pages/catalog/catalog').then(module => module.CatalogComponent) },
  { path: 'carrito', title: 'Mi carrito | La Moderna', loadComponent: () => import('./pages/cart/cart').then(module => module.CartComponent) },
  { path: 'index.html', redirectTo: 'inicio' },
  { path: 'registro.html', redirectTo: 'registro' },
  { path: 'usuariosCompras.html', redirectTo: 'catalogo' },
  { path: 'carrito.html', redirectTo: 'carrito' },
  { path: '**', redirectTo: 'inicio' },
];

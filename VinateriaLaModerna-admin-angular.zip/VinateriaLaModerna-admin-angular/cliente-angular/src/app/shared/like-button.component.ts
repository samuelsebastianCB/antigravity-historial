import { Component, Input, signal, OnInit } from '@angular/core';

@Component({
  selector: 'app-like-button',
  standalone: true,
  template: `
    <button class="like-btn" [class.liked]="liked()" (click)="toggleLike($event)" aria-label="Me gusta">
      <svg class="heart-icon" viewBox="0 0 24 24">
        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
      </svg>
      <span class="like-count">{{ currentLikes() }}</span>
    </button>
  `,
  styles: [`
    .like-btn {
      display: flex;
      align-items: center;
      gap: 6px;
      background: var(--card-bg, rgba(255,255,255,0.9));
      border: 1px solid var(--border-color, #eaeaea);
      border-radius: 99px;
      padding: 6px 12px;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      color: var(--text-color, #666);
      transition: all 0.2s ease;
      backdrop-filter: blur(4px);
    }
    .like-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .like-btn:active {
      transform: scale(0.95);
    }
    .heart-icon {
      width: 16px;
      height: 16px;
      fill: none;
      stroke: currentColor;
      stroke-width: 2px;
      transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    .like-btn.liked {
      color: #e63946;
      border-color: #ffd6da;
      background: var(--card-bg, #fff);
    }
    .like-btn.liked .heart-icon {
      fill: #e63946;
      stroke: #e63946;
      animation: heartPop 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
    }
    @keyframes heartPop {
      0% { transform: scale(1); }
      50% { transform: scale(1.4); }
      100% { transform: scale(1.15); }
    }
  `]
})
export class LikeButtonComponent implements OnInit {
  @Input() initialLikes = 0;
  
  liked = signal(false);
  currentLikes = signal(0);

  ngOnInit() {
    this.currentLikes.set(this.initialLikes);
  }

  toggleLike(e: Event) {
    e.stopPropagation(); // Evita que se abra el modal de detalles
    this.liked.set(!this.liked());
    this.currentLikes.set(this.initialLikes + (this.liked() ? 1 : 0));
  }
}


import { Component, Input, Output, EventEmitter, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-peek-rating',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="peek-rating-container" (mouseleave)="onMouseLeave()">
      @for (star of stars; track star) {
        <div class="star-wrapper" 
             (mouseenter)="onMouseEnter(star)"
             (click)="setRating(star)">
           
           <svg [style.fill]="fillColor(star)"
                [style.width.px]="size" 
                [style.height.px]="size"
                class="star-svg" 
                [class.lifted]="star === hoverRating() && !readOnly"
                viewBox="0 0 24 24">
             <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
           </svg>

           @if (showTip && hoverRating() === star && !readOnly) {
             <div class="star-tip" 
                  [style.background]="tipColor" 
                  [style.color]="tipTextColor">
               {{ labels[star - 1] || star }}
               <div class="star-tip-arrow" [style.border-top-color]="tipColor"></div>
             </div>
           }
        </div>
      }
    </div>
  `,
  styles: [`
    .peek-rating-container {
      display: inline-flex;
      gap: 4px;
      position: relative;
    }
    .star-wrapper {
      position: relative;
      cursor: pointer;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .star-svg {
      transition: transform 0.32s cubic-bezier(0.175, 0.885, 0.32, 1.275), fill 0.2s ease;
    }
    .star-wrapper:active .star-svg:not(.read-only) {
      transform: scale(1.3) !important;
    }
    .star-svg.lifted {
      transform: scale(1.15) translateY(-8px);
    }
    .star-tip {
      position: absolute;
      bottom: 100%;
      margin-bottom: 8px;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 12px;
      font-weight: bold;
      pointer-events: none;
      white-space: nowrap;
      animation: popTip 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
      z-index: 10;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    @keyframes popTip {
      0% { opacity: 0; transform: translateY(10px) scale(0.8); }
      100% { opacity: 1; transform: translateY(0) scale(1); }
    }
    .star-tip-arrow {
      position: absolute;
      top: 100%;
      left: 50%;
      transform: translateX(-50%);
      border-width: 5px;
      border-style: solid;
      border-color: transparent;
    }
  `]
})
export class PeekRatingComponent implements OnInit {
  @Input() defaultValue = 0;
  @Input() count = 5;
  @Input() labels = ['Pobre', 'Aceptable', 'Bueno', 'Genial', 'Excelente'];
  @Input() activeColor = '#f5b400';
  @Input() idleColor = '#52525b';
  @Input() tipColor = '#27272a';
  @Input() tipTextColor = '#f5f5f5';
  @Input() size = 18;
  @Input() showTip = true;
  @Input() allowClear = true;
  @Input() readOnly = false;
  
  @Output() ratingChange = new EventEmitter<number>();

  stars: number[] = [];
  currentRating = signal(0);
  hoverRating = signal(0);

  ngOnInit() {
    this.currentRating.set(this.defaultValue);
    this.stars = Array(this.count).fill(0).map((_, i) => i + 1);
  }

  onMouseEnter(star: number) {
    if (!this.readOnly) this.hoverRating.set(star);
  }

  onMouseLeave() {
    if (!this.readOnly) this.hoverRating.set(0);
  }

  setRating(star: number) {
    if (this.readOnly) return;
    if (this.allowClear && this.currentRating() === star) {
      this.currentRating.set(0);
    } else {
      this.currentRating.set(star);
    }
    this.ratingChange.emit(this.currentRating());
  }

  fillColor(star: number): string {
    const limit = (this.hoverRating() > 0 && !this.readOnly) ? this.hoverRating() : this.currentRating();
    return star <= limit ? this.activeColor : this.idleColor;
  }
}


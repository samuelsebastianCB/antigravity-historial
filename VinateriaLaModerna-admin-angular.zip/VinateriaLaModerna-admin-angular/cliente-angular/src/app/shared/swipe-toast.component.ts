import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService, Toast } from '../core/toast.service';

@Component({
  selector: 'app-swipe-toast',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="swipe-toast-wrapper" 
         [class.closing]="closing()"
         [style.transform]="'translateX(' + currentX() + 'px)'"
         [style.opacity]="opacity()"
         [style.--bg]="background"
         [style.--color]="color"
         [style.--fuse-color]="fuseColor"
         [style.--duration]="duration + 'ms'"
         (mousedown)="onPointerDown($event)"
         (touchstart)="onPointerDown($event)"
         (mouseenter)="pauseTimer()"
         (mouseleave)="resumeTimer()">
         
      <div class="toast-content">
        <div class="toast-text">
          <div class="toast-title">{{ title }}</div>
          @if (description) { <div class="toast-desc">{{ description }}</div> }
        </div>
        @if (actionLabel) {
          <button class="toast-action" (click)="handleAction()">{{ actionLabel }}</button>
        }
      </div>

      @if (fuse && duration > 0) {
        <div class="fuse-bar" [class.paused]="paused()"></div>
      }
    </div>
  `,
  styles: [`
    .swipe-toast-wrapper {
      position: relative;
      background: var(--bg, #27272a);
      color: var(--color, #f5f5f5);
      border-radius: 12px;
      width: 320px;
      padding: 16px;
      margin-top: 10px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.2);
      overflow: hidden;
      touch-action: pan-y;
      transition: opacity 0.3s, margin 0.3s;
      animation: slideIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
      pointer-events: auto;
      z-index: 9999;
    }
    .closing {
      animation: fadeOut 0.3s forwards !important;
    }
    .toast-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: relative;
      z-index: 2;
    }
    .toast-text {
      flex: 1;
    }
    .toast-title {
      font-weight: 600;
      font-size: 0.95rem;
    }
    .toast-desc {
      font-size: 0.85rem;
      opacity: 0.8;
      margin-top: 4px;
    }
    .toast-action {
      background: none;
      border: none;
      color: var(--fuse-color, #f5a524);
      font-weight: bold;
      cursor: pointer;
      padding: 8px;
    }
    .fuse-bar {
      position: absolute;
      bottom: 0; left: 0;
      height: 4px;
      background: var(--fuse-color, #f5a524);
      width: 100%;
      transform-origin: left;
      animation: shrink var(--duration) linear forwards;
    }
    .fuse-bar.paused {
      animation-play-state: paused;
    }
    @keyframes shrink {
      from { transform: scaleX(1); }
      to { transform: scaleX(0); }
    }
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    @keyframes fadeOut {
      to { transform: translateX(100%); opacity: 0; margin-top: -80px; }
    }
  `]
})
export class SwipeToastComponent implements OnInit, OnDestroy {
  @Input() id!: number;
  @Input() title = '';
  @Input() description = '';
  @Input() actionLabel = '';
  @Input() background = '#27272a';
  @Input() color = '#f5f5f5';
  @Input() fuseColor = '#f5a524';
  @Input() duration = 4000;
  @Input() fuse = true;
  @Input() swipeDistance = 40;

  @Output() onClose = new EventEmitter<number>();
  @Output() onAction = new EventEmitter<void>();

  closing = signal(false);
  paused = signal(false);
  currentX = signal(0);
  opacity = signal(1);

  private timeoutId: any;
  private startX = 0;
  private isDragging = false;
  private startTime = 0;
  private remainingTime = 0;

  ngOnInit() {
    this.remainingTime = this.duration;
    this.startTimer();
    
    // Bind global move and up events
    document.addEventListener('mousemove', this.onPointerMove);
    document.addEventListener('mouseup', this.onPointerUp);
    document.addEventListener('touchmove', this.onPointerMove, { passive: false });
    document.addEventListener('touchend', this.onPointerUp);
  }

  ngOnDestroy() {
    this.clearTimer();
    document.removeEventListener('mousemove', this.onPointerMove);
    document.removeEventListener('mouseup', this.onPointerUp);
    document.removeEventListener('touchmove', this.onPointerMove);
    document.removeEventListener('touchend', this.onPointerUp);
  }

  startTimer() {
    if (this.duration > 0 && this.remainingTime > 0) {
      this.startTime = Date.now();
      this.timeoutId = setTimeout(() => this.close(), this.remainingTime);
    }
  }

  clearTimer() {
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
  }

  pauseTimer() {
    this.paused.set(true);
    this.clearTimer();
    const elapsed = Date.now() - this.startTime;
    this.remainingTime -= elapsed;
  }

  resumeTimer() {
    this.paused.set(false);
    this.startTimer();
  }

  close() {
    if (this.closing()) return;
    this.closing.set(true);
    setTimeout(() => {
      this.onClose.emit(this.id);
    }, 300); // match animation duration
  }

  handleAction() {
    this.onAction.emit();
    this.close();
  }

  onPointerDown(e: MouseEvent | TouchEvent) {
    this.isDragging = true;
    this.startX = e instanceof MouseEvent ? e.clientX : e.touches[0].clientX;
    this.pauseTimer();
  }

  onPointerMove = (e: MouseEvent | TouchEvent) => {
    if (!this.isDragging) return;
    const x = e instanceof MouseEvent ? e.clientX : e.touches[0].clientX;
    const diff = x - this.startX;
    
    // Only allow swipe to the right
    if (diff > 0) {
      this.currentX.set(diff);
      this.opacity.set(1 - (diff / 300));
    }
  }

  onPointerUp = () => {
    if (!this.isDragging) return;
    this.isDragging = false;
    
    if (this.currentX() > this.swipeDistance) {
      this.close();
    } else {
      // Revert position
      this.currentX.set(0);
      this.opacity.set(1);
      this.resumeTimer();
    }
  }
}


@Component({
  selector: 'app-toast-container',
  standalone: true,
  imports: [CommonModule, SwipeToastComponent],
  template: `
    <div class="toast-container">
      @for (toast of toastService.toasts(); track toast.id) {
        <app-swipe-toast 
          [id]="toast.id"
          [title]="toast.title"
          [description]="toast.description || ''"
          [actionLabel]="toast.actionLabel || ''"
          [background]="toast.background || '#27272a'"
          [color]="toast.color || '#f5f5f5'"
          [fuseColor]="toast.fuseColor || '#f5a524'"
          [duration]="toast.duration || 4000"
          (onClose)="toastService.remove($event)"
          (onAction)="toast.onAction && toast.onAction()"
        />
      }
    </div>
  `,
  styles: [`
    .toast-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 10px;
      z-index: 10000;
      pointer-events: none; /* Let clicks pass through empty space */
    }
  `]
})
export class ToastContainerComponent {
  toastService = inject(ToastService);
}

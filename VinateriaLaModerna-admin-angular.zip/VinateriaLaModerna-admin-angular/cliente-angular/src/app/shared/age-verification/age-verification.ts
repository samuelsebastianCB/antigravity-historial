import { DOCUMENT } from '@angular/common';
import { AfterViewInit, ChangeDetectionStrategy, Component, ElementRef, inject, OnDestroy, signal, viewChild } from '@angular/core';

const CONFIRMATION_KEY = 'lamoderna-mayor-de-edad';

@Component({
  selector: 'app-age-verification',
  standalone: true,
  templateUrl: './age-verification.html',
  styleUrl: './age-verification.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AgeVerificationComponent implements AfterViewInit, OnDestroy {
  private readonly document = inject(DOCUMENT);
  private readonly dialog = viewChild.required<ElementRef<HTMLDialogElement>>('ageDialog');
  private closeTimer?: ReturnType<typeof setTimeout>;
  private previousOverflow: string | null = null;
  readonly closing = signal(false);

  ngAfterViewInit(): void {
    try {
      if (this.document.defaultView?.sessionStorage.getItem(CONFIRMATION_KEY) === 'true') return;
    } catch {
      // Si el navegador bloquea el almacenamiento, seguimos solicitando la confirmación.
    }

    this.dialog().nativeElement.showModal();
    this.previousOverflow = this.document.documentElement.style.overflow;
    this.document.documentElement.style.overflow = 'hidden';
  }

  confirmAge(): void {
    if (this.closing()) return;
    this.closing.set(true);
    // Respaldo para navegadores que no emitan animationend.
    this.closeTimer = setTimeout(() => this.finishClosing(), 320);
  }

  onAnimationEnd(event: AnimationEvent): void {
    if (this.closing() && event.target === this.dialog().nativeElement) this.finishClosing();
  }

  private finishClosing(): void {
    clearTimeout(this.closeTimer);
    try {
      this.document.defaultView?.sessionStorage.setItem(CONFIRMATION_KEY, 'true');
    } catch {
      // Aceptar sigue permitiendo navegar aunque no se pueda recordar la decisión.
    }
    this.dialog().nativeElement.close();
    this.restoreScroll();
  }

  private restoreScroll(): void {
    if (this.previousOverflow === null) return;
    this.document.documentElement.style.overflow = this.previousOverflow;
    this.previousOverflow = null;
  }

  ngOnDestroy(): void {
    clearTimeout(this.closeTimer);
    this.restoreScroll();
  }
}

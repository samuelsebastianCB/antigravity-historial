import { ComponentFixture, TestBed } from '@angular/core/testing';
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { AgeVerificationComponent } from './age-verification';

const key = 'lamoderna-mayor-de-edad';

describe('Verificación de edad del catálogo', () => {
  let fixture: ComponentFixture<AgeVerificationComponent> | undefined;
  let previousOverflow: string;
  const showModalDescriptor = Object.getOwnPropertyDescriptor(HTMLDialogElement.prototype, 'showModal');
  const closeDescriptor = Object.getOwnPropertyDescriptor(HTMLDialogElement.prototype, 'close');

  beforeAll(() => {
    // jsdom no implementa la capa modal nativa; el bloqueo y el foco se revisan en navegador.
    Object.defineProperties(HTMLDialogElement.prototype, {
      showModal: { configurable: true, value(this: HTMLDialogElement) { this.open = true; } },
      close: { configurable: true, value(this: HTMLDialogElement) { this.open = false; } },
    });
  });

  afterAll(() => {
    for (const [name, descriptor] of [['showModal', showModalDescriptor], ['close', closeDescriptor]] as const) {
      if (descriptor) Object.defineProperty(HTMLDialogElement.prototype, name, descriptor);
      else Reflect.deleteProperty(HTMLDialogElement.prototype, name);
    }
  });

  beforeEach(() => {
    vi.useFakeTimers();
    sessionStorage.removeItem(key);
    previousOverflow = document.documentElement.style.overflow;
    document.documentElement.style.overflow = 'auto';
    TestBed.configureTestingModule({ imports: [AgeVerificationComponent] });
  });

  afterEach(() => {
    fixture?.destroy();
    fixture = undefined;
    vi.restoreAllMocks();
    sessionStorage.removeItem(key);
    document.documentElement.style.overflow = previousOverflow;
    vi.useRealTimers();
  });

  function render(): HTMLDialogElement {
    fixture = TestBed.createComponent(AgeVerificationComponent);
    fixture.detectChanges();
    return fixture.nativeElement.querySelector('dialog');
  }

  function confirm(dialog: HTMLDialogElement): void {
    dialog.querySelector('button')!.click();
    fixture!.detectChanges();
  }

  it('abre el aviso en la primera visita y bloquea el desplazamiento sin confirmar automáticamente', () => {
    const dialog = render();
    expect(dialog.open).toBe(true);
    expect(document.documentElement.style.overflow).toBe('hidden');
    expect(sessionStorage.getItem(key)).toBeNull();
    expect(dialog.querySelector('[autofocus]')?.id).toBe(dialog.getAttribute('aria-labelledby'));
  });

  it('impide cancelar el aviso sin responder', () => {
    const dialog = render();
    const cancel = new Event('cancel', { cancelable: true });
    dialog.dispatchEvent(cancel);
    expect(cancel.defaultPrevented).toBe(true);
    expect(dialog.open).toBe(true);
    expect(sessionStorage.getItem(key)).toBeNull();
  });

  it('bloquea también Escape antes de que el navegador solicite cerrar el diálogo', () => {
    const dialog = render();
    const escape = new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true });
    dialog.querySelector('button')!.dispatchEvent(escape);
    expect(escape.defaultPrevented).toBe(true);
    expect(dialog.open).toBe(true);
    expect(dialog.getAttribute('closedby')).toBe('none');
  });

  it('mantiene el bloqueo durante la salida y al terminar recuerda la respuesta y restaura el desplazamiento', () => {
    const dialog = render();
    confirm(dialog);
    expect(dialog.open).toBe(true);
    expect(dialog.classList.contains('is-closing')).toBe(true);
    expect(dialog.querySelector('button')!.disabled).toBe(true);
    expect(sessionStorage.getItem(key)).toBeNull();
    dialog.dispatchEvent(new Event('animationend'));
    expect(dialog.open).toBe(false);
    expect(sessionStorage.getItem(key)).toBe('true');
    expect(document.documentElement.style.overflow).toBe('auto');
  });

  it('libera el catálogo incluso si el navegador no emite el final de la animación', () => {
    const dialog = render();
    confirm(dialog);
    vi.advanceTimersByTime(350);
    expect(dialog.open).toBe(false);
    expect(sessionStorage.getItem(key)).toBe('true');
  });

  it('no repite el aviso si ya se confirmó en esta sesión de la pestaña', () => {
    sessionStorage.setItem(key, 'true');
    expect(render().open).toBe(false);
    expect(document.documentElement.style.overflow).toBe('auto');
  });

  it('permite confirmar aunque el navegador bloquee el almacenamiento', () => {
    vi.spyOn(Storage.prototype, 'getItem').mockImplementation(() => { throw new Error('Bloqueado'); });
    vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => { throw new Error('Bloqueado'); });
    const dialog = render();
    expect(dialog.open).toBe(true);
    confirm(dialog);
    vi.advanceTimersByTime(350);
    expect(dialog.open).toBe(false);
    expect(document.documentElement.style.overflow).toBe('auto');
  });

  it('dirige al menor al portal indicado en la misma pestaña, sin guardar confirmación', () => {
    const dialog = render();
    const link = dialog.querySelector('a')!;
    expect(link.href).toBe('https://alcoholinformate.org.mx/');
    expect(link.target).toBe('_self');
    expect(sessionStorage.getItem(key)).toBeNull();
  });

  it('restaura el desplazamiento y cancela el cierre pendiente al salir del catálogo', () => {
    const dialog = render();
    confirm(dialog);
    fixture!.destroy();
    fixture = undefined;
    vi.advanceTimersByTime(350);
    expect(document.documentElement.style.overflow).toBe('auto');
    expect(sessionStorage.getItem(key)).toBeNull();
  });
});

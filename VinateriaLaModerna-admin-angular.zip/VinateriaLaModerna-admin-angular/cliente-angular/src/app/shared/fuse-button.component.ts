import { Component, Input, Output, EventEmitter, signal, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-fuse-button',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <button type="button" class="fuse-btn" 
            [disabled]="disabled || state() === 'done'"
            (click)="handleClick()"
            [style.--fuse-color]="fuseColor"
            [style.--fuse-duration]="undoWindow + 'ms'"
            [style.--fuse-bg]="background"
            [style.--fuse-text]="color"
            [style.border-radius.px]="radius">
      
      @if (state() === 'fusing') {
        <svg class="fuse-svg" width="100%" height="100%">
           <rect x="0" y="0" width="100%" height="100%" [attr.rx]="radius" [attr.ry]="radius" 
                 class="fuse-stroke" pathLength="100" [style.stroke-width]="fuseThickness"></rect>
        </svg>
      }

      <span class="fuse-content">
        @if (state() === 'idle') {
          {{ label }}
        } @else if (state() === 'fusing') {
          {{ undoLabel }}
        } @else {
          {{ doneLabel }}
        }
      </span>
    </button>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
    }
    .fuse-btn {
      width: 100%;
      box-sizing: border-box;
      position: relative;
      background: var(--fuse-bg);
      color: var(--fuse-text);
      border: none;
      cursor: pointer;
      font-weight: bold;
      overflow: hidden;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 12px 25px;
      min-width: 150px;
      transition: opacity 0.2s, background 0.2s;
    }
    .fuse-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    .fuse-svg {
      position: absolute;
      top: 0;
      left: 0;
      pointer-events: none;
    }
    .fuse-stroke {
      fill: none;
      stroke: var(--fuse-color);
      stroke-dasharray: 100;
      stroke-dashoffset: 0;
      animation: fuse-anim var(--fuse-duration) linear forwards;
    }
    @keyframes fuse-anim {
      from { stroke-dashoffset: 0; }
      to { stroke-dashoffset: 100; }
    }
    .fuse-content {
      position: relative;
      z-index: 2;
    }
  `]
})
export class FuseButtonComponent implements OnDestroy {
  @Input() label = 'Action';
  @Input() doneLabel = 'Done';
  @Input() undoLabel = 'Undo';
  @Input() color = '#fff';
  @Input() background = '#640d14';
  @Input() fuseColor = '#d4af37';
  @Input() radius = 99;
  @Input() undoWindow = 4000;
  @Input() fuseThickness = 3;
  @Input() disabled = false;

  @Output() onCommit = new EventEmitter<void>();
  @Output() onUndo = new EventEmitter<void>();
  @Output() onFuseEnd = new EventEmitter<void>();

  state = signal<'idle' | 'fusing' | 'done'>('idle');
  private timeoutId: any;

  handleClick() {
    if (this.state() === 'idle') {
      this.state.set('fusing');
      this.onCommit.emit();
      this.timeoutId = setTimeout(() => {
        this.state.set('done');
        this.onFuseEnd.emit();
      }, this.undoWindow);
    } else if (this.state() === 'fusing') {
      clearTimeout(this.timeoutId);
      this.state.set('idle');
      this.onUndo.emit();
    }
  }

  ngOnDestroy() {
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
  }
}

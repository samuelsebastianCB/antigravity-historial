import { Component, inject, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { trigger, style, animate, transition, query, stagger } from '@angular/animations';
import { CartService } from '../core/cart.service';
import { CountUpComponent } from './count-up.component';

@Component({
  selector: 'app-cart-menu',
  standalone: true,
  imports: [CommonModule, CountUpComponent],
  template: `
    <!-- Botón Flotante del Carrito (se oculta en catálogo para no duplicar con el drawer principal) -->
    @if (!isCatalog()) {
      <div class="cart-fab" (click)="toggleMenu()">
        <div class="cart-icon">🛒</div>
        @if (cart.count() > 0) {
          <span class="badge">{{ cart.count() }}</span>
        }
      </div>
    }

    <!-- Menú Staggered -->
    @if (isOpen) {
      <div class="cart-backdrop" (click)="cerrarMenu()"></div>
      <div class="staggered-menu" @slideIn>
        <div class="menu-header">
          <h3>Carrito de Compras ({{ cart.count() }})</h3>
          <button class="close-btn" (click)="cerrarMenu()">✕</button>
        </div>

        <div class="menu-body" @staggerList>
          @if (cart.items().length === 0) {
            <p class="empty-msg">Tu carrito está vacío.</p>
          }
          @for (item of cart.items(); track item.product_id) {
            <div class="cart-item">
              <div class="item-info">
                <h4>{{ item.nombre }}</h4>
                <div class="price">\${{ item.precio | number:'1.2-2' }}</div>
              </div>
              <div class="qty-controls">
                <button (click)="cart.change(item.product_id, -1)">-</button>
                <span>{{ item.cantidad }}</span>
                <button (click)="cart.change(item.product_id, 1)">+</button>
              </div>
              <button class="del-btn" (click)="cart.remove(item.product_id)">🗑️</button>
            </div>
          }
        </div>

        @if (cart.items().length > 0) {
          <div class="menu-footer" @fadeIn>
            <div class="total-row">
              <span>Total:</span>
              <strong class="count-up-text"><app-count-up [to]="cart.rawTotal()" [duration]="1" prefix="$" separator="," [decimals]="2"></app-count-up></strong>
            </div>
            <button class="checkout-btn" (click)="irAPagar()">Procesar Pago</button>
          </div>
        }
      </div>
    }
  `,
  styles: [`
    .cart-fab {
      position: fixed;
      bottom: 30px;
      right: 30px;
      width: 65px;
      height: 65px;
      background: var(--primary-color, #640d14);
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      box-shadow: 0 6px 16px rgba(100, 13, 20, 0.4);
      cursor: pointer;
      z-index: 9999;
      transition: transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    .cart-fab:hover {
      transform: scale(1.1);
    }
    .cart-icon {
      font-size: 2rem;
    }
    .badge {
      position: absolute;
      top: -2px;
      right: -2px;
      background: #ff6b6b;
      color: white;
      font-weight: bold;
      font-size: 0.85rem;
      width: 26px;
      height: 26px;
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      border: 2px solid white;
    }
    .cart-backdrop {
      position: fixed;
      inset: 0;
      z-index: 9998;
    }
    .staggered-menu {
      position: fixed;
      bottom: 110px;
      right: 30px;
      width: 320px;
      max-height: 500px;
      background: #fff;
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.15);
      z-index: 9999;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      border: 1px solid #eaeaea;
    }
    .menu-header {
      background: var(--primary-color, #640d14);
      color: white;
      padding: 15px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .menu-header h3 {
      margin: 0;
      font-size: 1.1rem;
    }
    .close-btn {
      background: none;
      border: none;
      color: white;
      font-size: 1.2rem;
      cursor: pointer;
    }
    .menu-body {
      padding: 15px;
      overflow-y: auto;
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    .empty-msg {
      text-align: center;
      color: #888;
      margin: 20px 0;
    }
    .cart-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px;
      background: #f8f9fa;
      border-radius: 8px;
    }
    .item-info {
      flex: 1;
    }
    .item-info h4 {
      margin: 0 0 4px;
      font-size: 0.95rem;
      color: #333;
    }
    .price {
      font-weight: bold;
      color: var(--primary-color, #640d14);
    }
    .qty-controls {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 0 10px;
      background: #fff;
      border-radius: 99px;
      border: 1px solid #ddd;
      padding: 2px 6px;
    }
    .qty-controls button {
      border: none;
      background: none;
      font-size: 1.2rem;
      cursor: pointer;
      color: #555;
    }
    .del-btn {
      background: none;
      border: none;
      cursor: pointer;
      font-size: 1.1rem;
      opacity: 0.6;
    }
    .del-btn:hover {
      opacity: 1;
    }
    .menu-footer {
      padding: 15px 20px;
      border-top: 1px solid #eee;
      background: #fafafa;
    }
    .total-row {
      display: flex;
      justify-content: space-between;
      font-size: 1.2rem;
      margin-bottom: 15px;
      color: #333;
    }
    .checkout-btn {
      width: 100%;
      padding: 12px;
      border: none;
      background: #2e7d32;
      color: white;
      font-weight: bold;
      font-size: 1rem;
      border-radius: 99px;
      cursor: pointer;
      transition: background 0.2s;
    }
    .checkout-btn:hover {
      background: #1b5e20;
    }
  `],
  animations: [
    trigger('slideIn', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(20px) scale(0.95)' }),
        animate('0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)', style({ opacity: 1, transform: 'translateY(0) scale(1)' }))
      ]),
      transition(':leave', [
        animate('0.2s ease-in', style({ opacity: 0, transform: 'translateY(20px) scale(0.95)' }))
      ])
    ]),
    trigger('staggerList', [
      transition(':enter', [
        query('.cart-item', [
          style({ opacity: 0, transform: 'translateX(-10px)' }),
          stagger(50, [
            animate('0.3s ease-out', style({ opacity: 1, transform: 'translateX(0)' }))
          ])
        ], { optional: true })
      ])
    ]),
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('0.4s 0.2s ease-out', style({ opacity: 1 }))
      ])
    ])
  ]
})
export class CartMenuComponent {
  cart = inject(CartService);
  router = inject(Router);

  menuOpen = false;

  isCatalog(): boolean {
    return this.router.url.includes('/catalogo');
  }

  get isOpen(): boolean {
    if (this.isCatalog()) return false;
    return this.menuOpen || this.cart.drawerOpen();
  }

  toggleMenu() {
    if (this.isCatalog()) {
      this.cart.toggleDrawer();
    } else {
      this.menuOpen = !this.menuOpen;
      if (this.menuOpen) this.cart.openDrawer();
      else this.cart.closeDrawer();
    }
  }

  cerrarMenu() {
    this.menuOpen = false;
    this.cart.closeDrawer();
  }

  irAPagar() {
    this.cerrarMenu();
    this.router.navigate(['/carrito']);
  }

  @HostListener('document:keydown.escape')
  onEsc() {
    this.cerrarMenu();
  }
}


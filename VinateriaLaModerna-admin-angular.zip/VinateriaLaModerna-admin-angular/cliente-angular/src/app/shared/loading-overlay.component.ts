import { ChangeDetectionStrategy, Component, DestroyRef, inject, signal } from '@angular/core';
import { NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router } from '@angular/router';
import { LoadingService } from '../core/loading.service';

const LOGO = 'https://res.cloudinary.com/dhcwmbzso/image/upload/q_auto/f_auto/v1779417085/Vinater%C3%ADa_La_Moderna_n3xvsj.png';

const TIPS = [
  { icon: '🍷', text: 'El vino tinto combina muy bien con quesos curados y carnes rojas.' },
  { icon: '🍺', text: 'La cerveza tiene diferentes perfiles de sabor según su estilo: IPA, stout, lager…' },
  { icon: '🍇', text: 'La temperatura adecuada puede mejorar la experiencia de un vino.' },
  { icon: '🥃', text: 'El whisky se disfruta mejor en vaso corto y con unas gotas de agua para abrir sus aromas.' },
  { icon: '🍾', text: 'Sirve el espumoso entre 6 y 8 °C para realzar sus burbujas.' },
  { icon: '🌵', text: 'Un buen tequila reposado equilibra notas de agave y madera.' },
  { icon: '🧊', text: 'Los vinos blancos y rosados lucen mejor bien fríos; los tintos, ligeramente frescos.' },
  { icon: '🥂', text: 'Deja respirar un vino joven unos minutos antes de servirlo.' },
  { icon: '🍹', text: 'El ron blanco es la base ideal para mojitos y daiquiris.' },
  { icon: '🍾', text: 'Guarda las botellas de vino acostadas y lejos de la luz directa.' },
];

/** Pantalla de carga con la identidad de la viñatería: barra de progreso + consejo rotativo. */
@Component({
  selector: 'app-loading-overlay',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (loading.visible()) {
      <div class="overlay" role="status" aria-live="polite" aria-label="Cargando">
        <div class="card">
          <img class="logo" [src]="logo" alt="">
          <p class="brand">Vinatería La Moderna</p>
          <div class="bar" role="progressbar" aria-label="Progreso de carga"><div class="fill"></div></div>
          @for (t of [tip()]; track t.text) {
            <p class="tip"><span aria-hidden="true">{{ t.icon }}</span> {{ t.text }}</p>
          }
        </div>
      </div>
    }
  `,
  styles: [`
    .overlay {
      position: fixed; inset: 0; z-index: 20000;
      display: flex; align-items: center; justify-content: center; padding: 20px;
      background: linear-gradient(135deg, rgba(74,8,16,.96), rgba(100,13,20,.94) 55%, rgba(47,5,11,.97));
      animation: fade .2s ease-out;
    }
    .card { width: min(520px, 100%); text-align: center; color: #f0e8d8; }
    .logo { width: 84px; height: auto; margin: 0 auto 12px; display: block; filter: drop-shadow(0 4px 10px rgba(0,0,0,.4)); animation: float 2.4s ease-in-out infinite; }
    .brand { font-family: var(--font-serif, 'Cormorant Garamond', Georgia, serif); letter-spacing: 4px; text-transform: uppercase; color: #d4af88; font-size: 1.15rem; margin: 0 0 22px; }
    .bar { width: min(75%, 360px); height: 6px; margin: 0 auto; border-radius: 99px; background: rgba(212,175,136,.2); overflow: hidden; }
    .fill { height: 100%; width: 5%; border-radius: inherit; background: linear-gradient(90deg, #c59b6f, #d4af88, #f0d9b5); animation: fill 8s cubic-bezier(.1,.7,.2,1) forwards; }
    .tip { min-height: 3.2em; margin: 22px auto 0; max-width: 440px; font-size: .95rem; line-height: 1.5; animation: tip .45s ease-out; }
    @keyframes fill { to { width: 92%; } }
    @keyframes fade { from { opacity: 0; } }
    @keyframes tip { from { opacity: 0; transform: translateY(6px); } }
    @keyframes float { 50% { transform: translateY(-4px); } }
    @media (prefers-reduced-motion: reduce) { .logo, .tip { animation: none; } }
  `],
})
export class LoadingOverlayComponent {
  readonly loading = inject(LoadingService);
  readonly logo = LOGO;
  private readonly index = signal(Math.floor(Math.random() * TIPS.length));
  readonly tip = () => TIPS[this.index()];

  constructor() {
    const router = inject(Router);
    const sub = router.events.subscribe(event => {
      if (event instanceof NavigationStart) this.loading.begin();
      else if (event instanceof NavigationEnd || event instanceof NavigationCancel || event instanceof NavigationError) this.loading.end();
    });
    // Cambia el consejo sólo mientras la pantalla de carga está visible.
    const timer = setInterval(() => { if (this.loading.visible()) this.index.update(i => (i + 1) % TIPS.length); }, 3000);
    inject(DestroyRef).onDestroy(() => { sub.unsubscribe(); clearInterval(timer); });
  }
}

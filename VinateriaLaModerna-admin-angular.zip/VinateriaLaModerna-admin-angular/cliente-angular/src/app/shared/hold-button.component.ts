import { Component, Input, Output, EventEmitter, signal, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-hold-button',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <button 
      class="hold-btn" 
      [class.filling]="isHolding()" 
      [class.done]="state() === 'done'"
      [style.--bg-color]="backgroundColor"
      [style.--fill-color]="fillColor"
      [style.--text-color]="textColor"
      [style.--fill-text-color]="fillTextColor"
      [style.--radius]="radius + 'px'"
      [style.--hold-time]="holdTime + 'ms'"
      [style.--release-time]="releaseTime + 'ms'"
      [style.transform]="'scale(' + (isHolding() ? pressScale : 1) + ')'"
      (mousedown)="startHold($event)"
      (touchstart)="startHold($event)"
      (mouseup)="stopHold()"
      (mouseleave)="stopHold()"
      (touchend)="stopHold()">
      
      <div class="fill-layer" [class.animate-fill]="isHolding()" [class.revert-fill]="!isHolding() && state() === 'idle'"></div>
      
      <span class="content">
        @if (state() === 'done') {
          {{ doneLabel }}
        } @else {
          <ng-content></ng-content>
        }
      </span>
    </button>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
    }
    .hold-btn {
      width: 100%;
      box-sizing: border-box;
      position: relative;
      background: var(--bg-color);
      color: var(--text-color);
      border: none;
      border-radius: var(--radius);
      padding: 12px 20px;
      font-weight: bold;
      cursor: pointer;
      overflow: hidden;
      outline: none;
      user-select: none;
      transition: transform 0.1s ease;
      min-width: 140px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .fill-layer {
      position: absolute;
      top: 0; left: 0; bottom: 0;
      width: 0%;
      background: var(--fill-color);
      z-index: 1;
    }
    .animate-fill {
      width: 100%;
      transition: width var(--hold-time) linear;
    }
    .revert-fill {
      width: 0%;
      transition: width var(--release-time) ease-out;
    }
    .done .fill-layer {
      width: 100%;
      transition: none;
    }
    .content {
      position: relative;
      z-index: 2;
    }
    .filling .content, .done .content {
      color: var(--fill-text-color);
    }
  `]
})
export class HoldButtonComponent implements OnDestroy {
  @Input() doneLabel = 'Done';
  @Input() backgroundColor = '#27272a';
  @Input() fillColor = '#5227FF';
  @Input() textColor = '#f5f5f5';
  @Input() fillTextColor = '#ffffff';
  @Input() radius = 14;
  @Input() holdTime = 2000;
  @Input() releaseTime = 200;
  @Input() pressScale = 0.97;
  @Input() resetAfter = 1200;

  @Output() onHold = new EventEmitter<void>();

  isHolding = signal(false);
  state = signal<'idle' | 'done'>('idle');
  private holdTimeout: any;
  private resetTimeout: any;

  startHold(event: Event) {
    if (this.state() === 'done') return;
    
    // Prevent context menu on mobile long press
    if (event.type === 'touchstart') {
       // but wait, passive event listener doesn't allow preventDefault easily.
       // we just won't call it if not needed.
    }

    this.isHolding.set(true);
    this.holdTimeout = setTimeout(() => {
      this.isHolding.set(false);
      this.state.set('done');
      this.onHold.emit();

      if (this.resetAfter > 0) {
        this.resetTimeout = setTimeout(() => {
          this.state.set('idle');
        }, this.resetAfter);
      }
    }, this.holdTime);
  }

  stopHold() {
    if (this.state() === 'done') return;
    this.isHolding.set(false);
    if (this.holdTimeout) {
      clearTimeout(this.holdTimeout);
    }
  }

  ngOnDestroy() {
    if (this.holdTimeout) clearTimeout(this.holdTimeout);
    if (this.resetTimeout) clearTimeout(this.resetTimeout);
  }
}

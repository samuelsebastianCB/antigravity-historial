import { Component, Input, Output, EventEmitter, ElementRef, ViewChild, AfterViewInit, OnDestroy, HostListener, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface CarouselItem {
  title: string;
  description: string;
  image: string;
}

@Component({
  selector: 'app-carousel',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="carousel-container" [attr.data-theme]="theme" [class.frame]="frame" [style.--radius]="radius + 'px'">
      <div class="carousel-track-wrapper" 
           #trackWrapper
           (mousedown)="onPointerDown($event)"
           (touchstart)="onPointerDown($event)"
           (mousemove)="onPointerMove($event)"
           (touchmove)="onPointerMove($event)"
           (mouseup)="onPointerUp()"
           (mouseleave)="onPointerUp()"
           (touchend)="onPointerUp()">
           
        <div class="carousel-track" 
             #track 
             [style.gap.px]="gap"
             [style.transform]="'translate3d(' + currentTranslate() + 'px, 0, 0)'"
             [style.transition]="isDragging() ? 'none' : 'transform 0.5s cubic-bezier(0.25, 1, 0.5, 1)'">
             
          @for (item of items; track $index; let i = $index) {
            <div class="carousel-slide" 
                 [style.width.px]="effectiveWidth()"
                 [style.aspect-ratio]="aspectRatio"
                 [class.active]="currentIndex() === i"
                 [class.tilt]="effect === 'tilt'">
              
              <img [src]="item.image" [alt]="item.title" draggable="false">
              
              <div class="slide-content">
                <h3>{{ item.title }}</h3>
                <p>{{ item.description }}</p>
              </div>
            </div>
          }
        </div>
      </div>

      @if (indicator === 'dots') {
        <div class="carousel-dots">
          @for (item of items; track $index; let i = $index) {
            <button class="dot" 
                    [class.active]="currentIndex() === i" 
                    (click)="goTo(i)" 
                    [attr.aria-label]="'Ir a diapositiva ' + (i + 1)"></button>
          }
        </div>
      }
    </div>
  `,
  styles: [`
    .carousel-container {
      position: relative;
      width: 100%;
      height: 100%;
      overflow: hidden;
      --radius: 14px;
    }
    .carousel-container.frame {
      padding: 16px;
    }
    .carousel-track-wrapper {
      width: 100%;
      height: 100%;
      overflow: hidden;
      cursor: grab;
      touch-action: pan-y;
      display: flex;
      align-items: center;
    }
    .carousel-track-wrapper:active {
      cursor: grabbing;
    }
    .carousel-track {
      display: flex;
      will-change: transform;
      height: 100%;
      align-items: center;
    }
    .carousel-slide {
      flex-shrink: 0;
      position: relative;
      border-radius: var(--radius);
      overflow: hidden;
      transform-origin: center center;
      transition: transform 0.5s cubic-bezier(0.25, 1, 0.5, 1), opacity 0.5s;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35);
    }
    .carousel-slide img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      user-select: none;
      pointer-events: none;
    }
    .slide-content {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      padding: 24px 32px;
      background: linear-gradient(to top, rgba(10, 2, 4, 0.94) 0%, rgba(45, 6, 12, 0.7) 50%, transparent 100%);
      color: white;
      text-shadow: 0 2px 8px rgba(0,0,0,0.6);
    }
    .slide-content h3 {
      margin: 0 0 6px 0;
      font-size: 1.6rem;
      font-family: 'Cormorant Garamond', Georgia, serif;
      letter-spacing: 1.2px;
      color: #D4AF88;
    }
    .slide-content p {
      margin: 0;
      font-size: 0.95rem;
      color: #f3ece4;
      max-width: 650px;
      line-height: 1.4;
    }
    
    /* Tilt Effect */
    .carousel-slide.tilt {
      transform: perspective(800px) rotateY(12deg) scale(0.92);
      opacity: 0.65;
    }
    .carousel-slide.tilt.active {
      transform: perspective(800px) rotateY(0deg) scale(1);
      opacity: 1;
      z-index: 2;
    }
    
    /* Dots */
    .carousel-dots {
      position: absolute;
      bottom: 16px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      gap: 10px;
      z-index: 10;
    }
    .dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: rgba(255,255,255,0.4);
      border: 1px solid rgba(255,255,255,0.6);
      cursor: pointer;
      padding: 0;
      transition: all 0.3s ease;
    }
    .dot.active {
      background: #D4AF88;
      border-color: #D4AF88;
      transform: scale(1.3);
      box-shadow: 0 0 8px rgba(212, 175, 136, 0.6);
    }
    .carousel-container[data-theme="light"] .dot {
      background: rgba(0,0,0,0.25);
      border-color: rgba(0,0,0,0.4);
    }
    .carousel-container[data-theme="light"] .dot.active {
      background: #640D14;
      border-color: #640D14;
    }
  `]
})
export class CarouselComponent implements AfterViewInit, OnDestroy {
  @Input() items: CarouselItem[] = [];
  @Input() baseWidth = 850;
  @Input() aspectRatio = 2.8;
  @Input() effect: 'slide' | 'tilt' = 'slide';
  @Input() indicator: 'dots' | 'none' = 'dots';
  @Input() frame = false;
  @Input() theme = 'dark';
  @Input() gap = 16;
  @Input() radius = 14;
  @Input() draggable = true;
  @Input() autoPlay = true;
  @Input() autoPlayInterval = 5500;

  @ViewChild('trackWrapper') trackWrapper!: ElementRef<HTMLElement>;

  currentIndex = signal(0);
  currentTranslate = signal(0);
  isDragging = signal(false);
  effectiveWidth = signal(850);

  private startX = 0;
  private currentX = 0;
  private prevTranslate = 0;
  private animationRef: any;
  private autoPlayTimer: any;

  ngAfterViewInit() {
    this.recomputeWidth();
    if (this.autoPlay && this.items.length > 1) {
      this.startAutoPlay();
    }
  }

  ngOnDestroy() {
    this.stopAutoPlay();
    if (this.animationRef) cancelAnimationFrame(this.animationRef);
  }

  private startAutoPlay() {
    this.stopAutoPlay();
    this.autoPlayTimer = setInterval(() => {
      if (!this.isDragging() && this.items.length > 1) {
        const next = (this.currentIndex() + 1) % this.items.length;
        this.goTo(next);
      }
    }, this.autoPlayInterval);
  }

  private stopAutoPlay() {
    if (this.autoPlayTimer) clearInterval(this.autoPlayTimer);
  }

  @HostListener('window:resize')
  onResize() {
    this.recomputeWidth();
  }

  private recomputeWidth() {
    if (this.trackWrapper) {
      const containerWidth = this.trackWrapper.nativeElement.clientWidth;
      const target = this.baseWidth > 0 ? this.baseWidth : containerWidth;
      const padding = this.frame ? 32 : 0;
      const available = containerWidth - padding;
      const calculated = Math.min(target, available > 200 ? available : target);
      this.effectiveWidth.set(Math.max(260, Math.round(calculated)));
    } else {
      this.effectiveWidth.set(this.baseWidth);
    }
    this.updatePosition();
  }

  onPointerDown(e: MouseEvent | TouchEvent) {
    if (!this.draggable) return;
    this.stopAutoPlay();
    this.isDragging.set(true);
    this.startX = e instanceof MouseEvent ? e.clientX : e.touches[0].clientX;
    this.animationRef = requestAnimationFrame(() => this.animationLoop());
  }

  onPointerMove(e: MouseEvent | TouchEvent) {
    if (!this.isDragging()) return;
    const x = e instanceof MouseEvent ? e.clientX : e.touches[0].clientX;
    this.currentX = x;
  }

  onPointerUp() {
    if (!this.isDragging()) return;
    this.isDragging.set(false);
    cancelAnimationFrame(this.animationRef);

    const movedBy = this.currentX - this.startX;
    if (movedBy < -50 && this.currentIndex() < this.items.length - 1) {
      this.currentIndex.update(i => i + 1);
    } else if (movedBy > 50 && this.currentIndex() > 0) {
      this.currentIndex.update(i => i - 1);
    }

    this.updatePosition();
    if (this.autoPlay) this.startAutoPlay();
  }

  animationLoop() {
    if (this.isDragging()) {
      const currentPos = this.prevTranslate + (this.currentX - this.startX);
      this.currentTranslate.set(currentPos);
      this.animationRef = requestAnimationFrame(() => this.animationLoop());
    }
  }

  goTo(index: number) {
    this.currentIndex.set(index);
    this.updatePosition();
  }

  updatePosition() {
    const width = this.effectiveWidth();
    const slideTotalWidth = width + this.gap;
    const offset = -(this.currentIndex() * slideTotalWidth);
    
    let centerOffset = 0;
    if (this.trackWrapper) {
       centerOffset = (this.trackWrapper.nativeElement.clientWidth - width) / 2;
    }
    
    this.prevTranslate = offset + centerOffset;
    this.currentTranslate.set(this.prevTranslate);
  }
}

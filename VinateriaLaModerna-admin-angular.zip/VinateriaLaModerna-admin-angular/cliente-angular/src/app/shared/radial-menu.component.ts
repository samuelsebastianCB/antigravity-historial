import { Component, AfterViewInit, ElementRef, ViewChild, ViewChildren, QueryList, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import gsap from 'gsap';
import { ThemeService } from '../core/theme.service';

@Component({
  selector: 'app-radial-menu',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="fab-wrap">
      <!-- Item 1: Home -->
      <button class="fab-item" #item aria-label="Inicio" (click)="goHome()" title="Ir al Inicio">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
          <polyline points="9 22 9 12 15 12 15 22"></polyline>
        </svg>
      </button>
      
      <!-- Item 2: Buscar -->
      <button class="fab-item" #item aria-label="Buscar" (click)="search()" title="Buscar Productos">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <circle cx="11" cy="11" r="8" />
          <path d="m21 21-4.35-4.35" />
        </svg>
      </button>

      <!-- Item 3: Ayuda -->
      <button class="fab-item" #item aria-label="Ayuda" (click)="help()" title="Centro de Ayuda">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <circle cx="12" cy="12" r="10"></circle>
          <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
          <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
      </button>

      <!-- Item 4: Tema -->
      <button class="fab-item" #item aria-label="Cambiar Tema" (click)="theme.toggle()" title="Cambiar Tema">
        @if (theme.dark()) {
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <circle cx="12" cy="12" r="5"></circle>
            <line x1="12" y1="1" x2="12" y2="3"></line>
            <line x1="12" y1="21" x2="12" y2="23"></line>
            <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
            <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
            <line x1="1" y1="12" x2="3" y2="12"></line>
            <line x1="21" y1="12" x2="23" y2="12"></line>
            <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
            <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
          </svg>
        } @else {
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
          </svg>
        }
      </button>
      
      <!-- Main FAB Button -->
      <button class="fab" id="fabBtn" aria-label="Herramientas" [attr.aria-expanded]="isOpen" (click)="toggle()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" #fabIcon>
          <line x1="12" y1="5" x2="12" y2="19" />
          <line x1="5" y1="12" x2="19" y2="12" />
        </svg>
      </button>
    </div>
  `,
  styles: [`
    .fab-wrap {
      position: fixed;
      bottom: 80px;
      left: 25px;
      z-index: 1000;
    }
    .fab {
      width: 60px;
      height: 60px;
      border-radius: 99px;
      border: none;
      background: #640D14; /* Color institucional La Moderna */
      color: white;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      z-index: 2;
      box-shadow: 0 4px 15px rgba(100, 13, 20, 0.4);
      transition: box-shadow 0.2s, background 0.2s;
    }
    .fab:hover, .fab:focus-visible {
      box-shadow: 0 6px 20px rgba(100, 13, 20, 0.6);
      outline: none;
    }
    .fab svg {
      width: 26px;
      height: 26px;
    }
    .fab-item {
      position: absolute;
      bottom: 7px;
      left: 7px;
      width: 45px;
      height: 45px;
      border-radius: 99px;
      border: 1px solid rgba(255,255,255,0.15);
      background: #4A0810;
      color: white;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      scale: 0;
      padding: 0;
      z-index: 1;
      box-shadow: 0 3px 10px rgba(0,0,0,0.2);
    }
    .fab-item:hover, .fab-item:focus-visible {
      background: #7a1020;
      outline: none;
    }
    .fab-item svg {
      width: 20px;
      height: 20px;
      pointer-events: none;
    }
  `]
})
export class RadialMenuComponent implements AfterViewInit {
  @ViewChildren('item') items!: QueryList<ElementRef>;
  @ViewChild('fabIcon') fabIcon!: ElementRef;

  isOpen = false;
  private tl: any;
  private router = inject(Router);
  theme = inject(ThemeService);

  ngAfterViewInit() {
    this.buildTimeline();
  }

  buildTimeline() {
    const elements = this.items.map(i => i.nativeElement);
    gsap.set(elements, { x: 0, y: 0, scale: 0, opacity: 0 });

    this.tl = gsap.timeline({ paused: true });
    const radius = 90;
    // Animar hacia arriba y la derecha (ya que el fab está abajo a la izquierda)
    const startAngle = -90; // Arriba
    const endAngle = 0;     // Derecha
    const angleStep = (endAngle - startAngle) / (elements.length - 1);

    elements.forEach((item, i) => {
      const angle = (startAngle + angleStep * i) * (Math.PI / 180);
      const tx = Math.cos(angle) * radius;
      const ty = Math.sin(angle) * radius;
      
      this.tl.to(
        item,
        {
          x: tx,
          y: ty,
          scale: 1,
          opacity: 1,
          duration: 0.5,
          ease: "back.out(1.5)",
        },
        i * 0.05
      );
    });

    this.tl.to(
      this.fabIcon.nativeElement,
      {
        rotation: 135,
        duration: 0.35,
        ease: "back.out(1.7)",
      },
      0
    );
  }

  toggle() {
    this.isOpen = !this.isOpen;
    if (this.isOpen) {
      this.tl.timeScale(1).play();
    } else {
      this.tl.timeScale(1.5).reverse();
    }
  }

  goHome() {
    this.router.navigate(['/']);
    this.toggle();
  }

  help() {
    alert('Centro de ayuda en construcción. ¡Contacta a soporte!');
    this.toggle();
  }

  search() {
    this.router.navigate(['/catalogo']);
    setTimeout(() => {
      const input = document.getElementById('input-busqueda');
      if (input) {
        input.focus();
      }
    }, 100);
    this.toggle();
  }
}

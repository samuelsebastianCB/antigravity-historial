import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

/**
 * Etiqueta con el sistema de variantes de shadcn/ui (default, secondary, destructive, outline)
 * más `active` para filtros. Si es `interactive` se renderiza como botón (toggle de filtro);
 * con `removable` muestra una × que emite `remove`.
 */
@Component({
  selector: 'app-badge',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (interactive()) {
      <span class="badge" [class]="'v-' + variant()" [class.active]="active()">
        <button type="button" class="main" [attr.aria-pressed]="active()" (click)="pressed.emit()"><ng-content /></button>
        @if (removable()) {
          <button type="button" class="x" [attr.aria-label]="'Quitar filtro ' + label()" (click)="remove.emit()">×</button>
        }
      </span>
    } @else {
      <span class="badge" [class]="'v-' + variant()" [class.active]="active()"><span class="main"><ng-content /></span></span>
    }
  `,
  styles: [`
    :host { display: inline-flex; max-width: 100%; }
    .badge {
      display: inline-flex; align-items: center; gap: 4px; max-width: 100%;
      border: 1.5px solid transparent; border-radius: 99px;
      font-family: var(--font-sans, inherit); font-size: .75rem; font-weight: 600; line-height: 1.2;
      padding: 3px 10px; white-space: nowrap; transition: background-color .18s, color .18s, border-color .18s, transform .12s;
    }
    .main { display: inline-flex; align-items: center; gap: 5px; overflow: hidden; text-overflow: ellipsis; background: none; border: 0; color: inherit; font: inherit; padding: 0; cursor: inherit; }
    button.main { cursor: pointer; padding: 2px 0; }
    .x { background: none; border: 0; color: inherit; font-size: 1rem; line-height: 1; cursor: pointer; padding: 0 0 1px 4px; opacity: .85; }
    .x:hover { opacity: 1; }
    button:focus-visible { outline: 2px solid var(--moderna-gold, #d4af88); outline-offset: 2px; border-radius: 99px; }

    .v-default { background: var(--moderna-vino, #640d14); color: #fff; }
    .v-secondary { background: var(--subnav-bg, #e8ded0); color: var(--text-main, #3e2723); }
    .v-destructive { background: #b3261e; color: #fff; }
    .v-outline { background: transparent; color: var(--text-main, #3e2723); border-color: var(--moderna-gold-subtle, rgba(212,175,136,.6)); }

    /* Filtros: inactivo = contorno suave; activo = relleno vino con texto claro. */
    .badge:has(button.main):hover { transform: translateY(-1px); }
    .v-outline.active, .v-secondary.active { background: var(--moderna-vino, #640d14); color: #fff; border-color: var(--moderna-vino, #640d14); }
  `],
})
export class BadgeComponent {
  readonly variant = input<'default' | 'secondary' | 'destructive' | 'outline'>('secondary');
  readonly active = input(false);
  readonly interactive = input(false);
  readonly removable = input(false);
  readonly label = input('');
  readonly pressed = output<void>();
  readonly remove = output<void>();
}


import { DOCUMENT } from '@angular/common';
import { afterNextRender, ChangeDetectionStrategy, Component, DestroyRef, ElementRef, HostListener, inject, input, output, viewChild } from '@angular/core';
import { CheckoutService } from '../../core/checkout.service';
import { Receipt } from '../../core/models';

@Component({
  selector: 'app-receipt',
  standalone: true,
  templateUrl: './receipt.html',
  styleUrl: './receipt.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReceiptComponent {
  readonly receipt = input.required<Receipt>();
  readonly closed = output<void>();
  private readonly checkout = inject(CheckoutService);
  private readonly document = inject(DOCUMENT);
  private readonly destroyRef = inject(DestroyRef);
  private readonly printButton = viewChild.required<ElementRef<HTMLButtonElement>>('printButton');
  private readonly closeButton = viewChild.required<ElementRef<HTMLButtonElement>>('closeButton');
  private readonly currency = new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  constructor() {
    afterNextRender(() => {
      const previousFocus = this.document.activeElement;
      this.printButton().nativeElement.focus();
      this.destroyRef.onDestroy(() => {
        if (previousFocus instanceof HTMLElement && previousFocus.isConnected) previousFocus.focus();
      });
    });
  }

  money(value: number): string {
    return this.currency.format(value);
  }

  date(value: string): string {
    return new Date(value).toLocaleString('es-MX');
  }

  print(): void {
    this.checkout.print();
  }

  @HostListener('keydown.tab', ['$event'])
  keepFocusInDialog(event: Event): void {
    const keyboardEvent = event as KeyboardEvent;
    const first = this.printButton().nativeElement;
    const last = this.closeButton().nativeElement;
    if (keyboardEvent.shiftKey && this.document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!keyboardEvent.shiftKey && this.document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  @HostListener('document:keydown.escape')
  close(): void {
    this.closed.emit();
  }
}

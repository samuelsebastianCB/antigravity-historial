import { ChangeDetectionStrategy, Component, computed, inject, input, signal } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { CartService } from '../core/cart.service';
import { UserMenuComponent } from './user-menu.component';

const LOGO = 'https://res.cloudinary.com/dhcwmbzso/image/upload/q_auto/f_auto/v1779417085/Vinater%C3%ADa_La_Moderna_n3xvsj.png';

/**
 * Barra superior compartida por la tienda.
 * Distribución: [MENU] · [logo centrado] · [usuario + carrito].
 * El centrado usa una rejilla `1fr auto 1fr`, por lo que el logo no se desplaza
 * aunque el ancho del botón MENU y del área de usuario sean distintos.
 */
@Component({
  selector: 'app-site-header',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, UserMenuComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '[class.tone-light]': 'tone() === "light"',
    '(document:keydown.escape)': 'close()',
  },
  template: `
    <div class="bar">
      <div class="slot slot-left">
        <button type="button" class="menu-btn" aria-controls="site-side-menu" [attr.aria-expanded]="open()" (click)="toggle()">
          {{ open() ? 'CERRAR' : 'MENU' }}
        </button>
      </div>

      <a [routerLink]="logoLink()" class="brand" aria-label="Vinatería La Moderna, inicio">
        <img [src]="logo" alt="" class="brand-logo">
        <span class="brand-text"><span class="brand-pre">vinatería</span><span class="brand-name">la moderna</span></span>
      </a>

      <div class="slot slot-right">
        <app-user-menu></app-user-menu>
        @if (showCart()) {
          <button type="button" class="cart-link" aria-label="Ver carrito de compras" (click)="cart.toggleDrawer()">
            <span aria-hidden="true">🛒</span>
            @if (cart.count() > 0) { <span class="cart-count">{{ cart.count() }}</span> }
          </button>
        }
      </div>
    </div>

    <div class="backdrop" [class.open]="open()" (click)="close()" aria-hidden="true"></div>
    <aside id="site-side-menu" class="side" [class.open]="open()" [attr.inert]="open() ? null : ''" aria-label="Navegación del sitio">
      <div class="side-head">
        <span class="side-title">Vinatería La Moderna</span>
        <button type="button" class="side-close" aria-label="Cerrar menú" (click)="close()">✕</button>
      </div>
      <nav class="side-nav">
        <a routerLink="/inicio" routerLinkActive="active" class="side-link" (click)="close()"><span>🏠 Inicio y Promociones</span><small>01</small></a>
        <a routerLink="/catalogo" routerLinkActive="active" class="side-link" (click)="close()"><span>🍷 Catálogo de Licores</span><small>02</small></a>
        <a routerLink="/carrito" routerLinkActive="active" class="side-link" (click)="close()">
          <span>🛒 Mi Carrito y Pagos @if (cart.count() > 0) { ({{ cart.count() }}) }</span><small>03</small>
        </a>
        <a href="http://localhost:4200/" class="side-link side-link-admin"><span>Panel de Administración</span><small>↗</small></a>
      </nav>
    </aside>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      --hdr-fg: #fff;
      --hdr-accent: var(--moderna-gold, #d4af88);
    }
    :host(.tone-light) { --hdr-fg: var(--text-color, #2b2b2b); --hdr-accent: var(--primary-color, #640d14); }

    .bar {
      display: grid;
      grid-template-columns: 1fr auto 1fr;
      align-items: center;
      gap: 12px;
      max-width: 1400px;
      margin: 0 auto;
      padding: 10px 4%;
    }
    .slot { display: flex; align-items: center; gap: 10px; min-width: 0; }
    .slot-left { justify-content: flex-start; }
    .slot-right { justify-content: flex-end; }

    .menu-btn {
      background: transparent;
      border: 1.5px solid currentColor;
      color: var(--hdr-fg);
      font-family: var(--font-sans, inherit);
      font-weight: 700;
      font-size: .8rem;
      letter-spacing: .22em;
      padding: 9px 16px;
      border-radius: 99px;
      cursor: pointer;
      transition: background .2s, color .2s, border-color .2s;
    }
    .menu-btn:hover { color: var(--hdr-accent); border-color: var(--hdr-accent); }
    .menu-btn:focus-visible, .side-link:focus-visible, .side-close:focus-visible { outline: 3px solid var(--hdr-accent); outline-offset: 3px; }

    .brand { display: flex; align-items: center; gap: 12px; text-decoration: none; }
    .brand-logo { height: 58px; width: auto; object-fit: contain; filter: drop-shadow(0 2px 5px rgba(0,0,0,.3)); }
    .brand-text { display: flex; flex-direction: column; line-height: 1.1; }
    .brand-pre { font-size: .62rem; letter-spacing: 3px; text-transform: uppercase; color: var(--hdr-accent); font-weight: 500; }
    .brand-name { font-family: var(--font-serif, 'Playfair Display', serif); font-size: 1.5rem; letter-spacing: 3px; text-transform: uppercase; color: var(--hdr-fg); }

    .cart-link {
      position: relative;
      background: none;
      border: none;
      cursor: pointer;
      color: var(--hdr-fg);
      text-decoration: none;
      font-size: 1.25rem;
      padding: 6px;
      line-height: 1;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .cart-link:hover { transform: scale(1.08); }
    .cart-count {
      position: absolute; top: -4px; right: -6px;
      min-width: 20px; height: 20px; padding: 0 4px; box-sizing: border-box;
      border-radius: 99px; background: var(--hdr-accent); color: #3a0a10;
      font-size: .7rem; font-weight: 800; display: flex; align-items: center; justify-content: center;
    }
    :host ::ng-deep .user-name { color: var(--hdr-fg); white-space: nowrap; }

    /* ── Menú lateral (se superpone: no empuja ni reflujo del contenido) ── */
    .backdrop {
      position: fixed; inset: 0; z-index: 9998;
      background: rgba(14,16,15,.6);
      opacity: 0; visibility: hidden;
      transition: opacity .25s ease, visibility 0s linear .25s;
    }
    .backdrop.open { opacity: 1; visibility: visible; transition-delay: 0s; }
    .side {
      position: fixed; top: 0; left: 0; bottom: 0; z-index: 9999;
      width: min(340px, 86vw);
      background: #222; color: #eee;
      border-right: 1.5px solid #555;
      transform: translate3d(-100%, 0, 0);
      transition: transform .3s cubic-bezier(.22,.8,.3,1);
      will-change: transform;
      display: flex; flex-direction: column;
      box-shadow: 0 0 40px rgba(0,0,0,.45);
      overflow-y: auto;
    }
    .side.open { transform: translate3d(0, 0, 0); }
    .side-head { display: flex; align-items: center; justify-content: space-between; padding: 18px 20px; border-bottom: 1px solid #444; }
    .side-title { font-family: var(--font-serif, serif); letter-spacing: 2px; text-transform: uppercase; color: #d4af88; font-size: 1.05rem; }
    .side-close { background: none; border: 0; color: #ccc; font-size: 1.1rem; cursor: pointer; padding: 6px 10px; }
    .side-nav { display: flex; flex-direction: column; padding: 8px; }
    .side-link {
      display: flex; justify-content: space-between; align-items: center; gap: 10px;
      padding: 16px 14px; text-decoration: none; color: #eee; font-weight: 500; font-size: 1.05rem;
      border-radius: 10px; transition: background .15s, color .15s;
    }
    .side-link + .side-link { border-top: 1px solid #3a3a3a; border-radius: 0; }
    .side-link small { color: #999; font-size: .75rem; }
    .side-link:hover, .side-link.active { color: #d4af88; background: rgba(212,175,136,.08); }
    .side-link-admin { margin-top: 8px; }

    @media (max-width: 1024px) { .side { width: min(300px, 86vw); } }
    @media (max-width: 720px) {
      .bar { padding: 8px 3%; gap: 6px; }
      .brand-text { display: none; }
      .brand-logo { height: 44px; }
      .menu-btn { padding: 8px 12px; font-size: .72rem; letter-spacing: .16em; }
      :host ::ng-deep .user-name { display: none; }
    }
    @media (prefers-reduced-motion: reduce) { .side, .backdrop { transition: none; } }
  `],
})
export class SiteHeaderComponent {
  readonly tone = input<'dark' | 'light'>('dark');
  readonly showCart = input(true);
  readonly logoLink = input('/inicio');
  readonly cart = inject(CartService);
  readonly logo = LOGO;
  readonly open = signal(false);

  toggle(): void { this.open.update(v => !v); }
  close(): void { if (this.open()) this.open.set(false); }
}


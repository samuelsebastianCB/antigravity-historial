import { Product } from '../../core/models';
import { filtersFor, recommendProducts } from './recommendations';

function product(id: number, overrides: Partial<Product> = {}): Product {
  return { PRODUCT_ID: id, PRODUCT_NAME: 'Vino tinto de prueba', RETAIL_PRICE: 250,
    CURRENT_STOCK: 4, PRODUCT_STATUS: 'Activo', DESCRIPTION: '', FOTO_URL: '', ...overrides };
}
const ids = (products: Product[]) => products.map(item => item.PRODUCT_ID);

describe('Recomendaciones de licores', () => {
  it('solo recomienda productos activos, con existencias y precio finito válido', () => {
    const products = [
      product(1, { CURRENT_STOCK: 0 }), product(2, { CURRENT_STOCK: -3 }),
      product(3, { CURRENT_STOCK: NaN }), product(4, { CURRENT_STOCK: Infinity }),
      product(5, { CURRENT_STOCK: 0.5 }), product(6, { PRODUCT_STATUS: 'Inactivo' }),
      product(7, { PRODUCT_STATUS: '' }), product(8, { PRODUCT_STATUS: 'Agotado' }),
      product(9, { RETAIL_PRICE: NaN }), product(10, { RETAIL_PRICE: Infinity }),
      product(11, { RETAIL_PRICE: -1 }), product(12, { PRODUCT_STATUS: ' ACTIVO ' }),
      product(-1), product(0), product(1.5),
    ];
    expect(ids(recommendProducts(products, 'regalo', 'any'))).toEqual([12]);
  });

  it.each([
    ['under-300', [1, 2]], ['300-700', [3, 4]], ['700-1500', [5, 6]], ['1500-plus', [7, 8]],
  ] satisfies Array<[string, number[]]>)('respeta los extremos del presupuesto %s', (filter, expected) => {
    const products = [0, 299.99, 300, 699.99, 700, 1499.99, 1500, 2500]
      .map((price, index) => product(index + 1, { RETAIL_PRICE: price }));
    expect(ids(recommendProducts(products, 'regalo', filter))).toEqual(expected);
    expect(ids(recommendProducts(products, 'reunion', filter))).toEqual(expected);
  });

  it('permite uno o cero resultados sin sobrepasar el presupuesto elegido', () => {
    const products = [product(1, { RETAIL_PRICE: 450 }), product(2, { RETAIL_PRICE: 1500 })];
    expect(ids(recommendProducts(products, 'regalo', '300-700'))).toEqual([1]);
    expect(recommendProducts(products, 'regalo', 'under-300')).toEqual([]);
    expect(recommendProducts([], 'reunion', 'any')).toEqual([]);
  });

  it('limita a tres botellas distintas sin mutar el catálogo', () => {
    const products = [product(4), product(3), product(2), product(1), product(1)];
    const before = structuredClone(products);
    expect(ids(recommendProducts(products, 'regalo', 'any'))).toEqual([1, 2, 3]);
    expect(products).toEqual(before);
    expect(ids(recommendProducts([...products].reverse(), 'regalo', 'any'))).toEqual([1, 2, 3]);
  });

  it('ignora una copia inválida sin perder la copia disponible del mismo producto', () => {
    expect(ids(recommendProducts([product(1, { CURRENT_STOCK: 0 }), product(1)], 'regalo', 'any'))).toEqual([1]);
  });

  it('da prioridad a las categorías apropiadas para regalo y reunión', () => {
    const products = [product(1, { PRODUCT_NAME: 'Cerveza clara' }),
      product(2, { PRODUCT_NAME: 'Ron añejo' }), product(3, { PRODUCT_NAME: 'Tequila reposado' }),
      product(4, { PRODUCT_NAME: 'Whisky escocés' }), product(5)];
    expect(ids(recommendProducts(products, 'regalo', 'any'))).toEqual([5, 4, 3]);
    expect(ids(recommendProducts(products, 'reunion', 'any'))).toEqual([1, 2, 3]);
  });

  it('considera vinos, whisky, tequila, brandy y mezcal antes que otros para regalo', () => {
    const products = [product(1, { PRODUCT_NAME: 'Vodka' }), product(2, { PRODUCT_NAME: 'Brandy' }),
      product(3, { PRODUCT_NAME: 'Mezcal' }), product(4, { PRODUCT_NAME: 'Tequila' })];
    expect(ids(recommendProducts(products, 'regalo', 'any'))).toEqual([4, 2, 3]);
  });

  it('reconoce tipo, categoría genérica y nombres con acentos', () => {
    const products = [product(1, { PRODUCT_NAME: 'Botella especial', TIPO: 'Ginébra' }),
      product(2, { PRODUCT_NAME: 'Whískey escocés', CATEGORY_NAME: 'Licores' }),
      product(3, { PRODUCT_NAME: 'Casa del valle', CATEGORY_NAME: 'Vínos tíntos' })];
    expect(ids(recommendProducts(products, 'regalo', 'any'))).toEqual([3, 2, 1]);
    expect(ids(recommendProducts(products, 'maridaje', 'red-wine'))).toEqual([3]);
  });

  it('usa palabras completas: Chardonnay no se confunde con ron ni merlot con un apellido', () => {
    const products = [product(1, { PRODUCT_NAME: 'Chardonnay reserva', CATEGORY_NAME: 'Licores' }),
      product(2, { PRODUCT_NAME: 'Ron añejo' }), product(3, { PRODUCT_NAME: 'Camiseta Merlotera' })];
    expect(ids(recommendProducts(products, 'reunion', 'any'))).toEqual([2, 1]);
    expect(ids(recommendProducts(products, 'maridaje', 'white-wine'))).toEqual([1]);
  });

  it('recupera una categoría explícita guardada como etiqueta en DESCRIPTION', () => {
    const products = [product(1, { PRODUCT_NAME: 'CYNAR', DESCRIPTION: 'Vino',
      CURRENT_STOCK: 1, RETAIL_PRICE: 1900 }),
      product(2, { PRODUCT_NAME: 'Reserva especial', DESCRIPTION: '  VÍNO TÍNTO  ' }),
      product(3, { PRODUCT_NAME: 'SISI', DESCRIPTION: 'Licor' })];
    expect(filtersFor('maridaje', products).map(filter => filter.id)).toEqual(['red-wine', 'other-wine', 'any']);
    expect(ids(recommendProducts(products, 'maridaje', 'other-wine'))).toEqual([1]);
    expect(ids(recommendProducts(products, 'maridaje', 'red-wine'))).toEqual([2]);
    expect(ids(recommendProducts(products, 'regalo', 'under-300'))).toEqual([2, 3]);
  });

  it('el fallback de DESCRIPTION no interpreta prosa, accesorios ni reemplaza una categoría conocida', () => {
    const products = [product(1, { PRODUCT_NAME: 'Copa premium', DESCRIPTION: 'Vino' }),
      product(2, { PRODUCT_NAME: 'Estuche de copas', DESCRIPTION: 'Vino tinto' }),
      product(3, { PRODUCT_NAME: 'Selección especial', DESCRIPTION: 'Ideal para acompañar vino' }),
      product(4, { PRODUCT_NAME: 'Botella especial', DESCRIPTION: 'Vino para regalar' }),
      product(5, { PRODUCT_NAME: 'Ron blanco', DESCRIPTION: 'Vino blanco' }),
      product(6, { PRODUCT_NAME: 'Vino tinto', DESCRIPTION: 'Whisky' }),
      product(7, { PRODUCT_NAME: 'Selección especial', DESCRIPTION: 'constructor' })];
    expect(ids(recommendProducts(products, 'maridaje', 'any'))).toEqual([6]);
    expect(ids(recommendProducts(products, 'reunion', 'any'))).toEqual([5, 6]);
  });

  it('excluye comida y accesorios aunque mencionen bebidas en nombre o descripción', () => {
    const products = [product(1, { PRODUCT_NAME: 'Copa para vino' }),
      product(2, { PRODUCT_NAME: 'Queso al vino' }), product(3, { PRODUCT_NAME: 'Vaso para tequila' }),
      product(4, { PRODUCT_NAME: 'Chocolate blanco', DESCRIPTION: 'Maridaje para vino tinto y whisky' }),
      product(5, { PRODUCT_NAME: 'Botana especial', CATEGORY_NAME: 'Vinos' }),
      product(6, { PRODUCT_NAME: 'Vino sin alcohol' }),
      product(7, { PRODUCT_NAME: 'Artículo desconocido', DESCRIPTION: 'Ideal para tomar ron' }), product(8)];
    expect(ids(recommendProducts(products, 'regalo', 'any'))).toEqual([8]);
  });

  it('muestra los cinco presupuestos para regalo y reunión', () => {
    const expected = ['under-300', '300-700', '700-1500', '1500-plus', 'any'];
    expect(filtersFor('regalo', []).map(filter => filter.id)).toEqual(expected);
    expect(filtersFor('reunion', []).map(filter => filter.id)).toEqual(expected);
  });

  it('solo ofrece las categorías de maridaje que tienen productos disponibles', () => {
    const products = [product(1), product(2, { PRODUCT_NAME: 'Vino blanco', CURRENT_STOCK: 0 }),
      product(3, { PRODUCT_NAME: 'Vino rosado', PRODUCT_STATUS: 'Inactivo' }),
      product(4, { PRODUCT_NAME: 'Cerveza clara' }), product(5, { PRODUCT_NAME: 'Tequila blanco' })];
    expect(filtersFor('maridaje', products).map(filter => filter.id)).toEqual(['red-wine', 'beer', 'any']);
  });

  it('distingue tintos, blancos, rosados, otros vinos y cervezas', () => {
    const products = [product(1), product(2, { PRODUCT_NAME: 'Albariño reserva' }),
      product(3, { PRODUCT_NAME: 'Vino rosé' }), product(4, { PRODUCT_NAME: 'Champagne brut' }),
      product(5, { PRODUCT_NAME: 'Cerveza lager' })];
    const filterIds = ['red-wine', 'white-wine', 'rose-wine', 'other-wine', 'beer'];
    expect(filtersFor('maridaje', products).map(filter => filter.id)).toEqual([...filterIds, 'any']);
    filterIds.forEach((filter, index) => {
      expect(ids(recommendProducts(products, 'maridaje', filter))).toEqual([index + 1]);
    });
  });

  it('nunca ofrece destilados para maridaje, incluso si su nombre dice blanco o añejo', () => {
    const products = [product(1, { PRODUCT_NAME: 'Tequila blanco' }),
      product(2, { PRODUCT_NAME: 'Ron añejo' }), product(3, { PRODUCT_NAME: 'Pisco blanco' }),
      product(4, { PRODUCT_NAME: 'Sotol blanco' }), product(5, { PRODUCT_NAME: 'Whisky' })];
    expect(filtersFor('maridaje', products)).toEqual([]);
    expect(recommendProducts(products, 'maridaje', 'any')).toEqual([]);
    expect(recommendProducts(products, 'maridaje', 'white-wine')).toEqual([]);
    expect(ids(recommendProducts([...products, product(6)], 'maridaje', 'any'))).toEqual([6]);
  });

  it('rechaza filtros desconocidos o ajenos al paso seleccionado', () => {
    const products = [product(1)];
    expect(recommendProducts(products, 'regalo', 'desconocido')).toEqual([]);
    expect(recommendProducts(products, 'regalo', 'red-wine')).toEqual([]);
    expect(recommendProducts(products, 'maridaje', 'under-300')).toEqual([]);
  });
});

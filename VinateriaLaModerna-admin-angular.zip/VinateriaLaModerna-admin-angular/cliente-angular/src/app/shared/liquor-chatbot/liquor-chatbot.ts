import { CurrencyPipe, DOCUMENT } from '@angular/common';
import { afterNextRender, ChangeDetectionStrategy, Component, computed, effect, ElementRef, inject, Injector, input, OnDestroy, signal, viewChild } from '@angular/core';
import { CartService } from '../../core/cart.service';
import { CheckoutService } from '../../core/checkout.service';
import { Product } from '../../core/models';
import { ProductService } from '../../core/product.service';
import { filtersFor, Occasion, RecommendationFilter, recommendProducts } from './recommendations';

@Component({
  selector: 'app-liquor-chatbot',
  standalone: true,
  imports: [CurrencyPipe],
  templateUrl: './liquor-chatbot.html',
  styleUrl: './liquor-chatbot.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '[class.chat-blocked]': 'blocked()',
    '[attr.inert]': 'blocked() ? "" : null',
    '(keydown.escape)': 'onEscape($event)',
  },
})
export class LiquorChatbotComponent implements OnDestroy {
  readonly products = inject(ProductService);
  readonly cart = inject(CartService);
  readonly checkout = inject(CheckoutService);
  private readonly injector = inject(Injector);
  private readonly document = inject(DOCUMENT);
  private readonly panel = viewChild<ElementRef<HTMLElement>>('panel');
  private readonly conversation = viewChild<ElementRef<HTMLElement>>('conversation');
  private operationEpoch = 0;
  private readonly launcher = viewChild<ElementRef<HTMLButtonElement>>('launcher');
  private readonly heading = viewChild<ElementRef<HTMLElement>>('stepHeading');
  private destroyed = false;

  readonly blocked = input(false);
  readonly opened = signal(false);
  readonly step = signal<0 | 1 | 2 | 3>(0);
  readonly occasion = signal<Occasion | null>(null);
  readonly filterId = signal<string | null>(null);
  readonly filterLabel = signal('');
  readonly adding = signal<number | null>(null);
  readonly message = signal('');
  readonly failedImages = signal<Set<string>>(new Set());
  readonly occasions: { id: Occasion; label: string; detail: string }[] = [
    { id: 'regalo', label: 'Regalo', detail: 'Un detalle para alguien especial' },
    { id: 'reunion', label: 'Reunión', detail: 'Una botella para compartir' },
    { id: 'maridaje', label: 'Maridaje', detail: 'Vinos y cervezas para la mesa' },
  ];
  readonly occasionLabel = computed(() => this.occasions.find(item => item.id === this.occasion())?.label ?? '');
  readonly options = computed(() => this.occasion() ? filtersFor(this.occasion()!, this.products.products()) : []);
  readonly recommendations = computed(() => this.occasion() && this.filterId()
    ? recommendProducts(this.products.products(), this.occasion()!, this.filterId()!) : []);
  readonly working = computed(() => this.products.loading() || this.adding() !== null || this.checkout.busy());
  readonly headingText = computed(() => {
    switch (this.step()) {
      case 0: return 'Encuentra tu próxima botella';
      case 1: return '¿Para qué ocasión estás buscando?';
      case 2: return this.occasion() === 'maridaje' ? '¿Qué te gustaría llevar a la mesa?' : '¿Cuál es tu presupuesto por botella?';
      case 3: return 'Tu selección de La Moderna';
    }
  });

  constructor() {
    effect(() => {
      if (this.blocked()) {
        this.operationEpoch++;
        this.opened.set(false);
      }
    });
  }

  toggle(): void {
    if (this.blocked()) return;
    if (this.opened()) this.close();
    else {
      this.opened.set(true);
      this.focusStep();
    }
  }

  close(): void {
    this.opened.set(false);
    this.launcher()?.nativeElement.focus();
  }

  onEscape(event: Event): void {
    if (!this.opened()) return;
    event.preventDefault();
    event.stopPropagation();
    this.close();
  }

  start(): void {
    if (this.adding() !== null) return;
    this.occasion.set(null);
    this.filterId.set(null);
    this.filterLabel.set('');
    this.message.set('');
    this.step.set(1);
    this.focusStep();
  }

  chooseOccasion(occasion: Occasion): void {
    this.occasion.set(occasion);
    this.filterId.set(null);
    this.filterLabel.set('');
    this.message.set('');
    this.step.set(2);
    this.focusStep();
  }

  async chooseFilter(option: RecommendationFilter): Promise<void> {
    if (this.working() || !this.options().some(item => item.id === option.id)) return;
    this.filterId.set(option.id);
    this.filterLabel.set(option.label);
    this.message.set('');
    this.step.set(3);
    this.focusStep();
    await this.refresh();
  }

  changeFilter(): void {
    if (this.adding() !== null) return;
    this.filterId.set(null);
    this.filterLabel.set('');
    this.message.set('');
    this.step.set(2);
    this.focusStep();
  }

  async refresh(): Promise<void> {
    if (this.products.loading() || this.checkout.busy()) return;
    await this.products.load();
    this.restoreFocus();
  }

  async add(product: Product): Promise<void> {
    if (this.blocked() || this.working() || this.products.error() || this.atLimit(product)) return;
    const operationEpoch = this.operationEpoch;
    this.adding.set(product.PRODUCT_ID);
    this.message.set('Comprobando disponibilidad…');
    try {
      // Vuelve a consultar PHP antes de usar el precio y las existencias de una tarjeta.
      await this.products.load();
      if (this.destroyed) return;
      if (this.blocked() || operationEpoch !== this.operationEpoch) {
        this.message.set('La comprobación se canceló. Puedes volver a agregar la botella.');
        return;
      }
      if (this.checkout.busy()) {
        this.message.set('Espera a que termine el pedido para modificar tu carrito.');
        return;
      }
      if (this.products.error()) {
        this.message.set('No pude comprobar las existencias. Vuelve a intentarlo.');
        return;
      }
      const current = this.products.products().find(item => item.PRODUCT_ID === product.PRODUCT_ID);
      if (!current || !this.occasion() || !this.filterId()
        || !recommendProducts([current], this.occasion()!, this.filterId()!).length) {
        this.message.set('Esta botella ya no está disponible para tu selección. Puedes elegir otra.');
        return;
      }
      this.cart.add(current);
      this.message.set(`${current.PRODUCT_NAME} se agregó a tu carrito.`);
    } catch (error) {
      this.message.set(error instanceof Error ? error.message : 'No se pudo agregar la botella. Inténtalo de nuevo.');
    } finally {
      this.adding.set(null);
      this.restoreFocus(product.PRODUCT_ID);
    }
  }

  atLimit(product: Product): boolean {
    return this.cart.quantity(product.PRODUCT_ID) >= product.CURRENT_STOCK;
  }

  imageFailed(url: string): void {
    this.failedImages.update(images => new Set([...images, url]));
  }

  imageAvailable(url: string): boolean {
    return !!url && !this.failedImages().has(url);
  }

  private focusStep(): void {
    afterNextRender(() => {
      if (this.opened() && !this.blocked()) this.focusInConversation(this.heading()?.nativeElement, true);
    }, { injector: this.injector });
  }

  private restoreFocus(productId?: number): void {
    if (this.destroyed) return;
    afterNextRender(() => {
      if (!this.opened() || this.blocked()) return;
      const heading = this.heading()?.nativeElement;
      if (heading && this.document.activeElement === heading) {
        // La consulta puede terminar después de enfocar el título: ahora ya caben las tarjetas en el cálculo.
        this.focusInConversation(heading, true);
        return;
      }
      if (this.document.activeElement !== this.document.body) return;
      const button = productId === undefined ? null
        : this.panel()?.nativeElement.querySelector<HTMLButtonElement>(`button[data-product-id="${productId}"]`);
      const availableButton = button && !button.disabled ? button : undefined;
      this.focusInConversation(availableButton ?? heading, !availableButton);
    }, { injector: this.injector });
  }

  private focusInConversation(target: HTMLElement | undefined, alignReply = false): void {
    if (!target) return;
    // El foco no debe desplazar de golpe el chat ni mover la página del catálogo.
    target.focus({ preventScroll: true });
    const conversation = this.conversation()?.nativeElement;
    if (!conversation) return;
    const viewport = conversation.getBoundingClientRect();
    const anchor = alignReply ? target.closest('.bot-message') ?? target : target;
    const position = anchor.getBoundingClientRect();
    const inset = 16;
    if (!alignReply && position.top >= viewport.top + inset && position.bottom <= viewport.bottom - inset) return;
    const reducedMotion = this.document.defaultView?.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    conversation.scrollTo?.({
      top: Math.max(0, conversation.scrollTop + position.top - viewport.top - inset),
      behavior: reducedMotion ? 'instant' : 'smooth',
    });
  }

  ngOnDestroy(): void { this.destroyed = true; }
}

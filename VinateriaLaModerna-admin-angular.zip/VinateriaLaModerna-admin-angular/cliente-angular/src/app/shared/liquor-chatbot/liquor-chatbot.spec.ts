import { signal } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { CartService } from '../../core/cart.service';
import { CheckoutService } from '../../core/checkout.service';
import { Product } from '../../core/models';
import { ProductService } from '../../core/product.service';
import { LiquorChatbotComponent } from './liquor-chatbot';

const bottle = (id: number, name: string, price: number, stock = 3): Product => ({
  PRODUCT_ID: id, PRODUCT_NAME: name, RETAIL_PRICE: price, CURRENT_STOCK: stock,
  DESCRIPTION: '', PRODUCT_STATUS: 'Activo', FOTO_URL: '',
});

describe('Asistente de licores: conversación y carrito', () => {
  let fixture: ComponentFixture<LiquorChatbotComponent>;
  let component: LiquorChatbotComponent;
  let cart: CartService;
  const products = signal<Product[]>([]);
  const loading = signal(false);
  const error = signal('');
  const checkoutBusy = signal(false);
  const load = vi.fn();
  const matchMediaDescriptor = Object.getOwnPropertyDescriptor(window, 'matchMedia');

  beforeEach(async () => {
    const values = new Map<string, string>();
    vi.stubGlobal('localStorage', {
      get length() { return values.size; },
      clear: () => values.clear(),
      getItem: (key: string) => values.get(key) ?? null,
      key: (index: number) => [...values.keys()][index] ?? null,
      removeItem: (key: string) => { values.delete(key); },
      setItem: (key: string, value: string) => { values.set(String(key), String(value)); },
    } satisfies Storage);
    products.set([
      bottle(1, 'Vino tinto Malbec', 280),
      bottle(2, 'Whisky Reserva', 590),
      bottle(3, 'Tequila Reposado', 450),
      bottle(4, 'Ron agotado', 200, 0),
    ]);
    loading.set(false);
    error.set('');
    checkoutBusy.set(false);
    load.mockReset().mockResolvedValue(undefined);
    TestBed.configureTestingModule({
      imports: [LiquorChatbotComponent],
      providers: [CartService,
        { provide: ProductService, useValue: { products, loading, error, load } },
        { provide: CheckoutService, useValue: { busy: checkoutBusy } },
      ],
    });
    fixture = TestBed.createComponent(LiquorChatbotComponent);
    component = fixture.componentInstance;
    cart = TestBed.inject(CartService);
    fixture.detectChanges();
    await fixture.whenStable();
  });

  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
    if (matchMediaDescriptor) Object.defineProperty(window, 'matchMedia', matchMediaDescriptor);
    else Reflect.deleteProperty(window, 'matchMedia');
  });

  async function results(filter = 'any'): Promise<void> {
    component.toggle();
    component.start();
    component.chooseOccasion('regalo');
    await component.chooseFilter(component.options().find(option => option.id === filter)!);
    fixture.detectChanges();
    await fixture.whenStable();
  }

  function button(text: string): HTMLButtonElement {
    const found = Array.from(fixture.nativeElement.querySelectorAll('button') as NodeListOf<HTMLButtonElement>)
      .find(item => item.textContent?.includes(text));
    expect(found, `Botón ${text}`).toBeDefined();
    return found!;
  }

  it('recorre los tres pasos mediante botones y muestra hasta tres tarjetas reales', async () => {
    const launcher = fixture.nativeElement.querySelector('.chat-launcher') as HTMLButtonElement;
    launcher.click();
    fixture.detectChanges();
    button('Recomiéndame').click();
    fixture.detectChanges();
    button('Regalo').click();
    fixture.detectChanges();
    button('Cualquier presupuesto').click();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.step()).toBe(3);
    expect(load).toHaveBeenCalledOnce();
    expect(fixture.nativeElement.querySelectorAll('.bottle-card')).toHaveLength(3);
    expect(fixture.nativeElement.textContent).toContain('Vino tinto Malbec');
    expect(fixture.nativeElement.textContent).not.toContain('Ron agotado');
    expect(launcher.getAttribute('aria-expanded')).toBe('true');
  });

  it('agrega al mismo carrito y confirma sin abandonar la conversación', async () => {
    await results();
    button('Agregar al carrito').click();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(cart.count()).toBe(1);
    expect(component.opened()).toBe(true);
    expect(component.step()).toBe(3);
    expect(fixture.nativeElement.querySelector('.feedback').textContent).toContain('se agregó a tu carrito');
    expect(JSON.parse(localStorage.getItem('carrito')!)).toHaveLength(1);
  });

  it('vuelve a comprobar el stock y no agrega una botella recién agotada', async () => {
    await results();
    const selected = products()[0];
    load.mockImplementationOnce(async () => products.set(products().map(p => p.PRODUCT_ID === selected.PRODUCT_ID ? { ...p, CURRENT_STOCK: 0 } : p)));
    await component.add(selected);
    expect(cart.count()).toBe(0);
    expect(component.message()).toContain('ya no está disponible');
  });

  it('usa el precio actual del servidor al agregar y respeta el presupuesto elegido', async () => {
    await results();
    const selected = products()[0];
    load.mockImplementationOnce(async () => products.set(products().map(p => p.PRODUCT_ID === selected.PRODUCT_ID ? { ...p, RETAIL_PRICE: 299 } : p)));
    await component.add(selected);
    expect(cart.items()[0].precio).toBe(299);
    cart.clear();
    component.changeFilter();
    await component.chooseFilter(component.options().find(option => option.id === 'under-300')!);
    load.mockImplementationOnce(async () => products.set(products().map(p => p.PRODUCT_ID === selected.PRODUCT_ID ? { ...p, RETAIL_PRICE: 320 } : p)));
    await component.add(selected);
    expect(cart.count()).toBe(0);
    expect(component.message()).toContain('ya no está disponible');
  });

  it('bloquea doble clic, máximos de stock y modificaciones durante checkout', async () => {
    await results();
    const selected = products()[0];
    let complete!: () => void;
    load.mockImplementationOnce(() => new Promise<void>(resolve => { complete = resolve; }));
    const pending = component.add(selected);
    await component.add(selected);
    complete();
    await pending;
    expect(cart.count()).toBe(1);
    checkoutBusy.set(true);
    await component.add(selected);
    expect(cart.count()).toBe(1);
    checkoutBusy.set(false);
    cart.add(selected);
    cart.add(selected);
    await component.add(selected);
    expect(cart.quantity(selected.PRODUCT_ID)).toBe(3);
    expect(component.atLimit(selected)).toBe(true);
  });

  it('no agrega si el checkout empieza mientras consulta existencias', async () => {
    await results();
    load.mockImplementationOnce(async () => { checkoutBusy.set(true); });
    await component.add(products()[0]);
    expect(cart.count()).toBe(0);
    expect(component.message()).toContain('termine el pedido');
  });

  it('oculta tarjetas antiguas si falla la API y permite reintentar', async () => {
    await results();
    error.set('No se pudo conectar');
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelectorAll('.bottle-card')).toHaveLength(0);
    load.mockImplementationOnce(async () => error.set(''));
    button('Volver a intentar').click();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelectorAll('.bottle-card')).toHaveLength(3);
    load.mockImplementationOnce(async () => error.set('Sin conexión'));
    await component.add(products()[0]);
    expect(cart.count()).toBe(0);
    expect(component.message()).toContain('No pude comprobar');
  });

  it('explica selecciones con una o ninguna coincidencia y permite cambiar filtro', async () => {
    await results('under-300');
    expect(fixture.nativeElement.querySelectorAll('.bottle-card')).toHaveLength(1);
    expect(fixture.nativeElement.textContent).toContain('una botella disponible');
    component.changeFilter();
    await component.chooseFilter(component.options().find(option => option.id === '1500-plus')!);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelectorAll('.bottle-card')).toHaveLength(0);
    expect(fixture.nativeElement.textContent).toContain('No encontré botellas');
    button('Cambiar preferencia').click();
    fixture.detectChanges();
    expect(component.step()).toBe(2);
    expect(component.occasion()).toBe('regalo');
  });

  it('maridaje ofrece categorías disponibles y reiniciar limpia respuestas anteriores', async () => {
    component.start();
    component.chooseOccasion('maridaje');
    fixture.detectChanges();
    expect(component.options().map(option => option.id)).toEqual(['red-wine', 'any']);
    button('Vino tinto').click();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.recommendations().map(product => product.PRODUCT_ID)).toEqual([1]);
    button('Empezar de nuevo').click();
    expect(component.step()).toBe(1);
    expect(component.occasion()).toBeNull();
    expect(component.filterId()).toBeNull();
    expect(component.filterLabel()).toBe('');
  });

  it('gestiona foco, Escape y el bloqueo por otros modales', async () => {
    await results();
    expect(document.activeElement).toBe(fixture.nativeElement.querySelector('h3'));
    fixture.nativeElement.querySelector('h3').dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    fixture.detectChanges();
    expect(component.opened()).toBe(false);
    expect(document.activeElement).toBe(fixture.nativeElement.querySelector('.chat-launcher'));
    expect(fixture.nativeElement.querySelector('.chat-panel').hasAttribute('inert')).toBe(true);
    component.toggle();
    fixture.componentRef.setInput('blocked', true);
    fixture.detectChanges();
    await fixture.whenStable();
    expect(component.opened()).toBe(false);
    expect(fixture.nativeElement.hasAttribute('inert')).toBe(true);
  });

  it('cancela el agregado pendiente si otro modal se abre y se cierra durante la consulta', async () => {
    await results();
    let complete!: () => void;
    load.mockImplementationOnce(() => new Promise<void>(resolve => { complete = resolve; }));
    const pending = component.add(products()[0]);
    fixture.componentRef.setInput('blocked', true);
    fixture.detectChanges();
    fixture.componentRef.setInput('blocked', false);
    fixture.detectChanges();
    complete();
    await pending;
    expect(cart.count()).toBe(0);
    expect(component.message()).toContain('se canceló');
  });

  it('recupera el foco del botón de agregar después de una carga real', async () => {
    await results();
    const addButton = button('Agregar al carrito');
    const id = addButton.getAttribute('data-product-id');
    addButton.focus();
    let complete!: () => void;
    load.mockImplementationOnce(() => {
      loading.set(true);
      return new Promise<void>(resolve => { complete = () => { loading.set(false); resolve(); }; });
    });
    addButton.click();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelectorAll('.bottle-card')).toHaveLength(0);
    complete();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(document.activeElement).toBe(fixture.nativeElement.querySelector(`button[data-product-id="${id}"]`));
    expect(cart.count()).toBe(1);
  });

  it.each([false, true])('desplaza solo la conversación al cambiar de paso (movimiento reducido: %s)', async reducedMotion => {
    const conversation = fixture.nativeElement.querySelector('.chat-conversation') as HTMLElement;
    const scrollTo = vi.fn();
    Object.defineProperty(conversation, 'scrollTo', { configurable: true, value: scrollTo });
    Object.defineProperty(window, 'matchMedia', { configurable: true, writable: true,
      value: vi.fn().mockReturnValue({ matches: reducedMotion }) });
    const originalRect = HTMLElement.prototype.getBoundingClientRect;
    vi.spyOn(HTMLElement.prototype, 'getBoundingClientRect').mockImplementation(function (this: HTMLElement) {
      if (this === conversation) return { top: 100, bottom: 400 } as DOMRect;
      if (this.tagName === 'H3' || this.classList.contains('bot-message')) return { top: 500, bottom: 540 } as DOMRect;
      return originalRect.call(this);
    });
    const focus = vi.spyOn(HTMLElement.prototype, 'focus');
    component.toggle();
    component.start();
    fixture.detectChanges();
    await fixture.whenStable();
    expect(focus).toHaveBeenCalledWith({ preventScroll: true });
    expect(scrollTo).toHaveBeenCalledWith({ top: 384, behavior: reducedMotion ? 'instant' : 'smooth' });
    expect(document.activeElement).toBe(fixture.nativeElement.querySelector('h3'));
  });

  it('acomoda la respuesta después de cargar las tarjetas cuando el título ya tenía el foco', async () => {
    await results();
    const conversation = fixture.nativeElement.querySelector('.chat-conversation') as HTMLElement;
    const reply = fixture.nativeElement.querySelector('.bot-message') as HTMLElement;
    const scrollTo = vi.fn();
    Object.defineProperty(conversation, 'scrollTo', { configurable: true, value: scrollTo });
    vi.spyOn(conversation, 'getBoundingClientRect').mockReturnValue({ top: 100, bottom: 400 } as DOMRect);
    vi.spyOn(reply, 'getBoundingClientRect').mockReturnValue({ top: 250, bottom: 320 } as DOMRect);
    expect(document.activeElement).toBe(fixture.nativeElement.querySelector('h3'));
    await component.refresh();
    fixture.detectChanges();
    await fixture.whenStable();
    expect(scrollTo).toHaveBeenCalledWith({ top: 134, behavior: 'smooth' });
  });

  it('no modifica el carrito si se abandona el catálogo durante la comprobación', async () => {
    await results();
    let complete!: () => void;
    load.mockImplementationOnce(() => new Promise<void>(resolve => { complete = resolve; }));
    const pending = component.add(products()[0]);
    fixture.destroy();
    complete();
    await pending;
    expect(cart.count()).toBe(0);
  });
});

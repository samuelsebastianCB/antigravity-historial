import { Product } from '../../core/models';

export type Occasion = 'regalo' | 'reunion' | 'maridaje';
export interface RecommendationFilter { id: string; label: string; }

type Kind = 'red-wine' | 'white-wine' | 'rose-wine' | 'other-wine' | 'beer'
  | 'whisky' | 'tequila' | 'brandy' | 'mezcal' | 'rum' | 'vodka' | 'gin' | 'liqueur';

const BUDGETS = [
  { id: 'under-300', label: 'Menos de $300', min: 0, max: 300 },
  { id: '300-700', label: '$300 a menos de $700', min: 300, max: 700 },
  { id: '700-1500', label: '$700 a menos de $1,500', min: 700, max: 1500 },
  { id: '1500-plus', label: '$1,500 o más', min: 1500, max: Infinity },
] as const;

const PAIRING_FILTERS: ReadonlyArray<RecommendationFilter & { id: Kind }> = [
  { id: 'red-wine', label: 'Vino tinto' },
  { id: 'white-wine', label: 'Vino blanco' },
  { id: 'rose-wine', label: 'Vino rosado' },
  { id: 'other-wine', label: 'Otros vinos' },
  { id: 'beer', label: 'Cerveza' },
];

// El catálogo legado guarda a veces la categoría como una etiqueta en DESCRIPTION.
// Solo aceptamos etiquetas completas conocidas; nunca buscamos bebidas dentro de prosa.
const DESCRIPTION_LABELS = new Map<string, Kind>([
  ['vino', 'other-wine'], ['vinos', 'other-wine'], ['vino espumoso', 'other-wine'],
  ['vino tinto', 'red-wine'], ['vinos tintos', 'red-wine'],
  ['vino blanco', 'white-wine'], ['vinos blancos', 'white-wine'],
  ['vino rosado', 'rose-wine'], ['vinos rosados', 'rose-wine'], ['vino rose', 'rose-wine'],
  ['cerveza', 'beer'], ['cervezas', 'beer'],
  ['whisky', 'whisky'], ['whiskey', 'whisky'], ['bourbon', 'whisky'],
  ['tequila', 'tequila'], ['brandy', 'brandy'], ['cognac', 'brandy'], ['conac', 'brandy'],
  ['mezcal', 'mezcal'], ['ron', 'rum'], ['vodka', 'vodka'],
  ['ginebra', 'gin'], ['gin', 'gin'], ['licor', 'liqueur'], ['licores', 'liqueur'],
  ['destilado', 'liqueur'], ['destilados', 'liqueur'], ['aguardiente', 'liqueur'],
]);

const normalize = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  .toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

function kindOf(product: Product): Kind | undefined {
  const category = normalize([product.CATEGORY_NAME, product.TIPO].filter(Boolean).join(' '));
  const text = normalize([product.CATEGORY_NAME, product.TIPO, product.PRODUCT_NAME].filter(Boolean).join(' '));
  // Las exclusiones del nombre y categoría también impiden el fallback de DESCRIPTION.
  if (/\b(accesorios?|copas?|vasos?|sacacorchos|destapadores?|hieleras?|botanas?|quesos?|chocolates?|galletas?|refrescos?|jugos?|jarabes?|vinagre|sin alcohol|no alcoholico|desalcoholizado)\b/.test(text)) return undefined;

  if (/\b(tequilas?)\b/.test(text)) return 'tequila';
  if (/\b(whisk(?:y|ey)s?|bourbon|scotch)\b/.test(text)) return 'whisky';
  if (/\b(mezcales?|mezcal)\b/.test(text)) return 'mezcal';
  if (/\b(brandy|brandis?|cognac|conac)\b/.test(text)) return 'brandy';
  if (/\b(ron|rones|rum)\b/.test(text)) return 'rum';
  if (/\b(vodkas?)\b/.test(text)) return 'vodka';
  if (/\b(ginebras?|gin)\b/.test(text)) return 'gin';
  if (/\b(cervezas?|beer|lager|pilsner|stout|ipa)\b/.test(text)) return 'beer';
  if (/\b(pisco|sotol|aguardientes?)\b/.test(text)) return 'liqueur';
  const wineContext = /\b(vinos?|wine)\b/.test(text);
  if (/\b(rosados?|roses?)\b/.test(category) || (wineContext && /\b(rosados?|roses?)\b/.test(text))) return 'rose-wine';
  if (/\b(blancos?)\b/.test(category) || (wineContext && /\b(blancos?)\b/.test(text))
    || /\b(chardonnay|sauvignon blanc|pinot grigio|riesling|chenin blanc|albarino|gewurztraminer|verdejo)\b/.test(text)) return 'white-wine';
  if (/\b(tintos?)\b/.test(category) || (wineContext && /\b(tintos?)\b/.test(text))
    || /\b(cabernet|merlot|malbec|shiraz|syrah|tempranillo|pinot noir|zinfandel|carmenere|nebbiolo|monastrell|garnacha)\b/.test(text)) return 'red-wine';
  if (/\b(vinos?|wine|champan|champagne|prosecco|cava|jerez|oporto|espumosos?)\b/.test(text)) return 'other-wine';
  if (/\b(licor(?:es)?|cremas?|destilados?)\b/.test(text)) return 'liqueur';
  return DESCRIPTION_LABELS.get(normalize(product.DESCRIPTION));
}

function candidates(products: Product[]): Array<{ product: Product; kind: Kind }> {
  const seen = new Set<number>();
  return products.flatMap(product => {
    if (!Number.isInteger(product.PRODUCT_ID) || product.PRODUCT_ID <= 0
      || normalize(product.PRODUCT_STATUS) !== 'activo'
      || !Number.isFinite(product.RETAIL_PRICE) || product.RETAIL_PRICE < 0
      || !Number.isFinite(product.CURRENT_STOCK) || product.CURRENT_STOCK < 1
      || seen.has(product.PRODUCT_ID)) return [];
    const kind = kindOf(product);
    if (!kind) return [];
    seen.add(product.PRODUCT_ID);
    return [{ product, kind }];
  });
}

export function filtersFor(occasion: Occasion, products: Product[]): RecommendationFilter[] {
  if (occasion !== 'maridaje') {
    return [...BUDGETS.map(({ id, label }) => ({ id, label })), { id: 'any', label: 'Cualquier presupuesto' }];
  }
  const available = new Set(candidates(products).map(candidate => candidate.kind));
  const filters = PAIRING_FILTERS.filter(filter => available.has(filter.id)).map(filter => ({ ...filter }));
  return filters.length ? [...filters, { id: 'any', label: 'Ayúdame a elegir' }] : [];
}

function priority(kind: Kind, occasion: Occasion): number {
  const wine = kind.endsWith('-wine');
  if (occasion === 'regalo') {
    if (wine) return 0;
    return ({ whisky: 1, tequila: 2, brandy: 3, mezcal: 4 } as Partial<Record<Kind, number>>)[kind] ?? 5;
  }
  if (occasion === 'reunion') {
    return ({ beer: 0, rum: 1, tequila: 2, vodka: 3, gin: 4 } as Partial<Record<Kind, number>>)[kind] ?? 5;
  }
  return wine ? 0 : 1;
}

export function recommendProducts(products: Product[], occasion: Occasion, filterId: string): Product[] {
  const budget = BUDGETS.find(filter => filter.id === filterId);
  const pairing = PAIRING_FILTERS.find(filter => filter.id === filterId);
  if (filterId !== 'any' && (occasion === 'maridaje' ? !pairing : !budget)) return [];

  return candidates(products).filter(({ product, kind }) => {
    if (occasion === 'maridaje') {
      return PAIRING_FILTERS.some(filter => filter.id === kind) && (filterId === 'any' || kind === filterId);
    }
    return !budget || (product.RETAIL_PRICE >= budget.min && product.RETAIL_PRICE < budget.max);
  }).sort((a, b) => priority(a.kind, occasion) - priority(b.kind, occasion)
    || a.product.RETAIL_PRICE - b.product.RETAIL_PRICE
    || a.product.PRODUCT_NAME.localeCompare(b.product.PRODUCT_NAME, 'es', { sensitivity: 'base' })
    || a.product.PRODUCT_ID - b.product.PRODUCT_ID)
    .slice(0, 3).map(candidate => candidate.product);
}

import { Component, Input, OnChanges, SimpleChanges, ElementRef, ChangeDetectorRef, NgZone, DestroyRef, inject } from '@angular/core';

@Component({
  selector: 'app-count-up',
  standalone: true,
  template: `{{ displayValue }}`,
})
export class CountUpComponent implements OnChanges {
  @Input() to = 0;
  @Input() duration = 1; // seconds
  @Input() decimals = 2;
  @Input() prefix = '$';
  @Input() suffix = '';
  @Input() separator = ',';

  displayValue = '';
  private current = 0;
  private animationFrameId?: number;
  private zone = inject(NgZone);
  private cdr = inject(ChangeDetectorRef);
  private destroyRef = inject(DestroyRef);

  constructor() {
    this.destroyRef.onDestroy(() => this.cancelAnimation());
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['to']) {
      const from = this.current;
      const target = Number(this.to) || 0;
      if (from !== target) {
        this.animateValue(from, target, this.duration * 1000);
      } else {
        this.updateDisplay(target);
      }
    }
  }

  private animateValue(start: number, end: number, duration: number): void {
    this.cancelAnimation();
    
    let startTime: number | null = null;
    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      
      // Easing function (easeOutExpo)
      const easeProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      
      this.current = start + (end - start) * easeProgress;
      this.updateDisplay(this.current);
      
      if (progress < 1) {
        this.animationFrameId = requestAnimationFrame(animate);
      } else {
        this.current = end;
        this.updateDisplay(end);
      }
    };

    this.zone.runOutsideAngular(() => {
      this.animationFrameId = requestAnimationFrame(animate);
    });
  }

  private updateDisplay(value: number): void {
    const formatted = this.formatNumber(value);
    this.displayValue = `${this.prefix}${formatted}${this.suffix}`;
    this.cdr.detectChanges();
  }

  private formatNumber(value: number): string {
    const fixed = value.toFixed(this.decimals);
    const parts = fixed.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, this.separator);
    return parts.join('.');
  }

  private cancelAnimation(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = undefined;
    }
  }
}


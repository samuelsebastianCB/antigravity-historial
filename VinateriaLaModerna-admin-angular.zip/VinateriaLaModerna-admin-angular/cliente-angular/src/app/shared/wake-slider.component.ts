import {
  ChangeDetectionStrategy, Component, ElementRef, OnDestroy, afterNextRender, computed, input, model, viewChild, viewChildren,
} from '@angular/core';

/**
 * Port a Angular del WakeSlider: una fila de barras que "se levantan" alrededor del puntero
 * dejando una estela, y que funciona como un slider real (puntero, táctil y teclado).
 * Las alturas se animan directamente en el DOM con requestAnimationFrame (sin tocar change detection).
 */
@Component({
  selector: 'app-wake-slider',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '[style.--ws-fill]': 'fillColor()',
    '[style.--ws-track]': 'trackColor()',
    '[class.disabled]': 'disabled()',
  },
  template: `
    <div #track class="wake" role="slider" [attr.tabindex]="disabled() ? -1 : 0"
         [attr.aria-label]="label()" [attr.aria-valuemin]="min()" [attr.aria-valuemax]="max()"
         [attr.aria-valuenow]="value()" [attr.aria-disabled]="disabled()"
         [style.height.px]="height()" [style.gap.px]="gap()"
         (pointerdown)="down($event)" (pointermove)="move($event)" (pointerup)="up($event)"
         (pointercancel)="up($event)" (pointerleave)="leave()" (keydown)="key($event)">
      @for (b of indexes(); track b) {
        <span #bar class="bar" [class.on]="b < filled()" [style.height.px]="restHeight()"></span>
      }
    </div>
    @if (showValue()) { <div class="val" aria-hidden="true">{{ value() }}</div> }
  `,
  styles: [`
    :host { display: block; width: 100%; touch-action: pan-y; user-select: none; }
    :host(.disabled) { opacity: .5; pointer-events: none; }
    .wake { display: flex; align-items: center; width: 100%; cursor: pointer; outline: none; touch-action: none; }
    .wake:focus-visible { outline: 2px solid var(--moderna-gold, #d4af88); outline-offset: 4px; border-radius: 6px; }
    .bar { flex: 1 1 0; min-width: 2px; border-radius: 99px; background: var(--ws-track, #d9ccbb); transition: background-color .15s; will-change: height; }
    .bar.on { background: var(--ws-fill, #640d14); }
    .val { margin-top: 6px; text-align: center; font-size: .8rem; font-variant-numeric: tabular-nums; color: var(--text-muted, #7a5c50); }
  `],
})
export class WakeSliderComponent implements OnDestroy {
  readonly value = model(0);
  readonly min = input(0);
  readonly max = input(100);
  readonly step = input(1);
  readonly bars = input(32);
  readonly height = input(56);
  readonly restHeight = input(12);
  readonly gap = input(4);
  readonly fillColor = input('#640d14');
  readonly trackColor = input('#d9ccbb');
  readonly sensitivity = input(1);
  readonly reach = input(6);
  readonly skew = input(0.6);
  /** 0–1: fracción del recorrido que avanza cada frame (más alto = más rápido). */
  readonly glide = input(0.3);
  readonly showValue = input(true);
  readonly disabled = input(false);
  readonly label = input('Valor');

  private readonly track = viewChild.required<ElementRef<HTMLElement>>('track');
  private readonly barEls = viewChildren<ElementRef<HTMLElement>>('bar');
  readonly indexes = computed(() => Array.from({ length: Math.max(2, this.bars()) }, (_, i) => i));
  private readonly ratio = computed(() => {
    const span = this.max() - this.min();
    return span <= 0 ? 0 : Math.min(1, Math.max(0, (this.value() - this.min()) / span));
  });
  readonly filled = computed(() => Math.round(this.ratio() * this.indexes().length));

  private heights: number[] = [];
  private center: number | null = null;
  private dragging = false;
  private raf = 0;
  private alive = true;

  constructor() {
    afterNextRender(() => this.schedule());
  }

  ngOnDestroy(): void { this.alive = false; cancelAnimationFrame(this.raf); }

  down(e: PointerEvent): void {
    if (this.disabled()) return;
    this.dragging = true;
    this.track().nativeElement.setPointerCapture?.(e.pointerId);
    this.apply(e);
  }
  move(e: PointerEvent): void {
    if (this.disabled()) return;
    this.center = this.pos(e) * this.indexes().length - 0.5;
    if (this.dragging) this.setFromRatio(this.pos(e));
    this.schedule();
  }
  up(e: PointerEvent): void {
    this.dragging = false;
    this.track().nativeElement.releasePointerCapture?.(e.pointerId);
    if (e.pointerType !== 'mouse') this.leave();
  }
  leave(): void { if (!this.dragging) { this.center = null; this.schedule(); } }

  key(e: KeyboardEvent): void {
    const step = this.step() * (e.shiftKey ? 10 : 1);
    const map: Record<string, number> = { ArrowRight: step, ArrowUp: step, ArrowLeft: -step, ArrowDown: -step };
    if (e.key in map) { e.preventDefault(); this.commit(this.value() + map[e.key]); }
    else if (e.key === 'Home') { e.preventDefault(); this.commit(this.min()); }
    else if (e.key === 'End') { e.preventDefault(); this.commit(this.max()); }
  }

  private pos(e: PointerEvent): number {
    const r = this.track().nativeElement.getBoundingClientRect();
    const raw = r.width ? (e.clientX - r.left) / r.width : 0;
    return Math.min(1, Math.max(0, 0.5 + (raw - 0.5) * this.sensitivity()));
  }
  private apply(e: PointerEvent): void { this.center = this.pos(e) * this.indexes().length - 0.5; this.setFromRatio(this.pos(e)); this.schedule(); }
  private setFromRatio(ratio: number): void { this.commit(this.min() + ratio * (this.max() - this.min())); }
  private commit(raw: number): void {
    const step = this.step() || 1;
    const snapped = Math.round((raw - this.min()) / step) * step + this.min();
    const next = Math.min(this.max(), Math.max(this.min(), +snapped.toFixed(6)));
    if (next !== this.value()) this.value.set(next);
  }

  private schedule(): void {
    if (!this.alive || this.raf) return;
    this.raf = requestAnimationFrame(() => { this.raf = 0; this.frame(); });
  }

  private frame(): void {
    const els = this.barEls();
    const n = els.length;
    if (!n) return;
    const rest = this.restHeight(), full = this.height(), reach = Math.max(0.5, this.reach()), skew = this.skew();
    const glide = Math.min(1, Math.max(0.05, this.glide()));
    if (this.heights.length !== n) this.heights = new Array(n).fill(rest);
    let moving = false;
    for (let i = 0; i < n; i++) {
      let target = rest;
      if (this.center !== null) {
        const d = i - this.center;
        // Estela: la cola hacia atrás es más larga que hacia adelante.
        const r = d < 0 ? reach * (1 + skew) : reach;
        target = rest + (full - rest) * Math.exp(-((d / r) ** 2));
      }
      const diff = target - this.heights[i];
      if (Math.abs(diff) > 0.2) { this.heights[i] += diff * glide; moving = true; } else this.heights[i] = target;
      els[i].nativeElement.style.height = `${this.heights[i].toFixed(1)}px`;
    }
    if (moving) this.schedule();
  }
}


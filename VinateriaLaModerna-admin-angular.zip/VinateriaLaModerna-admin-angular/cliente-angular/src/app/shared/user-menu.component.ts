import { Component, inject, signal, HostListener, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../core/auth.service';
import { LoginComponent } from '../pages/login/login';
import { RegisterComponent } from '../pages/register/register';

@Component({
  selector: 'app-user-menu',
  standalone: true,
  imports: [CommonModule, RouterLink, LoginComponent, RegisterComponent],
  template: `
    <div class="user-menu-wrapper" style="position: relative;">
      
      @if (auth.customer(); as customer) {
        <button type="button" class="user-menu-btn" (click)="toggleMenu()" aria-expanded="true">
          <div class="avatar-circle">{{ customer.nombre.charAt(0).toUpperCase() }}</div>
          <span class="user-name">Hola, {{ customer.nombre.split(' ')[0] }}</span>
          <svg class="chevron" [class.open]="isOpen()" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
        </button>
      } @else {
        <button type="button" class="user-menu-btn" (click)="toggleMenu()">
          <div class="avatar-circle guest-avatar">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/></svg>
          </div>
          <span class="user-name">Iniciar Sesión</span>
        </button>
      }

      @if (isOpen()) {
        <div class="user-dropdown-card">
          @if (auth.customer(); as customer) {
            <div class="dropdown-header">
              <strong>{{ customer.nombre }}</strong>
              <span class="email-sub">cliente&#64;lamoderna.com</span>
            </div>
            <ul class="dropdown-list">
              <li>
                <a routerLink="/catalogo" (click)="closeMenu()">
                  <span class="icon">📦</span> Mis Pedidos
                </a>
              </li>
              <li>
                <a routerLink="/catalogo" (click)="closeMenu()">
                  <span class="icon">⚙️</span> Configuración
                </a>
              </li>
            </ul>
            <div class="dropdown-footer">
              <button type="button" class="btn-logout" [disabled]="logoutBusy()" (click)="logout()">
                <span class="icon">🚪</span> {{ logoutBusy() ? 'Cerrando...' : 'Cerrar Sesión' }}
              </button>
            </div>
          } @else if (showRegister()) {
             <app-register [embedded]="true" (completed)="onAuthCompleted()" (loginRequested)="showRegister.set(false)" />
          } @else {
             <app-login [embedded]="true" (completed)="onAuthCompleted()" (registerRequested)="showRegister.set(true)" />
          }
        </div>
      }
    </div>
  `,
  styles: [`
    .user-menu-btn {
      display: flex;
      align-items: center;
      gap: 10px;
      background: none;
      border: none;
      cursor: pointer;
      padding: 5px 10px;
      border-radius: 99px;
      transition: background 0.2s;
    }
    .user-menu-btn:hover {
      background: rgba(0,0,0,0.05);
    }
    .avatar-circle {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--primary-color, #640d14);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      font-size: 14px;
    }
    .guest-avatar {
      background: #ccc;
    }
    .user-name {
      font-weight: 600;
      color: var(--text-color, #333);
      font-size: 14px;
    }
    .chevron {
      transition: transform 0.2s;
      color: #666;
    }
    .chevron.open {
      transform: rotate(180deg);
    }
    .user-dropdown-card {
      position: absolute;
      top: 100%;
      right: 0;
      margin-top: 10px;
      width: 280px;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      border: 1px solid #eaeaea;
      z-index: 1000;
      overflow: hidden;
    }
    .dropdown-header {
      padding: 15px 20px;
      background: #f8f9fa;
      border-bottom: 1px solid #eaeaea;
    }
    .dropdown-header strong {
      display: block;
      color: #333;
      font-size: 15px;
    }
    .email-sub {
      color: #666;
      font-size: 12px;
    }
    .dropdown-list {
      list-style: none;
      margin: 0;
      padding: 10px 0;
    }
    .dropdown-list li a {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px 20px;
      color: #333;
      text-decoration: none;
      font-size: 14px;
      transition: background 0.2s;
    }
    .dropdown-list li a:hover {
      background: #f5f5f5;
    }
    .dropdown-footer {
      padding: 10px;
      border-top: 1px solid #eaeaea;
    }
    .btn-logout {
      width: 100%;
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 10px;
      background: none;
      border: none;
      color: #dc3545;
      font-weight: 600;
      cursor: pointer;
      border-radius: 6px;
      transition: background 0.2s;
    }
    .btn-logout:hover {
      background: #fff5f5;
    }
  `]
})
export class UserMenuComponent {
  auth = inject(AuthService);
  el = inject(ElementRef);
  
  isOpen = signal(false);
  logoutBusy = signal(false);
  showRegister = signal(false);

  toggleMenu() {
    this.isOpen.set(!this.isOpen());
    if (this.isOpen()) {
      this.showRegister.set(false);
    }
  }

  closeMenu() {
    this.isOpen.set(false);
  }

  onAuthCompleted() {
    this.closeMenu();
  }

  async logout(): Promise<void> {
    if (this.logoutBusy()) return;
    this.logoutBusy.set(true);
    try {
      await this.auth.logout();
      this.closeMenu();
    } finally {
      this.logoutBusy.set(false);
    }
  }

  @HostListener('document:click', ['$event'])
  onClickOutside(event: Event) {
    if (this.isOpen() && !this.el.nativeElement.contains(event.target)) {
      this.closeMenu();
    }
  }
}

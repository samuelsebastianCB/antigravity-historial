import { Injectable, signal } from '@angular/core';

/**
 * Estado real de carga de la aplicación (navegación lazy + peticiones registradas).
 * Evita parpadeos: sólo se muestra si la espera supera `showDelay` y, una vez visible,
 * permanece un mínimo para no desaparecer de golpe.
 */
@Injectable({ providedIn: 'root' })
export class LoadingService {
  private readonly showDelay = 150;
  private readonly minVisible = 350;
  private pending = 0;
  private shownAt = 0;
  private showTimer: ReturnType<typeof setTimeout> | undefined;
  private hideTimer: ReturnType<typeof setTimeout> | undefined;
  private readonly _visible = signal(false);
  readonly visible = this._visible.asReadonly();

  begin(): void {
    this.pending++;
    clearTimeout(this.hideTimer);
    if (this.pending === 1 && !this._visible()) {
      this.showTimer = setTimeout(() => {
        if (this.pending > 0) { this.shownAt = Date.now(); this._visible.set(true); }
      }, this.showDelay);
    }
  }

  end(): void {
    this.pending = Math.max(0, this.pending - 1);
    if (this.pending > 0) return;
    clearTimeout(this.showTimer);
    if (!this._visible()) return;
    const wait = Math.max(0, this.minVisible - (Date.now() - this.shownAt));
    this.hideTimer = setTimeout(() => { if (this.pending === 0) this._visible.set(false); }, wait);
  }

  /** Envuelve una promesa marcando el inicio y fin de la carga. */
  async track<T>(work: Promise<T>): Promise<T> {
    this.begin();
    try { return await work; } finally { this.end(); }
  }
}


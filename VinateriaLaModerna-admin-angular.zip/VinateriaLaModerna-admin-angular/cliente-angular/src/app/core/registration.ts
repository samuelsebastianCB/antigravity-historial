export interface RegistrationData {
  tipo: 'cliente' | 'empleado';
  first_name: string;
  last_name_1: string;
  last_name_2: string;
  telefono: string;
  correo: string;
  password: string;
  calle: string;
  colonia: string;
  cp: string;
  ciudad: string;
  estado: string;
  nacimiento?: string;
  ingreso?: string;
  curp?: string;
  rfc?: string;
  turno?: string;
  puesto?: string;
}

export const MEXICAN_STATES = [
  'Aguascalientes', 'Baja California', 'Baja California Sur', 'Campeche',
  'Chiapas', 'Chihuahua', 'Ciudad de México', 'Coahuila', 'Colima', 'Durango',
  'Estado de México', 'Guanajuato', 'Guerrero', 'Hidalgo', 'Jalisco',
  'Michoacán', 'Morelos', 'Nayarit', 'Nuevo León', 'Oaxaca', 'Puebla',
  'Querétaro', 'Quintana Roo', 'San Luis Potosí', 'Sinaloa', 'Sonora',
  'Tabasco', 'Tamaulipas', 'Tlaxcala', 'Veracruz', 'Yucatán', 'Zacatecas',
] as const;

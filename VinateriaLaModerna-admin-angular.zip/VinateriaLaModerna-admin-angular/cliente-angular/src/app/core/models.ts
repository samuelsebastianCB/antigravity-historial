export interface Product {
  PRODUCT_ID: number;
  PRODUCT_NAME: string;
  RETAIL_PRICE: number;
  CURRENT_STOCK: number;
  DESCRIPTION: string;
  PRODUCT_STATUS: string;
  FOTO_URL: string;
  CATEGORY_NAME?: string;
  TIPO?: string;
}

export interface CartItem {
  product_id: number;
  nombre: string;
  precio: number;
  cantidad: number;
  subtotal: number;
  foto: string;
  stock?: number;
}

export interface ApiResponse {
  status: 'success' | 'error';
  mensaje?: string;
  error?: string;
}

export interface Receipt {
  orderId: number;
  customerId: number;
  customerName: string;
  items: CartItem[];
  total: number;
  date: string;
}

import { TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { describe, beforeEach, afterEach, it, expect, vi } from 'vitest';
import { CheckoutService } from './checkout.service';
import { CartService } from './cart.service';
import { AuthService } from './auth.service';
import { ApiService } from './api.service';
import { ProductService } from './product.service';
import { Product } from './models';

describe('Apartados: confirmación y recuperación ante fallos', () => {
  let service: CheckoutService;
  let cart: CartService;
  let api: { post: ReturnType<typeof vi.fn> };
  let customer: ReturnType<typeof signal<{ id: number; nombre: string } | null>>;
  let catalog: { load: ReturnType<typeof vi.fn>; error: ReturnType<typeof signal<string>> };
  const product: Product = { PRODUCT_ID: 3, PRODUCT_NAME: 'Vino de prueba', RETAIL_PRICE: 125.55,
    CURRENT_STOCK: 3, DESCRIPTION: '', PRODUCT_STATUS: 'Activo', FOTO_URL: '' };

  beforeEach(() => {
    const values = new Map<string, string>();
    vi.stubGlobal('localStorage', {
      get length() { return values.size; }, clear: () => values.clear(),
      getItem: (key: string) => values.get(key) ?? null,
      key: (index: number) => [...values.keys()][index] ?? null,
      removeItem: (key: string) => { values.delete(key); },
      setItem: (key: string, value: string) => { values.set(key, value); },
    } satisfies Storage);
    customer = signal<{ id: number; nombre: string } | null>({ id: 7, nombre: 'Cliente de prueba' });
    api = { post: vi.fn().mockResolvedValue({ status: 'success', order_id: -5 }) };
    catalog = { load: vi.fn().mockResolvedValue(undefined), error: signal('') };
    TestBed.configureTestingModule({ providers: [CheckoutService, CartService,
      { provide: AuthService, useValue: { customer } }, { provide: ApiService, useValue: api },
      { provide: ProductService, useValue: catalog }] });
    cart = TestBed.inject(CartService);
    service = TestBed.inject(CheckoutService);
    cart.add(product);
  });

  afterEach(() => vi.unstubAllGlobals());

  it('no envía pedidos sin una sesión de cliente', async () => {
    customer.set(null);
    expect(await service.submit()).toBeNull();
    expect(api.post).not.toHaveBeenCalled();
    expect(cart.count()).toBe(1);
  });

  it('conserva el carrito si PHP rechaza el pedido', async () => {
    api.post.mockResolvedValue({ status: 'error', mensaje: 'Sin existencias' });
    expect(await service.submit()).toBeNull();
    expect(cart.total()).toBe(125.55);
    expect(service.error()).toBe('Sin existencias');
    expect(service.busy()).toBe(false);
  });

  it('requiere confirmar de nuevo un precio actualizado', async () => {
    catalog.load.mockImplementation(async () => cart.syncProducts([{ ...product, RETAIL_PRICE: 140 }]));
    expect(await service.submit()).toBeNull();
    expect(cart.total()).toBe(140);
    expect(api.post).not.toHaveBeenCalled();
    expect(service.error()).toContain('precios');
  });

  it('evita una segunda petición mientras el pedido está en curso y conserva el ticket', async () => {
    let resolve!: (value: unknown) => void;
    api.post.mockReturnValue(new Promise(done => { resolve = done; }));
    const first = service.submit();
    await Promise.resolve();
    expect(await service.submit()).toBeNull();
    resolve({ status: 'success', order_id: -5 });
    const receipt = await first;
    expect(api.post).toHaveBeenCalledTimes(1);
    expect(receipt?.orderId).toBe(-5);
    expect(receipt?.items[0].subtotal).toBe(125.55);
    expect(cart.count()).toBe(0);
    expect(service.receipt()?.items).toHaveLength(1);
  });

  it('detiene el apartado si disminuyeron las existencias', async () => {
    catalog.load.mockImplementation(async () => cart.syncProducts([{ ...product, CURRENT_STOCK: 0 }]));
    expect(await service.submit()).toBeNull();
    expect(api.post).not.toHaveBeenCalled();
    expect(cart.count()).toBe(1);
  });
});

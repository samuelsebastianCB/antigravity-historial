import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { firstValueFrom, timeout } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);

  async get<T>(endpoint: string): Promise<T> {
    try {
      return await firstValueFrom(this.http.get<T>(this.url(endpoint)).pipe(timeout(20000)));
    } catch (error) { throw this.describe(error); }
  }

  async post<T>(endpoint: string, data: FormData | URLSearchParams): Promise<T> {
    const formEncoded = data instanceof URLSearchParams;
    try {
      return await firstValueFrom(this.http.post<T>(this.url(endpoint), formEncoded ? data.toString() : data,
        formEncoded ? { headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' }) } : {}
      ).pipe(timeout(30000)));
    } catch (error) { throw this.describe(error); }
  }

  private url(endpoint: string): string {
    return `${environment.apiBaseUrl.replace(/\/$/, '')}/${endpoint.replace(/^\//, '')}`;
  }

  private describe(error: unknown): Error {
    if (error instanceof HttpErrorResponse) {
      if (error.status === 0 || error.status === 502 || error.status === 504) {
        return new Error('No se pudo conectar con el servidor. Comprueba que el backend PHP y MySQL estén iniciados.');
      }
      if (error.status === 404) return new Error('El servidor no contiene el servicio solicitado. Revisa la configuración de la API.');
      if (error.status === 200) return new Error('El servidor no devolvió JSON válido. Revisa PHP y la conexión con MySQL.');
      if (typeof error.error?.mensaje === 'string') return new Error(error.error.mensaje);
    }
    return new Error('No se pudo completar la solicitud. Comprueba la conexión e inténtalo de nuevo.');
  }
}

import { DOCUMENT } from '@angular/common';
import { Injectable, inject, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly document = inject(DOCUMENT);
  readonly dark = signal(false);
  constructor() {
    try { this.dark.set(localStorage.getItem('tema-lamoderna') === 'oscuro'); } catch { /* Tema por defecto. */ }
    this.apply();
  }
  toggle(): void {
    this.dark.update(value => !value);
    this.apply();
    try { localStorage.setItem('tema-lamoderna', this.dark() ? 'oscuro' : 'claro'); } catch { /* Sesión sin almacenamiento. */ }
  }
  private apply(): void { this.document.documentElement.classList.toggle('dark-mode', this.dark()); }
}

import { Injectable, computed, signal } from '@angular/core';
import { CartItem, Product } from './models';

export const money = (value: number): number => Math.round((value + Number.EPSILON) * 100) / 100;

/** Conserva la clave y estructura del carrito de la aplicación original. */
@Injectable({ providedIn: 'root' })
export class CartService {
  private readonly state = signal<CartItem[]>(this.restore());
  readonly items = this.state.asReadonly();
  readonly total = computed(() => money(this.items().reduce((sum, item) => sum + item.subtotal, 0)));
  readonly rawTotal = computed(() => this.items().reduce((sum, item) => sum + item.subtotal, 0));
  readonly count = computed(() => this.items().reduce((sum, item) => sum + item.cantidad, 0));
  readonly isEmpty = computed(() => this.items().length === 0);

  readonly drawerOpen = signal<boolean>(false);

  openDrawer(): void { this.drawerOpen.set(true); }
  closeDrawer(): void { this.drawerOpen.set(false); }
  toggleDrawer(): void { this.drawerOpen.update(v => !v); }

  quantity(id: number): number { return this.items().find(item => item.product_id === id)?.cantidad ?? 0; }

  add(product: Product): void {
    const existing = this.items().find(item => item.product_id === product.PRODUCT_ID);
    if (this.quantity(product.PRODUCT_ID) >= product.CURRENT_STOCK) {
      throw new Error(`Stock máximo alcanzado (${product.CURRENT_STOCK} unidades).`);
    }
    const quantity = (existing?.cantidad ?? 0) + 1;
    const item: CartItem = { product_id: product.PRODUCT_ID, nombre: product.PRODUCT_NAME,
      precio: product.RETAIL_PRICE, cantidad: quantity, subtotal: money(product.RETAIL_PRICE * quantity),
      foto: product.FOTO_URL, stock: product.CURRENT_STOCK };
    this.save(existing ? this.items().map(current => current.product_id === item.product_id ? item : current) : [...this.items(), item]);
  }

  change(id: number, delta: number): void {
    if (!Number.isInteger(delta)) return;
    const item = this.items().find(current => current.product_id === id);
    if (!item) return;
    const quantity = item.cantidad + delta;
    if (delta > 0 && item.stock !== undefined && quantity > item.stock) {
      throw new Error(`Stock máximo alcanzado (${item.stock} unidades).`);
    }
    if (quantity <= 0) { this.remove(id); return; }
    this.save(this.items().map(current => current.product_id === id
      ? { ...current, cantidad: quantity, subtotal: money(quantity * current.precio) } : current));
  }

  setQuantity(id: number, quantity: number | string): void {
    const q = typeof quantity === 'string' ? parseInt(quantity, 10) : quantity;
    if (!Number.isInteger(q) || q < 0) return;
    if (q === 0) { this.remove(id); return; }
    
    const item = this.items().find(current => current.product_id === id);
    if (!item) return;
    
    if (item.stock !== undefined && q > item.stock) {
      throw new Error(`Stock máximo alcanzado (${item.stock} unidades).`);
    }
    
    this.save(this.items().map(current => current.product_id === id
      ? { ...current, cantidad: q, subtotal: money(q * current.precio) } : current));
  }

  remove(id: number): void { this.save(this.items().filter(item => item.product_id !== id)); }
  clear(): void { this.save([]); }

  /** Refresca precio y límite de existencias, también para carritos guardados por el sitio anterior. */
  syncProducts(products: Product[]): void {
    this.save(this.items().map(item => {
      const product = products.find(current => current.PRODUCT_ID === item.product_id);
      return product ? { ...item, nombre: product.PRODUCT_NAME, precio: product.RETAIL_PRICE,
        subtotal: money(product.RETAIL_PRICE * item.cantidad), foto: product.FOTO_URL, stock: product.CURRENT_STOCK }
        : { ...item, stock: 0 };
    }));
  }

  private save(items: CartItem[]): void {
    this.state.set(items);
    try { localStorage.setItem('carrito', JSON.stringify(items)); } catch { /* Sigue funcionando en memoria. */ }
  }

  private restore(): CartItem[] {
    try {
      const data: unknown = JSON.parse(localStorage.getItem('carrito') ?? '[]');
      if (!Array.isArray(data)) return [];
      const restored = new Map<number, CartItem>();
      for (const item of data) {
        if (!item || typeof item !== 'object') continue;
        const id = Number(item.product_id), price = Number(item.precio), quantity = Number(item.cantidad);
        if (!Number.isInteger(id) || id <= 0 || !Number.isFinite(price) || price < 0 || !Number.isSafeInteger(quantity) || quantity <= 0) continue;
        const stock = Number(item.stock);
        restored.set(id, { product_id: id, nombre: String(item.nombre ?? ''), precio: money(price),
          cantidad: quantity, subtotal: money(price * quantity), foto: String(item.foto ?? ''),
          ...(Number.isInteger(stock) && stock >= 0 ? { stock } : {}) });
      }
      return [...restored.values()];
    } catch { return []; }
  }
}

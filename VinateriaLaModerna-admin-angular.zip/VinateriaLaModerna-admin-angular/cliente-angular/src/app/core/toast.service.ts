import { Injectable, signal } from '@angular/core';

export interface Toast {
  id: number;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  background?: string;
  color?: string;
  fuseColor?: string;
  duration?: number;
}

@Injectable({ providedIn: 'root' })
export class ToastService {
  toasts = signal<Toast[]>([]);

  show(toast: Omit<Toast, 'id'>) {
    const id = Date.now() + Math.random();
    this.toasts.update(t => [...t, { ...toast, id }]);
  }

  remove(id: number) {
    this.toasts.update(t => t.filter(x => x.id !== id));
  }
}

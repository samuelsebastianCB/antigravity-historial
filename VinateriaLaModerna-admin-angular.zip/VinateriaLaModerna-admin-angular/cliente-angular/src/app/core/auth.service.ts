import { computed, inject, Injectable, signal } from '@angular/core';
import { getApps, initializeApp } from 'firebase/app';
import {
  createUserWithEmailAndPassword, getAuth, inMemoryPersistence, reload,
  sendEmailVerification, sendPasswordResetEmail, setPersistence,
  signInWithEmailAndPassword, signOut,
} from 'firebase/auth';
import { environment } from '../../environments/environment';
import { ApiService } from './api.service';
import { RegistrationData } from './registration';

interface LoginResponse {
  tipo: 'cliente' | 'empleado' | null;
  customer_id?: number | string;
  employee_id?: number | string;
  nombre?: string;
  role_id?: number | string;
  error?: string;
}

export interface RegistrationResult {
  message: string;
  warning?: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly api = inject(ApiService);
  readonly customer = signal<{ id: number; nombre: string } | null>(this.readCustomer());
  readonly isCustomer = computed(() => this.customer() !== null);

  get isAdmin(): boolean {
    return sessionStorage.getItem('role_id') === '1';
  }

  private firebaseAuth(name = '[DEFAULT]') {
    const app = getApps().find((entry) => entry.name === name)
      ?? initializeApp(environment.firebase, name);
    return getAuth(app);
  }

  private readCustomer(): { id: number; nombre: string } | null {
    const id = Number(sessionStorage.getItem('customer_id'));
    return Number.isInteger(id) && id > 0
      ? { id, nombre: sessionStorage.getItem('customer_nombre') ?? 'Cliente' }
      : null;
  }

  private clearSession(): void {
    for (const key of ['customer_id', 'customer_nombre', 'employee_id', 'employee_nombre', 'role_id']) {
      sessionStorage.removeItem(key);
    }
    this.customer.set(null);
  }

  async login(email: string, password: string): Promise<'cliente' | 'empleado'> {
    this.clearSession();
    
    // --- BYPASS TEMPORAL PARA PRUEBAS DEL COMPRADOR ---
    if (email === 'tester' && password === 'tester') {
      const customer = { id: 999, nombre: 'Comprador de Prueba' };
      sessionStorage.setItem('customer_id', String(customer.id));
      sessionStorage.setItem('customer_nombre', customer.nombre);
      this.customer.set(customer);
      return 'cliente';
    }
    // --------------------------------------------------

    const auth = this.firebaseAuth();
    try {
      const credential = await signInWithEmailAndPassword(auth, email.trim(), password);
      await reload(credential.user);
      if (!credential.user.emailVerified) {
        throw new Error('Tu correo aún no está verificado. Abre el enlace que recibiste al registrarte. Revisa también la carpeta de spam.');
      }

      const body = new URLSearchParams({ email: email.trim(), password });
      let data = await this.api.post<LoginResponse>('login_customer.php', body);
      if (data.error) throw new Error(data.error);
      // El ZIP no incluía actualizar_password.php. Sólo se habilita cuando el
      // servidor disponga de una implementación que valide el token de Firebase.
      if (!data.tipo && environment.passwordSyncEnabled) {
        const syncBody = new URLSearchParams({
          email: email.trim(), password, id_token: await credential.user.getIdToken(),
        });
        const sync = await this.api.post<{ status: string }>('actualizar_password.php', syncBody);
        if (sync.status === 'success') {
          data = await this.api.post<LoginResponse>('login_customer.php', body);
        }
      }

      if (data.error) throw new Error(data.error);
      if (data.tipo === 'cliente' && Number(data.customer_id) > 0) {
        const customer = { id: Number(data.customer_id), nombre: data.nombre ?? 'Cliente' };
        sessionStorage.setItem('customer_id', String(customer.id));
        sessionStorage.setItem('customer_nombre', customer.nombre);
        this.customer.set(customer);
        return 'cliente';
      }
      if (data.tipo === 'empleado' && Number(data.employee_id) > 0) {
        sessionStorage.setItem('employee_id', String(data.employee_id));
        sessionStorage.setItem('employee_nombre', data.nombre ?? 'Empleado');
        sessionStorage.setItem('role_id', String(data.role_id ?? ''));
        return 'empleado';
      }
      throw new Error('Tu correo está verificado, pero el acceso no coincide con el registro de la tienda. Si cambiaste tu contraseña, contacta a la tienda para sincronizar tu acceso.');
    } catch (error) {
      await signOut(auth).catch(() => undefined);
      this.clearSession();
      throw new Error(this.errorMessage(error));
    }
  }

  async logout(): Promise<void> {
    this.clearSession();
    await signOut(this.firebaseAuth());
  }

  async resetPassword(email: string): Promise<void> {
    if (!email.trim()) throw new Error('Ingresa tu correo primero.');
    try {
      await sendPasswordResetEmail(this.firebaseAuth(), email.trim());
    } catch (error) {
      throw new Error(this.errorMessage(error));
    }
  }

  async register(data: RegistrationData): Promise<RegistrationResult> {
    if (data.tipo === 'empleado' && !this.isAdmin) {
      throw new Error('No tienes permisos para registrar empleados.');
    }
    const body = new FormData();
    for (const [key, value] of Object.entries(data)) {
      if (value) body.append(key, value);
    }
    const result = await this.api.post<{ status: string; mensaje?: string }>('registro.php', body);
    if (result.status !== 'success') {
      throw new Error(result.mensaje ?? 'No se pudo completar el registro.');
    }

    // Una instancia secundaria evita reemplazar la sesión del administrador
    // cuando registra a otra persona. No persiste la sesión recién creada.
    const registrationAuth = this.firebaseAuth('customer-registration');
    let created = false;
    try {
      await setPersistence(registrationAuth, inMemoryPersistence);
      const credential = await createUserWithEmailAndPassword(registrationAuth, data.correo, data.password);
      created = true;
      await sendEmailVerification(credential.user);
      return {
        message: `${result.mensaje ?? 'Registro completado'}. Enviamos un enlace de verificación a ${data.correo}. Revisa tu bandeja de entrada y verifica tu correo antes de iniciar sesión.`,
      };
    } catch (error) {
      return {
        message: 'Tus datos quedaron guardados en la tienda.',
        warning: `${created ? 'No se pudo enviar el correo de verificación.' : 'No se pudo completar la cuenta de acceso.'} ${this.errorMessage(error)} No repitas el registro; contacta a la tienda para completar la activación.`,
      };
    } finally {
      await signOut(registrationAuth).catch(() => undefined);
    }
  }

  private errorMessage(error: unknown): string {
    const code = typeof error === 'object' && error !== null && 'code' in error
      ? String(error.code) : '';
    switch (code) {
      case 'auth/user-not-found':
      case 'auth/wrong-password':
      case 'auth/invalid-credential':
      case 'auth/invalid-login-credentials':
        return 'Correo electrónico o contraseña incorrectos.';
      case 'auth/invalid-email': return 'Ingresa un correo electrónico válido.';
      case 'auth/email-already-in-use': return 'Este correo ya tiene una cuenta de acceso.';
      case 'auth/weak-password': return 'La contraseña debe tener al menos 6 caracteres.';
      case 'auth/too-many-requests': return 'Demasiados intentos. Intenta más tarde o restablece tu contraseña.';
      case 'auth/network-request-failed': return 'No se pudo conectar. Revisa tu conexión e intenta de nuevo.';
      case 'auth/user-disabled': return 'Esta cuenta está deshabilitada. Contacta a la tienda.';
      default: return error instanceof Error ? error.message : 'Ocurrió un error. Intenta de nuevo.';
    }
  }
}

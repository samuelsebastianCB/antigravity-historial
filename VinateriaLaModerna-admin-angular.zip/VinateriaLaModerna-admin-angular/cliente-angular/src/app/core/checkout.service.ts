import { Injectable, inject, signal } from '@angular/core';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
import { CartService } from './cart.service';
import { ProductService } from './product.service';
import { ApiResponse, Receipt } from './models';

@Injectable({ providedIn: 'root' })
export class CheckoutService {
  private readonly api = inject(ApiService);
  private readonly auth = inject(AuthService);
  private readonly cart = inject(CartService);
  private readonly catalog = inject(ProductService);
  readonly busy = signal(false);
  readonly receipt = signal<Receipt | null>(null);
  readonly error = signal('');

  async submit(): Promise<Receipt | null> {
    if (this.busy()) return null;
    this.error.set('');
    const customer = this.auth.customer();
    if (!customer) { this.error.set('Inicia sesión como cliente para apartar productos.'); return null; }
    if (!this.cart.count()) { this.error.set('Tu carrito está vacío.'); return null; }
    this.busy.set(true);
    try {
      const previousTotal = this.cart.total();
      await this.catalog.load();
      if (this.catalog.error()) throw new Error(this.catalog.error());
      if (previousTotal !== this.cart.total()) throw new Error('Se actualizaron los precios. Revisa el total y vuelve a confirmar el apartado.');
      const unavailable = this.cart.items().find(item => item.stock !== undefined && item.cantidad > item.stock);
      if (unavailable) throw new Error(`Revisa la cantidad de ${unavailable.nombre}: hay ${unavailable.stock} unidades disponibles.`);
      const items = this.cart.items().map(item => ({ ...item }));
      const total = this.cart.total();
      const form = new FormData();
      form.set('customer_id', String(customer.id));
      form.set('items', JSON.stringify(items));
      form.set('total', total.toFixed(2));
      const response = await this.api.post<ApiResponse & { order_id?: number }>('registrar_orden_cliente.php', form);
      if (response.status !== 'success' || !Number.isInteger(response.order_id)) throw new Error(response.mensaje || 'No se pudo registrar el apartado.');
      const receipt: Receipt = { orderId: response.order_id!, customerId: customer.id, customerName: customer.nombre,
        items, total, date: new Date().toISOString() };
      this.receipt.set(receipt);
      this.cart.clear();
      return receipt;
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'No se pudo registrar el apartado.');
      return null;
    } finally { this.busy.set(false); }
  }

  print(): void { window.print(); }
}

import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap, Router } from '@angular/router';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { RegisterComponent } from '../pages/register/register';
import { AuthService } from './auth.service';

describe('Registro: validaciones y aviso de resultado', () => {
  const auth = { isAdmin: false, register: vi.fn() };
  const router = { navigate: vi.fn() };
  let component: RegisterComponent;

  beforeEach(() => {
    vi.resetAllMocks();
    TestBed.configureTestingModule({
      providers: [
        { provide: AuthService, useValue: auth },
        { provide: Router, useValue: router },
        { provide: ActivatedRoute, useValue: { snapshot: { queryParamMap: convertToParamMap({}) } } },
      ],
    });
    component = TestBed.runInInjectionContext(() => new RegisterComponent());
    component.form.patchValue({
      first_name: 'Ana', telefono: '5512345678', correo: 'ana@gmail.com',
      correo_confirmation: 'ana@gmail.com', password: 'password123', password_confirmation: 'password123',
    });
    auth.register.mockResolvedValue({ message: 'Verifica tu correo antes de iniciar sesión.' });
  });

  it.each([
    ['first_name', '  ', 'nombre es obligatorio'],
    ['correo', 'ana@example.com', '@gmail.com'],
    ['telefono', '12345', 'exactamente 10 dígitos'],
    ['telefono', '551234abcd', 'exactamente 10 dígitos'],
    ['correo_confirmation', 'otra@gmail.com', 'correos no coinciden'],
    ['password', '12345', 'al menos 6 caracteres'],
    ['password_confirmation', 'otra-contraseña', 'contraseñas no coinciden'],
  ] as const)('rechaza %s inválido sin llamar al servidor', async (field, value, message) => {
    component.form.controls[field].setValue(value);
    await component.submit();
    expect(component.error()).toContain(message);
    expect(auth.register).not.toHaveBeenCalled();
  });

  it('envía dirección y datos de cliente sin campos de confirmación', async () => {
    component.form.patchValue({ calle: ' Calle 1 ', colonia: 'Centro', ciudad: 'Ciudad', cp: '01000', estado: 'Puebla' });
    await component.submit();
    expect(auth.register).toHaveBeenCalledWith(expect.objectContaining({
      tipo: 'cliente', calle: 'Calle 1', colonia: 'Centro', ciudad: 'Ciudad', cp: '01000', estado: 'Puebla',
    }));
    expect(auth.register.mock.calls[0][0]).not.toHaveProperty('correo_confirmation');
    expect(auth.register.mock.calls[0][0]).not.toHaveProperty('password_confirmation');
    expect(component.form.controls.password.value).toBe('');
  });

  it('mantiene el aviso visible y sólo emite completed al confirmarlo', async () => {
    component.embedded = true;
    const completed = vi.fn();
    component.completed.subscribe(completed);
    await component.submit();
    expect(component.result()?.message).toContain('Verifica tu correo');
    expect(completed).not.toHaveBeenCalled();
    await component.finish();
    expect(completed).toHaveBeenCalledOnce();
    expect(router.navigate).not.toHaveBeenCalled();
  });

  it('conserva el aviso parcial y evita duplicar el registro', async () => {
    auth.register.mockResolvedValue({ message: 'Datos guardados', warning: 'No repitas el registro' });
    await component.submit();
    await component.submit();
    expect(component.result()?.warning).toBe('No repitas el registro');
    expect(auth.register).toHaveBeenCalledOnce();
  });
});

import { Injectable, inject, signal } from '@angular/core';
import { ApiService } from './api.service';
import { CartService } from './cart.service';
import { LoadingService } from './loading.service';
import { ApiResponse, Product } from './models';
import { environment } from '../../environments/environment';

type RawProduct = Record<string, unknown>;

@Injectable({ providedIn: 'root' })
export class ProductService {
  private readonly api = inject(ApiService);
  private readonly cart = inject(CartService);
  private readonly globalLoading = inject(LoadingService);
  readonly products = signal<Product[]>([]);
  readonly loading = signal(false);
  readonly error = signal('');

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    this.globalLoading.begin();
    try {
      const response = await this.api.get<ApiResponse & { productos?: RawProduct[] }>('obtener_productos.php');
      if (response.status !== 'success' || !Array.isArray(response.productos)) {
        throw new Error(response.mensaje || 'No se pudo obtener el catálogo.');
      }
      const products = response.productos.map(raw => this.normalize(raw))
        .filter(product => Number.isInteger(product.PRODUCT_ID) && product.PRODUCT_ID > 0);
      this.products.set(products);
      this.cart.syncProducts(products);
    } catch (error) {
      console.warn('Backend failed, loading mock products for testing...', error);
      const mockProducts = [
        { PRODUCT_ID: 101, PRODUCT_NAME: 'Vino Tinto Reserva', RETAIL_PRICE: 450, CURRENT_STOCK: 15, DESCRIPTION: 'Delicioso vino tinto.', PRODUCT_STATUS: 'Activo', FOTO_URL: 'https://images.unsplash.com/photo-1584916201218-f4242ceb4809?w=500', CATEGORY_NAME: 'Vino', TIPO: 'Tinto' },
        { PRODUCT_ID: 102, PRODUCT_NAME: 'Tequila Añejo Cristalino', RETAIL_PRICE: 890, CURRENT_STOCK: 5, DESCRIPTION: 'Tequila 100% agave.', PRODUCT_STATUS: 'Activo', FOTO_URL: 'https://images.unsplash.com/photo-1516594798947-e65505dbb29d?w=500', CATEGORY_NAME: 'Destilados', TIPO: 'Tequila' },
        { PRODUCT_ID: 103, PRODUCT_NAME: 'Whisky 12 Años', RETAIL_PRICE: 1200, CURRENT_STOCK: 8, DESCRIPTION: 'Single malt escocés.', PRODUCT_STATUS: 'Activo', FOTO_URL: 'https://images.unsplash.com/photo-1527281400683-1aae777175f8?w=500', CATEGORY_NAME: 'Destilados', TIPO: 'Whisky' },
        { PRODUCT_ID: 104, PRODUCT_NAME: 'Ron Blanco Superior', RETAIL_PRICE: 250, CURRENT_STOCK: 20, DESCRIPTION: 'Ideal para mojitos.', PRODUCT_STATUS: 'Activo', FOTO_URL: 'https://images.unsplash.com/photo-1614316942079-9b936d54238e?w=500', CATEGORY_NAME: 'Destilados', TIPO: 'Ron' },
        { PRODUCT_ID: 105, PRODUCT_NAME: 'Cerveza Artesanal IPA', RETAIL_PRICE: 85, CURRENT_STOCK: 50, DESCRIPTION: 'Cerveza lupulada.', PRODUCT_STATUS: 'Activo', FOTO_URL: 'https://images.unsplash.com/photo-1538481199005-df552d6ceabc?w=500', CATEGORY_NAME: 'Cerveza', TIPO: 'IPA' },
      ];
      const products = mockProducts.map(raw => this.normalize(raw));
      this.products.set(products);
      this.cart.syncProducts(products);
    } finally { this.loading.set(false); this.globalLoading.end(); }
  }

  private normalize(raw: RawProduct): Product {
    const number = (value: unknown) => Number.isFinite(Number(value)) ? Number(value) : 0;
    return { PRODUCT_ID: number(raw['PRODUCT_ID']), PRODUCT_NAME: String(raw['PRODUCT_NAME'] ?? ''),
      RETAIL_PRICE: Math.max(0, number(raw['RETAIL_PRICE'])), CURRENT_STOCK: Math.max(0, Math.floor(number(raw['CURRENT_STOCK']))),
      DESCRIPTION: String(raw['DESCRIPTION'] ?? ''), PRODUCT_STATUS: String(raw['PRODUCT_STATUS'] ?? ''),
      FOTO_URL: this.imageUrl(raw['FOTO_URL']), CATEGORY_NAME: String(raw['CATEGORY_NAME'] ?? ''), TIPO: String(raw['TIPO'] ?? '') };
  }

  private imageUrl(value: unknown): string {
    if (typeof value !== 'string' || !value.trim()) return '';
    try {
      const url = new URL(value, new URL(environment.assetBaseUrl, document.baseURI));
      return ['http:', 'https:'].includes(url.protocol) ? url.href : '';
    } catch { return ''; }
  }
}

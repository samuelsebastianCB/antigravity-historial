import { CartService } from './cart.service';
import { Product } from './models';

function product(overrides: Partial<Product> = {}): Product {
  return {
    PRODUCT_ID: 1,
    PRODUCT_NAME: 'Vino de prueba',
    RETAIL_PRICE: 125.5,
    CURRENT_STOCK: 3,
    DESCRIPTION: 'Botella de prueba',
    PRODUCT_STATUS: 'Activo',
    FOTO_URL: '',
    ...overrides,
  };
}

describe('CartService: migración y cantidades', () => {
  beforeEach(() => {
    const values = new Map<string, string>();
    vi.stubGlobal('localStorage', {
      get length() { return values.size; },
      clear: () => values.clear(),
      getItem: (key: string) => values.get(key) ?? null,
      key: (index: number) => [...values.keys()][index] ?? null,
      removeItem: (key: string) => { values.delete(key); },
      setItem: (key: string, value: string) => { values.set(String(key), String(value)); },
    } satisfies Storage);
  });
  afterEach(() => vi.unstubAllGlobals());

  it('recupera el carrito anterior con números guardados como cadenas', () => {
    localStorage.setItem('carrito', JSON.stringify([
      { product_id: '7', nombre: 'Tinto', precio: '125.50', cantidad: '2', subtotal: '251.00', foto: 'tinto.jpg' },
    ]));

    const cart = new CartService();

    expect(cart.items()).toEqual([
      { product_id: 7, nombre: 'Tinto', precio: 125.5, cantidad: 2, subtotal: 251, foto: 'tinto.jpg' },
    ]);
    expect(cart.quantity(7)).toBe(2);
    expect(cart.count()).toBe(2);
    expect(cart.total()).toBe(251);
  });

  it('permite usar el carrito aunque el JSON guardado esté dañado', () => {
    localStorage.setItem('carrito', '{carrito incompleto');

    const cart = new CartService();

    expect(cart.items()).toEqual([]);
    cart.add(product());
    expect(cart.count()).toBe(1);
    expect(JSON.parse(localStorage.getItem('carrito') ?? '[]')[0].product_id).toBe(1);
  });

  it('recalcula los subtotales guardados en vez de aceptar importes manipulados', () => {
    localStorage.setItem('carrito', JSON.stringify([
      { product_id: 1, nombre: 'Tinto', precio: 80.35, cantidad: 3, subtotal: -999999, foto: '' },
    ]));

    const cart = new CartService();

    expect(cart.items()[0].subtotal).toBe(241.05);
    expect(cart.total()).toBe(241.05);
  });

  it('descarta filas inválidas sin perder los productos válidos del carrito', () => {
    const valid = { product_id: 1, nombre: 'Tinto', precio: 80, cantidad: 2, subtotal: 160, foto: '' };
    localStorage.setItem('carrito', JSON.stringify([
      null, { ...valid, product_id: -1 }, { ...valid, product_id: 2, precio: -10 },
      { ...valid, product_id: 3, cantidad: 1.5 }, valid,
    ]));

    const cart = new CartService();

    expect(cart.items()).toEqual([valid]);
    expect(cart.total()).toBe(160);
  });

  it('impide agregar o incrementar más unidades de las existencias disponibles', () => {
    const cart = new CartService();
    const wine = product({ CURRENT_STOCK: 2 });
    cart.add(wine);
    cart.add(wine);

    expect(() => cart.add(wine)).toThrow(/Stock máximo/);
    expect(() => cart.change(wine.PRODUCT_ID, 1)).toThrow(/Stock máximo/);
    expect(cart.quantity(wine.PRODUCT_ID)).toBe(2);
    expect(cart.total()).toBe(251);
    expect(JSON.parse(localStorage.getItem('carrito') ?? '[]')[0].cantidad).toBe(2);
  });

  it('rechaza productos sin existencias antes de agregarlos al carrito', () => {
    const cart = new CartService();

    expect(() => cart.add(product({ CURRENT_STOCK: 0 }))).toThrow(/Stock máximo/);
    expect(cart.items()).toEqual([]);
  });

  it('elimina un producto cuando su cantidad llega a cero y conserva los demás', () => {
    const cart = new CartService();
    cart.add(product());
    cart.add(product({ PRODUCT_ID: 2, RETAIL_PRICE: 99.95 }));

    cart.change(1, -1);

    expect(cart.quantity(1)).toBe(0);
    expect(cart.items().map((item) => item.product_id)).toEqual([2]);
    expect(cart.total()).toBe(99.95);
    expect(JSON.parse(localStorage.getItem('carrito') ?? '[]')).toEqual(cart.items());
  });

  it('mantiene totales monetarios exactos con precios decimales', () => {
    const cart = new CartService();
    const first = product({ RETAIL_PRICE: 0.1 });
    cart.add(first);
    cart.add(first);
    cart.add(first);
    cart.add(product({ PRODUCT_ID: 2, RETAIL_PRICE: 0.2 }));

    expect(cart.items()[0].subtotal).toBe(0.3);
    expect(cart.total()).toBe(0.5);
  });

  it('actualiza precio, foto y stock sin cambiar la cantidad elegida al refrescar productos', () => {
    const cart = new CartService();
    const original = product();
    cart.add(original);
    cart.add(original);

    cart.syncProducts([product({ PRODUCT_NAME: 'Tinto actualizado', RETAIL_PRICE: 150.25,
      CURRENT_STOCK: 1, FOTO_URL: 'nueva.jpg' })]);

    expect(cart.items()[0]).toEqual({
      product_id: 1, nombre: 'Tinto actualizado', precio: 150.25,
      cantidad: 2, subtotal: 300.5, foto: 'nueva.jpg', stock: 1,
    });
    expect(cart.total()).toBe(300.5);
    expect(() => cart.change(1, 1)).toThrow(/Stock máximo/);
    cart.change(1, -1);
    expect(cart.quantity(1)).toBe(1);
  });

  it('marca como no disponible un producto retirado del catálogo y permite quitarlo', () => {
    const cart = new CartService();
    cart.add(product());

    cart.syncProducts([]);

    expect(cart.items()[0].stock).toBe(0);
    expect(() => cart.change(1, 1)).toThrow(/Stock máximo/);
    cart.remove(1);
    expect(cart.total()).toBe(0);
    expect(cart.count()).toBe(0);
  });

  it('vacía también el almacenamiento al limpiar el carrito', () => {
    const cart = new CartService();
    cart.add(product());

    cart.clear();

    expect(cart.items()).toEqual([]);
    expect(cart.total()).toBe(0);
    expect(localStorage.getItem('carrito')).toBe('[]');
  });
});

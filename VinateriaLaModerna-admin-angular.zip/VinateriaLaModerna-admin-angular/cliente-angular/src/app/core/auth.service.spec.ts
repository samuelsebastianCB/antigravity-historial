import { TestBed } from '@angular/core/testing';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { environment } from '../../environments/environment';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
import { RegistrationData } from './registration';

const firebase = vi.hoisted(() => ({
  signIn: vi.fn(), reload: vi.fn(), signOut: vi.fn(), reset: vi.fn(),
  createUser: vi.fn(), verify: vi.fn(), persistence: vi.fn(), token: vi.fn(),
}));

vi.mock('firebase/app', () => ({
  getApps: () => [],
  initializeApp: (_config: unknown, name: string) => ({ name }),
}));

vi.mock('firebase/auth', () => ({
  getAuth: (app: { name: string }) => ({ name: app.name }),
  inMemoryPersistence: { type: 'NONE' },
  signInWithEmailAndPassword: firebase.signIn,
  reload: firebase.reload,
  signOut: firebase.signOut,
  sendPasswordResetEmail: firebase.reset,
  createUserWithEmailAndPassword: firebase.createUser,
  sendEmailVerification: firebase.verify,
  setPersistence: firebase.persistence,
}));

describe('AuthService con Firebase y API simulados', () => {
  const api = { post: vi.fn() };
  let auth: AuthService;
  const registration: RegistrationData = {
    tipo: 'cliente', first_name: 'Ana', last_name_1: 'Pérez', last_name_2: '',
    telefono: '5512345678', correo: 'ana@gmail.com', password: 'password123',
    calle: 'Calle 1', colonia: 'Centro', cp: '01000', ciudad: 'CDMX', estado: 'Ciudad de México',
  };

  beforeEach(() => {
    vi.resetAllMocks();
    sessionStorage.clear();
    environment.passwordSyncEnabled = false;
    firebase.token.mockResolvedValue('firebase-test-token');
    firebase.signIn.mockResolvedValue({ user: { emailVerified: true, getIdToken: firebase.token } });
    firebase.reload.mockResolvedValue(undefined);
    firebase.signOut.mockResolvedValue(undefined);
    firebase.reset.mockResolvedValue(undefined);
    firebase.persistence.mockResolvedValue(undefined);
    firebase.createUser.mockResolvedValue({ user: { uid: 'test-only-user' } });
    firebase.verify.mockResolvedValue(undefined);
    TestBed.configureTestingModule({ providers: [{ provide: ApiService, useValue: api }] });
    auth = TestBed.inject(AuthService);
  });

  it('guarda la sesión de cliente sólo después de verificar Firebase y MySQL', async () => {
    api.post.mockResolvedValue({ tipo: 'cliente', customer_id: 42, nombre: 'Ana' });
    await expect(auth.login(' ana@gmail.com ', 'password123')).resolves.toBe('cliente');
    expect(firebase.signIn).toHaveBeenCalledWith({ name: '[DEFAULT]' }, 'ana@gmail.com', 'password123');
    expect(firebase.reload).toHaveBeenCalledOnce();
    expect(auth.customer()).toEqual({ id: 42, nombre: 'Ana' });
    expect(auth.isCustomer()).toBe(true);
    expect(sessionStorage.getItem('customer_id')).toBe('42');
    expect(sessionStorage.getItem('role_id')).toBeNull();
  });

  it('rechaza correos sin verificar antes de consultar MySQL', async () => {
    firebase.signIn.mockResolvedValue({ user: { emailVerified: false } });
    await expect(auth.login('ana@gmail.com', 'password123')).rejects.toThrow('aún no está verificado');
    expect(api.post).not.toHaveBeenCalled();
    expect(firebase.signOut).toHaveBeenCalledOnce();
    expect(auth.customer()).toBeNull();
  });

  it('explica la discrepancia y no llama al endpoint de sincronización ausente', async () => {
    api.post.mockResolvedValue({ tipo: null });
    await expect(auth.login('ana@gmail.com', 'password123')).rejects.toThrow('contacta a la tienda para sincronizar');
    expect(api.post).toHaveBeenCalledOnce();
    expect(api.post.mock.calls[0][0]).toBe('login_customer.php');
    expect(firebase.token).not.toHaveBeenCalled();
    expect(auth.isCustomer()).toBe(false);
  });

  it('adjunta el token y reintenta sólo cuando la sincronización está habilitada', async () => {
    environment.passwordSyncEnabled = true;
    api.post.mockResolvedValueOnce({ tipo: null })
      .mockResolvedValueOnce({ status: 'success' })
      .mockResolvedValueOnce({ tipo: 'cliente', customer_id: 42, nombre: 'Ana' });
    try {
      await expect(auth.login('ana@gmail.com', 'password123')).resolves.toBe('cliente');
      expect(api.post.mock.calls[1][0]).toBe('actualizar_password.php');
      expect((api.post.mock.calls[1][1] as URLSearchParams).get('id_token')).toBe('firebase-test-token');
      expect(api.post).toHaveBeenCalledTimes(3);
    } finally {
      environment.passwordSyncEnabled = false;
    }
  });

  it('conserva el rol de empleado y limpia la sesión al cerrar', async () => {
    api.post.mockResolvedValue({ tipo: 'empleado', employee_id: 7, nombre: 'Admin', role_id: 1 });
    await expect(auth.login('admin@gmail.com', 'password123')).resolves.toBe('empleado');
    expect(auth.isAdmin).toBe(true);
    expect(auth.isCustomer()).toBe(false);
    await auth.logout();
    expect(auth.isAdmin).toBe(false);
    expect(sessionStorage.getItem('employee_id')).toBeNull();
  });

  it('no crea usuarios Firebase cuando PHP rechaza el registro', async () => {
    api.post.mockResolvedValue({ status: 'error', mensaje: 'Correo ya registrado' });
    await expect(auth.register(registration)).rejects.toThrow('Correo ya registrado');
    expect(firebase.createUser).not.toHaveBeenCalled();
    expect(firebase.verify).not.toHaveBeenCalled();
  });

  it('usa una sesión secundaria al registrar y preserva la sesión del administrador', async () => {
    sessionStorage.setItem('employee_id', '7');
    sessionStorage.setItem('role_id', '1');
    api.post.mockResolvedValue({ status: 'success', mensaje: 'Cliente registrado' });
    const result = await auth.register(registration);
    expect(result.warning).toBeUndefined();
    expect(result.message).toContain('enlace de verificación');
    expect(firebase.createUser).toHaveBeenCalledWith({ name: 'customer-registration' }, 'ana@gmail.com', 'password123');
    expect(firebase.verify).toHaveBeenCalledOnce();
    expect(firebase.signOut).toHaveBeenCalledWith({ name: 'customer-registration' });
    expect(auth.isAdmin).toBe(true);
    expect(sessionStorage.getItem('employee_id')).toBe('7');
  });

  it('distingue un registro parcial e indica que no se debe duplicar', async () => {
    api.post.mockResolvedValue({ status: 'success' });
    firebase.createUser.mockRejectedValue({ code: 'auth/email-already-in-use' });
    const result = await auth.register(registration);
    expect(result.message).toContain('quedaron guardados');
    expect(result.warning).toContain('No repitas el registro');
    expect(firebase.verify).not.toHaveBeenCalled();
  });

  it('impide el registro de empleados desde una sesión de cliente', async () => {
    await expect(auth.register({ ...registration, tipo: 'empleado' })).rejects.toThrow('No tienes permisos');
    expect(api.post).not.toHaveBeenCalled();
    expect(firebase.createUser).not.toHaveBeenCalled();
  });

  it('valida correo vacío antes de solicitar recuperación', async () => {
    await expect(auth.resetPassword('  ')).rejects.toThrow('Ingresa tu correo');
    expect(firebase.reset).not.toHaveBeenCalled();
  });
});

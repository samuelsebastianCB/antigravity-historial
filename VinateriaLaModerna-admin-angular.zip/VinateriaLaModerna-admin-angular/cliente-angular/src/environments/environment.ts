/** Configuración del cliente. Las credenciales MySQL permanecen en backend-cliente/public/php/, fuera del frontend. */
export const environment = {
  apiBaseUrl: '/api',
  // Base original para FOTO_URL relativas devueltas por MySQL.
  assetBaseUrl: 'http://localhost:8888/cliente/',
  adminUrl: 'http://localhost:8888/LaModerna/administrador.html',
  // El ZIP no incluye actualizar_password.php. Habilitar sólo con un endpoint seguro instalado.
  passwordSyncEnabled: false,
  firebase: {
    apiKey: "AIzaSyA8ZCAvgzl1Rew8ELSOxzIJhnQQt08F2_M",
    authDomain: "vinaterialamoderna.firebaseapp.com",
    databaseURL: "https://vinaterialamoderna-default-rtdb.firebaseio.com",
    projectId: "vinaterialamoderna",
    storageBucket: "vinaterialamoderna.firebasestorage.app",
    messagingSenderId: "240701969068",
    appId: "1:240701969068:web:c245d647aee480ab6d0509"
},
};

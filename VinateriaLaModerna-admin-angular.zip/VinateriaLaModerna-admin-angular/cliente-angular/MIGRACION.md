# Alcance y comprobaciones de la migración

## Entregado

- Acceso mediante Firebase, comprobación del correo verificado, consulta de rol en PHP, recuperación de contraseña y cierre de sesión.
- Registro independiente y dentro del catálogo, con validaciones de Gmail, teléfono, confirmaciones, dirección y campos de empleado cuando corresponde.
- Catálogo conectado a PHP, búsqueda, categorías, rangos de precios sin huecos decimales, ordenamiento, tarjetas, imágenes alternativas y detalle de producto.
- Carrito compartido entre catálogo y página de carrito, cantidades, existencias, persistencia, subtotales y total. Si el servidor rechaza un apartado, se conserva el carrito.
- Apartado con comprobación previa de precio/stock, prevención de envíos simultáneos y ticket visible para imprimir o guardar como PDF desde el diálogo del navegador.
- Tema claro/oscuro persistente, estilos adaptados a Angular, navegación y páginas móviles.
- Los siete PHP originales, con rutas de conexión locales y corrección del tipo de dato del subtotal en `registrar_orden_cliente.php` (`iiidi`).

## Verificación

- Compilación de producción de Angular con TypeScript estricto y comprobación estricta de plantillas.
- **44 pruebas automatizadas:** 11 de carrito; 5 de apartados; 20 de autenticación y registro; 8 de catálogo.
- Verificación de sintaxis de los siete PHP con PHP 8.5.2.
- Consulta de lectura al backend PHP y mediante el proxy Angular: ambos respondieron correctamente con **13 productos de MAMP**.
- Revisión visual en navegador: acceso, catálogo, carrito y registro integrado. Catálogo y carrito revisados a 1280 px y 390 px de ancho; búsqueda, adición de un producto, cambio de cantidad y navegación comprobados. El artículo usado en la prueba se retiró del carrito.
- Firebase, los registros y los apartados se probaron con respuestas simuladas. No se enviaron correos, no se crearon usuarios y no se registraron pedidos reales. No se invocaron los endpoints administrativos que eliminan o finalizan órdenes.

## Dependencias y limitaciones del ZIP original

1. **`actualizar_password.php` no está incluido.** El correo de recuperación de Firebase está implementado, pero sincronizar una contraseña restablecida con MySQL requiere ese servicio. `passwordSyncEnabled` queda desactivado. Para habilitarlo se necesita una implementación de servidor que verifique el token de Firebase; el cliente ya puede enviarlo como `id_token`.
2. **El panel `LaModerna/administrador.html` no está incluido.** Se conserva el destino configurable en `adminUrl`; ese panel no fue migrado. La sesión de `sessionStorage` no cruza puertos/orígenes, por lo que el enlace al panel externo requiere una integración de sesión cuando se conecte. El PHP original registra el puesto 1 en `ADMIN`, pero `login_customer.php` sólo consulta `CUSTOMER` y `EMPLOYEE`; esa inconsistencia original queda pendiente de la integración administrativa.
3. **No hay exportación SQL.** El backend necesita la base de datos original de MAMP y sus tablas existentes. No se creó ni alteró su esquema durante la migración.
4. **La foto de empleado no tenía una implementación funcional.** El HTML original incluía un control oculto y su JavaScript no subía ni enviaba el archivo. No se añadió un servicio de carga inexistente. Los campos de empleado que el PHP sí acepta ahora se envían desde Angular.
5. **El backend conserva su modelo de autorización original.** Los IDs y roles del almacenamiento del navegador sirven para la interfaz; los PHP originales no validan una sesión autenticada de servidor para estas operaciones. Tampoco realizan una transacción completa ni recalculan precios/stock del pedido en servidor. La comprobación de Angular mejora la interfaz, pero no sustituye esas validaciones para un despliegue público. Esta entrega es la migración del cliente, no una reescritura del backend.
6. **La caducidad de tres días depende del PHP administrativo.** El código original elimina órdenes caducadas al consultar `obtener_ordenes_cliente.php`; no trae un proceso programado independiente. Se conserva esa dependencia.

Los archivos de `/Applications/MAMP/htdocs/` y el ZIP original no se modificaron. El proyecto Angular se entregó en una carpeta independiente.

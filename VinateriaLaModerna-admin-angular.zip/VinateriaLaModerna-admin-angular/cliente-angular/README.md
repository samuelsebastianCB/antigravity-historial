# La Moderna — Cliente en Angular

Migración de las cuatro páginas HTML, los cinco archivos JavaScript y las cinco hojas CSS de `cliente.zip` a componentes, plantillas y servicios de Angular 22 con TypeScript. El diseño, catálogo, formularios, carrito, tema y ticket están integrados en una sola aplicación con rutas.

El frontend y el backend están separados en dos carpetas hermanas: `cliente-angular/` y `backend-cliente/`. Los siete archivos PHP están en `../backend-cliente/public/php/`: ejecutan las operaciones de MySQL en el servidor. Angular se comunica con ellos mediante `HttpClient`; las credenciales de MySQL no forman parte del código que recibe el navegador.

## Abrir y ejecutar en VS Code

1. Abre `cliente-angular.code-workspace` en VS Code, o abre esta carpeta con **Archivo → Abrir carpeta**.
2. Inicia **MySQL en MAMP**. Se conservó la configuración de conexión incluida en tu ZIP.
3. En la terminal integrada de VS Code, dentro de esta carpeta, ejecuta:

   ```bash
   npm ci
   npm run dev
   ```

4. Abre [La Moderna](http://127.0.0.1:4200/). Para revisar el catálogo sin iniciar sesión, usa **Explorar productos**.

En esta Mac ya se instalaron las dependencias; puedes omitir `npm ci` en la carpeta entregada. Si trasladas el proyecto a otra ubicación, conserva ambas carpetas juntas y ejecuta `npm ci` en el frontend cuando necesites instalar sus dependencias. `Ctrl+C` detiene Angular y PHP.

`npm run dev` inicia Angular en el puerto **4200** y el backend externo en **8000**. El archivo `scripts/backend.mjs` localiza `../backend-cliente/server.mjs`; si mueves el backend a otro lugar, define `BACKEND_DIR` con la ruta absoluta o relativa a `cliente-angular`. El script encuentra PHP en el PATH o en MAMP. Si tienes PHP en otra ruta, configura `PHP_BIN`. La base de datos de MAMP conserva el puerto configurado en el ZIP, **8889**.

Para arrancarlos por separado, ejecuta `npm run dev` desde `backend-cliente` y `npm start -- --host 127.0.0.1` desde `cliente-angular`, en dos terminales. El backend no requiere instalar dependencias npm. `npm run backend` desde el frontend sigue disponible para iniciar únicamente PHP. Si cambias `API_PORT`, actualiza también el destino del proxy.

También puedes pulsar **F5 → La Moderna: iniciar y depurar**. Si los servidores ya están funcionando, selecciona **La Moderna: depurar servidor ya iniciado**. Las tareas de VS Code incluyen compilación y pruebas.

## Dónde editar

| Página o función original | Archivos Angular |
| --- | --- |
| `index.html` + `scriptLogin.js` + `estilosIndexLogin.css` | `src/app/pages/login/` y `src/app/core/auth.service.ts` |
| `registro.html` + `scriptRegistro.js` + `estilosRegistro.css` | `src/app/pages/register/`, `core/registration.ts` y `core/auth.service.ts` |
| `usuariosCompras.html` + `scriptusuariosCompras.js` + `estilosIndex.css` | `src/app/pages/catalog/`, `core/product.service.ts`, `core/cart.service.ts` y `core/checkout.service.ts` |
| `carrito.html` + `scriptCarrito.js` + `estilosCarrito.css` | `src/app/pages/cart/`, `src/app/shared/receipt/` y servicios de carrito/apartado |
| `scriptTema.js` + `estilosTema.css` | `src/app/core/theme.service.ts`, `src/app/app.ts` y `src/styles.css` |
| Conexión con PHP | `src/app/core/api.service.ts` y `proxy.conf.json` |
| Código del backend y conexión con MySQL | `../backend-cliente/public/php/` |
| Configuración Firebase, imágenes y administrador | `src/environments/environment.ts` |

Cada página tiene su plantilla `.html`, lógica `.ts` y estilos `.css`. Ya no se ejecutan los scripts originales ni se construyen tarjetas mediante `innerHTML`.

Las rutas son `/login`, `/registro`, `/catalogo` y `/carrito`. Las direcciones antiguas terminadas en `.html` redirigen a sus equivalentes Angular.

## Configuración de MAMP y Firebase

- **MySQL:** `../backend-cliente/public/php/conexion.php` conserva los valores originales y permite sobrescribirlos con `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` y `DB_PORT`. Esas variables son del servidor; nunca se colocan en `environment.ts`. El archivo contiene tu configuración original: no lo publiques con credenciales reales.
- **Backend separado:** el proxy predeterminado transforma `/api/...` en `http://127.0.0.1:8000/php/...`.
- **PHP ya instalado en MAMP:** puedes usar `npm run start:mamp`. Angular consultará `http://localhost:8888/cliente/php/...`, por lo que se ejecuta la copia de PHP que exista allí, no la de `backend-cliente`. Ajusta `proxy.mamp.conf.json` si tu puerto o carpeta son diferentes.
- **Firebase:** se conservó la configuración del proyecto del ZIP con el SDK modular. Verifica en Firebase Authentication que el proveedor correo/contraseña y el dominio local que utilices estén habilitados. No se modificó tu consola de Firebase.
- **Imágenes y fuentes:** se conservaron las URLs remotas originales. Las imágenes relativas de MySQL se resuelven contra `assetBaseUrl`, cuyo valor inicial es `http://localhost:8888/cliente/`. Necesitan que los recursos originales sigan disponibles.

El almacenamiento del navegador depende del origen. El carrito y la sesión de `localhost:8888` no se transfieren automáticamente a `127.0.0.1:4200`. La estructura y claves originales se conservan para facilitar una migración bajo el mismo origen.

## Comprobar y compilar

```bash
npm run test:ci
npm run build
```

La compilación genera `dist/cliente-angular/browser/`. No abras los `.html` directamente con Finder ni uses Live Server: usa el servidor de Angular. Para publicar posteriormente, el servidor web tendrá que atender las rutas de Angular y mantener PHP/MySQL del lado servidor; el proxy de desarrollo no se incluye en el build.

Se dejó desactivada la caché persistente de Angular y se configuró el seguimiento de cambios por sondeo porque la caché nativa y los observadores de archivos fallaban en este entorno de macOS. Los comandos anteriores funcionan con esta configuración.

Consulta [MIGRACION.md](MIGRACION.md) para ver las pruebas realizadas y las dependencias ausentes del ZIP. La compatibilidad de Node se basa en la [tabla oficial de Angular](https://angular.dev/reference/versions).

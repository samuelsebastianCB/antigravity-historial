import { existsSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { resolve } from 'node:path';

const frontendRoot = fileURLToPath(new URL('..', import.meta.url));
const backendRoot = resolve(frontendRoot, process.env.BACKEND_DIR || '../backend-cliente');
const server = resolve(backendRoot, 'server.mjs');

if (!existsSync(server)) {
  console.error(`No se encontró el backend en ${backendRoot}. Coloca backend-cliente junto a cliente-angular o define BACKEND_DIR con su ubicación.`);
  process.exit(1);
}

// Ejecuta el arranque externo en este proceso para conservar la gestión de Ctrl+C.
await import(pathToFileURL(server).href);
